package javaparser;

import tide.editor.MainEditorFrame;
import snow.utils.StringUtils;
import tide.utils.SyntaxUtils;
import java.util.*;
import javaparser.javacc_gen.*;

public class MethodNode extends ParserTreeNode implements NodeWithMod, HighlightableNode
{


  // true if the Override annotation is present.
  // makes sense to record because retention is source => no more present in the class
  // so our internal analysis must use the javaCC parsed Override info.
  public boolean override_ = false;
  public boolean implements_ = false;

  // true if present   @edu.umd.cs.findbugs.annotations.OverrideMustInvoke  or any same name annot.
  public boolean overrideMustInvoke = false;
  public boolean hasRecurseAnnotation = false;
  public boolean hasJUnitTest = false;

  public int[] modifiers;
  public String resultType = "";  // ex: "void"
  public String name = "";
  String paramsS = "";
  public String modifiersShort = "";
  String typeParameters = null;
  // (int a, double b)
  public final List<Parameter> params;

  //note: abstract methods may have null block !
  public Token blokStart, blokEnd;

  public MethodNode(RAWParserTreeNode methodDeclarationNode, RAWParserTreeNode modNode)
  {
     super("method");

     this.sortPriority = 1;

     this.modifiers = CCTreeUtils.getAllModifiers(modNode);
     this.override_  = CCTreeUtils.methodOverrides(modNode);
     this.implements_  = CCTreeUtils.methodImplementsAnn(modNode);

     if(this.implements_)
     {
        String arg = CCTreeUtils.methodImplementsAnnParam(modNode);
        System.out.println("@Impl ARG="+arg);
     }

     this.overrideMustInvoke  = CCTreeUtils.hasOverrideMustInvokeAnnotation(modNode);
     this.hasRecurseAnnotation = CCTreeUtils.hasRecurseAnnotation(modNode);
     hasJUnitTest = CCTreeUtils.hasJUnitTestAnnotation(modNode);

     modifiersShort = Utils.getModifiersShortString(this.modifiers);

     if(modNode.getChildCount()>0)
     {
       this.setStartPosFrom( CCTreeUtils.getFirstSubchild(modNode) );
     }
     else
     {
       this.setStartPosFrom( CCTreeUtils.getFirstSubchild(methodDeclarationNode) );
     }
     this.setEndPosFrom( CCTreeUtils.getLastSubchild(methodDeclarationNode) );

     RAWParserTreeNode tp = CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(methodDeclarationNode, "TypeParameters");
     if(tp!=null)
     {
        typeParameters = CCTreeUtils.getImageOfAllSubElements( tp );
     }

     // childs: {ResultType, VariableDeclarator}
     RAWParserTreeNode tn = CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(methodDeclarationNode, "ResultType");
      //methodDeclarationNode.getChildNodeAt(0); //no, sometime ParameterTypes
     //ParserTreeNode vdn = fieldDeclarationNode.getChildNodeAt(1);    // a=1
     //ParserTreeNode vdidn = vdn.getChildNodeAt(0); // VariableDeclaratorId
     this.resultType = CCTreeUtils.getImageOfAllSubElements( tn );


     RAWParserTreeNode md = CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(methodDeclarationNode, "MethodDeclarator");
     this.name =  md.getChildNodeAt(0).toString();

     RAWParserTreeNode block = CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(methodDeclarationNode, "Block");
     if(block!=null && block.getChildCount()>1)
     {
        for(int i=0; i<block.getChildCount(); i++)
        {
           RAWParserTreeNode ci = block.getChildNodeAt(i);
           if(ci.getTokenKind()==JavaParserConstants.LBRACE)
           {
              blokStart = ci.t;
           }
           else if(ci.getTokenKind()==JavaParserConstants.RBRACE)
           {
              blokEnd   = ci.t;
           }
        }
     }

     RAWParserTreeNode fp = CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(md, "FormalParameters");
     this.params = CCTreeUtils.getParameters( fp );
     this.paramsS = StringUtils.concatenate(this.params, ", "); // Utils.toStringWithoutBraces(this.params);

  } // Constructor


  public final int[] getModifiers() { return modifiers; }
  public final boolean isStatic() { return Utils.isStatic( modifiers); }
  public final boolean isPublic() { return Utils.isPublic( modifiers); }
  public final boolean isPrivate() { return Utils.isPrivate( modifiers); }
  public final boolean isProtected() { return Utils.isProtected( modifiers); }


  public boolean isPublicStaticMainMethod()
  {
     if(!isPublic()) return false;
     if(!isStatic()) return false;

     if(!"main".equals(name)) return false;
     if(!"void".equals(resultType)) return false;

     // ensure one single param: a string array!
     if(paramsS.contains(",")) return false;
     if(!paramsS.contains("String")) return false;
     if(!paramsS.contains("[")) return false;   // [Oct2008]: allow array part everywhere. (String a[   ]) or String[] a

     return true;
  }

  /** must be public, non static and marked with @ Test or @ org.junit.Test
  */
  public boolean hasJUnitTest()
  {
     if(!isPublic()) return false;
     if(isStatic()) return false;

     return hasJUnitTest;
  }

  /** Call this to help GC !
  */
@Override
  public void terminate()
  {
     super.terminate();

     if(params!=null) params.clear();
     blokStart = null;
     blokEnd   = null;
     modifiers = null;
     modifiersShort = null;
     name    = null;
     resultType = null;
     paramsS = null;
  }


  /** [Dec2007]: removed "returns", just appending the return type.
  *  Used as syntax tree text
  */
  @Override
  public String toString()
  {
     if(name==null) return "######";
     if("void".equals(resultType)) return name+"("+paramsS+")"+(typeParameters!=null?" "+typeParameters:"");
     return name+"("+paramsS+")"+(typeParameters!=null?" "+typeParameters:"")+" " + resultType;
  }

  public String toStringForStub()
  {
     if(name==null) return "######";
     return (isStatic() ? "static ":"")+ resultType +" " + name+"("+paramsS+")";
  }

  /** name + % + nargs. */
   public String getSignatureSimplified1()
   {
      return name+"%"+params.size();
   }

  /** Name and simple arg names (without generics).
      ex: "add(Vector,int)".
      Used in static analysis.
      Caution: not sufficient for the purpose of dependencies study ! (missing return type and generics !)
  */
   public String getSignatureSimplified2()
   {
      if(params.isEmpty()) return name+"()";

      StringBuilder sb = new StringBuilder(30);
      sb.append(name);
      sb.append("(");
      for(final Parameter pi : params)
      {
         sb.append(SyntaxUtils.removeSingleTypeParameters(pi.type));  //  Vector<String> => Vector
         sb.append(",");
      }
      sb.setLength(sb.length()-1);  // remove last ","   // quick.
      sb.append(")");

      return sb.toString();
   }

  /**
      ex: "[modifiers list as ParserConstants...] void <T> myMethod(Vector<String>,int,T)".
      Used in static analysis.
      Is sufficient for the purpose of dependencies study.
  */
   public String getDetailledSignatureForDepDet()
   {
      StringBuilder sb = new StringBuilder();
      sb.append(Arrays.toString(modifiers));
      sb.append(" ");
      sb.append(this.resultType);
      sb.append(" ");
      if(typeParameters!=null)
      {
         sb.append(typeParameters);
         sb.append(" ");
      }
      sb.append(name);
      sb.append("(");

      boolean first = true;
      for(final Parameter pi : params)
      {
         if(!first) sb.append(",");
         sb.append(pi.type);  //  Vector<String>
         first = false;
      }
      sb.append(")");
      return sb.toString();
   }


   // HighlightableNode
   //

    private /*@checkers.nullness.quals.LazyNonNull*/  String fullJavaID = null;
    public String getFullJavaID()
    {
       if(fullJavaID!=null) return fullJavaID;  // ok because immutable
       fullJavaID = NodeUtils.getFullJavaID(this);
       return fullJavaID;
    }

    public void setHighlighted(boolean is)
    {
       MainEditorFrame.getActualProject().setSyntaxTreeNodeHighlighted(getFullJavaID(), is);
    }

    public boolean isHighlighted()
    {
       return MainEditorFrame.getActualProject().isSyntaxTreeNodeHighlighted(getFullJavaID());
    }


}