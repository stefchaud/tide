package javaparser;

import java.util.concurrent.ArrayBlockingQueue;
import javaparser.javacc_gen.Token;
import java.util.*;

/** Reuse last milion nodes...
*   Quicker ? yes.
*   Less mem ? yes, we see mem errors otherwise
*/
public final class RAWParserTreeNodeFactory
{
   private final static boolean deactivated = false;
   private final Deque<RAWParserTreeNode> freedNodes = new ArrayDeque<RAWParserTreeNode>();

   //private int maxSize = 1000000;   // 1 000 000   (approx 30MB)

   // stats
   private long reused = 0;
   private long created = 0;

   // singleton  (20% quicker)

   private static class SingletonHolder {
      private static final RAWParserTreeNodeFactory instance = new RAWParserTreeNodeFactory();
   }

   public static RAWParserTreeNodeFactory getInstance() {
      return SingletonHolder.instance;
   }

   private RAWParserTreeNodeFactory()
   {
   }


   // API

   public void liberateResources()
   {
      freedNodes.clear();
   }

   synchronized RAWParserTreeNode create(Token t)
   {
      if(deactivated) return new RAWParserTreeNode(t);

      if(freedNodes.size()>0)
      {
         RAWParserTreeNode nn = freedNodes.remove();
         reused++;
         nn.t = t;
         return nn;
      }
      created++;
      return new RAWParserTreeNode(t);
   }

   public synchronized RAWParserTreeNode create(String t)
   {
      if(deactivated) return new RAWParserTreeNode(t);

      if(freedNodes.size()>0)
      {
         RAWParserTreeNode nn = freedNodes.remove();
         reused++;
         nn.name = t;
         return nn;
      }
      created++;
      return new RAWParserTreeNode(t);
   }

   public synchronized void addFreed(RAWParserTreeNode rp)
   {
      if(deactivated) return;

      freedNodes.add(rp);
   }

   public static void terminateRecurse(RAWParserTreeNode root)
   {
      if(root==null) return;

      for(RAWParserTreeNode ci : root.childs)
      {
         terminateRecurse(ci);
      }
      root.terminateAndOfferReuse();
   }

   @Override public final String toString()
   {
      return "RAWParserTreeNodeFactory: "+freedNodes.size()+" free, "+reused+" already reused, "+created+" created";
   }

}