package javaparser;

import tide.editor.UIConstants;


/** Parser error.
*/
public final class ErrorNode extends MainNode
{
  final String message;

  public ErrorNode(String message)
  {
     super("", "E", UIConstants.red, true);
     this.message = message;
     this.expandInView = true;

     int line = 0;
     int pos = message.indexOf("line ");
     if(pos>0)
     {
       int posE = message.indexOf(',', pos+5);
       if(posE>0)
       {
         String ls = message.substring(pos+5, posE);
         //System.out.println("Error node: ls="+ls);
         try
         {
            line = Integer.parseInt(ls);
         } catch(Exception ee) { }
       }
     }

     int column = 0;
     pos = message.indexOf("column ", pos);
     if(pos>0)
     {
       int posE = message.indexOf('.', pos+7);
       if(posE>0)
       {
         String ls = message.substring(pos+7, posE);
         try
         {
            column = Integer.parseInt(ls);
         } catch(Exception ee) { }
       }
     }

     setStart(line, column);
     setEnd(line, column+1);

  }

  @Override
  public String toString()
  {
    return message;
  }



}