package javaparser;

public final class AnnotationMemberNode  extends ParserTreeNode
{
   String type;
   String name;

   public AnnotationMemberNode(RAWParserTreeNode annotationTypeMemberDeclaration)
   {
      super("annotationMember");
      this.setStartPosFrom( CCTreeUtils.getFirstSubchild(annotationTypeMemberDeclaration) );
      this.setEndPosFrom( CCTreeUtils.getLastSubchild(annotationTypeMemberDeclaration) );
       // modifiers, type, name, (, ), ;
      if(annotationTypeMemberDeclaration.getChildCount()>1)
      {
        type = CCTreeUtils.getImageOfAllSubElements( annotationTypeMemberDeclaration.getChildNodeAt(1));
      }
      if(annotationTypeMemberDeclaration.getChildCount()>2)
      {
        name = CCTreeUtils.getImageOfAllSubElements( annotationTypeMemberDeclaration.getChildNodeAt(2));
      }
      // args ???
   }

   @Override
   public String toString()
   {
      return type+" "+name+"()";
   }

  /** Call this to help GC !
  */
@Override
  public void terminate()
  {
    super.terminate();

    name = null;
    type = null;
  }
}