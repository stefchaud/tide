package javaparser;

import snow.utils.StringUtils;
import snow.utils.ArrayUtils;
import javaparser.javacc_gen.JavaParserConstants;
import javaparser.javacc_gen.Token;
import java.util.*;

/** Some utils.
*/
public final class CCTreeUtils
{
   private CCTreeUtils()
   {
   }

  /** Depth first.  used
  */
  static void collectChilds(RAWParserTreeNode tn, List<Token> tokens)
  {
     if(tn.t != null)
     {
       tokens.add( tn.t );
       return ;  // a token is terminal
     }

     for(RAWParserTreeNode ci : tn.childs)
     {
       collectChilds(ci, tokens);
     }
  }

  /** used for extends, implements, ...
  */
  public static List<String> collectIdentifiers(RAWParserTreeNode node, String name)
  {
     List<String> ids = new ArrayList<String>();
     for(RAWParserTreeNode ci : node.childs)
     {
        if(ci.toString().equals(name))
        {
           ids.add( getImageOfAllSubElements(ci) );
        }
     }
     return ids;
  }

  /** Depth first.
  */
  public static Token getFirstSubchild(RAWParserTreeNode tn)
  {
     if(tn.t != null)   // first at first level = first
     {
       return tn.t;
     }

     for(RAWParserTreeNode ci : tn.childs)
     {
       Token t = getFirstSubchild(ci);
       if(t!=null) return t;
     }
     // none found
     return null;
  }

  /** depth first.  used
  */
  @tide.annotations.Recurse
  public static Token getLastSubchild(RAWParserTreeNode tn)
  {
     if(tn.t != null)      // last at first level = last
     {
       return tn.t;
     }

     for(int i=tn.childs.size()-1; i>=0; i--)    // reverse search
     {
       RAWParserTreeNode ci = tn.childs.get(i);
       Token t = getLastSubchild(ci);
       if(t!=null) return t;
     }
     // none found
     return null;
  }

  /** if any mod found, a space after is present
      Annotations are ignored
  */
  public static String getModifiers(RAWParserTreeNode mods)
  {
     if(mods==null) return "<ERR: no modifiers>";   // ERROR
     if(mods.getChildCount()==0) return "";
     StringBuilder mod = new StringBuilder();
     for(RAWParserTreeNode ci : mods.childs)
     {
        if(!ci.toString().equals("Annotation"))
        {
          mod.append(ci);
          mod.append(" ");
        }
     }
     return mod.toString();
  }

  public static boolean methodOverrides(RAWParserTreeNode mods)
  {
     if(mods==null) return false; //error
     for(RAWParserTreeNode ci : mods.childs)
     {
        String st = getImageOfAllSubElements(ci);
        //System.out.println("Method mod: "+ci);
        // avoid collisions with OverrideMustInvoke
        if(st.endsWith("@Override")) return true;
        if(st.endsWith(".Override")) return true;  // @java.lang.Override
     }
     return false;
  }

  /** Hint: if present (true), use methodImplementsAnnParam to fetch the optional value...
  */
  public static boolean methodImplementsAnn(RAWParserTreeNode mods)
  {
     if(mods==null) return false; //error
     for(RAWParserTreeNode ci : mods.childs)
     {
        String st = getImageOfAllSubElements(ci);
        //System.out.println("Method mod: "+ci);
        if(st.contains("@Implements")) return true;
        if(st.contains(".Implements")) return true;
     }
     return false;
  }

  /** null if not found.
  *  Lazy method, just looking for any annotation with the simple name "Implements"
  */
  public static String methodImplementsAnnParam(RAWParserTreeNode mods)
  {
     if(mods==null) return null; //error
     for(RAWParserTreeNode ci : mods.childs)
     {
        String st = getImageOfAllSubElements(ci);
        //System.out.println("Method mod: "+ci);
        int pos = st.indexOf("@Implements(");
        if(pos<0) pos = st.indexOf(".Implements("); // same length 12
        if(pos>0)
        {
           return StringUtils.extractFromFirstToNext_Excluded(st.substring(pos+10),"(",")");
        }
     }
     return null;
  }

  /** Lazy method, just looking for any annotation with the simple name "OverrideMustInvoke"
  */
  public static boolean hasOverrideMustInvokeAnnotation(RAWParserTreeNode mods)
  {
     if(mods==null) return false; //error
     for(RAWParserTreeNode ci : mods.childs)
     {
        String st = getImageOfAllSubElements(ci);
        //System.out.println("Method mod: "+ci);
        if(st.contains("@OverrideMustInvoke")) return true;
        if(st.contains(".OverrideMustInvoke")) return true;
     }
     return false;
  }

  /** Lazy method, just looking for any annotation with the simple name "Test" or "org.junit.Test"
  */
  public static boolean hasJUnitTestAnnotation(RAWParserTreeNode mods)
  {
     if(mods==null) return false; //error
     for(RAWParserTreeNode ci : mods.childs)
     {
        String st = getImageOfAllSubElements(ci);
        //System.out.println("Method mod: "+ci);
        if(st.contains("@"+"Test")) return true;
        if(st.contains("@"+"org.junit.Test")) return true;
     }
     return false;
  }

  /** Lazy method, just looking for any annotation with the simple name "Recurse"
  */
  public static boolean hasRecurseAnnotation(RAWParserTreeNode mods)
  {
     if(mods==null) return false; //error
     for(RAWParserTreeNode ci : mods.childs)
     {
        String st = getImageOfAllSubElements(ci);
        //System.out.println("Method mod: "+ci);
        if(st.contains("@Recurse")) return true;
        if(st.contains(".Recurse")) return true;
     }
     return false;
  }


  /** @return a list of all modifiers according to the JavaParserConstants.
      -1 for unknown !
      use ArrayUtils.contains()
  */
  public static int[] getAllModifiers(final RAWParserTreeNode mods)
  {
     if(mods==null) return null; //error
     List<Integer> modsv = new ArrayList<Integer>();
     for(RAWParserTreeNode ci : mods.childs)
     {
        switch(ci.getTokenKind())
        {
          case -1: break;
          case JavaParserConstants.PUBLIC    : modsv.add(ci.getTokenKind()); break;
          case JavaParserConstants.PRIVATE   : modsv.add(ci.getTokenKind()); break;
          case JavaParserConstants.PROTECTED : modsv.add(ci.getTokenKind()); break;
          case JavaParserConstants.FINAL     : modsv.add(ci.getTokenKind()); break;
          case JavaParserConstants.STATIC    : modsv.add(ci.getTokenKind()); break;
          case JavaParserConstants.ABSTRACT  : modsv.add(ci.getTokenKind()); break;
          case JavaParserConstants.STRICTFP  : modsv.add(ci.getTokenKind()); break;
          case JavaParserConstants.SYNCHRONIZED : modsv.add(ci.getTokenKind()); break;
          case JavaParserConstants.NATIVE    : modsv.add(ci.getTokenKind()); break;
          case JavaParserConstants.TRANSIENT : modsv.add(ci.getTokenKind()); break;
          case JavaParserConstants.VOLATILE  : modsv.add(ci.getTokenKind()); break;
          default: modsv.add(-1); break;
        }
     }
     return ArrayUtils.toIntArray(modsv);
  }

  /** Recurse in all subtrees.
  */
  public static void getAllChildsNamed(RAWParserTreeNode node, String name, List<RAWParserTreeNode> found)
  {
     for(RAWParserTreeNode ci : node.childs)
     {
       if(ci.toString().equals(name))
       {
          found.add(ci);
       }

       // recurse
       getAllChildsNamed(ci, name, found);
     }
  }

  /** null if none
  */
  public static /*@org.checkerframework.checker.nullness.qual.Nullable*/ RAWParserTreeNode getFirstSubchildNamed_ONLYInDirectChilds(RAWParserTreeNode tn, String name)
  {
     for(RAWParserTreeNode ci : tn.childs)
     {
       if(ci.toString().equals(name)) return ci;
     }
     // none found
     return null;
  }

  /** null if none, null if tn is null
  */
  public static /*@org.checkerframework.checker.nullness.qual.Nullable*/ Token getFirstToken_ONLYInDirectChilds(RAWParserTreeNode tn, int kind)
  {
     if(tn==null) return null;
     for(RAWParserTreeNode ci : tn.childs)
     {
       if(ci.t !=null && ci.t.kind == kind) return ci.t;
     }
     // none found
     return null;
  }

  /** Collects the paramters.
  */
  public static List<Parameter> getParameters(RAWParserTreeNode formalParametersNode)
  {
    List<Parameter> params = new ArrayList<Parameter>();
    for(RAWParserTreeNode ci : formalParametersNode.childs)
    {
      if(ci.toString().equals("FormalParameter"))
      {
         params.add( Parameter.parseFromFormalParamNode(ci) );
      }
    }
    return params;
  }

  public static String getImageOfAllSubElements(RAWParserTreeNode tn)
  {
     ArrayList<Token> tokens = new ArrayList<Token>();

     collectChilds(tn, tokens);
     StringBuilder sb = new StringBuilder();
     for(int i=0; i<tokens.size(); i++)
     {
        //if(i>0) sb.append(" ");
        sb.append(tokens.get(i).image);

     }
     return sb.toString();
  }

}