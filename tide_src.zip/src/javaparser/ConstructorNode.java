package javaparser;

import tide.editor.MainEditorFrame;
import snow.utils.StringUtils;
import java.util.*;
import javaparser.javacc_gen.*;

public class ConstructorNode extends ParserTreeNode implements NodeWithMod, HighlightableNode
{
  public int[] modifiers;
  public String modifiersShort;
  public String name = "";
  String paramsS = "";            // ex:  "int a, String[] b"
  String typeParameters = null;   // ex: <T>
  public final List<Parameter> params;

  public Token blokStart, blokEnd;

  public ConstructorNode(RAWParserTreeNode constructorDeclarationNode, RAWParserTreeNode modNode)
  {
     super("constructor");

     this.sortPriority = 2;

     this.modifiers = CCTreeUtils.getAllModifiers(modNode);
     modifiersShort = Utils.getModifiersShortString(this.modifiers);

     if(modNode.getChildCount()>0)
     {
       this.setStartPosFrom( CCTreeUtils.getFirstSubchild(modNode) );
     }
     else
     {
       this.setStartPosFrom( CCTreeUtils.getFirstSubchild(constructorDeclarationNode) );
     }
     this.setEndPosFrom( CCTreeUtils.getLastSubchild(constructorDeclarationNode) );

     // childs: {Name, FormalParameters, {, }}  [Nov2007]
     //  OR // childs: {TypeParameters, Name, FormalParameters, {, }}
     RAWParserTreeNode nameNode = constructorDeclarationNode.childs.get(0);
     if(nameNode.getTokenKind()==JavaParserConstants.IDENTIFIER) //76
     {
        this.name =  nameNode.toString();
     }
     else
     {
        nameNode = constructorDeclarationNode.childs.get(1);
        this.name =  nameNode.toString();

        typeParameters = CCTreeUtils.getImageOfAllSubElements(constructorDeclarationNode.childs.get(0));
     }

     // TODO: name maybe preceeded by TypeParameters


     // not the same as for methods. Here we have no block node but { and } are directly in the constructorDeclarationNode
     for(int i=1; i<constructorDeclarationNode.getChildCount(); i++)
     {
        RAWParserTreeNode ci = constructorDeclarationNode.getChildNodeAt(i);
        if(ci.getTokenKind()==JavaParserConstants.LBRACE)
        {
           blokStart = ci.t;
        }
        else if(ci.getTokenKind()==JavaParserConstants.RBRACE)
        {
           blokEnd = ci.t;
        }
     }

     RAWParserTreeNode fp = CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(constructorDeclarationNode, "FormalParameters");
     this.params = CCTreeUtils.getParameters(fp);
     this.paramsS = StringUtils.concatenate(params, ", ");

  } // Constructor

  /** Call this to help GC !
  */
@Override
  public void terminate()
  {
    super.terminate();

    if(params!=null) params.clear();

    modifiersShort = null;
    modifiers = null;
    blokEnd = null;
    blokStart = null;
    name = null;
    paramsS = null;
  }

  @Override
  public String toString()
  {
    return name+"("+paramsS+")"+(typeParameters!=null ? " "+typeParameters:"");
  }

  public String toStringForStub()
  {
     if(name==null) return "######";
     return name+"("+paramsS+")";
  }

  public final int[] getModifiers() { return modifiers; }
  public boolean isStatic() { return false; }  // never
  public boolean isPublic() { return Utils.isPublic( modifiers); }
  public boolean isPrivate() { return Utils.isPrivate( modifiers); }
  public boolean isProtected() { return Utils.isProtected( modifiers); }


  /**
      ex: "[modifiers list as ParserConstants...] <T> MyClass(Vector<String>,int,T)".
      Used in static analysis.
      Is sufficient for the purpose of dependencies study.
  */
   public String getDetailledSignatureForDepDet()
   {
      StringBuilder sb = new StringBuilder();
      sb.append(Arrays.toString(modifiers));
      sb.append(" ");
      if(typeParameters!=null)
      {
         sb.append(typeParameters);
         sb.append(" ");
      }
      sb.append(name);
      sb.append("(");

      boolean first = true;
      for(final Parameter pi : params)
      {
         if(!first) sb.append(",");
         sb.append(pi.type);  //  Vector<String>
         first = false;
      }
      sb.append(")");
      return sb.toString();
   }

   // HighlightableNode
   //

    private /*@checkers.nullness.quals.LazyNonNull*/  String fullJavaID = null;
    public String getFullJavaID()
    {
       if(fullJavaID!=null) return fullJavaID;  // ok because immutable
       fullJavaID = NodeUtils.getFullJavaID(this);
       return fullJavaID;
    }

    public void setHighlighted(boolean is)
    {
       MainEditorFrame.getActualProject().setSyntaxTreeNodeHighlighted(getFullJavaID(), is);
    }

    public boolean isHighlighted()
    {
       return MainEditorFrame.getActualProject().isSyntaxTreeNodeHighlighted(getFullJavaID());
    }

}