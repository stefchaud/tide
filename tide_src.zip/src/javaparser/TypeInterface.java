package javaparser;

/** Parent for types and anonymous classes, used in completion for "this.".
*   Used by: AnonymousType
*/
public interface TypeInterface
{
  // as declared in the source.
  String getTypeSimpleName();
}