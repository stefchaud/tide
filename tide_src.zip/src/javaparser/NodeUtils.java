package javaparser;

/** class NodeUtils.
*/
public final class NodeUtils
{
   private NodeUtils()
   {
   }


   /** For class, method and field
   */
   public static String getFullJavaID( ParserTreeNode tn)
   {
         StringBuilder sb = new StringBuilder();
         sb.append(getNamePartForJavaID(tn));  // tostring()

         ParserTreeNode par = tn.getParentNode();
         int lev=0;
         while(par!=null)
         {
            sb.insert(0, getNamePartForJavaID(par)+"#");  // tostring()

            if(par == tn.getParentNode())
            {
               // the top of each class hit this!!
               //todo: fix
               //System.out.println("ERROR: parent is itself for "+par+" ("+par.getClass()+")");
               //new Throwable().printStackTrace(System.out);
               break;
            }

            par = tn.getParentNode();
            lev++;
            if(lev>10) break; // security
         }

         //System.out.println("FullName for highlight "+sb);

         return sb.toString();
   }


   static String getNamePartForJavaID(ParserTreeNode n)
   {
      if(n instanceof ClassNode)
      {
         return ((ClassNode) n).getJavaFullName();
      }
      else if(n instanceof FieldNode)
      {
         return ((FieldNode) n).name;
      }
      else if(n instanceof MethodNode)
      {
         return ((MethodNode) n).getSignatureSimplified2();
      }
      else if(n instanceof ConstructorNode)
      {
         return ((ConstructorNode) n).getDetailledSignatureForDepDet();  // ??
      }
      else
      {
         return "??"+n;
      }
   }

}