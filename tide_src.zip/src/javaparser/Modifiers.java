package javaparser;

public enum Modifiers
{
  PUBLIC(1), PRIVATE(2);

  Modifiers(int a)
  {
  }

  public static Modifiers getMod()
  {
    return null;
  }

}
