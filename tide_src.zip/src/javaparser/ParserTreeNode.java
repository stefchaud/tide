package javaparser;

import javaparser.javacc_gen.Token;
import javax.swing.tree.*;

/** Used to build the syntax tree over the tokens directly from the parser in the ParserOutputProcessor.
*<br>
*  Also used for the simplified tree (syntax tree displayed to the user)
* ( often several 10MB in memory)
*
*/
public class ParserTreeNode extends DefaultMutableTreeNode
    implements Comparable<ParserTreeNode>  // used to sort in the view
{

  public boolean expandInView = false;

  public boolean isRawTreeRoot = false;

  // if non null, this is used as string representation
  // for example the tree simplifier replace TypeDeclaration nodes with "public class XXX"
  String simplifiedDescription = null;

  // if positive, defines the start line and column of this class definition
  // set when simplifying the tree
  private int startCol = -1, startLine = -1;
  private int endCol   = -1, endLine   = -1;

  public void setStartPosFrom( Token t)
  {
     startLine = t.beginLine;
     startCol = t.beginColumn;
  }

  public void setPositionFrom(ParserTreeNode tn)
  {
     startLine = tn.startLine;
     startCol = tn.startCol;

     endLine = tn.endLine;
     endCol = tn.endCol;
  }

  public void setEndPosFrom( Token t)
  {
     endLine = t.endLine;
     endCol = t.endColumn;
  }

  public void setStart(int line, int col)
  {
     startCol = col;
     startLine = line;
  }

  public void setEnd(int line, int col)
  {
     endCol = col;
     endLine = line;
  }

  /** Used in the parse fro errors when one create new warning nodes and
   wants that they have the same start and end as some target
  */
  public void takeBoundsFrom(ParserTreeNode n)
  {
    this.startCol = n.startCol;
    this.startLine = n.startLine;
    this.endCol = n.endCol;
    this.endLine = n.endLine;
  }

  /**
  *   field 0,
  *   method 1,
  *   constructor 2
  *
  *   enum 3
  *   class 4
  *   annotation 5  (type def)
  *   static init 6
  */
  protected int sortPriority = 0;


  public static volatile int created = 0;
  public static volatile int terminated = 0;

  /** Used for compound nodes (non leafs) and parsed simplified ones.
  *   May contain a list of tokens.
  */
  public ParserTreeNode(String name)
  {
    super(name);
    created++;
  }

  /** Contains a single terminal non null token (leaf)
     (is only called during the raw tree construction).
  */
  public ParserTreeNode(Token t)
  {
    super(t);
    created++;
  }

  public ParserTreeNode getChildNodeAt(int i)
  {
    return (ParserTreeNode) super.getChildAt(i);
  }

  /** Caution: [Oct2010]
  */
  public ParserTreeNode getParentNode()
  {
    /* if(this.getParent() == this)
     {
        System.out.println("CAUTION: parent is itself for "+this);
        new Throwable().printStackTrace(System.out);
     }*/
    return (ParserTreeNode) this.getParent();
  }

  @Override
  public void setParent(MutableTreeNode newParent) {
     if(newParent==this)
     {
        System.out.println("CAUTION: parent is itself for "+this);
        new Throwable().printStackTrace(System.out);
     }
     super.setParent(newParent);
  }

  public boolean isToken() { return (this.getUserObject() instanceof Token); }

  /** null if none
  */
  public /*@org.checkerframework.checker.nullness.qual.Nullable*/ Token getToken() { return (Token) this.getUserObject(); }

  /** -1 if not a token
  */
  public int getTokenKind()
  {
    if(!isToken()) return -1;
    return getToken().kind;
  }

  /** Used in the tree as text representation
  */
  @Override
  public String toString()
  {
     if(simplifiedDescription!=null)
     {
       return simplifiedDescription;
     }

     return super.toString();
  }

  public final int compareTo(ParserTreeNode n2)
  {
     // [March2008]: first try to use the modifiers, first {public, package scope, protected, private}

     if(this instanceof NodeWithMod && n2 instanceof NodeWithMod)
     {
        NodeWithMod nm1 = (NodeWithMod) this;
        NodeWithMod nm2 = (NodeWithMod) n2;
        int cmp = Utils.compareModifiers( nm1.getModifiers(), nm2.getModifiers());
        if(cmp!=0) return cmp;
     }

     // first class then method then field, ...
     if(sortPriority>n2.sortPriority) return  1;
     if(sortPriority<n2.sortPriority) return -1;

     // alphabetic.
     return n2.toString().compareTo(this.toString());
  }

  public int[] getStartLinCol()
  {
     int[] lc = new int[] {-1, -1};
     if(this.startLine>0)
     {
        lc[0] = this.startLine;
        lc[1] = this.startCol;
     }
     else if(this.isToken())
     {
        lc[0] = this.getToken().beginLine;
        lc[1] = this.getToken().beginColumn;
     }
     else
     {
        // first subchild
        Token t = Utils.getFirstSubchild(this);
        if(t!=null)
        {
           lc[0] = t.beginLine;
           lc[1] = t.beginColumn;
        }
     }
     return lc;
  }

  public int[] getEndLinCol()
  {
     int[] lc = new int[] {-1, -1};
     if(this.endLine>0)
     {
        lc[0] = this.endLine;
        lc[1] = this.endCol;
     }
     else if(this.isToken())
     {
        lc[0] = this.getToken().endLine;
        lc[1] = this.getToken().endColumn;
     }
     else
     {
        // last subchild
        Token t = Utils.getLastSubchild(this);
        if(t!=null)
        {
           lc[0] = t.endLine;
           lc[1] = t.endColumn;
        }
     }
     return lc;
  }

  public boolean isterminated = false;

  /** Call this to help the GC !
  *  Removes itself from parent. (IMPORTANT).
  *  Overriders MUST call super.terminate()!
  */
  public void terminate()
  {
     if(isterminated)
     {
      // new Throwable().printStackTrace();
       return;
     }
     isterminated = true;

     terminated++;
/*
    if(terminated % 100000 ==0)
    {
       new Throwable().printStackTrace();
    }*/


     removeFromParent();

     setParent(null);
     setUserObject(null);  //DEBUG
     simplifiedDescription = null;
  }

}