package javaparser;

import tide.editor.MainEditorFrame;
import java.util.Arrays;

public class FieldNode extends ParserTreeNode implements NodeWithMod, HighlightableNode
{
  public int[] modifiers;
  public String modifiersShort;
  public String type = "";
  public String name = "";   //


  /** May add several FieldNodes if several fields declared on the same statement
      i.e.  public final int a,b,c=3, d;
  */
  public FieldNode(RAWParserTreeNode fieldDeclarationNode, RAWParserTreeNode modNode, ParserTreeNode destination)
  {
    super("field");
    this.sortPriority = 0;

    this.modifiers = CCTreeUtils.getAllModifiers(modNode);
    this.modifiersShort = Utils.getModifiersShortString(this.modifiers);

    if(modNode.getChildCount()>0)
    {
      this.setStartPosFrom( CCTreeUtils.getFirstSubchild(modNode) );
    }
    else
    {
      this.setStartPosFrom( CCTreeUtils.getFirstSubchild(fieldDeclarationNode) );
    }
    this.setEndPosFrom( CCTreeUtils.getLastSubchild(fieldDeclarationNode) );

    // childs: {Type, VariableDeclarator [,VariableDeclarator]* }
    RAWParserTreeNode tn = fieldDeclarationNode.getChildNodeAt(0);
    this.type = CCTreeUtils.getImageOfAllSubElements( tn );

    for(int i=1; i<fieldDeclarationNode.getChildCount(); i++)  // start at 1
    {
      RAWParserTreeNode vdn = fieldDeclarationNode.getChildNodeAt(i);    // a=1
      if(vdn.toString().equals("VariableDeclarator"))
      {
        RAWParserTreeNode vdidn = vdn.getChildNodeAt(0); // VariableDeclaratorId
        if(i==1)
        {
          this.name = CCTreeUtils.getImageOfAllSubElements( vdidn );
        }
        else
        {
          //System.out.println("Additional variable in multiple field declaration found:");
          String n = CCTreeUtils.getImageOfAllSubElements( vdidn );
          //System.out.println("   "+n);
          FieldNode fn = new FieldNode(n, type, modifiers, modifiersShort);
          Utils.sortedInsert( fn, destination);

          // set precise start and end
          fn.setStartPosFrom( CCTreeUtils.getFirstSubchild(vdidn) );  // vdidn : without initializer,  // vdn: with
          fn.setEndPosFrom( CCTreeUtils.getLastSubchild( vdidn ) );

        }
      }
    }

    // add to the destination
    Utils.sortedInsert(this, destination);
  }


  /** Special case when multiple declaration encountered.
      overtakes the main modifiers and type.
      Causes a java.lang.verify error when optimized/shrinked with Proguard4beta4 when private.
  */
  public FieldNode(String name, String type, int[] modifiers, String modifiersShort)
  {
    super("field");

    this.sortPriority = 0;
    this.name = name;
    this.type = type;
    this.modifiers = modifiers;
    this.modifiersShort = modifiersShort;
  }

  @Override
  public String toString()
  {
    return name+"   "+type;
  }

  public final int[] getModifiers() { return modifiers; }
  public boolean isStatic() { return Utils.isStatic(modifiers); }
  public boolean isPublic() { return Utils.isPublic( modifiers); }
  public boolean isPrivate() { return Utils.isPrivate( modifiers); }
  public boolean isProtected() { return Utils.isProtected( modifiers); }
  public boolean isFinal() { return Utils.isFinal( modifiers); }


  /** Call this to help GC !
  */
@Override
  public void terminate()
  {
    super.terminate();

    modifiers = null;
    modifiersShort = null;
    name = null;
    type = null;
  }


  /**
      ex: "[modifiers list as ParserConstants...] int age".
      Used in static analysis.
      Is sufficient for the purpose of dependencies study.

      TODO
      [June2010]: should contain the value, if compile time constant !!!

      example:
         public static final String myID = "XX";
      causes the recompilation of if "XX" changes to "XY".
         public static String myID = "XYZ";  is NOT a compile time constant and is read from "users" dynamically.
  */
   public String getDetailledSignatureForDepDet()
   {
      StringBuilder sb = new StringBuilder();
      sb.append(Arrays.toString(modifiers));
      sb.append(this.type);
      sb.append(" ");
      sb.append(name);
      return sb.toString();
   }


   // Highlightable Node
   //

    private /*@checkers.nullness.quals.LazyNonNull*/  String fullJavaID = null;
    public String getFullJavaID()
    {
       if(fullJavaID!=null) return fullJavaID;  // ok because immutable
       fullJavaID = NodeUtils.getFullJavaID(this);
       return fullJavaID;
    }

    public void setHighlighted(boolean is)
    {
       MainEditorFrame.getActualProject().setSyntaxTreeNodeHighlighted(getFullJavaID(), is);
    }

    public boolean isHighlighted()
    {
       return MainEditorFrame.getActualProject().isSyntaxTreeNodeHighlighted(getFullJavaID());
    }

}