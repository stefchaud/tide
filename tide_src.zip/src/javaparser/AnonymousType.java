package javaparser;

import javaparser.javacc_gen.*;

/** As for example in

        new ActionListener()
        {
           // body
        }

   parsed from raw syntax during completion.
*/
public class AnonymousType implements TypeInterface
{
  public Token start, end;
  private String name;
  public TypeNode parent;

  public AnonymousType(String name, Token start, Token end, TypeNode parent)
  {
     this.start = start;
     this.end = end;
     this.name = name;
     this.parent = parent;
  }

  public String getTypeSimpleName() { return name; }

  /** @return null if not found.
  */
  public static /*@org.checkerframework.checker.nullness.qual.Nullable*/ AnonymousType parse(RAWParserTreeNode classOrInterfaceBodyNode, TypeNode parent)
  {

      RAWParserTreeNode tnc = classOrInterfaceBodyNode.parent;
      RAWParserTreeNode tncs = CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(tnc, "ClassOrInterfaceType");
      if(tncs==null)
      {
        return null;
      }

      String name = CCTreeUtils.getImageOfAllSubElements(tncs);  // with full decl and type params

      // the bounds must exist
      Token tstart = CCTreeUtils.getFirstSubchild(classOrInterfaceBodyNode);
      Token tend   = CCTreeUtils.getLastSubchild( classOrInterfaceBodyNode);

      return new AnonymousType(name, tstart, tend, parent);
  }
}