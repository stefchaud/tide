package javaparser;

public class StaticInitializerNode extends ParserTreeNode
{
  public StaticInitializerNode(RAWParserTreeNode decl)
  {
     super("static initializer");

     this.sortPriority = 6;
     this.setStartPosFrom( CCTreeUtils.getFirstSubchild( decl ));
     this.setEndPosFrom(   CCTreeUtils.getLastSubchild( decl ) );
  }
}