package javaparser;

/** for constructors, fields, methods, type (class, enum, ...)
*/
public interface NodeWithMod
{
   // according JavaParserConstants {PUBLIC, PRIVATE, ...}
   int[] getModifiers();
   boolean isStatic();

   // these 3 must be present in the modifiers. if none is true => package scope.
   boolean isPublic();
   boolean isPrivate();
   boolean isProtected();

}