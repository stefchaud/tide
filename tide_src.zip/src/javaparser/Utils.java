package javaparser;

import javaparser.javacc_gen.Token;
import javaparser.javacc_gen.JavaParserConstants;
import java.util.*;
import javax.swing.text.*;
import javax.swing.tree.*;
import javax.swing.JTree;

/** Mainly tree utils.
*/
public final class Utils
{
  private Utils()
  {
  }


/*
  public static Element getLine(Document doc, int line)
  {
      Element map = doc.getDefaultRootElement();
      return map.getElement(line);
  }*/



  /** depth first. used
  */
  static Token getFirstSubchild(ParserTreeNode tn)
  {
     if(tn.getUserObject() instanceof Token)   // first at first level = first
     {
       return (Token) tn.getUserObject();
     }

     for(int i=0; i<tn.getChildCount(); i++)
     {
       ParserTreeNode ci = tn.getChildNodeAt(i);
       Token t = getFirstSubchild(ci);
       if(t!=null) return t;
     }
     // none found
     return null;
  }

  /** @param line 1 for the first
  */
  public static boolean isInto( int line, int col, Token from, Token to )
  {
     if(from==null) return false;
     if(to==null) return false;
     if(line<from.beginLine) return false;
     if(line>to.endLine) return false;
     // TODO: look at columns

     return true;
  }


  /** @param node pass the public, private of package scope or protected node as argument.
  */
  @tide.annotations.Recurse
  public static void getAllMethods(ParserTreeNode node, List<MethodNode> found)
  {
     for(int i=0; i<node.getChildCount(); i++)
     {
       ParserTreeNode ci = node.getChildNodeAt(i);
       if(ci instanceof MethodNode)
       {
          found.add((MethodNode) ci);
       }

       // recurse
       getAllMethods(ci, found);
     }
  }


  /** @param node pass the public, private of package scope or protected node as argument.
  */
  @tide.annotations.Recurse
  public static void getAllFields(ParserTreeNode node, List<FieldNode> found)
  {
     for(int i=0; i<node.getChildCount(); i++)
     {
       ParserTreeNode ci = node.getChildNodeAt(i);
       if(ci instanceof FieldNode)
       {
          found.add((FieldNode) ci);
       }

       // recurse
       getAllFields(ci, found);
     }
  }


  /** null if none, null if tn is null. used
  */
  static /*@org.checkerframework.checker.nullness.qual.Nullable*/ Token getFirstToken_ONLYInDirectChilds(ParserTreeNode tn, int kind)
  {
     if(tn==null) return null;
     for(int i=0; i<tn.getChildCount(); i++)
     {
       ParserTreeNode ci = tn.getChildNodeAt(i);
       if(ci.isToken() && ci.getToken().kind == kind) return ci.getToken();
     }
     // none found
     return null;
  }


  /** depth first.  used
  */
  @tide.annotations.Recurse
  static Token getLastSubchild(ParserTreeNode tn)
  {
     if(tn.getUserObject() instanceof Token)      // last at first level = last
     {
       return (Token) tn.getUserObject();
     }

//     if(tn.tokens!=null && tn.tokens.size()>0) return tn.tokens.get(tn.tokens.size()-1);

     for(int i=tn.getChildCount()-1; i>=0; i--)    // reverse search
     {
       ParserTreeNode ci = tn.getChildNodeAt(i);

       Token t = getLastSubchild(ci);
       if(t!=null) return t;
     }
     // none found
     return null;
  }

  /** depth first.  used
  */
  @tide.annotations.Recurse
  static void collectChilds(ParserTreeNode tn, List<Token> tokens)
  {
     if(tn.getUserObject() instanceof Token)
     {
       tokens.add( (Token) tn.getUserObject() );
       return ;  // a token is terminal
     }

     for(int i=0; i<tn.getChildCount(); i++)
     {
       ParserTreeNode ci = tn.getChildNodeAt(i);
       collectChilds(ci, tokens);
     }
  }

  static String getImageOfAllSubElements(ParserTreeNode tn)
  {
     ArrayList<Token> tokens = new ArrayList<Token>();
     collectChilds(tn, tokens);
     StringBuilder sb = new StringBuilder();
     for(int i=0; i<tokens.size(); i++)
     {
        //if(i>0) sb.append(" ");
        sb.append(tokens.get(i).image);

     }
     return sb.toString();
  }

 /** makes the given number of levels childs expanded.
 */@tide.annotations.Recurse
  public static void makeChildsExpanded(ParserTreeNode node, JTree tree, int numberOfLevels)
  {
     for(int i=0; i<node.getChildCount(); i++)
     {
        ParserTreeNode ni = node.getChildNodeAt(i);
        if(i==0)
        {
           tree.makeVisible(new TreePath(ni.getPath()));  // out of bounds here !!  ((Make visible ??)
        }

        // recurse
        if(numberOfLevels>0)
        {
          makeChildsExpanded(ni, tree, numberOfLevels-1);
        }
     }
  }


  /** Only "s f a t y n v" ignores access modifiers as {public protected packagescope private}.
  *  Is used in the syntax tree for Classes, Methods and Fields
  */
  static String getModifiersShortString(int[] mods)
  {
     StringBuilder mod = new StringBuilder();
     for(int mi : mods)
     {
        switch(mi)
        {
          case -1: break;
          case JavaParserConstants.PUBLIC    : break;  // ignore, because already present in the parent node that collect them.
          case JavaParserConstants.PRIVATE   : break;
          case JavaParserConstants.PROTECTED : break;
          case JavaParserConstants.FINAL     : mod.append("f"); break;
          case JavaParserConstants.STATIC    : mod.append("s"); break;
          case JavaParserConstants.ABSTRACT  : mod.append("a"); break;
          case JavaParserConstants.STRICTFP  : mod.append("t"); break;
          case JavaParserConstants.SYNCHRONIZED : mod.append("y"); break;
          case JavaParserConstants.NATIVE    : mod.append("n"); break;
          case JavaParserConstants.TRANSIENT : mod.append("r"); break;
          case JavaParserConstants.VOLATILE  : mod.append("v"); break;
          default: mod.append(" ?ERROR? "+mi);                   // unknow !! => add it
        }
     }
     return mod.toString();
  }


  /** ignoring public, private, protected.
  */
  public static String getModifiersWithoutAccessModifiersFullString(int[] mods)
  {
     if(mods.length==0) return "";
     final StringBuilder mod = new StringBuilder();
     for(int mi : mods)
     {
        if(isAccessModifier(mi)) continue;

        if(mod.length()>0) mod.append(" ");

        if(mi==-1)
        {
          mod.append("ERROR");
        }
        else
        {
          String tim = JavaParserConstants.tokenImage[mi];
          if(tim.startsWith("\"")) tim = tim.substring(1,tim.length()-1);
          mod.append(tim);
        }
     }

     return mod.toString();
  }


  private static boolean contains(int[] mods, int mod)
  {
    if(mods==null) return false;   // Warn ??
    for(int modi: mods)
    {
      if(modi==mod) return true;
    }
    return false;
  }

  public static boolean isAccessModifier(int mod)
  {
     if(mod==JavaParserConstants.PUBLIC) return true;
     if(mod==JavaParserConstants.PRIVATE) return true;
     if(mod==JavaParserConstants.PROTECTED) return true;

     return false;
  }

  /** looks if JavaParserConstants.PUBLIC is present.
  */
  public static boolean isPublic(int[] mods)
  {
     return contains(mods, JavaParserConstants.PUBLIC);
  }

  /** looks if JavaParserConstants.PRIVATE is present.
  */
  public static boolean isPrivate(int[] mods)
  {
     return contains(mods, JavaParserConstants.PRIVATE);
  }

  /** looks if JavaParserConstants.PROTECTED is present.
  */
  public static boolean isProtected(int[] mods)
  {
     return contains(mods, JavaParserConstants.PROTECTED);
  }

  /** looks if JavaParserConstants.STATIC is present.
  */
  public static boolean isStatic(int[] mods)
  {
     return contains(mods, JavaParserConstants.STATIC);
  }

  public static boolean isFinal(int[] mods)
  {
     return contains(mods, JavaParserConstants.FINAL);
  }


  /** Can be used to compare accorting ordering {public, pscope, protected, private}
  *  pscope araises when no other modifier (pub, pri, pro) are declared.
  */
  public static int compareModifiers(int[] m1, int[] m2)
  {
     int o1 = getOrderForSort(m1);
     int o2 = getOrderForSort(m2);
     if(o1==o2) return 0;
     if(o1<o2) return 1;
     return -1;
  }

  /** Can be used to compare accorting ordering {1=public, 2=pscope, 3=protected, 4=private}
  *  pscope araises when no other modifier (pub, pri, pro) are declared.
  *
  */
  public static int getOrderForSort(int[] mods)
  {
     for(int mi : mods)
     {
        if(mi==JavaParserConstants.PUBLIC) return 1;
        if(mi==JavaParserConstants.PROTECTED) return 3;
        if(mi==JavaParserConstants.PRIVATE) return 4;
     }
     return 2;
  }


  /** Used for fields and methods and constructors.
  *   Uses node's sort order provided by the comparable interface.
  */
  public static void sortedInsert( final ParserTreeNode node, final ParserTreeNode destination)
  {
     for(int i=0; i<destination.getChildCount(); i++)
     {
       ParserTreeNode ci = destination.getChildNodeAt(i);
       if(node.compareTo(ci)>0)
       {
          destination.insert(node, i);
          return;
       }
     }
     // append at end
     destination.add(node);
  }



  /** Used for clever dependencies propagation.
  *   Allows to detect if a class hasn't changed its accessible members
  *   => no need to recompile the classes using it.
  *  Caution: be either conservative ! add better more than not enough stuff.
  *  the passed signature has to be XORed with the actual node.
  */
  public static long getSignatureOf_NonPrivate_Recurse(ParserTreeNode ptn, long sig)
  {
     if(ptn instanceof TypeNode)
     {
        // class, enum, interface, ...
        TypeNode tn = (TypeNode) ptn;


        if(tn.isPrivate()) return sig;   // nothing to do !

        if(tn instanceof ClassNode)
        {
          // the name itself and parameters and extends and implements !
          sig = sig ^ ((ClassNode) tn).getDetailledSignatureForDepDet().hashCode();
        }
        else
        {
           //todo: ??
          sig = sig ^ (""+ tn).hashCode();
        }


        // inner classes, recurse !
        for(TypeNode tnc : tn.directChildTypes)
        {
           sig = getSignatureOf_NonPrivate_Recurse(tnc, sig);
        }

        // members, fields, constructor and methods
        for(int i=0; i<tn.getChildCount(); i++)
        {
           final ParserTreeNode ci = tn.getChildNodeAt(i);

           // ignore private members
           if(ci instanceof NodeWithMod)
           {
              if( ((NodeWithMod) ci).isPrivate()) continue;
           }

           if(ci instanceof ConstructorNode)
           {
              ConstructorNode cn = (ConstructorNode) ci;
              //System.out.println("Cons: "+cn);
              sig = sig ^ cn.getDetailledSignatureForDepDet().hashCode();
           }
           else if(ci instanceof MethodNode)
           {
              MethodNode cn = (MethodNode) ci;
              sig = sig ^ cn.getDetailledSignatureForDepDet().hashCode();
           }
           else if(ci instanceof FieldNode)
           {
              FieldNode cn = (FieldNode) ci;
              sig = sig ^ cn.getDetailledSignatureForDepDet().hashCode();
           }
        }
     }
     else
     {
        System.out.println("SIGC: Not a type: "+ptn.getClass());
     }
     return sig;
  }



}