package javaparser;

import java.util.*;
import javaparser.javacc_gen.Token;
import tide.editor.UIConstants;

public class PackageNode extends MainNode
{
  public String packageName = "";

  /** For the unnamed package, when no explicit declaration was made.
  */
  public PackageNode()
  {
     super("package", null, null, false);
  }

  public PackageNode(ParserTreeNode packageDeclarationNode)
  {
     super("", "package", UIConstants.blue, false);

     ArrayList<Token> tokens = new ArrayList<Token>();
     Utils.collectChilds( packageDeclarationNode, tokens );
     //ci.simplifiedDescription = "package "+createImportText(tokens);
     this.packageName = "";
     for(int i=1; i<tokens.size()-1; i++)  // ignore ";" and "package"
     {
        packageName += tokens.get(i);
     }

     this.setStartPosFrom( tokens.get(0));
     this.setEndPosFrom( tokens.get(tokens.size()-1) );

  }

  public PackageNode(RAWParserTreeNode packageDeclarationNode)
  {
     super("", "package", UIConstants.blue, false);

     ArrayList<Token> tokens = new ArrayList<Token>();
     CCTreeUtils.collectChilds( packageDeclarationNode, tokens );
     //ci.simplifiedDescription = "package "+createImportText(tokens);
     this.packageName = "";
     for(int i=1; i<tokens.size()-1; i++)  // ignore ";" and "package"
     {
        packageName += tokens.get(i);
     }

     this.setStartPosFrom( tokens.get(0));
     this.setEndPosFrom( tokens.get(tokens.size()-1) );

  }

  @Override
  public String toString()
  {
    return packageName;
  }

  /** call this to help GC !
  */
@Override
  public void terminate()
  {
    packageName = null;
  }

}