package javaparser;

import java.util.*;
import tide.syntaxtree.*;

/** represents an enum in the simplified syntax tree
*/
public class EnumNode extends TypeNode
{
  public String name = "", fullName;
  public int[] modifiers;
  public String modifiersShort;
  public List<String> items = new ArrayList<String>();

  final private SimplifiedJapaTree sst;

  public EnumNode(SimplifiedJapaTree sst, RAWParserTreeNode enumDeclarationNode, RAWParserTreeNode modNode, TypeNode parentType)
  {
     super("enum", parentType, enumDeclarationNode);

     this.sst = sst;

     this.sortPriority = 3;
     this.expandInView = false;

     this.modifiers = CCTreeUtils.getAllModifiers(modNode);
     modifiersShort = Utils.getModifiersShortString(modifiers);

     if(modNode.getChildCount()>0)
     {
       this.setStartPosFrom( CCTreeUtils.getFirstSubchild(modNode) );
     }
     else
     {
       this.setStartPosFrom( CCTreeUtils.getFirstSubchild(enumDeclarationNode) );
     }

     this.setEndPosFrom( CCTreeUtils.getLastSubchild(enumDeclarationNode) );

     //  {enum, name, EnumBody}
     this.name = enumDeclarationNode.childs.get(1).toString();
     parseEnumBody(enumDeclarationNode.childs.get(2));

     StringBuilder fn = new StringBuilder();
     if(parentType!=null)
     {
        fn.append(parentType.getJavaFullName());
        fn.append("$"); // inner classes
     }
     else
     {
        fn.append(sst.packageNode.toString());
        if(fn.length()>0) fn.append(".");  // may be the root package (no name)
     }
     fn.append(name);
     fullName = fn.toString();

     RAWParserTreeNode bodyNode = CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(enumDeclarationNode, "EnumBody");
     if(bodyNode!=null)
     {
        for(RAWParserTreeNode ci : bodyNode.childs)
        {
           if(ci.toString().equals("EnumConstant"))
           {
              addConstant(ci);
           }
        }
     }
  } // Constructor2

  private void addConstant(RAWParserTreeNode enumConstNode)
  {
     EnumConstantNode en = new EnumConstantNode(enumConstNode);
     items.add( ""+en.name );
     this.add(en);
  }

  /** call this to help GC !
  */
@Override
  public void terminate()
  {
    super.terminate();

    items.clear();
    fullName = null;
    name = null;
    modifiersShort = null;
    modifiers = null;
  }

  /** Have {EnumConstant and ClassOrInterfaceBodyDeclaration (with Constructor, Method, Field)}
  */
  private void parseEnumBody(RAWParserTreeNode body)
  {
     for(RAWParserTreeNode ci : body.childs)
     {
        if(ci.toString().equals("EnumConstant"))
        {
           items.add( ci.childs.get(1).toString() );
        }
        else if(ci.toString().equals("ClassOrInterfaceBodyDeclaration"))
        {
           // Simplified !, no public, private nodes...
           ClassNode.addClassOrInterfaceBodyDeclaration(sst, ci, this, this);
        }
     }
     //test: System.out.println(""+items);
  }


  @Override
  public String toString()
  {
    return "" + name;
  }
@Override
  public String getTypeSimpleName()
  {
    return name;
  }

  /** With the package name.
  */
@Override
  public String getJavaFullName()
  {
     return fullName;
  }

@Override
  public int[] getModifiers() { return this.modifiers; }

@Override
  public boolean isPublic() { return Utils.isPublic( modifiers ); }
  public boolean isPrivate() { return Utils.isPrivate( modifiers ); }
  public boolean isProtected() { return Utils.isProtected( modifiers ); }
  public boolean isStatic() { return Utils.isStatic( modifiers ); }

}