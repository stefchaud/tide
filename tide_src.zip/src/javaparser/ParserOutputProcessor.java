package javaparser;

import javaparser.javacc_gen.Token;

/**  Taken from Schmortopf !
  *
  *  This interface must be implemented by any class,
  *  which wants to create a parser and get all
  *  output strings the parser creates when running
  *  its compilationunit.
  */

public interface ParserOutputProcessor
{

 /**
  *  Called by the parser when it encounters a new node.
  */
  public void addNode( String name);


 /**
  *  Called by the parser when it returns from a previously
  *  encountered node (for which it has called addNode)
  */
  public void returnFromNode( String name);


 /**
  *  Called by the parser when it has encountered a token
  *  at the current treeposition, which is defined by all
  *  already received calls of addNode() and returnFromNode().
  */
  public void addLeaf( final Token content );


}