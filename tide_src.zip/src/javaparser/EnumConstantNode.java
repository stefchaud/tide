package javaparser;


public final class EnumConstantNode extends ParserTreeNode
{
   public String name;

   public EnumConstantNode(RAWParserTreeNode enumConstNode)
   {
      super("enum const");
      name = ""+enumConstNode.childs.get(1);

      this.setStartPosFrom( CCTreeUtils.getFirstSubchild(enumConstNode) );
      this.setEndPosFrom( CCTreeUtils.getLastSubchild(enumConstNode) );
   }

   @Override
   public String toString()
   {
     return name;
   }

   /** Call this to help GC !
   */
 @Override
   public void terminate()
   {
     super.terminate();

     name = null;
   }
}