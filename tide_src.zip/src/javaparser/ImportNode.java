package javaparser;

import javaparser.javacc_gen.JavaParserConstants;
import javaparser.javacc_gen.Token;
import java.util.*;

public final class ImportNode extends ParserTreeNode
{
  String importName;
  boolean isStatic = false;

  public ImportNode(RAWParserTreeNode importDeclarationNode)
  {
     super("import statement");

     List<Token> tokens = new ArrayList<Token>();
     CCTreeUtils.collectChilds( importDeclarationNode, tokens );
     this.importName = createImportText(tokens);
     if(importName.startsWith("static "))
     {
        importName = importName.substring(7).trim();  // can be ameliorated...
     }

     this.setStartPosFrom( tokens.get(0));
     this.setEndPosFrom( tokens.get(tokens.size()-1) );
  }

  @Override
  public String toString()
  {
     return "" + importName;
  }

  /** The name, without static.
  */
  public String getImportName()
  {
    return importName;
  }

  /** @return true for "import static" imports
  */
  public boolean isStatic() { return isStatic; }

  /** "static java.lang.Math.*",  "javax.swing.JFrame", ...
  */
  private String createImportText(List<Token> tokens)
  {
    StringBuilder sb = new StringBuilder(50);
    for(int i=1; i<tokens.size()-1; i++)  // ignore the "import" token itself
    {
      Token ti = tokens.get(i);
      sb.append(ti);
      if(ti.kind==JavaParserConstants.STATIC)
      {
        isStatic=true;
        sb.append(" ");  // import static special case
      }
    }
    return sb.toString();
  }

  /** Call this to help GC !
  */
@Override
  public void terminate()
  {
    super.terminate();

    importName = null;
  }

}