package javaparser;

import java.util.*;
import javaparser.javacc_gen.Token;

/**
*  Reusable through the RAWParserTreeNodeFactory.
*  Two times quicker as MutableTreeNode !!
*  Even quicker associated with the reusable nodes pool.
*  Must be used with the new SimplifiedSyntaxTree.
*/
public final class RAWParserTreeNode
{

   // for leafs
   Token t = null;

   // for nodes
   String name = null;

   // tree structure
   final public List<RAWParserTreeNode> childs = new ArrayList<RAWParserTreeNode>(1);
   public RAWParserTreeNode parent = null;

   RAWParserTreeNode(Token t)
   {
      this.t=t;
   }

   RAWParserTreeNode(String name)
   {
      this.name=name;
   }

   /** Used by the simpifiedtree parser.
   *  Name if non null or the token image.
   */
   @Override
   public String toString()
   {
      if(name!=null)
      {
        return name;
      }

      return t.image;
   }

   /** Also sets child's parent to this.
   */
   public void add(RAWParserTreeNode child)
   {
      childs.add(child);
      child.parent = this;
   }

   /** Without any terminations !
   */
   public void removeFromParent()
   {
      parent.childs.remove(this);
      parent = null;
   }

   public int getChildCount() { return childs.size(); }

   /** -1 if not a token
   */
   public int getTokenKind()
   {
     if(t==null) return -1;
     return t.kind;
   }

   /** null if not a token
   */
   public /*@org.checkerframework.checker.nullness.qual.Nullable*/ Token getToken()
   {
     return t;
   }

   public boolean isToken()
   {
     return t != null;
   }
   public RAWParserTreeNode getChildNodeAt(int i)
   {
      return childs.get(i);
   }

   public RAWParserTreeNode getNextSibling()
   {
      if(parent==null) return null;
      int tp = parent.childs.indexOf(this);
      if(tp+1 >= parent.childs.size()) return null;
      return parent.childs.get(tp+1);
   }

   public int getIndex(RAWParserTreeNode child)
   {
      return childs.indexOf(child);
   }

   /** Not recurse.
   */
   public void terminateAndOfferReuse()
   {
      childs.clear();
      parent = null;

      name = null;
      t = null;

      RAWParserTreeNodeFactory.getInstance().addFreed(this);
   }

}