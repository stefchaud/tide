package javaparser;

import tide.editor.MainEditorFrame;
import com.github.javaparser.ast.body.ConstructorDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import java.util.*;
import javaparser.javacc_gen.*;

/** The parameter of a method or constructor of a for loop
*   or a field in a class.
*/
public class Parameter
{
  public final String type;   // ex: "double" or double[]  or "Vector<String>"
  public final String name;   // ex: "a"

  // declaration position (start)
  public int line, col;

  public boolean isParameterAfterLine( int _line)
  {
     if(line > _line ) return true;
     return false;
  }


  public Parameter(String type, String name)
  {
    this.type = type;
    this.name = name;
  }


  /** Occurs in methods and constructors
      parsed during simplified syntax tree construction
  */
  public static Parameter parseFromFormalParamNode(RAWParserTreeNode formalParameterNode)
  {
    String type = CCTreeUtils.getImageOfAllSubElements( CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(formalParameterNode, "Type") );
    RAWParserTreeNode vidNode = CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(formalParameterNode, "VariableDeclaratorId");
    Token t = CCTreeUtils.getFirstSubchild(vidNode);

    String name = CCTreeUtils.getImageOfAllSubElements( vidNode );
    // [April2007]: varargs
    if(CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(formalParameterNode, "...")!=null)
    {
       type+="[]";  // really an array for the usage...
    }

    Parameter p = new Parameter(type, name);

    p.line = t.beginLine;
    p.col = t.beginColumn;

    return p;
  }


  public static Parameter parseFromLocalVariableDeclaration(RAWParserTreeNode localVariableDeclarationNode)
  {
    String type = CCTreeUtils.getImageOfAllSubElements( CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(localVariableDeclarationNode, "Type") );
    RAWParserTreeNode vidNode = CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(localVariableDeclarationNode, "VariableDeclarator");  // was Id
    vidNode = CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(vidNode, "VariableDeclaratorId");

    Token t = CCTreeUtils.getFirstSubchild(vidNode);

    String name = CCTreeUtils.getImageOfAllSubElements( vidNode );
    Parameter p = new Parameter(type, name);

    p.line = t.beginLine;
    p.col = t.beginColumn;

    return p;

  }

  /** Occurs in field declarations.
  *  Subtle bug: if a Class named "FieldDeclaration" exists, it interracts and cause errors...
  */
  public static Parameter parseFromFieldDeclaration(RAWParserTreeNode fieldDeclarationNode)
  {
    RAWParserTreeNode tn = CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(fieldDeclarationNode, "Type");
    if(tn==null)
    {
       System.out.println("No Type node in field declaration: "+fieldDeclarationNode);
       return null;
    }
    String type = CCTreeUtils.getImageOfAllSubElements( tn );
    RAWParserTreeNode vidNode = CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(fieldDeclarationNode, "VariableDeclarator");  // was Id
    if(vidNode==null) return null;
    vidNode = CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(vidNode, "VariableDeclaratorId");

    Token t = CCTreeUtils.getFirstSubchild(vidNode);

    String name = CCTreeUtils.getImageOfAllSubElements( vidNode );
    Parameter p = new Parameter(type, name);

    p.line = t.beginLine;
    p.col = t.beginColumn;

    return p;
  }


  public static List<Parameter> parseFromConstructorDeclaration(ConstructorDeclaration declarationNode)
  {
     return getParams(declarationNode.getParameters());
  }


  public static List<Parameter> parseFromMethodDeclaration(MethodDeclaration methodDeclarationNode)
  {
     return getParams(methodDeclarationNode.getParameters());
  }

  public static List<Parameter> getParams(List<com.github.javaparser.ast.body.Parameter> ps)
  {
     List<Parameter> ret = new ArrayList<Parameter>();
     if(ps!=null)
     {
       for(com.github.javaparser.ast.body.Parameter p : ps)
       {
          ret.add(new Parameter(""+ p.getType(), p.getId().getName()));
       }
     }
     return ret;
  }

  @Deprecated
  public static Parameter parseFromMethodDeclaration(RAWParserTreeNode methodDeclarationNode)
  {
    RAWParserTreeNode rtNode = CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(methodDeclarationNode, "ResultType");
    if(rtNode==null)
    {
       MainEditorFrame.debugOut("ERROR: No ResultType node for method declaration");
       return null;
    }
    String type = CCTreeUtils.getImageOfAllSubElements( rtNode );

    RAWParserTreeNode mdNode = CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(methodDeclarationNode, "MethodDeclarator");
    if(mdNode==null)
    {
       MainEditorFrame.debugOut("ERROR: No MethodDeclarator for method declaration");
       return null;
    }

    String name = ""+mdNode.getChildNodeAt(0);
    Parameter p = new Parameter(type, name);
    return p;
  }

  /** Occurs in field declarations.
  * type 1:   for(String s : args)  {}
  * type 2:   for(int i=0; i<12; i++) {}
  * variant:  for(; i<12; i++) {}    no ForInit
  */
  public static Parameter parseFromForStatementDeclaration(RAWParserTreeNode forDeclarationNode)
  {
    RAWParserTreeNode finitNode = CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(forDeclarationNode, "ForInit");
    if(finitNode!=null)
    {
       // type 2:
       RAWParserTreeNode lvdNode = CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(finitNode, "LocalVariableDeclaration");
       if(lvdNode==null)
       {
          MainEditorFrame.debugOut("No param2 in for decl found: "+forDeclarationNode);
          return null;
       }
       return parseFromLocalVariableDeclaration(lvdNode);
    }

    // type 1:
    RAWParserTreeNode typeNode = CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(forDeclarationNode, "Type");
    if(typeNode==null)
    {
       MainEditorFrame.debugOut("No param1 in for decl found: "+forDeclarationNode);
       return null;
    }
    String type = CCTreeUtils.getImageOfAllSubElements( typeNode );

    RAWParserTreeNode nameNode = typeNode.getNextSibling();

    String name = CCTreeUtils.getImageOfAllSubElements( nameNode );
    Parameter p = new Parameter(type, name);

    return p;

  }


  /** Collects the paramters.
  */
  public static List<Parameter> getParameters(RAWParserTreeNode formalParametersNode)
  {
    List<Parameter> params = new ArrayList<Parameter>();
    for(int i=0; i<formalParametersNode.getChildCount(); i++)
    {
      RAWParserTreeNode ci = formalParametersNode.getChildNodeAt(i);
      if(ci.toString().equals("FormalParameter"))
      {
         params.add( Parameter.parseFromFormalParamNode(ci) );
      }
    }
    return params;
  }

  /** appears in the symplified syntax tree !
  *  example: "List<String> names"
  */
  @Override
  public String toString()
  {
    return type+" "+name;
  }


}