package javaparser;

import tide.editor.MainEditorFrame;
import javaparser.javacc_gen.*;
import java.util.*;
import tide.syntaxtree.*;

/** A type is a class, an interface an enum an annotation defined
    at first level of a source.
    Subclasses: ClassNode, EnumNode, ...
*/
public abstract class TypeNode extends ParserTreeNode implements TypeInterface, NodeWithMod, HighlightableNode
{
  // the limits of this type
  public Token blokStart, blokEnd;
 //protected SimplifiedJapaTree simplifiedSyntaxTree;
  public TypeNode parentType;

  // not used in the tree
  public List<TypeNode> directChildTypes = new ArrayList<TypeNode>();

  // raw tree reference. Used for real time later parsing
  //  also used during
 // public ParserTreeNode rawDeclarationNode;
  public RAWParserTreeNode rawDeclarationNode2;

  // TODO:
  // interesting for completion: the ClassOrInterfaceBodyDeclaration tokens that are NOT subchilds type declarations
  // but anonymous instanciations with body.
  //   for example new ActionListener() { ... }

  public TypeNode(String descr, /*SimplifiedJapaTree sst, */TypeNode parentType, RAWParserTreeNode rawDeclarationNode2)
  {
    super(descr);

    this.sortPriority = 5;

    //this.simplifiedSyntaxTree = sst;
    this.parentType = parentType;
    this.rawDeclarationNode2 = rawDeclarationNode2;

    if(parentType!=null)
    {
       parentType.directChildTypes.add(this);
    }
  }


  /** Simple name, without the parent.
  */
  public abstract String getTypeSimpleName();

  //public abstract boolean isPublic();

  /** With the package name.
  */
  public abstract String getJavaFullName();

  /** The name without the package. Constructed from the simple name and the parents chain.
  */
  public String getTypeRelativeName()
  {
     StringBuilder sb = new StringBuilder();
     sb.append(getTypeSimpleName());
     TypeNode pn = this.parentType;
     while(pn!=null)
     {
        sb.insert(0, ".");
        sb.insert(0, pn.getTypeSimpleName());
        pn = pn.parentType;
     }
     return sb.toString();
  }

  /* To detect if public or static, use Utils.contains(mods, JavaParserConstants.PUBLIC)
  */
  //public abstract int[] getModifiers();


  /** null if none
    looks in the declared subchilds, but not actually in the anonymous declared classes
  */
  @tide.annotations.Recurse
  public /*@org.checkerframework.checker.nullness.qual.Nullable*/ TypeNode getDeepestContainingTypeAt(int line, int col)
  {
     if(!TreeUtils.contains(this, line, col)) return null;

     // deepest => look in childs
     for(TypeNode tn: this.directChildTypes)
     {
        TypeNode found = tn.getDeepestContainingTypeAt(line, col);
        if(found !=null) return found;
     }

     // not found in childs => this is the deepest
     return this;
  }


  /** Interesting for completion: the ClassOrInterfaceBodyDeclaration tokens that are NOT subchilds type declarations
    but anonymous instanciations with body.
    for example new ActionListener() { ... }

    this is called at completion time
  */
  public AnonymousType getDeepestContainingAnonymousClassBlocForLocation(int line, int col)
  {
    List<RAWParserTreeNode> found = new ArrayList<RAWParserTreeNode>();
    if(rawDeclarationNode2==null)
    {
       System.out.println("No raw tree found for deepest type search.");
       return null;
    }
    CCTreeUtils.getAllChildsNamed(rawDeclarationNode2, "ClassOrInterfaceBody", found);   // TODO: annotations ?, enums ?
    //System.out.println("\n"+found.size()+" declaration found:");

    for( RAWParserTreeNode tn : found)
    {
      //System.out.println("\nDecl at line "+tn.getStartLinCol()[0]);
      AnonymousType at = AnonymousType.parse( tn, this );
      if(at!=null)
      {
         if(Utils.isInto( line, col, at.start, at.end))
         {
           //System.out.println("found anonymous type "+at.name);
           //new Throwable().printStackTrace();
           return at;
         }
      }
    }

    return null;
  }


  /** Call this to help GC !
  */
@Override
  public void terminate()
  {
    super.terminate();

    parentType = null;
    directChildTypes.clear();
    rawDeclarationNode2 = null;
    blokEnd = null;
    blokStart = null;
  }

   // HighlightableNode
   //

    private   String fullJavaID = null;
    public String getFullJavaID()
    {
       if(fullJavaID!=null) return fullJavaID;  // ok because immutable
       fullJavaID = NodeUtils.getFullJavaID(this);
       return fullJavaID;
    }

    public void setHighlighted(boolean is)
    {
       MainEditorFrame.getActualProject().setSyntaxTreeNodeHighlighted(getFullJavaID(), is);
    }

    public boolean isHighlighted()
    {
       return MainEditorFrame.getActualProject().isSyntaxTreeNodeHighlighted(getFullJavaID());
    }


}