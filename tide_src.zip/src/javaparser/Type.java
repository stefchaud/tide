package javaparser;

/** Parent for types and anonymous classes, used in completion for "this."
*/
public interface Type
{
  String getTypeName();

  /** for example Point in Point2D
  * null if none
  */
  // String getEnclosingType();
}