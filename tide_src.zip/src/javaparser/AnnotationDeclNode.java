package javaparser;

import tide.syntaxtree.*;

/** Top annotation node.
*   Also creates the childs.
*/
public class AnnotationDeclNode extends TypeNode //implements NodeWithMod
{
  private String name = "";
  private String typeName, fullName;
  public int[] modifiers;
  public String modifiersShort;

  public AnnotationDeclNode(SimplifiedJapaTree sst, RAWParserTreeNode annotationTypeDeclarationNode, RAWParserTreeNode modNode, TypeNode parentType)
  {
     super("annotation", parentType, annotationTypeDeclarationNode);
     this.expandInView = true;

     this.modifiers = CCTreeUtils.getAllModifiers(modNode);
     modifiersShort = Utils.getModifiersShortString(modifiers);

     if(modNode.getChildCount()>0)
     {
       this.setStartPosFrom( CCTreeUtils.getFirstSubchild(modNode) );
     }
     else
     {
       this.setStartPosFrom( CCTreeUtils.getFirstSubchild(annotationTypeDeclarationNode) );
     }

     this.setEndPosFrom( CCTreeUtils.getLastSubchild(annotationTypeDeclarationNode) );

     typeName = ""+annotationTypeDeclarationNode.getChildNodeAt(2);

     StringBuilder fn = new StringBuilder();
     if(parentType!=null)
     {
        fn.append(parentType.getJavaFullName());
        fn.append("$"); // inner classes
     }
     else
     {
        fn.append(sst.packageNode.toString());
        if(fn.length()>0) fn.append(".");  // may be the root package (no name)
     }
     fn.append(typeName);
     fullName = fn.toString();


     this.name = typeName;

     // scan for childs, named annotationTypeMemberDeclaration
     RAWParserTreeNode bodyNode = CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(annotationTypeDeclarationNode, "AnnotationTypeBody");
     // iterate over the childs
     for(int i=0; i<bodyNode.getChildCount(); i++)
     {
       RAWParserTreeNode ci = bodyNode.getChildNodeAt(i);
       if(ci.toString().equals("AnnotationTypeMemberDeclaration"))
       {
          add(new AnnotationMemberNode(ci)); // sort ?
       }
     }
  }

  @Override
  public String toString()
  {
     return "" + name;
  }

  /** Without parent and package name.
  */
@Override
  public String getTypeSimpleName()
  {
     return typeName;
  }

  /** With the package name.
  */
@Override
  public String getJavaFullName()
  {
     return fullName;
  }

  //String getEnclosingType()
@Override
  public int[] getModifiers() { return this.modifiers; }

@Override
  public boolean isPublic() { return Utils.isPublic( modifiers ); }
  public boolean isPrivate() { return Utils.isPrivate( modifiers ); }
  public boolean isProtected() { return Utils.isProtected( modifiers ); }
  public boolean isStatic() { return Utils.isStatic( modifiers ); }

  /** call this to help GC !
  */
@Override
  public void terminate()
  {
    super.terminate();

    modifiers = null;
    modifiersShort = null;
    name = null;
    fullName = null;
    typeName = null;
  }
}