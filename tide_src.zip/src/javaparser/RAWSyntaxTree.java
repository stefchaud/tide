package javaparser;

import snow.utils.SysUtils;
import java.util.*;
import java.io.*;
import javaparser.javacc_gen.Token;


/** This builds the complete syntax tree as the tokens come from the trace methods of the parser.
*/
public class RAWSyntaxTree implements ParserOutputProcessor
{
  private RAWParserTreeNode actual;  // root at the beginning

  public RAWParserTreeNode root;

  public final String javaName;

  public RAWSyntaxTree(String javaName)
  {
     actual = new RAWParserTreeNode("");
     this.javaName = javaName;
     root = actual;
  }

  int level = 0;

  public void addNode( String name)
  {
     level++;
     RAWParserTreeNode n = RAWParserTreeNodeFactory.getInstance().create(name);
     actual.add(n);
     actual = n;
  }


 /**
  *  Called by the parser when it returns from a previously
  *  encountered node (for which it has called addNode)
  */
  public void returnFromNode( String name )
  {
     level--;
     //System.out.println("return from "+name);
     actual = actual.parent;
  }

 /**
  *  Called by the parser when it has encountered a token
  *  at the current treeposition, which is defined by all
  *  already received calls of addNode() and returnFromNode().
  */
  public void addLeaf( final Token t )
  {
     if(t.kind==javaparser.javacc_gen.JavaParserConstants.EOF) return;

     RAWParserTreeNode nn = RAWParserTreeNodeFactory.getInstance().create(t);
     actual.add(nn);

     //System.out.println("add leaf "+t+" ("+t.kind+")");
  }

  public void terminateRecurse()
  {
     RAWParserTreeNodeFactory.terminateRecurse(root);
  }




  public static void main(String[] arguments) throws Exception
  {
      //testOldRAWTree();

      testNewRAWTree();
  }

  /** two times quicker using RAWTreeNode as MutableTN...
  OLd tree: 483  171  156  187  171

  New tree:

  With recycling:  109  78  62  62  63  62  78  62  156  62
  RAWParserTreeNodeFactory: 57709 free, 519291 reused.

  Without  	     109  124  94  124  78  125  77  125  78  125
  Directcreat		  109  109  78  124  78  125  78  124  78  125

//2016
  //N3000
  RAWST>  125  63  16  16  31  31  31  15  31  31
  RAWST> RAWParserTreeNodeFactory: 63375 free, 570285 already reused, 63365 created
RAWST>  109  32  31  31  15  32  31  31  47  15
RAWST> RAWParserTreeNodeFactory: 193569 free, 440091 already reused, 48899 created

RAWST>  125  47  47  46  47  78  31  78  32  78
RAWST> RAWParserTreeNodeFactory: 0 free, 0 already reused, 0 created
RAWST>  125  46  46  47  47  78  31  78  47  93
RAWST> RAWParserTreeNodeFactory: 0 free, 0 already reused, 0 created

[2016-03] with 3 files:
RAWST>  830  295  290  271  271  316  279  295  427  261
RAWST> RAWParserTreeNodeFactory: 295000 free, 5187500 already reused, 294970 created
RAWST> mem=24.450584 MB
RAWST> dt 4634 ms

RAWST> NEW Tree   quicker with the new singleton
RAWST>  602  235  237  244  244  264  247  247  388  244
RAWST> RAWParserTreeNodeFactory: 295000 free, 5187500 already reused, 294970 created
RAWST> mem=24.449711999999998 MB
RAWST> dt 4054 ms

RAWST> NEW Tree   without synchronized
RAWST>  550  227  221  233  226  254  232  238  365  233
RAWST> RAWParserTreeNodeFactory: 295000 free, 5187500 already reused, 294970 created
RAWST> mem=24.449807999999997 MB
RAWST> dt 3877 ms

RAWST>  540  241  235  242  249  263  249  249  384  255
RAWST> RAWParserTreeNodeFactory: 295000 free, 5187500 already reused, 294970 created
RAWST> mem=24.449783999999998 MB
RAWST> dt 4011 ms


  */
  public static void testNewRAWTree() throws Exception
  {

     List<File> ftp = new ArrayList<File>();
     ftp.add( new File("C:/STH/projects/tide/src/tide/editor/MainEditorFrame.java") );
     ftp.add( new File("C:/STH/projects/tide/src/com/github/javaparser/ASTParser.java") );
     ftp.add( new File("C:/STH/projects/tide/src/javaparser/javacc_gen/JavaParser.java") );

     System.out.println("NEW Tree");
     long um = SysUtils.getUsedMemory();

     long t00 = System.currentTimeMillis();

      for(int i=0; i<10; i++)
      {
        long t0 = System.currentTimeMillis();
        for(File f: ftp)
        {
           FileReader sr = new FileReader(f);
           javaparser.javacc_gen.JavaParser pa = new javaparser.javacc_gen.JavaParser(sr);
           pa.disable_tracing();

           RAWSyntaxTree st = new RAWSyntaxTree("??javaName??");  // 1/3 pf the global time, i.e. 2 times faster than parse
           pa.parserOutputProcessor = st;
           pa.CompilationUnit();
           st.terminateRecurse();
        }
        System.out.print(" "+(System.currentTimeMillis()-t0)+" ");

      }
      System.gc();
      try{ Thread.sleep(1000); } catch(InterruptedException ex) {  }

      System.out.println("\n"+ RAWParserTreeNodeFactory.getInstance() );
      System.out.println("mem="+((SysUtils.getUsedMemory()-um)*1e-6)+" MB");
      System.out.print("dt "+(System.currentTimeMillis()-t00)+" ms");
  }




}