package javaparser;

import java.awt.*;

/** Used for main modifiers, ... implements, warnings, errors, extends, ...
*/
public class MainNode extends ParserTreeNode
{
  public String iconName;
  public Color iconColor;

  public MainNode(String name, String iconName, Color iconColor, boolean expandInView)
  {
    super(name);
    this.expandInView = expandInView;
    this.iconName = iconName;
    this.iconColor = iconColor;
    this.expandInView = true;
  }


@Override
  public void terminate()
  {
    super.terminate();
    iconName = null;
    iconColor = null;
  }

}