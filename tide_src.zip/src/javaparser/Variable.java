package javaparser;

import javaparser.javacc_gen.*;


public class Variable
{
  public final String type;   // ex: "double"   or "Vector<String>"
  public final String name;   // ex: "a"

  public Token startDecl, endDecl;
  // for loal variables: from the decl up to the next "}" for params: constructor or method bloc
  public Token startValidity, endValidity;


  public Variable(String type, String name)
  {
    this.type = type;
    this.name = name;
  }

  /** for loops, local declarations, ...
  *
  public static Variable parseFromLocalVariableDeclarationNode(ParserTreeNode lvdn)
  {
    return null;
  }*/

}