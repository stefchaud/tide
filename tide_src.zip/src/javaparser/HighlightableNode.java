package javaparser;

/** Used to let user mark Methods, Fields, and Type nodes.
*
*/
public interface HighlightableNode
{
   /** A unique and representation independent name (not the tree node names!).
   *   Is used to store which nodes are highlighted.
   */
    String getFullJavaID();

    void setHighlighted(boolean is);

    boolean isHighlighted();

}