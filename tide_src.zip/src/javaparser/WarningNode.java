package javaparser;

import tide.editor.UIConstants;

public final class WarningNode extends MainNode
{
  final String warning;
  public int gravity = 1;

  public WarningNode(String warning, int gravity)
  {
     super("", "W", UIConstants.red, true);
     this.warning = warning;
     this.gravity = gravity;
  }

  @Override
  public String toString()
  {
    return warning;
  }

}