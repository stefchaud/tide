package javaparser;

import tide.editor.MainEditorFrame;
import javaparser.javacc_gen.Token;
import java.util.*;

public final class TreeUtils
{
  private TreeUtils()
  {
  }

  /** Be careful, the spaces are not tokens, therefore no space will be matched by any token.
      it is better to use the parsed simplified Nodes to scan in which block some input is rather than to
      search for an exact token match.
      @param line starts with 1
  */
  public static boolean contains(Token t, int line, int col)
  {
    if(t==null) return false;
    if(line < t.beginLine) return false;
    if(line > t.endLine)   return false;
    if(line==t.beginLine && col<t.beginColumn) return false;
    if(line==t.endLine && col>t.endColumn) return false;

    return true;  // ok !
  }

  /** can be boosted a little bit...
  */
  public static boolean isTokenContainingOrAfter(Token t, int line, int col)
  {
    if(contains(t,line,col)) return true;

    // true if token is AFTER !
    if(line < t.beginLine) return true;
    if(line==t.beginLine && col<t.beginColumn) return true;

    return false;  // ok !
  }


  /** allow in or just after (1 line)
  */
  public static boolean isPositionInOrJustAfter(Token t, int line, int col)
  {
    if(t==null) return false;

    if(contains(t,line,col)) return true;

    // so we know that it doesn't contain the pos, we just return if the pos is after

    if(t.endLine <= line && t.endLine+1 >= line) return true;

    return false;
  }

  /** @param line starts with 1
  */
  public static boolean contains(ParserTreeNode t, int line, int col)
  {
    if(t==null) return false;
    if(line  < t.getStartLinCol()[0]) return false;
    if(line  > t.getEndLinCol()[0])   return false;
    if(line == t.getStartLinCol()[0] && col<t.getStartLinCol()[1]) return false;
    if(line == t.getEndLinCol()[0]   && col>t.getEndLinCol()[1]) return false;

    return true;  // ok !
  }



  /** search for a token containing exactely the position. (DEPTH FIRST => ???)
      often don't exist ! use only for debug and completion type discover (IDResolver) in the RAW syntax tree (=tn)
      BETTER: use getFirstNodeBeforePosition to allow some tolerance when completing with old raw trees
  */
  public static RAWParserTreeNode getNodeTokenContaining(RAWParserTreeNode tn, int line, int col)
  {
     if(tn.isToken() && contains(tn.getToken(), line, col)) return tn;

     for(int i=0; i<tn.getChildCount(); i++)
     {
        RAWParserTreeNode found = getNodeTokenContaining(tn.getChildNodeAt(i), line, col);
        if(found!=null) return found;
     }

     //not found
     return null;
  }


  /** The node containing or just before
      getNodeTokenContaining often don't exist,
      this did sometimes more often exist :-)  !!
      especially when editing (inserting text chars) and using an old tree
      NOT WORKING WELL, TOO IMPRECISE ! use getTokenNodeAtOrAfterPosition instead !!!
  */@tide.annotations.Recurse
  public static ParserTreeNode getFirstTokenNodeBeforePosition(ParserTreeNode tn, int line, int col)
  {
     if(tn.isToken() && isPositionInOrJustAfter(tn.getToken(), line, col)) return tn;

     for(int i=0; i<tn.getChildCount(); i++)
     {
        ParserTreeNode found = getFirstTokenNodeBeforePosition(tn.getChildNodeAt(i), line, col);
        if(found!=null) return found;
     }

     //not found
     return null;
  }

  /** The node containing or just after the given position.
  *   Robust when the RAW tokens tree is walked down (depth first), this returns the first element direct after the position.
  */
  @tide.annotations.Recurse
  public static RAWParserTreeNode getTokenNodeAtOrAfterPosition(RAWParserTreeNode tn, int line, int col)
  {
     if(tn.t !=null && isTokenContainingOrAfter(tn.t, line, col)) return tn;

     for(int i=0; i<tn.getChildCount(); i++)
     {
        RAWParserTreeNode found = getTokenNodeAtOrAfterPosition(tn.getChildNodeAt(i), line, col);
        if(found!=null) return found;
     }

     //not found
     return null;
  }


  /** Walk up in the RAW tree and return the next declarator (LocalVariableDeclaration or FormalParameter node)
  *  maybe raw, in a for loop, in a method, ...
  * Previous means that the tree is only looked at previous siblings (and then down) and node up !
  * actually, this only looks backward for types declared before the position of "from". that means that this is only suitable for variables,
  *  not for fields or methds that have a bigger scope (class).
  * @param methodCallsOnly true if you know that you're searching for a method call like "hello(12)", use name="hello", methodCallsOnly=true
  */
  public static String searchTypeForVariableName(RAWParserTreeNode fromInRAW, String name, boolean methodCallsOnly)
  {
     List<RAWParserTreeNode> nodePreviousSiblings = null;
     RAWParserTreeNode actualNode = fromInRAW;

     if(!methodCallsOnly)
     {
        // recurse the tree back
     sr:while(actualNode!=null)
        {
           // first look in the parent node itself
           String type = lookInBranchForTypeForParameter(actualNode, name);
           if(type!=null) return type;

           // look at siblings (recurse !)
           nodePreviousSiblings = getPreviousSiblings(actualNode);
           if(nodePreviousSiblings==null) break sr; // root
           //System.out.println("Siblings: "+nodePreviousSiblings);

           for(RAWParserTreeNode sn : nodePreviousSiblings)
           {
              // looks down !
              type = lookInBranchForTypeForParameter(sn, name);
              if(type!=null) return type;
           }

           // go one step higher in the tree
           actualNode = actualNode.parent;
           if(actualNode.parent==null) break sr;  //ROOT
        }
     }

     // not found in the variables => caller must look in the methods and fields of the class
     return null;
  }

  /** Walk up in the RAW tree and return the next declarator (LocalVariableDeclaration or FormalParameter node)
  *  maybe raw, in a for loop, in a method, ...
  * Previous means that the tree is only looked at previous siblings (and then down) and node up !
  * actually, this only looks backward for types declared before the position of "from". that means that this is only suitable for variables,
  *  not for fields or methds that have a bigger scope (class).
  *
  * STOPS AT FIRST METHOD DECL !
  * all variables dclared after fromInRAW are ignored !
  */
  public static void collectLocalVariablesBefore(RAWParserTreeNode fromInRAW, int beforeLine, java.util.List<Parameter> params)
  {
     List<RAWParserTreeNode> nodePreviousSiblings = null;
     RAWParserTreeNode actualNode = fromInRAW;

        // recurse the tree back
     sr:while(actualNode!=null)
        {
           //System.out.println("Look in branch "+actualNode);
           // first look in the parent node itself
           lookInBranchForParameters(actualNode, beforeLine, params);

           // look at siblings (recurse !)
           nodePreviousSiblings = getPreviousSiblings(actualNode);
           if(nodePreviousSiblings==null) break sr; // root

           //System.out.println("Siblings: "+nodePreviousSiblings);

           for(RAWParserTreeNode sn : nodePreviousSiblings)
           {
              // looks down !
              lookInBranchForParameters(sn, beforeLine, params);
           }

           // go one step higher in the tree
           actualNode = actualNode.parent;
           if(actualNode.parent==null) break sr; // ROOT

           if(actualNode.toString().equals("MethodDeclaration"))
           {
             // TODO: maybe let jump higher in tree, because of anonymous classes !
             break sr;
           }

        }

     // not found in the variables => caller must look in the methods and fields of the class
  }

  /** recursive look for parameters. Used for completion of local variables (F2)
  *   slow, collect all but methods and fields (only preceedings)
  *   TODO: limit to scopes !
  */
  public static void lookInBranchForParameters(RAWParserTreeNode from, int beforeLine, java.util.List<Parameter> params)
  {
     for(int i=0; i<from.getChildCount(); i++)
     {
        RAWParserTreeNode ptn = from.getChildNodeAt(i);
        if(ptn.toString().equals("FormalParameter"))
        {
           Parameter parameter = Parameter.parseFromFormalParamNode(ptn);
           //System.out.println("** Param: "+parameter);
           if(parameter!=null && !parameter.isParameterAfterLine(beforeLine)) params.add(parameter);
        }
        else if(ptn.toString().equals("LocalVariableDeclaration"))
        {
           Parameter parameter = Parameter.parseFromLocalVariableDeclaration(ptn);
           //System.out.println("** Param loc var : "+parameter);
           if(parameter!=null && !parameter.isParameterAfterLine(beforeLine)) params.add(parameter);
        }
        /*else if(ptn.toString().equals("FieldDeclaration"))  // not necessary...
        {
           Parameter parameter = Parameter.parseFromFieldDeclaration(ptn);
           //System.out.println("** Param field : "+parameter);
           if(parameter!=null) params.add(parameter);
        }*/
        else if(ptn.toString().equals("ForStatement"))
        {
           Parameter parameter = Parameter.parseFromForStatementDeclaration(ptn);
           //System.out.println("** Param for for loop : "+parameter);
           // param may be null because some for statement doesn't initialize variables
           if(parameter!=null && !parameter.isParameterAfterLine(beforeLine)) params.add(parameter);
        }
        /*else if(ptn.toString().equals("MethodDeclaration"))  // not necessary...
        {
           Parameter parameter = Parameter.parseFromMethodDeclaration(ptn);
           if(parameter!=null && !parameter.isParameterAfterLine(beforeLine)) params.add(parameter);
        }*/
        else
        {
           // recurse (TODO: limit to some nodes, look in the raw tree for "ideas" )
           lookInBranchForParameters(ptn, beforeLine, params);
        }
     }
  }

  /** this look into the RAW tree (down) for parameters with the given name.
  *  quick because stops at first occurence.
  *  (TODO: some nodes have no chance to contain parameters => abort!)
  *  this is also not efficient for method and fields (look in the simplified tree instead !)
  */
  public static String lookInBranchForTypeForParameter(RAWParserTreeNode from, String name)
  {
     //System.out.println("Look in "+from+" for "+name);
     for(int i=0; i<from.getChildCount(); i++)
     {
        RAWParserTreeNode ptn = from.getChildNodeAt(i);
        if(ptn.toString().equals("FormalParameter"))
        {
           Parameter parameter = Parameter.parseFromFormalParamNode(ptn);
           //System.out.println("** Param: "+parameter);
           if(parameter.name.equals(name)) return parameter.type;
        }
        else if(ptn.toString().equals("LocalVariableDeclaration"))
        {
           Parameter parameter = Parameter.parseFromLocalVariableDeclaration(ptn);
           //System.out.println("** Param loc var : "+parameter);
           if(parameter.name.equals(name)) return parameter.type;
        }
        else if(ptn.toString().equals("FieldDeclaration"))  // not necessary...   + subtle bug: also reacts on classes named "FieldDeclaration" as in the japa AST
        {
           Parameter parameter = Parameter.parseFromFieldDeclaration(ptn);
           //System.out.println("** Param field : "+parameter);
           if(parameter!=null && parameter.name.equals(name)) return parameter.type;
        }
        else if(ptn.toString().equals("ForStatement"))
        {
           Parameter parameter = Parameter.parseFromForStatementDeclaration(ptn);
           //System.out.println("** Param for for loop : "+parameter);
           // param may be null because some for statement doesn't initialize variables
           if(parameter!=null && parameter.name.equals(name)) return parameter.type;
        }
        else if(ptn.toString().equals("MethodDeclaration"))  // not necessary...
        {
           Parameter parameter = Parameter.parseFromMethodDeclaration(ptn);
           if(parameter!=null)
           {
             //System.out.println("** Param for method : "+parameter);
             if(parameter.name.equals(name)) return parameter.type;
           }
           else
           {
              MainEditorFrame.debugOut("No param for method !!");
           }
        }
        else
        {
           // recurse (TODO: limit to some nodes, look in the raw tree for "ideas" )
           String found = lookInBranchForTypeForParameter(ptn, name);
           if(found!=null) return found;
        }
     }
     // not found
     return null;
  }

  /** @return null if no parent found for from
  *   (order = first element is the just preceding)
  */
  private static /*@org.checkerframework.checker.nullness.qual.Nullable*/ List<RAWParserTreeNode> getPreviousSiblings(RAWParserTreeNode from)
  {
     List<RAWParserTreeNode> ps = new ArrayList<RAWParserTreeNode>();
     RAWParserTreeNode parent = from.parent;
     if(parent==null) return null;

     int pos = parent.getIndex(from);
     for(int i=pos-1; i>=0; i--)  // pos-1 because we really want from the previous, NOT  !
     {
        ps.add (parent.getChildNodeAt(i));
     }

     return ps;
  }


  /** Search for a token containing exactely the position.
      often don't exist ! use only for debug
  */
  public static /*@org.checkerframework.checker.nullness.qual.Nullable*/ ParserTreeNode getBlokContaining(ParserTreeNode tn, int line, int col)
  {
     if(tn.isToken() && contains(tn.getToken(), line, col)) return tn;

     for(int i=0; i<tn.getChildCount(); i++)
     {
        ParserTreeNode found = getBlokContaining(tn.getChildNodeAt(i), line, col);
        if(found!=null) return found;
     }

     //not found
     return null;
  }

  /** @param classOrInterface may also be an enum or an annotation.
  */
  public static List<ParserTreeNode> getAllMethodsAndFieldsForType(ParserTreeNode classOrInterface)
  {
     // collect all childs
     //
     List<ParserTreeNode> allMethodsAndFields = new ArrayList<ParserTreeNode>();
     for(int i=0; i<classOrInterface.getChildCount(); i++)
     {
        ParserTreeNode ni = classOrInterface.getChildNodeAt(i);

        /*old

        if(ni instanceof MainModifierNode)  // public, private, prot, packsc
        {
           for(int j=0; j<ni.getChildCount(); j++)
           {
             allMethodsAndFields.add( ni.getChildNodeAt(j) );
           }
        }
        */

        // new:
        allMethodsAndFields.add( ni );

     }
     return allMethodsAndFields;
  }

  /** This do NOT look in the raw tree. Returns the first containing.
    Depth first recursive search
  */
  @tide.annotations.Recurse
  public static ParserTreeNode getNearestSimplifiedNode(ParserTreeNode node, int line, int col)
  {
     if(node.isRawTreeRoot) return null;

     // depth first
     for(int i=0; i<node.getChildCount(); i++)
     {
        ParserTreeNode ci = node.getChildNodeAt(i);

        ParserTreeNode found = getNearestSimplifiedNode(ci, line, col);

        if(found!=null) return found;
     }

     if(contains(node, line, col)) return node;
     return null;
  }

  public static ParserTreeNode getChildWithStringRep(ParserTreeNode tn, String str)
  {
     for(int i=0; i<tn.getChildCount(); i++)
     {
        ParserTreeNode tni = tn.getChildNodeAt(i);
        if(tni.toString().equals(str)) return tni;
     }
     //not found
     return null;
  }

}