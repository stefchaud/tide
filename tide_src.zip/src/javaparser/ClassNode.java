package javaparser;

import snow.utils.StringUtils;
import tide.editor.MainEditorFrame;
import javaparser.javacc_gen.*;
import java.util.*;
import tide.syntaxtree.*;

/** Class or Interface.
*/
public final class ClassNode extends TypeNode
{
  public String classOrInterface, name, fullName;
  final public boolean isInterface;
  public final int[] modifiers;
  public final String typeparameters;
  public List<String> implementsList = new ArrayList<String>();
  public List<String> extendsList    = new ArrayList<String>();
  private String extendsImplementsText = "";
  // used in ID chain
  public String extendsText= null;

  public String shortNameForTreeIcon = "";

  SimplifiedJapaTree sst = null;

  /** The main category of modifier
  */
  enum MainModifier {Public, Private, Protected, PackageScope}


  public ClassNode(SimplifiedJapaTree sst, RAWParserTreeNode classOrInterfaceDeclarationNode,
                   RAWParserTreeNode modNode, final ParserTreeNode destination, TypeNode parentType)
  {
     super("class or interface", parentType, classOrInterfaceDeclarationNode);

     this.sst = sst;
     this.sortPriority = 4;
     this.expandInView = true;

     RAWParserTreeNode classOrInterfaceN = classOrInterfaceDeclarationNode.getChildNodeAt(0);
     RAWParserTreeNode nameN = classOrInterfaceDeclarationNode.getChildNodeAt(1);

     if(modNode.getChildCount()>0)
     {
        this.modifiers = CCTreeUtils.getAllModifiers(modNode);
        this.setStartPosFrom( CCTreeUtils.getFirstSubchild(modNode) );
     }
     else
     {
        this.setStartPosFrom( CCTreeUtils.getFirstSubchild(classOrInterfaceN) );
        modifiers = new int[0];
     }

     this.classOrInterface = classOrInterfaceN.toString();
     isInterface = this.classOrInterface.equalsIgnoreCase("interface");
     this.name = nameN.toString();

     StringBuilder fn = new StringBuilder();
     if(parentType!=null)
     {
        fn.append(parentType.getJavaFullName());
        fn.append("$"); // inner classes
     }
     else
     {
        fn.append(sst.packageNode.toString());
        if(fn.length()>0) fn.append(".");  // may be the root package (no name)
     }

     fn.append(name);

     fullName = fn.toString();


     if(parentType==null)
     {
        destination.add(this);  // [Jan2007]: was only unsorted
     }
     else
     {
        Utils.sortedInsert(this, destination); // try... ??? not always fine...
     }

     RAWParserTreeNode tpNode = CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(classOrInterfaceDeclarationNode, "TypeParameters");
     if(tpNode!=null)
     {
       this.typeparameters = CCTreeUtils.getImageOfAllSubElements(tpNode);
     }
     else
     {
        this.typeparameters = "";
     }

     RAWParserTreeNode ciNode = CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(classOrInterfaceDeclarationNode, "ClassOrInterfaceBody");
     if(ciNode!=null)
     {
        //System.out.println("has ClassOrInterfaceBody");
        this.parseClassOrInterfaceBody( ciNode );
     }

     RAWParserTreeNode impNode = CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(classOrInterfaceDeclarationNode, "ImplementsList");
     if(impNode!=null)
     {
        this.implementsList = CCTreeUtils.collectIdentifiers( impNode, "ClassOrInterfaceType");
        extendsImplementsText += " impl "+StringUtils.concatenate(implementsList, ", ");

     }

     RAWParserTreeNode extNode = CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(classOrInterfaceDeclarationNode, "ExtendsList");
     if(extNode!=null)
     {

        this.extendsList = CCTreeUtils.collectIdentifiers( extNode, "ClassOrInterfaceType");
        extendsText = StringUtils.concatenate(extendsList, ", ");
        extendsImplementsText += " ext "+ extendsText;

     }

     shortNameForTreeIcon = (isInterface ? "I" : "K") + Utils.getModifiersShortString(modifiers);
  }


  /** Call this to help GC !
  */
@Override
  public void terminate()
  {
    super.terminate();

    implementsList.clear();
    extendsList.clear();

    extendsImplementsText = null;
    extendsText = null;

    classOrInterface = null;
    name = null;
    fullName = null;

  }

  @Override
  public String toString()
  {
     return //[April2008]: now in node: modifiers+" "
        name + typeparameters + extendsImplementsText;
  }

  /** the simple name... without the parent, even for inner classes.
  */
  @Override
  public String getTypeSimpleName()
  {
    return name;
  }

  /** With the package name.
  */
@Override
  public String getJavaFullName()
  {
     return fullName;
  }
@Override
  public int[] getModifiers() { return this.modifiers; }
@Override
  public boolean isPublic() { return Utils.isPublic( modifiers ); }
  public boolean isPrivate() { return Utils.isPrivate( modifiers ); }
  public boolean isProtected() { return Utils.isProtected( modifiers ); }
  public boolean isStatic() { return Utils.isStatic( modifiers ); }

  /** Parse the fields, enums, methods, constructors and add them to this class,
      removing original nodes
  */
  private void parseClassOrInterfaceBody(RAWParserTreeNode classOrInterfaceBodyNode)
  {

     this.setEndPosFrom( CCTreeUtils.getLastSubchild(classOrInterfaceBodyNode) );  // normally "}"

     for(int i=0; i<classOrInterfaceBodyNode.getChildCount(); i++)
     {
       RAWParserTreeNode ni = classOrInterfaceBodyNode.getChildNodeAt(i);
       if(ni.getTokenKind()==JavaParserConstants.LBRACE)  // {
       {
          blokStart = ni.t;
       }
       else if(ni.getTokenKind()==JavaParserConstants.RBRACE)
       {
          blokEnd = ni.t;
       }
       else if(ni.toString().equals( "ClassOrInterfaceBodyDeclaration"))
       {
          if(ni.getChildCount()==1)
          {
            // special cases
            RAWParserTreeNode ci = ni.getChildNodeAt(0);
            if(ci.toString().equals(";"))
            {
               /*
              if(MainEditorFrame.getInstance().getSyntaxTreePanel().enableParserWarnings.isSelected())
              {
                WarningNode warn = new WarningNode("unuseful semicolon", 2);
                warn.setStartPosFrom( CCTreeUtils.getFirstSubchild(ni.getChildNodeAt(0)) );
                warn.setEndPosFrom( CCTreeUtils.getFirstSubchild(ni.getChildNodeAt(0)) );
                sst.addWarning(warn);
              }
              */
              continue;
            }
            else if(ci.toString().equals("Initializer"))
            {
              addClassOrInterfaceBodyDeclaration(sst, ni, this/*privateChilds*/, this);
              continue;
            }
          }

          RAWParserTreeNode modNode = CCTreeUtils.getFirstSubchildNamed_ONLYInDirectChilds(ni, "Modifiers");
          if(modNode==null)
          {
             System.out.println("No modifier node found ! "+this.toString());
             addClassOrInterfaceBodyDeclaration(sst, ni, this/*protectedChilds*/, this);
          }
          else
          {
           switch( getModifier(modNode ))
           {
              // [March2008]: direct add to this instead of the modifier !
             case Public:       addClassOrInterfaceBodyDeclaration(sst, ni, this/*publicChilds*/, this); break;
             case Private:      addClassOrInterfaceBodyDeclaration(sst, ni, this/*privateChilds*/, this ); break;
             case Protected:    addClassOrInterfaceBodyDeclaration(sst, ni, this/*protectedChilds*/, this); break;
             case PackageScope: addClassOrInterfaceBodyDeclaration(sst, ni, this/*packageScopeChilds*/, this); break;
           }
          }

          // analyse field, method, constructor, ...
       }
     }

  }


  public MainModifier getModifier(ParserTreeNode modifNode)
  {
     if( classOrInterface.equals("interface") )
     {
        // interface have only public attributes
        return MainModifier.Public;
     }
     if(Utils.getFirstToken_ONLYInDirectChilds(modifNode, JavaParserConstants.PUBLIC)!=null)    return MainModifier.Public;
     if(Utils.getFirstToken_ONLYInDirectChilds(modifNode, JavaParserConstants.PRIVATE)!=null)   return MainModifier.Private;
     if(Utils.getFirstToken_ONLYInDirectChilds(modifNode, JavaParserConstants.PROTECTED)!=null) return MainModifier.Protected;
     return MainModifier.PackageScope;
  }

  public MainModifier getModifier(RAWParserTreeNode modifNode)
  {
     if( classOrInterface.equals("interface") )
     {
        // interface have only public attributes
        return MainModifier.Public;
     }
     if(CCTreeUtils.getFirstToken_ONLYInDirectChilds(modifNode, JavaParserConstants.PUBLIC)!=null)    return MainModifier.Public;
     if(CCTreeUtils.getFirstToken_ONLYInDirectChilds(modifNode, JavaParserConstants.PRIVATE)!=null)   return MainModifier.Private;
     if(CCTreeUtils.getFirstToken_ONLYInDirectChilds(modifNode, JavaParserConstants.PROTECTED)!=null) return MainModifier.Protected;
     return MainModifier.PackageScope;
  }


  /** add all methods, constructors, fields of the body
  *   @param cibd ClassOrInterfaceBodyDeclaration node
       child0 is modifiers
       child1 is one of { EnumDeclaration, ConstructorDeclaration,
          MethodDeclaration, FieldDeclaration,
          ClassOrInterfaceDeclaration }

       special case: static initializer have no modifier node.
       also used in the enum
  */
  public static void addClassOrInterfaceBodyDeclaration(SimplifiedJapaTree sst, RAWParserTreeNode cibd, ParserTreeNode destination, TypeNode parentType)
  {
      RAWParserTreeNode mod = cibd.childs.get(0);
      RAWParserTreeNode decl = null;
      if(mod.toString().equals("Initializer"))
      {
        // special case: static initializer have no modifier node.
        decl = mod;
        mod = null;
      }
      else
      {
        if(cibd.getChildCount()==1)
        {
          System.out.println("Only one child: "+mod.toString()+"  in "+cibd.toString()+" parent type = "+parentType.toString());
          decl = mod;
          mod = null;
        }
        else
        {
          decl = cibd.childs.get(1);
          if(decl.toString().equals("TypeParameter"))  // [Oct2007]
          {
             decl = cibd.childs.get(2);
          }
        }
      }

      if(decl.toString().equals("EnumDeclaration"))
      {
        EnumNode en = new EnumNode(sst, decl, mod, parentType);
        sst.getAllTypes().add(en);
        Utils.sortedInsert(en, destination);
      }
      else if(decl.toString().equals("ConstructorDeclaration"))
      {
        ConstructorNode cn = new ConstructorNode(decl, mod);
        Utils.sortedInsert(cn, destination);
      }
      else if(decl.toString().equals("MethodDeclaration"))
      {
        MethodNode mn = new MethodNode(decl, mod);
        Utils.sortedInsert(mn, destination);
      }
      else if(decl.toString().equals("FieldDeclaration"))
      {
         // childs: {Type, VariableDeclarator}
        FieldNode fn = new FieldNode(decl, mod, destination);
      }
      else if(decl.toString().equals("ClassOrInterfaceDeclaration"))
      {
        // recurse !
        ClassNode cn = new ClassNode(sst, decl, mod, destination, parentType);  // class adds itself to the destination
        // collect all
        sst.getAllTypes().add(cn);
      }
      else if(decl.toString().equals("Initializer"))
      {
        //System.out.println("initializer node found");
        StaticInitializerNode sin = new StaticInitializerNode(decl);
        destination.insert(sin, 0);
      }
      else
      {
        System.out.println("Unknown node found: "+decl.toString()+" in "+parentType.toString());
      }
  }


  /**
      ex: "[modifiers list as ParserConstants...] <T> class MyClass extends XX implements YY,ZZ".
      Used in static analysis.
      Is sufficient for the purpose of dependencies study.
  */
   public String getDetailledSignatureForDepDet()
   {
      StringBuilder sb = new StringBuilder();
      sb.append(Arrays.toString(modifiers));
      sb.append(" ");
      if(typeparameters!=null)
      {
         sb.append(typeparameters);
         sb.append(" ");
      }
      sb.append(this.classOrInterface);
      sb.append(" ");
      sb.append(name);
      sb.append(" ");
      sb.append(this.extendsImplementsText);

      return sb.toString();
   }
}