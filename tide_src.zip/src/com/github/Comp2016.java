package com.github;

import snow.utils.SysUtils;
import javaparser.RAWSyntaxTree;
import javaparser.RAWParserTreeNodeFactory;
import java.io.*;
import java.util.*;

/** class Comp2016.
*/
public final class Comp2016
{

  public static void test1() throws Exception
  {
     List<File> ftp = new ArrayList<File>();
     ftp.add( new File("C:/STH/projects/tide/src/tide/editor/MainEditorFrame.java") );
     ftp.add( new File("C:/STH/projects/tide/src/com/github/javaparser/ASTParser.java") );
     ftp.add( new File("C:/STH/projects/tide/src/javaparser/javacc_gen/JavaParser.java") );

     System.out.println("NEW Tree");
     long um = SysUtils.getUsedMemory();

     long t00 = System.currentTimeMillis();

      for(int i=0; i<10; i++)
      {
        long t0 = System.currentTimeMillis();
        for(File f: ftp)
        {
           FileReader sr = new FileReader(f);
           javaparser.javacc_gen.JavaParser pa = new javaparser.javacc_gen.JavaParser(sr);
           pa.disable_tracing();

           RAWSyntaxTree st = new RAWSyntaxTree("??javaName??");
           pa.parserOutputProcessor = st;
           pa.CompilationUnit();
           st.terminateRecurse();
        }
        System.out.print(" "+(System.currentTimeMillis()-t0)+" ");

      }
      System.gc();
      try{ Thread.sleep(1000); } catch(InterruptedException ex) {  }

      System.out.println("\n"+ RAWParserTreeNodeFactory.getInstance() );
      System.out.println("mem="+((SysUtils.getUsedMemory()-um)*1e-6)+" MB");
      System.out.print("dt "+(System.currentTimeMillis()-t00)+" ms");
  }


  public static void test2() throws Exception
  {
      File f = new File("C:/STH/projects/tide/src/com/github/Comp2016.java");
      long t00 = System.currentTimeMillis();

      FileReader sr = new FileReader(f);
      javaparser.javacc_gen.JavaParser pa = new javaparser.javacc_gen.JavaParser(sr);
      pa.disable_tracing();

      RAWSyntaxTree st = new RAWSyntaxTree("??javaName??");
      pa.parserOutputProcessor = st;
      pa.CompilationUnit();
      st.terminateRecurse();

      System.out.println("\n"+ RAWParserTreeNodeFactory.getInstance() );
      System.out.print("dt "+(System.currentTimeMillis()-t00)+" ms");
  }


  public static void main(final String[] arguments) throws Exception
  {
     test2();

     //test1();
     //test1();
  }

}