package snow.crypto;

import javax.crypto.spec.*;
import javax.crypto.*;

public final class SecretKeyUtilities
{
  private SecretKeyUtilities()
  {
  }

  /** take the first length_in_bytes bytes (*8 = bits) of the sha-1 hash of pass
     WARNING: this is really secret, rehash it to generate a signature
     @param length_in_bytes up to 16 (64 bits) can be used without restrictions
        length_in_bytes>16 requires the unrestricted jce policy (download it from sun)
         make no sense up to 160 bits (20 bytes) because of the use of sha-1
  */
  public static SecretKey generateKeyFromPassphrase(byte[] pass, int length_in_bytes) throws Exception
  {
     byte[] hash = CryptoUtilities.SHA1Hash(pass);
     byte[] wk = new byte[length_in_bytes];
     System.arraycopy(hash, 0, wk, 0, wk.length);
     SecretKeySpec skeySpec = new SecretKeySpec(wk, "Blowfish");
     return skeySpec;
  }

  /** take the 4 first bytes (24 bits) of the hash of the pass
  */
  public static SecretKeyID computeSignature(SecretKey key)
  {
    try
    {
      byte[] hashpass = CryptoUtilities.SHA1Hash(key.getEncoded());
      byte[] sign = new byte[4];
      System.arraycopy(hashpass, 0, sign, 0, sign.length);
      SecretKeyID ski = new SecretKeyID(sign, key.getEncoded().length);
      return ski;
    }
    catch(Exception e)
    {
      throw new RuntimeException("Cannot compute key signature");
    }
  }



}