package snow.crypto;

public class BadPasswordException extends Exception {

    /** Creates a new instance of BadPasswordException */
    public BadPasswordException(String err) {
        super(err);
    }

}