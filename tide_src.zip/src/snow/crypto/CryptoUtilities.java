package snow.crypto;

import java.io.*;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import snow.utils.gui.ProgressModalDialog;
import snow.utils.storage.FileUtils;


public final class CryptoUtilities
{
    private CryptoUtilities()
    {
    }

    public static byte[] MD5Hash(byte[] input)
    {
       try
       {
          MessageDigest md5 = MessageDigest.getInstance("MD5");
          return md5.digest(input);
       }
       catch(Exception e)
       {
          throw new RuntimeException(""+e.getMessage());
       }
    }

    public static byte[] SHA1Hash(byte[] input)
    {
       try
       {
          MessageDigest md = MessageDigest.getInstance("SHA1");
          return md.digest(input);
       }
       catch(Exception e)
       {
          throw new RuntimeException(""+e.getMessage());
       }
    }


 /** Take the first length_in_bytes bytes (*8 = bits) of the sha-1 hash of pass
     WARNING: this is really secret, rehash it to generate a signature
     @param length_in_bytes up to 16 (64 bits) can be used without restrictions
        length_in_bytes>16 requires the unrestricted jce policy (download it from sun)
         make no sense up to 160 bits (20 bytes) because of the use of sha-1

  */
  public static SecretKey generateKeyFromPassphrase(byte[] pass, int length_in_bytes) throws Exception
  {
     byte[] hash = SHA1Hash(pass);
     byte[] wk = new byte[length_in_bytes];
     System.arraycopy(hash, 0, wk, 0, wk.length);
     SecretKeySpec skeySpec = new SecretKeySpec(wk, "Blowfish");
     return skeySpec;
  }

  /** Take the 4 first bytes of the hash of the pass
  */
  public static SecretKeyID computeSignature(SecretKey key)
  {
    try
    {
      byte[] hashpass = SHA1Hash(key.getEncoded());
      byte[] sign = new byte[4];
      System.arraycopy(hashpass, 0, sign, 0, sign.length);
      SecretKeyID ski = new SecretKeyID(sign, key.getEncoded().length);
      return ski;
    }
    catch(Exception e)
    {
      throw new RuntimeException("Cannot compute key signature");
    }
  }

  /** Overwrites the file content with a random buffer.
  * [Nov2008]: if the file is readonly, it will just be deleted
  * [Jan2009]: ONE PASS IS ENOUGH FOR SECURITY !!!
  */
  public static void wipeFile(File f, int bufferSize, /*@org.checkerframework.checker.nullness.qual.Nullable*/ ProgressModalDialog progressDialog)
  {
    final int passes = 1;

    if(!f.canWrite())
    {
       try
       {
          f.setWritable(true);
       }
       catch(Exception e)
       {
          e.printStackTrace();
       }
    }

    long count = 0;  // for the progress
    RandomAccessFile raf = null;
    for(int p=0; p<passes; p++)
    {
       try
       {
           raf = new RandomAccessFile(f, "rw");

           raf.seek(0);
           byte[] buffer = new byte[bufferSize];
           int blocks = (int)(raf.length()/bufferSize)+1;
           for(int i=0; i<blocks; i++)
           {
             fillRandom(buffer);
             raf.write(buffer);
             if(progressDialog!=null && count%passes==1)
             {
               progressDialog.incrementProgress(1);
             }
             count++;
           }
       }
       catch(Exception e)
       {
         e.printStackTrace();
       }
       finally
       {
         FileUtils.closeIgnoringExceptions(raf);
       }
    }

    f.delete();
    if(f.exists())
    {
      System.out.println("Cannot delete the file "+f);
      f.deleteOnExit();
    }
  }

  private static void fillRandom(byte[] buf)
  {
    for(int i=0; i<buf.length; i++)
    {
      buf[i] = (byte) (Math.random()*256);
    }
  }

}