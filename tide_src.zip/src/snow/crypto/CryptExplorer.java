package snow.crypto;

import snow.texteditor.SimpleDocumentView;
import snow.utils.gui.JGridPanel;
import snow.texteditor.SimpleDocument;
import tide.utils.B64;
import snow.concurrent.DelayedMergedUpdater2;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.event.*;
import java.io.File;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;
import javax.swing.*;


/** class CryptoExplorer.
*  read: CON3326_Costlow-javaCrypto.pdf
*/
public final class CryptExplorer extends JFrame
{
   JTabbedPane tabs = new JTabbedPane();

   /** Constructor. */
   public CryptExplorer()
   {
      super("Crypto explorer");

      add(tabs, BorderLayout.CENTER);

      // providers

      tabs.addTab("Digest", exploreDigests());

      tabs.addTab("Coding", exploreCoding());
      tabs.addTab("Decoding", new JLabel("..."));
      //tabs.addTab("PKC", new JLabel("..."));


      setSize(800, 600);
      this.setLocationRelativeTo(null);
      setVisible(true);
   }


   JPanel exploreCoding()
   {
      final JGridPanel gp = new JGridPanel(2);
      return gp;
   }

   JPanel exploreDigests()
   {
      final JGridPanel gp = new JGridPanel(2);

      //hard coded
      //source: look in MessageDigestAlgorithm
      List<String> messageDigestNames = Arrays.asList(
         "MD2", "MD5",
         "SHA-1", "SHA-224", "SHA-256", "SHA-384", "SHA-512",
         //"SHA3_224", "SHA3_256", "SHA3_384", "SHA3_512",
         "Whirpool",
         "ripemd160"
         );

//         MessageDigestAlgorithm.


      //gp.addExplanationArea("Message digests\n"+messageDigestNames);

      SimpleDocument doc = new SimpleDocument();
      doc.append("Message digests (hardcoded)\n"+messageDigestNames+"\n\n");

      for(String dn : messageDigestNames)
      {
         doc.append(""+dn+"\t");
         try
         {

            MessageDigest md = MessageDigest.getInstance(dn);
            doc.append(""+md.getAlgorithm()+"\t"+(md.getDigestLength()*8)+"\t"+md.getProvider());
            doc.appendLine("");
            //doc.appe
         }
         catch(final Exception e) {
            //e.printStackTrace();
            doc.appendErrorLine(""+e.getMessage());
         }
      }

      final SimpleDocumentView sdv = doc.createView(false);
      sdv.packToContent();
   //   sdv.getView().setPreferredSize( sdv.getView().getPreferredSize() );
      sdv.getView().setPreferredSize( new Dimension(400,180) );
      gp.getGridLayout().addUpToLineEnd(sdv.getView());

      gp.addTitleSeparator("test");

      final JComboBox cbmd = new JComboBox(new Vector( messageDigestNames ));
      cbmd.setSelectedItem("SHA-256");
      cbmd.setEditable(true);
      gp.addG("Algo");
      gp.addG(cbmd, false);

      final JTextArea taIn = new JTextArea(4, 10);
      {
        gp.addG("Message (as UTF-8)");
        JScrollPane sp = new JScrollPane(taIn);
        gp.addG(sp);
        //ta.setMinimumSize(new Dimension(400,100));
        sp.setMinimumSize(new Dimension(10,50));   // <= nicer when resizing, otherwise, the scrollbar takes the whole place and the text disapears
      }

      final JTextArea taout = new JTextArea(4, 10);

      {
         taout.setEditable(false);
        gp.addG("Digest");
        JScrollPane sp = new JScrollPane(taout);
        gp.addG(sp);
        //ta.setMinimumSize(new Dimension(400,100));
        sp.setMinimumSize(new Dimension(10,50));   // <= nicer when resizing, otherwise, the scrollbar takes the whole place and the text disapears
      }


      DelayedMergedUpdater2 dmu = new DelayedMergedUpdater2(300, true, new ActionListener() { public void actionPerformed(final ActionEvent ae)
      {
         taout.setText("");
         try{
            MessageDigest md = MessageDigest.getInstance(""+cbmd.getSelectedItem());
            md.update( taIn.getText().getBytes("UTF-8"));
            byte[] dig = md.digest();
            taout.setText("digest: <"+B64.encodeBase64(dig)+">"
              +"\nAlgo: "+md
            );
         }
         catch(final Exception e) {
            taout.setText("Error: "+e.getMessage());
            //e.printStackTrace();
         }
      } });

     cbmd.addActionListener(dmu);
     taIn.getDocument().addDocumentListener(dmu);

      return gp;
   }



   public static void main(String[] args) throws Exception
   {
      EventQueue.invokeLater(new Runnable() { public void run() {
          new CryptExplorer();
      }});
   }
}