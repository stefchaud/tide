package snow.crypto;

import java.util.*;

/** An identifier for a secret key.
*/
public final class SecretKeyID
{
   public byte /*@org.checkerframework.checker.nullness.qual.Nullable*/ [] signature;
   public int key_length;

   public SecretKeyID (byte[] signature, int key_length)
   {
     this.signature = (signature!=null ? signature.clone() : null);
     this.key_length = key_length;
   }

   public byte /*@org.checkerframework.checker.nullness.qual.Nullable*/ [] getKeySignature()
   {
     if(signature==null) return null;
     // pass a copy
     return signature.clone();
   }

   public int getKeyLangth()       { return key_length; }

   @SuppressWarnings("nullness")  //[Aug2009]: checkers error ? stub not working for Arrays.equals(b[], b[])
   @Override
   public boolean equals(Object o)
   {
      if(!(o instanceof SecretKeyID))
      {
        System.out.println("Bad class, not SecretKeyID");
        return false;
      }
      SecretKeyID k2 = (SecretKeyID) o;
      if(k2.key_length != key_length)
      {
        return false;
      }
      if(!Arrays.equals( k2.signature, signature))
      {
        return false;
      }

      return true;
   }
@Override
   public int hashCode()
   {
     if(signature==null) return 0;
     return signature[0]+256*signature[1];
   }


@Override
   public String toString()
   {
      if(signature==null) return  "l="+this.key_length+", null signature.";
     return "l="+this.key_length+", sign={" + signature[0]+", "+signature[1]
                                        +", "+signature[2]+", "+signature[3] + "}";
   }

}