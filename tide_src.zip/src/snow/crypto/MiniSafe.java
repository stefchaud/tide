package snow.crypto;

import snow.texteditor.SimpleDocument;
import snow.utils.StringUtils;
import snow.datatransfer.ClipboardUtils;
import tide.utils.B64;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.*;
import java.io.*;
import java.nio.charset.Charset;
import java.util.*;
import java.util.prefs.Preferences;
import javax.crypto.SecretKey;
import javax.swing.*;
import snow.crypto.SimpleFileEncryptor;
import snow.utils.gui.Icons;
import snow.utils.storage.PrefUtils;
import snow.utils.storage.StorageVector;
import snow.utils.storage.StorageVectorUtils;


/** A mini password protected text safe, typically useful to save passwords.
*
*/
public final class MiniSafe extends JFrame
{

   final private File safeFile;
   final private JTextArea safeArea = new JTextArea();
   private SecretKey skey;
   private boolean quitWithoutSave = false;

   long savedContentHash = -1;

   public MiniSafe(final File safeFile, final boolean standalone)
   {
      super("Mini Safe ["+safeFile+"]");

      this.safeFile = safeFile;
      this.setIconImage( Icons.createImage( Icons.sharedSourceSafe ));

      add(new JLabel("Following content is ciphered on disk using blowfish 128bits", Icons.sharedClosedLock, JLabel.LEFT), BorderLayout.NORTH);
      add(new JScrollPane(safeArea), BorderLayout.CENTER);

      // small contrast more suitable for secrets
      safeArea.setBackground(Color.white);
      safeArea.setForeground(Color.lightGray);


      this.setJMenuBar(new JMenuBar());
      JMenu fileMenu = new JMenu("File");
      this.getJMenuBar().add(fileMenu);

      JMenuItem cpa = new JMenuItem("Change password");
      fileMenu.add(cpa);
      cpa.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         skey = null;
         savedContentHash = -1;
         saveIfNecessary();
      } });

      fileMenu.addSeparator();

      JMenuItem ccc = new JMenuItem("copy encrypted content to clipboard (for archive)");
      fileMenu.add(ccc);
      ccc.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         final PassphraseDialog pd = new PassphraseDialog(MiniSafe.this, "Enter a passphrase to encrypt the content", true, null, "not necessary the same password as used to store locally");
         if(pd.wasCancelled()) return;

         try
         {
           final byte[] enc = SimpleFileEncryptor.encrypt( safeArea.getText().getBytes(Charset.forName("UTF-8")), pd.getKey());
           String bco = B64.encodeBase64( enc);
           ClipboardUtils.copyToClipboard( "Minisafe:\n\n#begin"+bco+"\n#end" );
         }
         catch(final Exception e)
         {
            e.printStackTrace();
           JOptionPane.showMessageDialog(MiniSafe.this, "Err: "+e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
         }
      }});

      JMenuItem dcc = new JMenuItem("decrypt from clipboard (to another dialog)");
      fileMenu.add(dcc);
      dcc.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         try
         {
            String ccont = ClipboardUtils.getClipboardStringContent();
            if(ccont.contains("#begin"))
            {
               ccont = StringUtils.extractFromFirstToNext_Excluded(ccont, "#begin", "#end").trim();
            }
            byte[] cc = B64.decodeBase64(ccont);

            SecretKeyID ski = SimpleFileEncryptor.getKeyIDFromStream(new ByteArrayInputStream(cc));
            final PassphraseDialog pd = new PassphraseDialog(MiniSafe.this, "Enter a passphrase to decrypt the clipboard content", true, ski, "not necessary the same password as used to store locally");
            if(pd.wasCancelled()) return;

            byte[] dc =SimpleFileEncryptor.decryptToMem(new ByteArrayInputStream(cc), pd.getKey(), 256, null );
            SimpleDocument doc = new SimpleDocument();
            doc.setText(new String(dc, Charset.forName("UTF-8")));
            doc.createView(false).displayInDialog(MiniSafe.this, "Decrypted");

         }
         catch(final Exception e)
         {
            e.printStackTrace();
           JOptionPane.showMessageDialog(MiniSafe.this, "Err: "+e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
         }
      }});


      fileMenu.addSeparator();
      JMenuItem quitWithoutSaveMI = new JMenuItem("Quit without save", Icons.sharedCross);
      fileMenu.add(quitWithoutSaveMI);
      quitWithoutSaveMI.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         quitWithoutSave = true;
         setVisible(false);
         dispose();
      } });

      JMenuItem quit = new JMenuItem("Quit", Icons.turnOffIcon16);
      fileMenu.add(quit);
      quit.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         setVisible(false);
         dispose();
      } });


      this.addWindowListener(new WindowAdapter()
      {
         @Override public final void windowClosing( final WindowEvent e ) {
            saveIfNecessary();
            if(standalone) System.exit(0);
         }

         @Override public final void windowClosed( final WindowEvent e ) {
            saveIfNecessary();
            if(standalone) System.exit(0);
         }
      });

      if(!PrefUtils.setSizeAndLoc(this, "MainFrame", Preferences.userNodeForPackage(MiniSafe.class)))
      {
        setSize(370, 200);
        setLocationRelativeTo(null);
      }

      setVisible(true);

      load();
   }


   void load()
   {
      if(!safeFile.exists())
      {
        // Initialization
        safeArea.setText("what \twhen \tuser \tpass\n\nfile does not exist, will be created on close");
        safeArea.setCaretPosition(safeArea.getText().length());
        return;
      }

      // decipher if it is
      SecretKeyID skid = null;
      try {
         skid = SimpleFileEncryptor.getKeyIDFromFile(safeFile);

         PassphraseDialog pd = new PassphraseDialog(this, "Enter the password", true, skid, "");
         if(pd.wasCancelled())
         {
           // just exit
           quitWithoutSave = true;
           dispose();
           return;
         }

         if(!pd.matchesID())
         {
           throw new Exception("Wrong Password");
         }

         skey = pd.getKey();

         final byte[] content = SimpleFileEncryptor.decryptFileToMem(safeFile, skey, 256, null);

         try
         {
            createFromByteRep(content);
         }
         catch(final Exception e)
         {
            System.out.println("OLD format read");
            // old for compatibility
            safeArea.setText(new String(content, Charset.forName("UTF-8")));
         }

         savedContentHash = safeArea.getText().hashCode();

      }
      catch(Exception e)
      {
         quitWithoutSave = true;
         JOptionPane.showMessageDialog(this, "Can`t read:\n"+e.getMessage(), "MiniSafe Error", JOptionPane.ERROR_MESSAGE);
         dispose();
         return;
         // not encrypted
      }

      //
   }

   void saveIfNecessary()
   {
      if(quitWithoutSave) return;

      PrefUtils.saveSizeAndLoc(this, "MainFrame", Preferences.userNodeForPackage(MiniSafe.class));

      if(safeArea.getText().hashCode()==savedContentHash) return;

      save();
   }


   void save()
   {
      if(skey==null)
      {
         PassphraseDialog pd = new PassphraseDialog(this, "Enter the password to save", true, null, "");
         if(pd.wasCancelled()) return;
         try{
            skey = pd.getKey();
         }
         catch(final Exception e) {
            e.printStackTrace();
            return;
         }
      }

      final String toStore =  safeArea.getText();

      if(!safeFile.getParentFile().exists())
      {
         safeFile.getParentFile().mkdirs();
      }

      try{
         SimpleFileEncryptor.encrypt(getStoredByteRep(), safeFile, skey);

         // old.
         //SimpleFileEncryptor.encrypt(toStore.getBytes(Charset.forName("UTF-8")), safeFile, skey);

         // ok.
         savedContentHash = toStore.hashCode();
      }
      catch(final Exception e) {
         e.printStackTrace();
         savedContentHash = -1;
      }
   }

   private List<?> getStoredRep()
   {
      List<Object> rep = new ArrayList<Object>();
      rep.add(1);
      rep.add(safeArea.getText());
      //rep.add(System.currentTimeMillis());  // last view

      return rep;
   }

   private byte[] getStoredByteRep() throws Exception
   {
         ByteArrayOutputStream baos = new ByteArrayOutputStream(4096);
         DataOutputStream dos = new DataOutputStream(baos);
         StorageVectorUtils.vectorToStream(dos, getStoredRep());
         dos.flush();
         baos.flush();

         return baos.toByteArray();
   }

   private void createFromByteRep(byte[] rep) throws Exception
   {
      ByteArrayInputStream bais = new ByteArrayInputStream(rep);
      DataInputStream dis = new DataInputStream(bais);
      StorageVector sv = new StorageVector();
      StorageVectorUtils.streamToVector(dis, sv);

      int version = (Integer) sv.get(0);

      safeArea.setText((String) sv.get(1));
      safeArea.setCaretPosition(0);
   }


   public static void main(String[] args) throws Exception
   {
      // tempor
      new MiniSafe(new File("c:/temp/def.minisafe"), true);
   }

}