package snow.crypto;

import javax.swing.event.*;
import javax.swing.event.DocumentListener;
import snow.utils.gui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.crypto.*;
import javax.swing.border.*;

/** Ask for a passphrase. automatically validate if sign matches.
*   Use it to get passwords for deciphering.
*   Use NewPassphraseDialog to get new passwords for ciphering (with validation).
*/
public final class PassphraseDialog extends JDialog
{

  final int      fontSize = UIManager.getFont("Label.font").getSize();
  JPasswordField passField = new JPasswordField(20);
  JTextArea      explanationArea = new JTextArea();
  final CloseControlPanel ccp;

  final SecretKeyID    skid;

  /** @param skid null if no verification should be made here
  *
  */
  public PassphraseDialog( JFrame owner,
                      String title,
                      boolean isModal, SecretKeyID skid, String explanation )
  {
    super(owner,title,isModal);
    this.skid = skid;
    explanationArea.setText(explanation);

    ccp = new CloseControlPanel(this, true, true, "ok");
    init();
  }

  public PassphraseDialog( JDialog owner,
                      String title,
                      boolean isModal, SecretKeyID skid, String explanation )
  {
    super(owner,title,isModal);
    this.skid = skid;
    explanationArea.setText(explanation);

    ccp = new CloseControlPanel(this, true, true, "ok");
    init();

  }

  private void init()
  {
    JPanel cp = new JPanel(new BorderLayout());
    setContentPane(cp);
    cp.setBorder(new EmptyBorder(fontSize/2, fontSize/2, fontSize/2, fontSize/2));

    // South
    add(ccp, BorderLayout.SOUTH);

    // North
    add(this.explanationArea, BorderLayout.NORTH);
    explanationArea.setOpaque(false);
    explanationArea.setEditable(false);
    explanationArea.setBackground(cp.getBackground());

    add(new JLabel(Icons.sharedClosedLock), BorderLayout.WEST);

    // Center

    GridLayout3 grid = new GridLayout3(3);
    {
       JPanel centerPanel_ = grid.getTargetPanel();
       add(centerPanel_, BorderLayout.CENTER);
       grid.setColumnWeights(new double[]{1,100,1});
       //JPanel centerPanel = new JPanel(new GridLayout(1,2, fontSize/2, fontSize/2));
       centerPanel_.setOpaque(false);
       centerPanel_.setBorder(new EmptyBorder(fontSize/2, fontSize/2, fontSize/2, fontSize/2));
    }

    grid.add("Passphrase");
    grid.add(passField, true);
    passField.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        terminate();
      }
    });


    if(skid!=null)
    {

       passField.getDocument().addDocumentListener(new DocumentListener()
       {
          public final void insertUpdate( final DocumentEvent e ) {
             analyse();
          }
          public final void removeUpdate( final DocumentEvent e ) {
             analyse();
          }
          public final void changedUpdate( final DocumentEvent e ) {
             analyse();
          }

          void analyse()
          {
            if(matchesID())
            {
               ccp.setOkEnabled(true);
               ccp.setOkBackground(Color.green);

               // TURBO !
               terminate();
            }
            else
            {
               ccp.setOkEnabled(false);
               ccp.setOkBackground(Color.red);
            }
          }
      });
      ccp.setOkEnabled(false);
      ccp.setOkBackground(Color.red);
    }

    this.pack();
    this.setLocationRelativeTo(this.getOwner());

    this.addComponentListener(new ComponentAdapter()
    {
      public void componentShown(ComponentEvent e)
      {
        passField.requestFocus();
      }
    });

    this.setVisible(true);
  } // init

  public boolean wasCancelled()
  {
    return ccp.getWasCancelled();
  }

  public boolean matchesID()
  {
    if(this.skid==null) return false;
    try
    {
      SecretKeyID skid2 = CryptoUtilities.computeSignature(getKey());
      return skid2.equals(skid);
    }
    catch(Exception e)
    {
      return false;
    }
  }

  public SecretKey getKey() throws Exception
  {
    byte[] pass = new String(passField.getPassword()).getBytes();
    int len = 16;
    if(skid!=null)
    {
      len = skid.getKeyLangth();
    }
    return CryptoUtilities.generateKeyFromPassphrase(pass, len);
  }


  private void terminate()
  {
    setVisible(false);
  }

  /*test
  @SuppressWarnings("nullness")
  public static void main(String[] arguments) throws Exception {
     new PassphraseDialog(new JFrame(), "Test", true, null, "Enter a passphrase to protect the data");
  }*/


}