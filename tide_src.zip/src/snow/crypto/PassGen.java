package snow.crypto;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.*;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import snow.datatransfer.ClipboardUtils;
import snow.utils.gui.*;

/** Generates secure passwords based on
*
*  a) a base (secret, only to remember)
*  b) the site/domain/pc the pass is for
*  c) some options (not to change, normally)
*
* the output is a truncated string made of a mapping char by byte modulo the alphabet.
*
* look at http://en.wikipedia.org/wiki/Password_strength
* lok at HMAC rfc
*
*/
public final class PassGen extends JDialog
{
   final private JPasswordField pass = new JPasswordField(20);
   final private JTextField site = new JTextField(20);
   final private JTextField customChars = new JTextField();
   final private JTextField salt = new JTextField("some salt", 8);

   final private JTextField generatedPass = new JTextField(20);
   final private JLabel genPassInfoLabel = new JLabel();

   private final JSpinner passSize = new JSpinner();


   final private JLabel errLabel = new JLabel();

   final private JLabel passInfo = new JLabel("Please provide a strong password here, the unique you have to remember.   ** Never use it directly **");


   // user can give MD5 if he really wants...
   final private JComboBox algo = new JComboBox(new String[]{"SHA-1",  "SHA-256", "SHA-512"});
   final private JComboBox coding = new JComboBox(new String[]{
      "hex",
      "ASCII 64",
      "ASCII 94",
      "256 chars (CAUTION)",  // tipp: should try to paste in some username field to check copy paste ops !
      //idea: Chineese 65536 chars !
      "Custom chars"});

    /*ascii94 gen:  for(int i=33; i<127; i++)  // [33-126] (94)  (no space)
      {
         sb.append((char) i);
      } */
   final private String ascii94 = "!\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~";
   // Caution: not compatible with the "base64"
   final private String ascii64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";


   final private String alphabet256 = buildAlphabet256();


   // todo: with iso-latin-1 accents??  (dangerous)
   // todo: UTF-8
   // todo: use chinese chars ?
   public PassGen(boolean standalone, final Window parent)
   {
      this(standalone, parent, null);
   }

   public PassGen(boolean standalone, final Window parent, final String forSite)
   {
      super(parent, "Strong Password Generator v1.1  [nov2016]", JDialog.ModalityType.APPLICATION_MODAL);

      JGridPanel gp = new JGridPanel(2);
      add(gp, BorderLayout.CENTER);

      gp.getGridLayout().addExplanationArea("Algorithm: Hash( Hash( salt + pass) + site )."
         +"\nThe password is then build from the hash, one char per byte (modulo the alphabet).");

      gp.getGridLayout().addTitleSeparator("Input");

      gp.addG("Password (strong secret)");
      gp.addG(pass, false);

      //to warn if too small
      gp.addG("");
      gp.addG(passInfo);

      gp.addG("Site (ex: google.ch)");
      gp.addG(site, false);
      if(forSite!=null) site.setText(forSite);

      gp.getGridLayout().addTitleSeparator("Options  (change with care)");

      gp.addG("Hash Algorithm");
      gp.addG(algo, false);
      algo.setEditable(true);


      gp.addG("Size");
      gp.addG(passSize, false);
      passSize.setValue(14);

      passSize.addChangeListener(new ChangeListener()
      {
         public final void stateChanged( final ChangeEvent e ) {
            updatePass();
         }
      });

      gp.addG("Coding Alphabet");
      gp.addG(coding, false);
      coding.setSelectedIndex(2);
      coding.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         customChars.setEditable( coding.getSelectedIndex()==4 );
         customChars.setVisible( coding.getSelectedIndex()==4 );
         updatePass();
      } });
      customChars.setEditable(false);
      customChars.setVisible(false);

      //bug: resize of paretn frame cause clash in layout !! (?)  (to be fixed in GL3
      //Custom chars
      gp.addG("");
      gp.addG(GUIUtils.wrapLeft(customChars,0));     // how to fix
      StringBuilder sb = new StringBuilder();
      customChars.setText(""+ascii94);

      customChars.setMinimumSize(new Dimension(10,customChars.getPreferredSize().height));  // not ok
      customChars.setPreferredSize(customChars.getPreferredSize());

      gp.addG("Salt");
      gp.addG(salt, false);

      gp.getGridLayout().addTitleSeparator("Generated Password");

      gp.addG("Pass for site");
      JButton ccc = new JButton("copy to clip");
      ccc.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         ClipboardUtils.copyToClipboard( generatedPass.getText() );
      } });
      gp.addG(GUIUtils.boxLayout(2, ccc, generatedPass));
      generatedPass.setEditable(false);
      GUIUtils.selectAllTextWhenFocused(generatedPass);

      gp.addG("");
      gp.addG(genPassInfoLabel);


      gp.addG("");
      gp.addG(errLabel);
      errLabel.setForeground(new Color(255,120,120));


      DocumentListener updater = new DocumentListener()
      {
         public final void changedUpdate( final DocumentEvent de ) {
            updatePass();
         }

         public final void insertUpdate( final DocumentEvent de ) {
            updatePass();
         }

         public final void removeUpdate( final DocumentEvent de ) {
            updatePass();
         }
      };

      pass.getDocument().addDocumentListener(updater);
      site.getDocument().addDocumentListener(updater);
      customChars.getDocument().addDocumentListener(updater);
      salt.getDocument().addDocumentListener(updater);

      ActionListener ali = new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         updatePass();
      } };
      algo.addActionListener(ali);

      pack();
      // need to be greater because of warning labels
      setSize(830, 500);

      this.setLocationRelativeTo(null);
      setVisible(true);  // MODAL

      if(standalone)
      {
         System.exit(0);
      }
   }

   public static String evaluatePassStrength(String p)
   {
      if(p.length()<0)
      {
         return "Hint: use a long and hard to guess phrase.";//badRedLabel("too short");
      }

      boolean hasUpper=false;
      boolean hasLower=false;
      boolean hasDigit=false;
      boolean hasSpecials=false;

      for(int i=0; i<p.length(); i++)
      {
         char c = p.charAt(i);
         if(Character.isUpperCase(c)) hasUpper=true;
         else if(Character.isLowerCase(c)) hasLower=true;
         else if(Character.isDigit(c)) hasDigit=true;
         else hasSpecials = true;
      }

      int alphabetSize = 0;
      if(hasSpecials) alphabetSize += 32;
      if(hasDigit) alphabetSize += 10;
      if(hasLower) alphabetSize += 26;
      if(hasUpper) alphabetSize += 26;

      int bits = (int)(p.length()* Math.log(alphabetSize)/Math.log(2));  // all ascii printable: 94, with space: 95


      StringBuilder ret = new StringBuilder("<html>");

      if(bits<80)
      {
         ret.append(badRedLabel("WEAK"));
      }
      else
      {
         ret.append(greenLabel("GOOD"));
      }
      ret.append("  ("+p.length()+" chars, "+bits+" bits)");

      //return "<html>ok, strength is "+bits+" bits";

      StringBuilder miss = new StringBuilder();
      if(!hasUpper) miss.append("uppercase");
      if(!hasLower) miss.append(" / lowercase");
      if(!hasDigit) miss.append(" / digits");
      if(!hasSpecials) miss.append(" / special");

      if(miss.length()>0)
      {
         ret.append("    Tipp: should also use "+miss+" chars");
      }

      return ret.toString();
   }


   static String badRedLabel(String s)
   {
      return  "<span color=red>"+s+"</span>";
   }

   static String greenLabel(String s)
   {
      return  "<span color=green>"+s+"</span>";
   }

   /** crack info
   */
   static String estimateStrengthIn2011(int bits)
   {
      return "";
   }



   void updatePass()
   {
      errLabel.setText("");

      int requestedPassLength = 12;
      try{
         requestedPassLength = Integer.parseInt(""+passSize.getValue());
      }
      catch(final Exception e) {
         e.printStackTrace();
      }

      //this.

      StringBuilder genPass = new StringBuilder();
      StringBuilder warnings = new StringBuilder("<html>");

      generatedPass.setText("");
      genPassInfoLabel.setText("");

      try
      {
         // input pass evaluation
          passInfo.setText(evaluatePassStrength(new String(pass.getPassword())));

          String algoname = ""+algo.getSelectedItem();
          MessageDigest md = MessageDigest.getInstance(algoname);
          md.update( (salt.getText()+new String(pass.getPassword())).getBytes("UTF-8") );
          byte[] dig0 = md.digest();
          md = MessageDigest.getInstance(algoname);
          md.update( dig0 );

          md.update( site.getText().getBytes("UTF-8") );
          byte[] dig = md.digest();

          int n = Math.min(requestedPassLength, dig.length);

          int alphabetSize = -1;


          String alphabet = null;
          if(coding.getSelectedIndex()==0)
          {
             alphabet = "0123456789abcdef";
          }
          else if(coding.getSelectedIndex()==1)
          {
             alphabet = ascii64;
          }
          else if(coding.getSelectedIndex()==2)
          {
             alphabet = ascii94;
          }
          else if(coding.getSelectedIndex()==3)
          {
             alphabet = alphabet256;
          }
          else if(coding.getSelectedIndex()==4)
          {
             alphabet = customChars.getText();
          }

          alphabetSize =alphabet.length();

          int ma = Math.min(alphabetSize, 256);     // 256 is max because we take a byte *modulo*
          StringBuilder cp =new StringBuilder();

          for(int i=0; i<n; i++)
          {
             int pi = modulo(dig[i], ma);
             cp.append(""+alphabet.charAt(pi));
          }

          genPass.append(cp.toString());

          //System.out.println("entropy per char: "+(Math.log(ma)/Math.log(2)));
          int bits = (int)(n* Math.log(ma)/Math.log(2));
      if(bits<80)
      {
         warnings.append(badRedLabel("WEAK"));
      }
      else
      {
         warnings.append(greenLabel("GOOD"));
      }

          warnings.append("  ("+genPass.length()+" chars, alphabet size: "+ma+", strength: "+bits+" bits)");

          //!no sense: out.append("\nUTF8: "+new String(dig, "UTF-8"));
          // idea: base128, base256 ??  with UTF-8 ??

          generatedPass.setText(""+genPass);
          genPassInfoLabel.setText(""+warnings);

       }
       catch(Exception e)
       {
          e.printStackTrace();
          errLabel.setText(""+e.getMessage());
          throw new RuntimeException(""+e.getMessage());
       }

       //pass.getPassword()
   }

    /** @return r = a mod b, a real number in the range [0,b[
     *  such as a = b*n + r, with n being an integer
     *
     * ATTENTION : using java modulo gives -1.2 % 1 => -0.19999999999999996
    */
    public static int modulo(int a, int b)
    {
        int n = (int) Math.floor(1.0*a/b);  // caution: 1.0 is essential
        return (a-b*n);
    }




   public static void main(String[] args) throws Exception
   {
      EventQueue.invokeLater(new Runnable() { public void run() {
           new PassGen(true, null);
      }});

   }

   // experiments
   static void test()
   {
      StringBuilder sb = new StringBuilder();

      /* 94 ascii printable chars without space (32)
      int start = 33;
      int end = 127;
      */

      // 256 chars with accents
      int start = 33;
      int end = 289;

      for(int i=start; i<end; i++)  // [33-126] (94)  (no space)
      {
         sb.append((char) i);
      }

      System.out.println(""+sb.length());
      System.out.println(sb);
   }

   static String buildAlphabet256()
   {
      StringBuilder sb = new StringBuilder();

      /* 94 ascii printable chars without space (32)
      int start = 33;
      int end = 127;
      */

      // 256 chars with accents
      int start = 33;
      int end = 289;

      for(int i=start; i<end; i++)
      {
         char ci = (char) i;
         sb.append(ci);
      }

      return sb.toString();
   }


   // verification:
   // 1) copy pasted alphabet256::  (java1.6.0_23, jan2011) from tRun CONSOLE
   // 33.127: OK
   // 128..159: FAILS  (char==63 == ?) !
   // 160..255: OK
   //  256..289: FAILS

   // from JTextField: WORKS !!!
   //
   static void test(String s)
   {
      System.out.println(""+s.length());
      for(int i=0; i<s.length(); i++)
      {
         System.out.println(""+i+"\t"+s.charAt(i)+"\t"+((int) s.charAt(i)));
      }
   }

   static void test2()
   {
      // works
      test(buildAlphabet256());
   }


   static JTextField test3()
   {
      return new JTextField(buildAlphabet256());
   }




}