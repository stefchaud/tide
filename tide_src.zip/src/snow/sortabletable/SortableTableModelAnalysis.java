package snow.sortabletable;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Window;
import java.awt.event.*;
import java.io.File;
import java.util.*;
import javax.swing.*;
import javax.swing.text.JTextComponent;
import snow.datatransfer.ClipboardUtils;
import snow.files.JFileChooser2;
import snow.numerical.histogram.Histogram;
import snow.stats.DataStatistics;
import snow.tplot.*;
import snow.tplot.model.*;
import snow.utils.ArrayUtils;
import snow.utils.CollectionUtils;
import snow.utils.ProcessUtils;
import snow.utils.SysUtils;
import snow.utils.gui.GUIUtils;
import snow.utils.gui.Icons;
import snow.utils.gui.JGridPanel;


/** Analysis utilities, as plot, stats, histogram, column selections...
*/
public final class SortableTableModelAnalysis
{
   public SortableTableModelAnalysis()
   {
   }


  /** Count & plot
  */
  public static void viewSatsForColumn(final SortableTableModel sortableTableModel, final int columnModelIndex, final String fcolName)
  {
            final Window parentWindow = GUIUtils.getWindowForComponent(sortableTableModel.tableReference);
            final int visibleRows = sortableTableModel.getRowCount();

            double[] stats = SortableTableModelAnalysis.getSimpleColumnValuesNumberStatMOD( sortableTableModel, columnModelIndex, true ); // only visible
            StringBuilder sd = new StringBuilder();
            if(stats==null)
            {
              final Map<String, Integer> statsC = sortableTableModel.getDifferentColumnModValuesStats(columnModelIndex, true);
              sd.append("No numerical stats performed on column \""+fcolName+"\", "+visibleRows+" rows, not all cells are numbers."
                 +"\nHere are the sorted occurences ("+statsC.size()+" distinct values):\n");

              final List<Map.Entry<String, Integer>> svs = CollectionUtils.sortByValues(statsC);
              Collections.reverse(svs);  // to see the max val first.
              sd.append("\n Count  \tValue");
              for(final Map.Entry<String, Integer> ei : svs)
              {
                sd.append("\n "+ei.getValue()+"  \t"+ei.getKey());
              }

              JTextComponent expl = GUIUtils.createReadOnlyDescriptionArea(""+sd);
              GUIUtils.displayInDialog(parentWindow, "Statistics for column \""+fcolName+"\"", new JScrollPane(expl));
            }
            else
            {
              sd.append("Statistics for column <"+fcolName+">:\n\n   total =\t"+stats[0]);
              sd.append("\n   count =\t"+Math.round(stats[1]));
              sd.append("\n   mean =\t"+stats[2]);
              sd.append("\n   stdev =\t"+stats[3]);

              sd.append("\n\n   min =\t"+stats[4]);
              sd.append("\n   max =\t"+stats[5]);

              final List<Double> allVals = getAllDoubleValuesForModColumn(sortableTableModel, columnModelIndex, true);
              Collections.sort(allVals);
              sd.append("\n   median =\t"+allVals.get(allVals.size()/2));

              JTextComponent expl = GUIUtils.createReadOnlyDescriptionArea(""+sd);

              JPanel p = new JPanel(new BorderLayout());
              p.add(new JScrollPane(expl), BorderLayout.CENTER);

              JPanel cp = new JPanel();
              p.add(cp, BorderLayout.SOUTH);
              JButton histP = new JButton("Histogram", new Icons.StatIcon(18,18));
              cp.add(histP);
              histP.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae)
              {
                  Histogram hi = new Histogram();
                  hi.addData(allVals);
                  hi.classify();
                  HistogramElement he = new HistogramElement(hi, "Histogram");
                  TPlot p = new TPlot("Histogram for "+fcolName);
                  p.add(he);
                  p.autoscale();
                  p.zoomOut(false, true);
                  p.viewInDialog(parentWindow);

              } });

              JButton plot1 = new JButton("Plot");
              cp.add(plot1);
              plot1.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae)
              {
                  final List<Double> allVals = getAllDoubleValuesForModColumn(sortableTableModel, columnModelIndex, true);  // NOT SORTED so
                  final String title = "Plot for "+fcolName;

                  ListPlotElement pe = new ListPlotElement("col "+fcolName);
                  for(int i=0; i<allVals.size(); i++)
                  {
                     pe.addPoint(i+1, allVals.get(i));
                  }

                  TPlot p = new TPlot(title);
                  p.add(pe);
                  p.autoscale();
                  p.zoomOut(false, true);
                  p.viewInDialog(parentWindow);

              }});

              final JButton plot2 = new JButton("Plot as func of...");
              cp.add(plot2);
              plot2.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {

                 JPopupMenu pop2 = new JPopupMenu();
                 pop2.add("<html><body><small>Plot as function of column :");

                 int ci = 0;
                 for(final String cni: sortableTableModel.getAllBasicColumnNames())
                 {
                    final int fci = ci;
                    ci++;

                    final JMenuItem mi = new JMenuItem(cni);
                    pop2.add(mi);
                    mi.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae)
                    {
                       final List<Double> y = getAllDoubleValuesForModColumn(sortableTableModel, columnModelIndex, true);
                       final List<Double> x = getAllDoubleValuesForModColumn(sortableTableModel, fci, true);

                       final String title = "Plot for "+fcolName+" = f("+cni+")";

                       ListPlotElement pe = new ListPlotElement("col "+fcolName);
                       for(int i=0; i<x.size(); i++)
                       {
                          pe.addPoint(x.get(i), y.get(i));
                       }

                       TPlot p = new TPlot(title);
                       p.add(pe);
                       p.autoscale();
                       p.zoomOut(false, true);
                       p.viewInDialog(parentWindow);

                    } });
                 }

                 pop2.show(plot2, 0, 20);

              }});

              GUIUtils.displayInDialog(parentWindow, "Statistics for column \""+fcolName+"\"", p);

            }
  }



  public static void showAdvancedColumnExplorer(final SortableTableModel stm0, final Point showAt)
  {
         final Window parentWindow = GUIUtils.getWindowForComponent(stm0.tableReference);
         final int ncols = stm0.getBasicTableModel().getColumnCount();

         class Col implements EditableTableRow
         {
            final private int absIndex;
            final private String name;
            private boolean selected;

            Col(int absIndex, String name, boolean selected)
            {
               this.absIndex = absIndex;
               this.name = name;
               this.selected = selected;
            }

            @Override public final Object getValueForColumn( final int col ) {
               if(col==0) return absIndex+1;  // just a view
               if(col==1) return selected;
               if(col==2) return name;
               return "??";
            }

            @Override public final void setValueForColumn( final int col, final Object obj ) {
              if(col==1)
              {
                 selected = Boolean.parseBoolean(""+obj);
                 stm0.setColumnVisible(absIndex, selected);
              }
            }
         }

         final List<Col> cols = new ArrayList<Col>();
         for(int i=stm0.numberOfColumnAsRowHeaders; i<ncols; i++)
         {
            cols.add(new Col(i, stm0.getBasicTableModel().getColumnName(i), stm0.selectedColumns.contains(i)));
         }

         final FineGrainTableModelBuilder<Col> ftm = new FineGrainTableModelBuilder<Col>(cols, 3);
         ftm.setEditableColumns(1);
         ftm.setPreferredColumnWidth(4,4,30);
         ftm.setColumnNames("col", "view", "name");

         final  SortableTableModel stm = new SortableTableModel(ftm,0,true);  // caution: don't mix with argument above
         stm.setName("Columns Explorer");
         final JTable t = new JTable(stm);
         stm.installGUI(t);

         new UniversalTableCellRenderer(stm, t).installGUI(t);

         JPanel p = new JPanel(new BorderLayout());
         p.add(new JScrollPane(t), BorderLayout.CENTER);
         MultiSearchPanel msp = new MultiSearchPanel(stm);
         msp.viewColumSelectorButton(false);
         msp.setAdvancedState(false);
         p.add(msp, BorderLayout.NORTH);

         t.setComponentPopupMenu( new JPopupMenu()
         {
            @Override public final void show( final Component invoker, final int x, final int y ) {

               final List<Col> sel = ftm.getSelectedItems(t, stm);
               removeAll();

               if(sel.isEmpty())
               {
                  add("No selected column");
                  super.show(invoker, x, y);
                  return;
               }

               JMenuItem vs = new JMenuItem("View selected columns");
               add(vs);
               vs.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
                      for(Col ci : sel)
                      {
                         ci.setValueForColumn(1, true);
                      }
                      t.repaint();
               } });

               JMenuItem hs = new JMenuItem("Hide selected columns");
               add(hs);
               hs.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
                      for(Col ci : sel)
                      {
                         ci.setValueForColumn(1, false);
                      }
                      t.repaint();
               } });

               if(sel.size()==1)
               {
                  addSeparator();

                  JMenuItem sc = new JMenuItem("Sort ascending", Icons.sharedUpWedgeBlack);
                  add(sc);
                  sc.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
                         stm0.sort(sel.get(0).absIndex, true);
                  } });
                  JMenuItem scd = new JMenuItem("Sort descending", Icons.sharedDownWedgeBlack);
                  add(scd);
                  scd.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
                         stm0.sort(sel.get(0).absIndex, false);
                  } });

                  addSeparator();

                  JMenuItem mis = new JMenuItem("Statistics & plot", Icons.sharedStat);
                  add(mis);
                  mis.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
                      SortableTableModelAnalysis.viewSatsForColumn(stm0, sel.get(0).absIndex, sel.get(0).name);
                  } });

                  JMenuItem ts = new JMenuItem("Split as tree");
                  add(ts);
                  ts.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
                      List<String> vals = SortableTableModelAnalysis.getAllValuesForColumnMOD(stm0, sel.get(0).absIndex, true);
                      GUIUtils.displayInFrame( "Splitted values", TreeMaker.splitAsTree(vals), false);
                  } });

               }

               super.show(invoker, x, y);
            }
         });


         String title = stm0.getName();
         if(!title.isEmpty()) title += " - ";
         title+="Columns Selector";
         final JDialog dd = new JDialog(parentWindow, title, JDialog.ModalityType.MODELESS);
         if(showAt!=null)
         {
           dd.setLocation( showAt);
         }
         dd.add(p, BorderLayout.CENTER);
         dd.setPreferredSize(new Dimension(300, 200));
         dd.setSize(new Dimension(300, 200));
         GUIUtils.setWindowTransparency(dd, 0.9f);


         dd.setVisible(true);

  }



   /** known: Number, Date and parsed from strings.
   *  return null if not parsable...
   */
   static /*@org.checkerframework.checker.nullness.qual.Nullable*/ List<Double> getAllDoubleValuesForModColumn(final SortableTableModel stm,  final int colMod, boolean onlyOnVisibleElements)
   {
      List<Double> dv = new ArrayList<Double>();
      if(onlyOnVisibleElements)
      {
         int rc = stm.tableReference.getRowCount();
         for(int i=0; i<rc; i++)
         {
            int pos = stm.getIndexInUnsortedFromTablePos(i);
            Object oi = stm.getBasicTableModel().getValueAt(pos, colMod);
            if(oi instanceof Number)
            {
               Number ni = (Number) oi;
               dv.add( ni.doubleValue() );
            }
            else if(oi instanceof Date)
            {
               dv.add( (double) ((Date) oi).getTime() );
            }
            else  // by any chance !
            {
               try{
                  dv.add( Double.parseDouble(""+oi ));
               }
               catch(Exception e) {
                  return null;
               }
            }
         }
      }
      else
      {
         for(int i=0; i<stm.getBasicTableModel().getRowCount(); i++)
         {
            Object oi = stm.getBasicTableModel().getValueAt(i, colMod);
            if(oi instanceof Number)
            {
               Number ni = (Number) oi;
               dv.add( ni.doubleValue() );
            }
            else if(oi instanceof Date)
            {
               dv.add( (double) ((Date) oi).getTime() );
            }
            else  // by any chance !
            {
               try{
                  dv.add( Double.parseDouble(""+oi ));
               }
               catch(Exception e) {
                  return null;
               }
            }
         }
      }

      return dv;
   }


   /** Can be used for completion...
   */
   static Set<String> getDifferentColumnModValues(final FineGrainTableModel ref, final int colMod)
   {
      Set<String> set = new HashSet<String>();
      for(int i=0; i<ref.getRowCount(); i++)
      {
         set.add("" + ref.getValueAt(i, colMod));
      }

      return set;
   }



   /** used for split
   */
   static List<String> getAllValuesForColumnMOD(final SortableTableModel stm, final int colMod, boolean onlyOnVisibleElements)
   {
      List<String> dv = new ArrayList<String>();
      if(onlyOnVisibleElements)
      {
         int rc = stm.tableReference.getRowCount();
         for(int i=0; i<rc; i++)
         {
            int pos = stm.getIndexInUnsortedFromTablePos(i);
            Object oi = stm.getBasicTableModel().getValueAt(pos, colMod);
            dv.add(""+oi);
         }
      }
      else
      {
         for(int i=0; i<stm.getBasicTableModel().getRowCount(); i++)
         {
            Object oi = stm.getBasicTableModel().getValueAt(i, colMod);
            dv.add(""+oi);
         }
      }

      return dv;
   }


   /** Simple stats {total, count, mean, stdev, min, max}.
    *   null if not all numbers (Integer, Double, ...)
    */
   static double /*@org.checkerframework.checker.nullness.qual.Nullable*/ [] getSimpleColumnValuesNumberStatMOD(final SortableTableModel stm, final int col, final boolean onlyOnVisibleElements)
   {
     List<Double> dv = getAllDoubleValuesForModColumn(stm, col, onlyOnVisibleElements);
     if(dv==null) return null;

     double[] vs = ArrayUtils.toDoubleArray(dv);
     if(vs==null) return null;

     double tot = ArrayUtils.sum(vs);

     return new double[]{ tot, (double)dv.size(), tot/vs.length, DataStatistics.standardDeviation(vs), ArrayUtils.min(vs), ArrayUtils.max(vs)};
   }


   /** Displays a nice dialog to copy the table contents to the clipboard and open Excel/Word
   *    Also lets copy the transpose.
   */
   public static void viewCopyDialog(final SortableTableModel sortableTableModel)
   {
       JGridPanel gp = new JGridPanel(1);
       gp.getGridLayout().addExplanationArea("Copies the whole table with headers to the clipboard.\nJust type CTRL+V to paste the contents in another application.");

       JButton copy  = new JButton("Copy table to clipboard", Icons.sharedRightArrow);
       gp.getGridLayout().addSeparator();
       gp.addG(copy);
       copy.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae2) {
           SortableTableModelAnalysis.copyWholeActualTableContentToClipboard( sortableTableModel );
       } });

       JButton copyT = new JButton("Copy transposed table to clipboard", Icons.sharedRightArrow);
       gp.addG(copyT);
       copyT.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae2) {
           SortableTableModelAnalysis.copyWholeActualTableContentToClipboardTransposed( sortableTableModel );
       } });

       gp.getGridLayout().addSeparator();

/*
       JButton oex = new JButton("Open Excel", Icons.sharedSmallStart);
       gp.addG(oex, false);
       oex.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae2) {
          try
          {
             ProcessUtils.executeProcessAndGobble(Arrays.asList("cmd", "/c", "start",  "Excel"), "Excel");
          }
          catch(final Exception e)
          {
             e.printStackTrace();
          }
       } });*/

       JButton ono = new JButton("Open Wordpad", Icons.sharedSmallStart);
       gp.addG(ono, false);
       ono.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae2) {
          try{
             ProcessUtils.executeProcessAndGobble(Arrays.asList("cmd", "/c", "start",  "Wordpad"), "Wordpad");
          }
          catch(final Exception e) {
             e.printStackTrace();
          }
       } });

       //look if present in path (doesn't work well)
       final JButton sco = new JButton("Open OpenOffice Calc", Icons.sharedSmallStart);
       gp.addG(sco, false);
       sco.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae2)
       {
          JFileChooser2 sc = new JFileChooser2(sco);

          sc.remember("scalc", null);
          File scalcFile = JFileChooser2.getRememberedFile("scalc");

          if(scalcFile==null)
          {
             if(SysUtils.is_Windows_OS())
               sc.addChoosableType("exe", ".exe");
             sc.title("Choose the scalc executable");
             scalcFile = sc.chooseToOpen();
          }

          if(scalcFile==null) {
             return;
          }

          try
          {
             ProcessUtils.executeProcessAndGobble(               Arrays.asList( ""+scalcFile), "OOOSCalc");
//               Arrays.asList("cmd", "/c", "start",  "scalc"), "OOOSCalc");
          }
          catch(final Exception e) {
             e.printStackTrace();
          }
       } });

       gp.getGridLayout().addSeparator();

       JDialog dd = GUIUtils.displayInDialog( GUIUtils.getWindowForComponent(sortableTableModel.tableReference),  "Copy Table Contents", gp);
   }



   /** With column names
   */
   public static void copyWholeActualTableContentToClipboard(final SortableTableModel sortableTableModel)
   {
      StringBuilder sb = new StringBuilder();
      sb.append("Exported table values\n\n");
      for(int i=0; i<sortableTableModel.getColumnCount(); i++)
      {
         if(i>0) sb.append("\t");
         sb.append(sortableTableModel.getColumnName(i));
      }
      sb.append("\n");

      for(int j=0; j<sortableTableModel.getRowCount(); j++)
      {
         sb.append("\n");
         for(int i=0; i<sortableTableModel.getColumnCount(); i++)
         {
            if(i>0) sb.append("\t");
            sb.append(sortableTableModel.getValueAt(j,i));
         }
      }

      ClipboardUtils.copyToClipboard(sb.toString());
   }


   /** With column names
   */
   public static void copyWholeActualTableContentToClipboardTransposed(final SortableTableModel sortableTableModel)
   {
      StringBuilder sb = new StringBuilder();
      sb.append("Exported table values (transpose)\n\n");

      for(int i=0; i<sortableTableModel.getColumnCount(); i++)
      {
         sb.append("\n");
         sb.append(sortableTableModel.getColumnName(i));

         for(int j=0; j<sortableTableModel.getRowCount(); j++)
         {
            sb.append("\t");
            sb.append(sortableTableModel.getValueAt(j,i));
         }
      }

      ClipboardUtils.copyToClipboard(sb.toString());
   }


//test
public static void main(final String[] arguments) throws Exception {
   FineGrainTableModel.main(null);
}

}