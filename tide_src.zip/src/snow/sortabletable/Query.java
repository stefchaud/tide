package snow.sortabletable;

import java.util.regex.Pattern;

/**
 * Describes a search query for the sortable table
 *  IMMUTABLE !
 */
public class Query
{
  public int hitsCount = 0;

  public final static String[] booleanCombineNames = new String[]{ "and", "or", "and not", "or not"};
  public enum Combine { And, Or, AndNot, OrNot;
    public static Combine forIndex(int i)
    {
       switch (i) {
         case 0: return And;
         case 1: return Or;
         case 2: return AndNot;
         case 3: return OrNot;
       }
       return And;
    }
  }
  public final static String[] comparisonTypeNames = new String[]{ "contains", "equals", "starts with", "ends with", "regEx"};
  public enum Comparison { Contains, Equals, StartsWith, EndsWith, RegEx;
    public static Comparison forIndex(int i)
    {
       switch (i) {
         case 0: return Contains;
         case 1: return Equals;
         case 2: return StartsWith;
         case 3: return EndsWith;
         case 4: return RegEx;  // matcher matches (fully), case insensitive.
       }
       return RegEx;
    }
  }

  public Comparison comparison = Comparison.Contains;
  public final /*@org.checkerframework.checker.nullness.qual.Nullable*/ Pattern pattern;
  public final int column; // = -1;  // -1 means all columns
  public final String searchTxt;
  public final Combine boolOp; // = OPERATION_AND;

  public boolean isAllColumns()
  {
     return column==-1;
  }

  public Query(int _column, String _searchTxt, Combine _boolOp)
  {
     this(_column, _searchTxt, _boolOp, Comparison.Contains);
  }

  public Query(int _column, String _searchTxt, Combine _boolOp, Comparison _comparison)
  {
    this.column = _column;
    this.searchTxt = _searchTxt.toUpperCase();
    this.boolOp = _boolOp;
    this.comparison = _comparison;

    if(_comparison==Comparison.RegEx)
    {
       // use the arg, NOT the uppercased, because "\s" is NOT "\S" !!!
       pattern = Pattern.compile(_searchTxt, Pattern.CASE_INSENSITIVE);
    }
    else
    {
       pattern = null;
    }
  }

  public boolean isEmpty() { return searchTxt.length()==0; }
  public boolean isNegation() { return boolOp==Combine.AndNot || boolOp==Combine.OrNot; }

  public static Query[] simpleSearchQuery(String txt)
  {
     return new Query[]{ new Query(-1, txt, Combine.And, Comparison.Contains) };
  }

  public static Query[] simpleSearchQuery(String txt, int col)
  {
     return new Query[]{ new Query(col, txt, Combine.And, Comparison.Contains) };
  }

  public static Query[] emptySearchQuery()
  {
     return new Query[]{ new Query(-1, "", Combine.And, Comparison.Contains) };
  }

  @Override public final String toString()
  {
     if(this.isEmpty()) return "Query empty";
     StringBuilder sb = new StringBuilder(50);
     sb.append("Query '");
     sb.append(searchTxt);
     sb.append("' in col ");
     sb.append(column);
     sb.append(" bool ");
     sb.append(boolOp);
     return sb.toString();
  }
}
