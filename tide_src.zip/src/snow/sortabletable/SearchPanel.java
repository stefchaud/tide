package snow.sortabletable;

import snow.utils.gui.GUIUtils;
import java.util.*;
import snow.completion.TextComponentCompletion;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** A small utility to add a search (filter) panel to a sortable table viewer.
*/
public class SearchPanel extends JPanel
{
  SortableTableModel stm;

  final protected JTextField searchFT = GUIUtils.createTextFieldWithPromptString("Filter", true); // new JTextField(4); // [nov2011]=> name "Filter" instead of "Search"
  final protected JTextField searchFT2 = new JTextField(5);
  final protected JCheckBox useRegExCB = new JCheckBox("RegEx", false);

  /** @param secondSearch if true, two fields are shown, alowing an AND search
      @param searchLabelText is normally "Search: "
  */
  public SearchPanel(final String searchLabelText, final Icon searchIcon,
                     final SortableTableModel stm, final boolean secondSearch, final boolean allowRegEx)
  {
    super(new FlowLayout(FlowLayout.LEFT,2,1));
    this.stm = stm;

    // Components
    //
    searchFT.setColumns(5);
    GUIUtils.makeSmall(searchFT);

    add(searchFT);
    searchFT.putClientProperty("JComponent.sizeVariant", "small");

    if(secondSearch)
    {
       GUIUtils.makeSmall(searchFT2);
      add(new JLabel(" & "));
      add(searchFT2);
      searchFT2.putClientProperty("JComponent.sizeVariant", "small");
    }

    if(allowRegEx)
    {
      add(useRegExCB);
    }

    // key listener
    //
    KeyAdapter kad = new KeyAdapter()
    {
      @Override public void keyReleased(KeyEvent ee)
      {
        doSearch();
      }
    };

    searchFT.addKeyListener(kad);
    searchFT2.addKeyListener(kad);

    // focus behaviour
    //
    //todo: lok why disabled in MultiSearchPanel
    GUIUtils.selectAllTextWhenFocused(searchFT);
    GUIUtils.selectAllTextWhenFocused(searchFT2);

    // CTRL+F mapping
    //

    this.registerKeyboardAction(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          searchFT.requestFocus();
        }
      },
      KeyStroke.getKeyStroke(KeyEvent.VK_F, KeyEvent.CTRL_DOWN_MASK),
      JComponent.WHEN_IN_FOCUSED_WINDOW
    );  // ### Maybe pass the parent as argument reference and register actions on it.
        // It makes sense if several internal frames have searches...

  }

  public final JTextField getFirstSearchField() { return searchFT; }


  public void doSearch()
  {
    stm.search(searchFT.getText(), searchFT2.getText(), useRegExCB.isSelected());
  }


  public void setSearchText(String t1, String t2)
  {
     searchFT.setText(t1);
     searchFT2.setText(t2);
  }

  /** Adds completion for both search fields covering all cell values of the table.
  *  May miss some search keys if searchForColumn has been overridden in the finegraintablemodel.
  */
  public void _addCompletion()
  {
     final TextComponentCompletion<String> tcc = new TextComponentCompletion<String>(searchFT, false, true,  3, "");
     final TextComponentCompletion<String> tcc2 = new TextComponentCompletion<String>(searchFT2, false, true, 3, "");

     TextComponentCompletion.CompletionListener<String> upd = new TextComponentCompletion.CompletionListener<String>()
     {
        public void itemSelected(String item)
        {
           //hack.
           doSearch();
        }
     };

     tcc.setCompletionListener(upd);
     tcc2.setCompletionListener(upd);

     Set<String> allVals = new TreeSet<String>();
     for(int i=0; i<stm.getBasicTableModel().getColumnCount(); i++)
     {
        allVals.addAll( SortableTableModelAnalysis.getDifferentColumnModValues(stm.getBasicTableModel(), i) );
     }

     tcc.setCompletions(allVals);
     tcc2.setCompletions(allVals);
  }

}