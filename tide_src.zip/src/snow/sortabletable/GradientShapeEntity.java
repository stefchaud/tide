package snow.sortabletable;

import java.awt.*;
import java.awt.geom.*;


public class GradientShapeEntity
{
  private final GeneralPath shapePath;
  private final Color borderSelectedColor;
  private final GradientPaint gradientPaintSelected;
  private final BasicStroke shapeStroke;

  public GradientShapeEntity( Color borderDefaultColor,
                              Color borderSelectedColor,
                              Color insideDefaultColor,
                              Color insideSelectedColor,
                              float x_GradientLength,
                              float y_GradientLength,
                              int thickness )
  {
    this.shapePath = new GeneralPath( GeneralPath.WIND_NON_ZERO );
    this.borderSelectedColor = borderSelectedColor;
    this.shapeStroke = new BasicStroke( (float) thickness, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND );
    this.gradientPaintSelected = new GradientPaint( 0f,0f,
                                                    this.getBrighterColor(insideSelectedColor),
                                                    x_GradientLength,
                                                    y_GradientLength,
                                                    this.getDarkerColor(insideSelectedColor) );
  }

  public void paint( Graphics2D graphics2D)
  {
    Color borderColor = this.borderSelectedColor;
    GradientPaint gradientPaint = gradientPaintSelected ;

    graphics2D.setPaint( gradientPaint );
    graphics2D.fill( this.shapePath );

    graphics2D.setColor( borderColor );
    graphics2D.setStroke( this.shapeStroke );
    graphics2D.draw( this.shapePath );
  }


  public void moveTo( int x, int y )
  {
    this.shapePath.moveTo(x,y);
  }


  public void lineTo( int x, int y )
  {
    this.shapePath.lineTo(x,y);
  }

  public void closePath()
  {
    this.shapePath.closePath();
  }

  private Color getBrighterColor( Color c )
  {
    int r = c.getRed()   + 48; if( r > 255 ) r = 255;
    int g = c.getGreen() + 48; if( g > 255 ) g = 255;
    int b = c.getBlue()  + 48; if( b > 255 ) b = 255;
    return new Color(r,g,b);
  }

  private Color getDarkerColor( Color c )
  {
    int r = c.getRed()   - 48; if( r < 0 ) r = 0;
    int g = c.getGreen() - 48; if( g < 0 ) g = 0;
    int b = c.getBlue()  - 48; if( b < 0 ) b = 0;
    return new Color(r,g,b);
  }

}