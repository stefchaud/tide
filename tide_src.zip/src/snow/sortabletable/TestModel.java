package snow.sortabletable;

import snow.utils.gui.Icons;
import java.util.*;

public final class TestModel extends FineGrainTableModel
{
  private final Vector<TestModelItem> items = new Vector<TestModelItem>();
  private final String[] COLUMN_NAMES = new String[]{"Size", "Name", "Index", "Index2", "Index3", "check", "Icon", "aa", "bb", "cc"};


  public TestModel()
  {
    for (int i=0; i<353; i++)
    {
      addRandom();
    }
  }

  int[] COLUMN_PREFERRED_SIZES = new int[]{8,4,4,12,12,12};

  @Override
  public int getPreferredColumnWidth(int column)
  {
    if(column>=0 && column<COLUMN_PREFERRED_SIZES.length) return COLUMN_PREFERRED_SIZES[column];
    return -1;
  }


  public void add(TestModelItem titm)
  {
      fireTableModelWillChange();

      items.addElement(titm);

      fireTableDataChanged();
      fireTableModelHasChanged();
  }

  public void remove(TestModelItem titm)
  {
      fireTableModelWillChange();
      items.removeElement(titm);
      fireTableDataChanged();
      fireTableModelHasChanged();
  }


  int n=0;

  public void addRandom()
  {
     n++;

     TestModelItem titm = new TestModelItem();
     titm.col1 = Math.random()*1e6;
     if(Math.random()<0.1) titm.col1 = Math.random()*1e3;
     titm.col2 = ""+((char) ('a'+(n%26)));
     titm.col3 = n;
     titm.col4 = (int) (Math.random()*1000);
     titm.col5 = (int) (Math.random()*1000000);
     titm.col6 = System.currentTimeMillis() + (long)(Math.random()*3600L*1000*24*31);
     add(titm);
  }


  public void removeLast()
  {
      if(items.isEmpty()) return;

      fireTableModelWillChange();
      items.removeElementAt(items.size()-1);
      fireTableDataChanged();
      fireTableModelHasChanged();
  }


  public int getRowCount() {return items.size();}
  public int getColumnCount() {return 10;}

  public TestModelItem getItemAt(int pos)
  {
    return items.get(pos);
  }

  public Object getValueAt(int row, int column)
  {
    TestModelItem item = getItemAt(row);
    if(column==0) return item.col1;
    if(column==1) return item.col2;
    if(column==2) return item.col3;
    if(column==3) return item.col4;
    if(column==4) return item.col5;
    if(column==5) return item.checked;
    if(column==6) return Icons.sharedLeftArrow;
      //Don't work:
    if(column==7) return item.lt;
    if(column==8) return item.col6;
    if(column==9) return new Date(item.col6);
    return "??";
  }



  @Override
  public boolean isCellEditable(int row, int col)
  {
    return col<=2 || col==5;
  }

  @Override
  public void setValueAt(Object val, int row, int col)
  {
    if(val==null) return;

    fireTableModelWillChange();
    TestModelItem item = getItemAt(row);
    if(col==0)
    {
      try
      {
        double vd = Double.parseDouble(""+val);
        item.col1 = vd;
      }
      catch(Exception e){}
    }
    else if(col==1)
    {
      item.col2 = (String) val;
    }
    else if(col==2)
    {
      item.col3 = (Integer) val;
    }
    else if(col==5)
    {
      item.checked = (Boolean) val;
    }


    // must notify table that data has changed
    fireTableDataChanged();
    fireTableModelHasChanged();
  }


  @Override
  public String getColumnName(int column)
  {
    if(column>=0 && column<COLUMN_NAMES.length) return COLUMN_NAMES[column];
    return "Bad column "+column;
  }

     /*
  public int compareForColumnSort(int pos1, int pos2, int col)
  {
    if(col==0 || col>=2)
    {
      double v1 = Double.parseDouble(""+getValueAt(pos1, col));
      double v2 = Double.parseDouble(""+getValueAt(pos2, col));
      if(v1==v2) return 0;
      if(v1>v2) return 1;
      return -1;
    }
    else
    {
      String v1 = ""+getValueAt(pos1, col);
      String v2 = ""+getValueAt(pos2, col);
      return v1.compareTo(v2);
    }
   // return 0;

  }*/

  // Selection implementation
  //
  @Override
  public void setRowSelection(int row, boolean isSelected)
  {
    TestModelItem item = getItemAt(row);
    item.selected = isSelected;
  }

  @Override
  public boolean isRowSelected(int row)
  {
    TestModelItem item = getItemAt(row);
    return item.selected;
  }

  @Override
  public void clearRowSelection()
  {
    synchronized(items)
    {
      for(int i=0; i<getRowCount(); i++)
      {
         TestModelItem item = getItemAt(i);
         item.selected = false;
      }
    }
  }

}