package snow.sortabletable;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.event.*;
import java.io.File;
import java.util.*;
import java.util.prefs.Preferences;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import snow.datatransfer.ClipboardUtils;
import snow.sys.SystemCommandPanel;
import snow.utils.JavasDetector;
import snow.utils.ProcessUtils;
import snow.utils.SysUtils;
import snow.utils.gui.*;
import snow.utils.gui.files.FileField;
import tide.GlobalTideProps;
import tide.editor.MainEditorFrame;
import tide.editor.TideUtils;
import tide.editor.UIConstants;
import tide.project.ProjectSettings;
import tide.project.ProjectUtils;


/** View / edit the system properties and environment.
*/
public class SystemPropertiesViewer extends JDialog
{

  final private String[] columnNames = new String[] {"Key", "Value"};

  // properties
  final private JTable propertiesTable = new JTable();
  final private PropertiesTableModel propertiesTableModel = new PropertiesTableModel();
  final private SortableTableModel propertiesSortableTableModel = new SortableTableModel(propertiesTableModel, 0, true);
  final private JTextField propCodeField = new JTextField(50);


  // environment
  //  same as when type "set" in a windows cmd shell
  final private JTable environmentTable = new JTable();
  final private EnvironmentTableModel environmentTableModel = new EnvironmentTableModel();
  final private SortableTableModel environmentSortableTableModel = new SortableTableModel(environmentTableModel, 0, true);
  final private JTextField envCodeField = new JTextField(50);


  // preferences query/set tool (simplified, no tree...)
  // Win: stored in the registry,
  // Lin: stored in /etc/.java/.globalPrefs/prefs.xml if parent path exists
  //   or (BAD) in the jre folder ! (=> no more global)
  private class PreferencesTool extends JPanel
  {
     JTextField name = new JTextField(10);
     JLabel user = new JLabel();
     JLabel glob = new JLabel();

     public PreferencesTool()
     {
        super(new BorderLayout());

        JPanel cp = new JPanel();
        add(cp, BorderLayout.CENTER);
        GridLayout3 gl3 = new GridLayout3(2, cp);

        gl3.addTitleSeparator("Preferences Explorer    ( java.util.prefs )");

        gl3.add("Key (Case Sensitive !)");
        gl3.add(name);

        gl3.add("User preference Preferences.userRoot().get(key): ");
        gl3.add(user);

        gl3.add("Global preference Preferences.systemRoot().get(key): ");
        gl3.add(glob);

        gl3.addSeparator();
        gl3.addSeparator();

        final JButton setUserProp = new JButton("Set a User Preference");
        gl3.add(setUserProp);
        gl3.add("");
        setUserProp.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
           String[] ret = setDialog("Please enter the key and value to set as user preference", "User Preference");
           if(ret==null) return;
           try{
              Preferences.userRoot().put(ret[0], ret[1]);
              Preferences.userRoot().flush();
           }
           catch(Exception e) {
              JOptionPane.showMessageDialog(setUserProp, "Can't set user preference "+ret[0]+"="+ret[1], "Error", JOptionPane.ERROR_MESSAGE);
           }
        } });

        final JButton setGProp = new JButton("Set a System Preference");
        gl3.add(setGProp);
        gl3.add("");
        setGProp.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
           String[] ret = setDialog("Please enter the key and value to set as system preference\nCAUTION: requires Admin or Power User rights.", "System Preference");
           if(ret==null) return;
           try{
              Preferences.systemRoot().put(ret[0], ret[1]);
              Preferences.systemRoot().flush();
           }
           catch(Exception e) {
              JOptionPane.showMessageDialog(setUserProp, "Can't set system preference\n\n  "+ret[0]+"="+ret[1]+"\n\nEnsure you've admin rights !", "Error", JOptionPane.ERROR_MESSAGE);
           }
        } });


        name.addKeyListener(new KeyAdapter()
        {
           @Override public void keyReleased(KeyEvent ke)
           {
               explore();
           }}
        );

        gl3.addSeparator();
        gl3.addTitleSeparator("Limitations");

        gl3.add("Max key length");
        gl3.add(""+Preferences.MAX_KEY_LENGTH);
        gl3.add("Max value length");
        gl3.add(""+Preferences.MAX_VALUE_LENGTH);
        gl3.add("Max name length");
        gl3.add(""+Preferences.MAX_NAME_LENGTH);

        gl3.fillSouth();

     }

     public String /*@org.checkerframework.checker.nullness.qual.Nullable*/ [] setDialog(String question, String title)
     {
        JPanel cont = new JPanel();
        GridLayout3 gl3 = new GridLayout3(2, cont);
        gl3.addExplanationArea(question);
        gl3.addSeparator();
        gl3.add("key");
        JTextField kv = new JTextField(10);
        gl3.add(kv);
        gl3.add("value");
        JTextField vv = new JTextField(10);
        gl3.add(vv);
        String[] choices = new String[]{"Set", "Cancel"};
        int choosed = JOptionPane.showOptionDialog(this, cont, title,
           JOptionPane.YES_NO_CANCEL_OPTION,
           JOptionPane.QUESTION_MESSAGE, null,
           choices, choices[1]);
        if(choosed!=0) return null;

        return new String[]{kv.getText(), vv.getText()};
     }

     public void explore()
     {
        String key = name.getText();
        try{
           glob.setText(Preferences.systemRoot().get(key, "<not set>"));
        }
        catch(Exception e) {
           e.printStackTrace();
        }

        try{
           user.setText(Preferences.userRoot().get(key, "<not set>"));
        }
        catch(Exception e) {
           e.printStackTrace();
        }
     }
  }


  @SuppressWarnings("nullness")
  public SystemPropertiesViewer( final JFrame parent)
  {
      super(parent, "Current System Properties and Environment variables values", false);
      setLayout(new BorderLayout());

      JTabbedPane pane = new JTabbedPane();

      JPanel systemPropertiesPanel = createSystemPropertiesPanel();
      JPanel systemEnvironmentPanel = createSystemEnvironmentPanel();

      pane.addTab("System Properties", null, systemPropertiesPanel, "System.getProperties()");
      pane.addTab("System Environment", null, systemEnvironmentPanel, "System.getenv()");
      pane.addTab("Preferences", null, new PreferencesTool(), "System and user preferences query tool");

      if(SysUtils.is_Windows_OS())
      {
        pane.addTab("JavaSoft Registry HKLM", new SystemCommandPanel("reg query hklm\\software\\javasoft /s"));
        // Windows 7
        pane.addTab("JavaSoft Registry HKCU", new SystemCommandPanel("reg query hkcu\\Software\\JavaSoft /s"));

        // 64 bit see other system prefs !!!
        // THIS MAY CAUSE SUBTLE BUGS !
        // global prefs are no more global prefs !!!
        //  if set on 32bit, they are not seen by 64bit machines!
        try
        {
          if(seems64bit())
          {
            pane.addTab("JavaSoft Registry HKLM 64bits", new SystemCommandPanel("reg query hklm\\software\\Wow6432Node\\javasoft /s"));
          }
        }
        catch(final Exception e) {
           e.printStackTrace();
        }

      }

      add(pane, BorderLayout.CENTER);

      tryToWriteAllProperties();

      environmentTable.addMouseListener(new MouseAdapter() {
        @Override public void mousePressed(MouseEvent me)
        {
           if(me.isPopupTrigger()) pop(me, environmentTable, environmentSortableTableModel, environmentTableModel);
        }
        @Override public void mouseReleased(MouseEvent me)
        {
           if(me.isPopupTrigger()) pop(me, environmentTable, environmentSortableTableModel, environmentTableModel);
        }
      });

      propertiesTable.addMouseListener(new MouseAdapter() {
        @Override public void mousePressed(MouseEvent me)
        {
           if(me.isPopupTrigger()) pop(me, propertiesTable, propertiesSortableTableModel, propertiesTableModel);
        }
        @Override public void mouseReleased(MouseEvent me)
        {
           if(me.isPopupTrigger()) pop(me, propertiesTable, propertiesSortableTableModel, propertiesTableModel);
        }
      });



      if(TideUtils.getTideJarMaybeFromPreviousRun()!=null)
      {
        JPanel mainSouthPanel = new JPanel();
        mainSouthPanel.setLayout(new BoxLayout(mainSouthPanel, BoxLayout.X_AXIS));
        add(mainSouthPanel, BorderLayout.SOUTH);

        JButton newInstanceVM = new JButton("new instancewith another VM");

        GUIUtils.makeSmall(newInstanceVM);

        newInstanceVM.setAlignmentY(0.5f);
        mainSouthPanel.add(newInstanceVM);
        newInstanceVM.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
           newInstanceOtherVM();
        } });
      }





      // map escape key
      ActionListener escapeActionListener = new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          closeButtonPressed();
        }
      };
      this.getRootPane().registerKeyboardAction( escapeActionListener,
                                                 KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false),
                                                 JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT );
      propertiesTable.registerKeyboardAction( escapeActionListener,
                                              KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false),
                                              JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT );

      setSize(700,700);
      setLocationRelativeTo(null); // screen
      LayoutUtils.ensureWithinScreen(this);
      setVisible(true);
  }

  private void pop(MouseEvent me, JTable table, SortableTableModel stm, FineGrainTableModel fgtm)
  {
     final JPopupMenu pop =new JPopupMenu();

     final int[] selRows = stm.getIndexInUnsortedFromTablePos( table.getSelectedRows() );
     ArrayList<String> selKeys = new ArrayList<String>();
     for(int ri : selRows)
     {
        selKeys.add( ""+fgtm.getValueAt(ri, 0) );
     }

     if(selKeys.size()==1)
     {
        final String key = selKeys.get(0);
        final String val = ""+fgtm.getValueAt(selRows[0], 1);


        JMenuItem mic = new JMenuItem(""+key);
        mic.setToolTipText("copy to clipboard: "+val);
        pop.add(mic);
        mic.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
           ClipboardUtils.copyToClipboard(val);
        } });

       String lk = key.toLowerCase();
        if(lk.contains("path") || lk.contains("dir") || lk.contains("home") || lk.contains("=")
          || val.contains(":") || val.contains(File.separator) )
        {
           pop.addSeparator();

           if(val.contains(File.pathSeparator))
           {
              String[] sp = val.split(File.pathSeparator);
              for(String si : sp)
              {
                 pop.add(openSys(si));

              }
           }
           else
           {
                 pop.add(openSys(val));
           }
        }

        if(key.contains("url"))
        {
           JMenuItem mib = new JMenuItem("Open in browser", Icons.sharedInternet);
           mib.setToolTipText("val:"+val);
           pop.add(mib);
           mib.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
              try{
                 SysUtils.openBrowser(val);
              }
              catch(final Exception e) {
                 e.printStackTrace();
              }
           } });
        }
     }
     else
     {
        pop.add(selKeys.size()+" selected rows");
     }


     pop.show(table, me.getX(), me.getY());
  }

  private static JMenuItem openSys(String path)
  {
        final File p = new File(path);
        JMenuItem mic = new JMenuItem(""+path, Icons.sharedSystemFolder);
        if(!p.exists())
        {
           mic.setForeground(UIConstants.red);
        }

        if(p.isAbsolute())
        {
          mic.setToolTipText(""+p);
        }
        else
        {
          mic.setToolTipText(""+p+", abs="+p.getAbsolutePath());
        }

        mic.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
           SysUtils.openFileExplorer(p );
        } });
        return mic;
  }

  public static boolean seems64bit()
  {
     if(System.getProperty("os.arch").contains("64")) return true;

     try{
        if(System.getenv("PROCESSOR_ARCHITECTURE").contains("64")) return true;
     }
     catch(final Exception e) {
        //e.printStackTrace();
     }

     try{
        if(System.getenv("PROCESSOR_ARCHITEW6432").contains("64")) return true;
     }
     catch(final Exception e) {
        //e.printStackTrace();
     }

     return false;

  }

  private JPanel createSystemPropertiesPanel()
  {
    JPanel p = new JPanel(new BorderLayout());
    p.add(GUIUtils.makeSmall(new JScrollPane(propertiesTable)), BorderLayout.CENTER);
    propertiesTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    propertiesTable.setModel(propertiesSortableTableModel);
    propertiesSortableTableModel.installGUI(propertiesTable);

    AdvancedSearchPanel asp = new AdvancedSearchPanel(propertiesSortableTableModel, false);
    p.add(asp, BorderLayout.NORTH);
    asp.setAdvancedMode(true);


    JPanel southPanel = new JPanel(new FlowLayout(FlowLayout.LEFT,2,0));
    p.add(southPanel, BorderLayout.SOUTH);
    southPanel.add(new JLabel("Code to paste: "));
    southPanel.add(propCodeField);
    GUIUtils.selectAllTextWhenFocused(propCodeField);
    propCodeField.setEditable(false);

    propertiesTable.getSelectionModel().addListSelectionListener(new ListSelectionListener()
    {
        public void valueChanged(ListSelectionEvent lse) {
           propCodeField.setText("");
           int rowView = propertiesTable.getSelectedRow();
           if(rowView<0) return;
           int rowMod = propertiesSortableTableModel.getIndexInUnsortedFromTablePos(rowView);
           propCodeField.setText("System.getProperty(\""+propertiesTableModel.getValueAt(rowMod,0)+"\")");        }

    });

    return p;
  }


  private JPanel createSystemEnvironmentPanel()
  {
    JPanel p = new JPanel(new BorderLayout());
    p.add(GUIUtils.makeSmall(new JScrollPane(environmentTable)), BorderLayout.CENTER);
    environmentTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    environmentTable.setModel(environmentSortableTableModel);
    environmentSortableTableModel.installGUI(environmentTable);

    AdvancedSearchPanel asp = new AdvancedSearchPanel(environmentSortableTableModel, false);
    p.add(asp, BorderLayout.NORTH);
    asp.setAdvancedMode(true);

    JPanel sp = new JPanel(new FlowLayout(FlowLayout.LEFT,2,0));
    p.add(sp, BorderLayout.SOUTH);
    sp.add(new JLabel("Code to paste: "));
    sp.add(envCodeField);
    envCodeField.addFocusListener(new FocusAdapter(){
       @Override public void focusGained(FocusEvent fe)
       {
          envCodeField.selectAll();
       }
    });
    envCodeField.setEditable(false);

    environmentTable.getSelectionModel().addListSelectionListener(new ListSelectionListener()
    {
        public void valueChanged(ListSelectionEvent lse) {
           envCodeField.setText("");
           int rowView = environmentTable.getSelectedRow();
           if(rowView<0) return;
           int rowMod = environmentSortableTableModel.getIndexInUnsortedFromTablePos(rowView);
           envCodeField.setText("System.getenv(\""+environmentTableModel.getValueAt(rowMod,0)+"\")");
        }

    });

    return p;
  }




  private final void closeButtonPressed()
  {
    setVisible(false);
    dispose();
  }



  private final void tryToWriteAllProperties()
  {
    // some security managers doesn't allow this (with unsigned WebStart apps, for example)
    try{
      Properties props = System.getProperties();
      for(String prn : props.stringPropertyNames())
      {
         writeprop(prn);
      }
    }
    catch(Exception e)
    {
       e.printStackTrace();
    }
  }


  private final class PropertiesTableModel extends FineGrainTableModel
  {
    final List<String> keys   = new Vector<String>();
@Override
    public final String getColumnName(int col)
    {
      return columnNames[col];
    }
    public final int getRowCount() { return keys.size(); }
    public final int getColumnCount() { return 2; }
@Override
    public final int getPreferredColumnWidth(int col)
    {
      if(col==0) return 15;
      return 35;

    }
@Override
    public final Object getValueAt(int row, int col)
    {

        String key = keys.get(row);
        if(col==0) return key;
        if(col==1)
        {
          try
          {
            return System.getProperty(key, "<NOT FOUND>");   //values.elementAt(row);
          }
          catch(Exception e)
          {
            return " *** no permission *** ";
          }
        }
        return "?";
    }
@Override
    public final boolean isCellEditable(int row, int col)
    {
       return col==1;
    }
@Override
    public final void setValueAt(Object value, int row, int col)
    {
       if(col!=1) return;

       String key = keys.get(row);
       this.fireTableModelWillChange();
       try
       {
         System.setProperty(key, (String) value);
       } catch(Exception e) { e.printStackTrace(); }

       this.fireTableDataChanged();
       this.fireTableModelHasChanged();
    }

    public final void addLine(String key)
    {
       keys.add(key);
       fireTableCellUpdated(keys.size()-1, 0);
    }
  }



  /** @since Java 1.5
  */
  private final class EnvironmentTableModel extends FineGrainTableModel
  {
    final List<String> keys   = new ArrayList<String>();

    public EnvironmentTableModel()
    {
      keys.addAll(System.getenv().keySet());
    }
@Override
    public final String getColumnName(int col)
    {
      return columnNames[col];
    }
    public final int getRowCount() { return keys.size(); }
    public final int getColumnCount() { return 2; }
@Override
    public final int getPreferredColumnWidth(int col)
    {
      if(col==0) return 15;
      return 35;

    }
@Override @SuppressWarnings("nullness")
    public final Object getValueAt(int row, int col)
    {

        String key = keys.get(row);
        if(col==0) return key;
        if(col==1)
        {
          try
          {
            return System.getenv(key);
          }
          catch(Exception e)
          {
            return " *** no permission *** ";
          }
        }
        return "?";
    }
@Override
    public final boolean isCellEditable(int row, int col)
    {
       return false;
    }
@Override
    public final void setValueAt(Object value, int row, int col)
    {
    }

  }


  public final void writeprop(String key)
  {
    String prop = null;
    try
    {
      // try to write
      System.getProperty(key);
    }
    catch(Exception e)
    {
      prop = "*** No permission ***";
    }
    propertiesTableModel.addLine(key);
  }



  /** let's explore the props of another UI in another VM
  */
  public void newInstanceOtherVM()
  {
     JGridPanel gp = new JGridPanel(2);

     final File tideJar = TideUtils.getTideJarMaybeFromPreviousRun();
     gp.getGridLayout().addExplanationArea("You can launch another instance from another VM\nThis lets you explore UI properties\n");


     FileField customJRE = new FileField("", false, "Choose the java executor (java.exe) to use", JFileChooser.FILES_ONLY);
     gp.addG("JRE");
     gp.addG(customJRE);
     //GUIUtils.makeSameHeight(autoJRE, customJRE.getTextField(), -1);

     if(MainEditorFrame.hasInstance())
     {
       customJRE.setPath( MainEditorFrame.getActualProject().getProperty(ProjectSettings.CUSTOM_JRE , null) );
       //customJRE.getTextField().setColumns(24);
       customJRE.setAlternatePaths( JavasDetector.getKnownRuntimes_withFavorites(false) );
       //customJRE.offerRememberedGlobalCompletion(GlobalTideProps.getGlobalProps(), "Global_ customJREs" );  // java.exe list
     }
     else
     {
        try{
           customJRE.setPath( new File(System.getProperty("java.home"), "bin/java") );
        }
        catch(final Exception e) {
           e.printStackTrace();
        }
     }

     JTextField vmOpts = new JTextField("");
     gp.addG("VM args");
     gp.addG(vmOpts);

     int rep = gp.showOptionPane(this, "Launch Another System Properties Viewer", new String[]{"Cancel", "Lanuch"}, 1);
     if(rep!=1) return;
     try
     {
        List<String> args = new ArrayList<String>();
        args.add(""+customJRE.getPath().getAbsolutePath());
        if(!vmOpts.getText().isEmpty())
        {
           args.addAll( ProjectUtils.splitArgs(vmOpts.getText().trim(), false) );
        }
        args.add(  "-cp" );
        args.add(  "."+File.pathSeparator+tideJar );
        args.add( "snow.sortabletable.SystemPropertiesViewer" );

        System.out.println("launch "+args);

        ProcessUtils.executeProcessAndGobbleToConsole("", null, args.toArray(new String[args.size()]));
     }
     catch(final Exception e) {
        e.printStackTrace();
     }
  }

  //Proguard: to KEEP
  /** used as standalone app
  */
  public static void main(String[] args)
  {
    GUIUtils.setNimbusLookAndFeel_IfPossible();
    EventQueue.invokeLater(new Runnable()
    { public void run()
      {
        new SystemPropertiesViewer(new JFrame());
      }
    });
  }



}