package snow.sortabletable;

import snow.utils.storage.FileUtils;
import java.net.URL;
import snow.utils.NetUtils;
import java.util.prefs.Preferences;
import snow.utils.gui.*;
import snow.texteditor.EditDistance;
import java.text.Collator;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import javax.swing.*;
import java.util.regex.*;
import java.io.*;
import java.util.*;

/** Utility...
*  ftp://ftp.heise.de/pub/ct/listings/0717-182.zip
*/
@SuppressWarnings("nullness")
public final class NamesExplorer extends JFrame
{
   Map<Integer, String> countries = new HashMap<Integer, String>();
   Map<String, Integer> chars = new HashMap<String, Integer>();
   List<Name> names = new ArrayList<Name>();
   JTextField searchField = new JTextField(12);
   final Pattern pc = Pattern.compile("<.*?>");  // must be reluctant "?"
   final Matcher mc = pc.matcher("");
   TM tm = new TM();

   JTextField unknownChars = new JTextField(20);
   Collator collator = Collator.getInstance(Locale.GERMAN);
   List<Integer> countriesIndices = new ArrayList<Integer>();
   Vector<String> countriesNames = new Vector<String>();
   final private JCheckBox ignoreAccents = new JCheckBox("Ignore accents", true);

   private final static String downloadURL = "ftp://ftp.heise.de/pub/ct/listings/0717-182.zip";

   JComboBox type = new JComboBox(new String[]{"exact equals", "approx equals", "contains", "tolerant approx"});
   JComboBox countriesCB;

   boolean debug = false;

   private final File f;

   public static final String title = "Names Explorer";

   private NamesExplorer() throws Exception
   {
      super("Names Explorer");

      f = new File(Preferences.userRoot().get("nam_dict_loc","nam_dict.txt"));

      if(!f.exists()) throw new RuntimeException("Names dictionary not found: "+f+"\n\nPlease download from "+downloadURL);

      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setSize(800, 600);

      JPanel np = new JPanel(new BorderLayout());

      JPanel sp = new JPanel();
      sp.setBorder(new EmptyBorder(5,5,5,5));
      np.add(sp, BorderLayout.CENTER);
      GridLayout3 settingsLayout = new GridLayout3(2, sp);
      /*settingsLayout.addExplanationArea(
          "Results hit types:  0: exact,  1: contains, 2: collated, 3: approx ");*/

      settingsLayout.add("Search:");

      settingsLayout.add(searchField);

      settingsLayout.add("type:");
      settingsLayout.add(type);
      settingsLayout.add(ignoreAccents);
      type.setSelectedIndex(2);

      if(debug)
      {
            settingsLayout.add("unknown chars:");
            settingsLayout.add(unknownChars);
      }


      try
      {
        search(-1, 0, "", null, true);
      }catch(Exception e)
      {
        JOptionPane.showMessageDialog(null, "Error: "+e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
      }

      countriesIndices.addAll(countries.keySet());
      Collections.sort(countriesIndices);

      for(int cii : countriesIndices)
      {
         countriesNames.add(countries.get(cii));
      }

      countriesIndices.add(0,-1);  // all
      countriesNames.add(0,"All");

      countriesCB = new JComboBox(countriesNames);
      countriesCB.setMaximumRowCount(30);
      settingsLayout.add("Country:");
      settingsLayout.add(countriesCB);

      settingsLayout.addSeparator();

      SortableTableModel stm = new SortableTableModel(tm);
      JTable table = new JTable(stm);
      stm.installGUI(table);
      add(GUIUtils.makeSmall(new JScrollPane(table)), BorderLayout.CENTER);
      MultiSearchPanel msp = new MultiSearchPanel("Filter: ", null, stm);
      add(np, BorderLayout.NORTH);
      np.add(msp, BorderLayout.SOUTH);
      setLocationRelativeTo(null);
      //GUIUtils.ensureWithinFrame(null, this);
      setVisible(true);

      ActionListener sac = new ActionListener() { public void actionPerformed(ActionEvent ae) {
         tm.clear();
         final ProgressModalDialog pmd = new ProgressModalDialog(NamesExplorer.this, "Search progress", false);
         pmd.setProgressBounds(45000);  // approx.
         pmd.setProgressValue(0, "");
         pmd.start();
         Thread t = new Thread()
         {
            public void run()
            {
               try
               {
                  int c = countriesIndices.get(countriesCB.getSelectedIndex());
                  search(c, 0, searchField.getText(), pmd, false);
               }
               catch(Exception e)
               {
                  JOptionPane.showMessageDialog(null, "Error: "+e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
               }
               finally
               {
                  pmd.closeDialog();
                  EventQueue.invokeLater(new Runnable() { public void run() {
                        tm.update();
                  }});

                  if(unknown.length()>0)
                  {
                     unknownChars.setText(""+unknown);
                     for(char ci : unknown.toString().toCharArray())
                     {
                        int co = (int) ci;
                        System.out.print("\\u0"+Integer.toString(co, 16)+"");
                     }

                  }
               }
            }
         };
         t.start();
      } };

      searchField.addActionListener(sac);

      EventQueue.invokeLater(new Runnable() { public void run() {
            searchField.requestFocus();
      }});

   }

   public static boolean isInstalled()
   {
      File cand = new File(Preferences.userRoot().get("nam_dict_loc","nam_dict.txt"));
      if(cand.exists()) return true;
      return false;
   }

   public static File installDict() throws Exception
   {
      String[] opts = new String[]{"Download it for you", "Take a specified nam_dict.txt location"};
      Object rep = JOptionPane.showInputDialog(null,
         "Names Explorer needs the nam_dict.txt file from\n\n   "+downloadURL+"  [420kB]"
         +"\n\nWhat should I do ?\n\n",
         "Confirmation", JOptionPane.QUESTION_MESSAGE,
         null, opts, opts[0]);
      if(rep==null) return null;

      if(rep.equals(opts[1]))
      {
         JFileChooser fs = new JFileChooser();
         fs.setDialogTitle("Specify the location of nam_dict.txt");
         fs.setFileSelectionMode(JFileChooser.FILES_ONLY);
         int acc = fs.showOpenDialog(null);
         if(acc!=JFileChooser.APPROVE_OPTION) return null;
         final File f = fs.getSelectedFile();
         if(!f.getName().equalsIgnoreCase("nam_dict.txt"))
         {
            JOptionPane.showMessageDialog(null, "The file MUST be nam_dict.txt\n\n   "+f+"\n\nis invalid.",
               "Error", JOptionPane.ERROR_MESSAGE);
            return null;
         }
         Preferences.userRoot().put("nam_dict_loc", f.getAbsolutePath());
         return f;
      }
      else
      {
         // download
         JFileChooser fs = new JFileChooser();
         fs.setDialogTitle("Specify a folder to install nam_dict.txt in");
         fs.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
         int acc = fs.showSaveDialog(null);
         if(acc!=JFileChooser.APPROVE_OPTION) return null;
         final File destFold = fs.getSelectedFile();
         final File destFile = new File(destFold, "0717-182.zip");
         ProgressModalDialog pmd = ProgressModalDialog.createStandaloneProgress("Installing");
         try
         {
            NetUtils.downloadFileFromServer(new URL(downloadURL), destFile, "nam_dict.txt", pmd);
            FileUtils.extractZipFile(destFile, destFold, pmd, null);
            final File f = new File(destFold, "nam_dict.txt");
            Preferences.userRoot().put("nam_dict_loc", f.getAbsolutePath());
            return f;
         }
         finally
         {
            pmd.closeDialog();
         }
      }

     // return null;
   }

   void search(int countryFilter, int occFilter, String nameFilter, /*@org.checkerframework.checker.nullness.qual.Nullable*/ ProgressModalDialog pmd, boolean onlyReadCountries) throws Exception
   {
      collator.setStrength(Collator.PRIMARY);
      BufferedReader fr = new BufferedReader(new FileReader(f));
      // preparation
      String line;

      while((line = fr.readLine())!=null)
      {
         if(line.indexOf("Non-iso")>0) break;
      }

      // chars
      while((line = fr.readLine())!=null)
      {
         line = line.substring(1, line.length()-1);  // ignore # and $
         String tr = line.trim();
         if(tr.length()==0) break;
         int pos = tr.indexOf('=');
         if(pos<0) break;

         int code = Integer.parseInt(tr.substring(0,pos).trim());
         String charsc = tr.substring(pos+1).trim();

         if(charsc.indexOf(" or ")>0)
         {
            for(String ci : charsc.split("\\sor\\s"))
            {
              //System.out.println(""+ci);
              chars.put( ci, code);
            }
         }
         else
         {
           chars.put( charsc, code);
         }

         //System.out.println("code="+tr.substring(0,pos).trim());
         //System.out.println("  char="+tr.substring(pos+1).trim());
      }

      //System.out.println(""+chars);


      while((line = fr.readLine())!=null)
      {
         if(line.indexOf("list of countries")>0) break;
      }

      // read the countries
      String previous = null;
      while((line = fr.readLine())!=null)
      {
         line = line.substring(1, line.length()-1);  // ignore # and $
         String tr = line.trim();
         if(tr.startsWith("|"))
         {
            countries.put( line.indexOf('|')-28, previous );
         }
         else
         {
            previous = tr;
         }

         if(line.indexOf("begin of name list")>=00) break;

         //System.out.println(""+line);
      }

      //System.out.println(""+countries.size()+" countries:\n"+countries);
      if(onlyReadCountries) return;

      // and now the names.
      int max = 100000;
      int read = 0;
      int lines =0;
      List<String> equivalences = new ArrayList<String>();

      String soundSearch = null; // approx
      if(nameFilter!=null)
      {
        if(type.getSelectedIndex()==3)  // approx
        {
           soundSearch = nameFilter.toUpperCase();
        }
        else if(type.getSelectedIndex()!=0)  // not exact
        {
           nameFilter = normalizeCH(nameFilter);
        }
      }

      long lastUpd = -1;

  nl: while((line = fr.readLine())!=null)
      {

         if(pmd.getWasCancelled()) throw new Exception("cancelled");
         pmd.incrementProgress(1);

         if(line.length()==0) continue;
         if(line.charAt(0)=='#') continue; // comment
         lines++;


         boolean isEqu = line.charAt(0) == '=';

         if(isEqu)    // name format: "A B"  means A is a variant for B
         {
            // treat later...
            equivalences.add(line);
            // TODO.
            continue nl;
         }

         //System.out.println(""+line.substring(29));

         //if(lines==10) return;


         if(line.charAt(29)=='+') continue;  // ignore since just a sort order change (copy)


         String gend = line.substring(0,3).trim();
         String nam = line.substring(3);

         String name = nam.substring(0,26).trim();
         name = decode(name);

         int hitQuality = 3;  // 0: exact,  1: contains, 2: collated, 3: approx
         if(nameFilter!=null)
         {
            if(ignoreAccents.isSelected())
            {
               name = removeAccents(name);
            }

            if(soundSearch!=null)
            {
              if(EditDistance.editexDistanceEnglish(soundSearch, name, 2)>1) continue;
              hitQuality = 3;
            }
            else
            {
              if(type.getSelectedIndex()==0)  // exact
              {
                 if(!name.equals(nameFilter)) continue;
                 hitQuality = 0;
              }
              else
              {
                 String sn = normalizeCH(name);

                 if(type.getSelectedIndex()==1)  // approx equals  ( ign case and accents but NOT ~contains)
                 {
                    if(!collator.equals(sn, nameFilter)) continue;
                    hitQuality = 2;
                 }

                 if(type.getSelectedIndex()==2)  // contains
                 {
                    if( !sn.contains(nameFilter)) continue;
                    hitQuality = 1;
                 }

                 if( sn.equals(nameFilter)) hitQuality = 0;
                 else if( sn.contains(nameFilter)) hitQuality = 1;
                 else if(collator.equals(sn, nameFilter))  hitQuality = 2;
                 else
                 {
                    continue;
                 }
              }
            }
         }

         String occs = nam.substring(27, nam.length()-1);  // without $

         Map<Integer, Integer> couOc = new HashMap<Integer, Integer>();

         int maxOcc = -1;

         for(int i=0; i<occs.length(); i++)
         {
            char ci = occs.charAt(i);
            if(Character.isSpaceChar(ci)) continue;
            int oci = 0;
            if(Character.isDigit(ci)) oci = Character.getNumericValue(ci);
            else if(ci=='A') oci = 10;
            else if(ci=='B') oci = 11;
            else if(ci=='C') oci = 12;
            else if(ci=='D') oci = 13;
            else if(ci=='E') oci = 14;

            couOc.put(i+1, oci);
            if(oci>maxOcc) maxOcc=oci;
            //System.out.println("   "+oci+": "+countries.get(i+1));
         }

         if(occFilter!=0)
         {
           if(occFilter>0)
           {
             if(maxOcc<occFilter) continue nl;
           }
           else if( maxOcc>-occFilter) continue nl;
         }


         if(countryFilter>=0 && !couOc.containsKey(countryFilter)) continue nl;
         //System.out.println(""+couOc);

         Name ni = new Name(name, gend, couOc, hitQuality);
         names.add(ni);

         if(System.currentTimeMillis()-lastUpd>2000)
         {
            EventQueue.invokeLater(new Runnable() { public void run() {
               tm.update();
            }});
            //pmd.set
            lastUpd = System.currentTimeMillis();
         }
         //System.out.println(""+ni);

         //System.out.println(""+occs);
         //line = line.substring(0, line.length()-1);  // ignore # and $
         read++;
         if(read>max)
         {
            System.out.println("To much hits: breaking");
            break;
         }

         //System.out.println(""+line);
      }

      System.out.println(""+names.size()+" names, "+lines+" lines, "+equivalences.size()+" equival");

      setTitle(title+" ["+names.size()+" names found]");


   }

// special chars
   String decode(String s)
   {
      if(s.indexOf('<')<0) return s;

      mc.reset(s);
      int start = 0;
      StringBuffer ret = new StringBuffer();
      while(mc.find())  // NEVER SET start, this reinitialises the replace...
      {
         int st = mc.start();
         int en = mc.end();

         String code = s.substring(st,en);

         //System.out.println(""+code);
         String ci = new String(Character.toChars( chars.get(code) ));
         //System.out.println(""+code+" :: "+ci);

         mc.appendReplacement( ret, ci);

         start = en;
      }
      mc.appendTail(ret);
      return ret.toString();
   }

   class Name
   {
      int hitQuality = 0;  // 0: exact,  1: contains, 2: collated, 3: approx
      String name;
      int max;
      String gender;
      int[][] occs;  // {{n1, c1}, ...}

      String freqLow = "";   // 0,1,2,3
      String freqMed = "";   // 4,5,6,7
      String freqHigh = "";  // 8..D

      public Name(String name, String gender, Map<Integer, Integer> couOc, int hitQuality)
      {
         this.hitQuality = hitQuality;
         this.name = name;
         this.gender = gender;

         if(this.name.indexOf(' ')>0)
         {
            // ignore equivalence name  "A B"
            this.name = name.substring(0, name.indexOf(' '));
         }

         occs = new int[couOc.size()][2];
         int i=0;
         for(int ci : couOc.keySet())  // country
         {
            int ni = couOc.get(ci);    // frequ (log-normed)
            max = Math.max(ni, max);
            occs[i][0] = ni;
            occs[i][1] = ci;
            i++;

            if(ni>7)
            {
               freqHigh += ", "+countries.get(ci);
            }
            else if(ni>3)
            {
               freqMed += ", "+countries.get(ci);
            }
            else
            {
               freqLow += ", "+countries.get(ci);
            }
         }

         if(freqHigh.startsWith(", ")) freqHigh = freqHigh.substring(2);
         if(freqMed.startsWith(", "))  freqMed = freqMed.substring(2);
         if(freqLow.startsWith(", "))  freqLow = freqLow.substring(2);
      }

      @Override public final String toString()
      {
         StringBuilder sb = new StringBuilder();
         sb.append(name+" "+gender+" "+max);
         if(freqHigh.length()>0) sb.append(": "+freqHigh);
         return sb.toString();
      }
   }

// quick De and Fr feeling
// Use only for compare and search !
   public static String normalizeCH(String name)
   {
      //name = removeAccents(name);
      name = name.toUpperCase(Locale.ENGLISH);  // same as DE for us

      name = name.replace("OE", "E");  // or Ö => OE  ???
      name = name.replace("OU", "U");
      name = name.replace("OI", "I");
      name = name.replace("OA", "A");

      //name = removeAccents(name);

      name = name.replace("SCH", "1");
      name = name.replace("CH", "K");  // Achermann
      name = name.replace("AU", "O");
      //name = name.replace("NN", "N");
      name = name.replace("PH", "F");
      //name = name.replace("SS", "S");
      name = name.replace("Y", "I");
      name = name.replace("Z", "S");
      name = name.replace("B", "P");
      name = name.replace("J", "I");
      name = name.replace("G", "I");
      name = name.replace("W", "V");
      name = name.replace("X", "K");
      name = name.replace("Q", "K");
      name = name.replace("C", "K");
      name = name.replace("D", "T");
      //name = name.replace("B", "P");


      name = name.replace("H", "");
      //name = name.replace("H", "");

      return removeDoubleLetters(name);
   }

   public static String removeDoubleLetters(String s)
   {
      if(s.length()==0) return s;
      char prev = s.charAt(s.length()-1);
      StringBuilder sb = null;
      for(int i=s.length()-2; i>=0; i--)
      {
         if(s.charAt(i)==prev)
         {
            if(sb==null) sb = new StringBuilder(s);
            sb.replace(i,i+1,"");
         }

         prev = s.charAt(i);
      }
      if(sb!=null) return sb.toString();
      return s;
   }

   static String acc = "éèêëóòôöúùûüíìîïáàâäãñõÿýÉÈÊËÓÒÔÖÚÙÛÜÍÌÎÏÁÀÂÄÃÑÕÐÆŠÅŽÝçÇØÞðšøæåß"
     +"\u0117\u0100\u0101\u015f\u0131\u012b\u0113\u017e\u013c\u011b"
     +"\u016b\u0163\u0111\u0159\u0146\u011f\u00fe\u0142\u0107\u010d"
     +"\u017c\u0103\u0106\u010c\u0110\u0151\u0105\u0112\u0122\u0130"
     +"\u013e\u0137\u0123\u0119\u013b\u013d\u0141\u010f\u0145\u016f"
     +"\u015e\u0165\u017b\u0148"
     +"\u0116\u012a\u011a\u016a\u0162\u0158\u011e\u0102\u0150\u0104\u0136\u0118\u010e\u016e\u0164\u0147";

   static String deacc="eeeeoooouuuuiiiiaaaaanoyyEEEEOOOOUUUUIIIIAAAAANODÆSAZYcCOposoaas"
     +"eAasllezle"
     +"utdrngplcc"
     +"zaCCDoaEGI"
     +"lkgeLLLdNu"
     +"StZn"
     +"EIEUTRGAOAKEDUTN";

   static StringBuilder unknown = new StringBuilder();

// deep (slow)
// Use only for compare and search !
   public static String removeAccents(String str)
   {
      boolean has = false;
      for(char ci : str.toCharArray())
      {
         if(ci>'z') { has=true; break; }
      }
      if(!has) return str;
      StringBuilder sb = new StringBuilder(str.length());
      for(char ci : str.toCharArray())
      {
         if(ci>'z')
         {
            int pos = acc.indexOf(ci);
            if(pos<0)
            {
               System.out.println("not found: "+((int)ci));
               sb.append(ci);
               if(unknown.indexOf(""+ci)<0)
               {
                  unknown.append(ci);
               }
            }
            else
            {
               sb.append(deacc.charAt(pos));
            }
         }
         else
         {
            sb.append(ci);
         }
      }

      return sb.toString();
   }


   public static void main(String[] args) throws Exception
   {
      if(!isInstalled())
      {
         if(installDict()==null) return;
      }


      EventQueue.invokeLater(new Runnable() { public void run() {
         try{
            new NamesExplorer();
         }
         catch(Exception e) {
            JOptionPane.showMessageDialog(null, "Names explorer error: "+e.getMessage(), "Names Explorer Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
         }

      }});

   }


   class TM extends FineGrainTableModel
   {
      public Object getValueAt(int row, int col)
      {
         if(row<0) return "??";
         Name ni = names.get(row);
         if(col==0) return ni.hitQuality;
         if(col==1) return ni.gender;
         if(col==2) return ni.name;
         if(col==3) return ni.max;
         if(col==4) return ni.freqHigh;
         if(col==5) return ni.freqMed;
         if(col==6) return ni.freqLow;
         return "??";
      }

      @Override
      public String getColumnName(int col)
      {
         if(col==0) return "Hit quality";
         if(col==1) return "Gender";
         if(col==2) return "Name";
         if(col==3) return "Max Log";
         if(col==4) return "Frequent";
         if(col==5) return "Medium";
         if(col==6) return "Rare";
         return "";
      }

      public void clear()
      {
         names.clear();
         fireTableDataChanged();
      }

      public void update()
      {
         fireTableDataChanged();
      }

      int[] COLUMN_PREFERRED_SIZES = new int[]{1,1,10,1,14,14,14};
      @Override
      public int getPreferredColumnWidth(int column)
      {
         if(column>=0 && column<COLUMN_PREFERRED_SIZES.length) return COLUMN_PREFERRED_SIZES[column];
         return -1;
      }

      public int getColumnCount() { return 7; }
      public int getRowCount()    { return names.size(); }
   }

}