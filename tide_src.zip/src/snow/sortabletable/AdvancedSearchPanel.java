package snow.sortabletable;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import snow.completion.*;
import snow.utils.gui.*;

/** a small utility to add a search panel to a sortable table viewer
*/
public class AdvancedSearchPanel extends JPanel
{
  final protected JTextField searchFT = new JTextField(4);
  final protected JTextField searchFT2 = new JTextField(4);

  final protected JButton activateAdvancedButton = new JButton(new SortDirectionSelfDrawingIcon(SortDirectionSelfDrawingIcon.Right));
  final protected JButton deactivateAdvancedButton = new JButton(new SortDirectionSelfDrawingIcon(SortDirectionSelfDrawingIcon.Left));

  final protected JComboBox searchOperationCB = new JComboBox(new String[]{ "&", "||"});
  final protected JComboBox searchColumnCB = new JComboBox();
  final protected JCheckBox regExSearchCB = new JCheckBox("RegEx", false);



  protected SortableTableModel stm;

  boolean advancedMode = false;
  boolean allowRegEx = false;

  private ArrayList<ChangeListener> searchChangeListeners = new ArrayList<ChangeListener>();

  final private AnimatedColorPanel backPanelToAnimate = new AnimatedColorPanel(new FlowLayout(FlowLayout.LEFT,2,2), 100);


  /** "Filter: " and without icon
  */
  @SuppressWarnings("nullness")
  public AdvancedSearchPanel(final SortableTableModel stm, boolean allowRegEx)
  {
     this("Filter: ", null, stm, allowRegEx);
  }


  @SuppressWarnings("nullness")
  public AdvancedSearchPanel(final String searchLabelText,
                     final SortableTableModel stm, boolean allowRegEx)
  {
     this(searchLabelText, null, stm, allowRegEx);
  }

  /**
      @param searchLabelText is normally "Search: " or "Filter: "
  */
  public AdvancedSearchPanel(final String searchLabelText, final /*@org.checkerframework.checker.nullness.qual.Nullable*/ Icon searchIcon,
                     final SortableTableModel stm, boolean allowRegEx)
  {
    super(new FlowLayout(FlowLayout.LEFT,0,0));  // margin already in backPanelToAnimate
    this.setOpaque(false);
    backPanelToAnimate.setOpaque(false);
    this.stm = stm;
    this.allowRegEx = allowRegEx;

    // must be a vector for the combobox
    final Vector<String> colNames = new Vector<String>();
    colNames.add("All Columns");
    if(stm!=null)
    {
      for(int i=0; i<stm.getBasicTableModel().getColumnCount(); i++)
      {
        colNames.add( stm.getBasicTableModel().getColumnName(i));
      }
      searchColumnCB.setModel(new DefaultComboBoxModel(colNames));
    }

    if(colNames.size()<3)
    {
      searchColumnCB.setVisible(false);
    }

    // Components
    //

    add(backPanelToAnimate);

    backPanelToAnimate.add(new JLabel(searchLabelText, searchIcon, JLabel.LEFT));
    backPanelToAnimate.add(searchFT);
    searchFT.putClientProperty("JComponent.sizeVariant", "small");

    backPanelToAnimate.add(activateAdvancedButton);
    activateAdvancedButton.setToolTipText("Advanced Search");
    activateAdvancedButton.setFocusPainted(false);
    activateAdvancedButton.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          setAdvancedMode(true);
        }
      });

    backPanelToAnimate.add(searchOperationCB);
    backPanelToAnimate.add(searchFT2);
    searchFT2.putClientProperty("JComponent.sizeVariant", "small");

    backPanelToAnimate.add(searchColumnCB);
    searchColumnCB.setMaximumRowCount(35);  // see all, without scroll

    add(deactivateAdvancedButton);
    deactivateAdvancedButton.setToolTipText("Return to Simple Search");
    deactivateAdvancedButton.setFocusPainted(false);
    deactivateAdvancedButton.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          setAdvancedMode(false);
        }
      });

    if(allowRegEx)
    {
      add(regExSearchCB);
      regExSearchCB.setOpaque(false);
    }

    // key listener
    //
    KeyAdapter kad = new KeyAdapter()
    {
      @Override public void keyReleased(KeyEvent ee)
      {
        doSearch();
      }
    };

    searchOperationCB.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          doSearch();
        }
      });

    searchColumnCB.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          doSearch();
        }
      });

    searchFT.addKeyListener(kad);
    searchFT2.addKeyListener(kad);

    // focus behaviour
    //

    GUIUtils.selectAllTextWhenFocused(searchFT);
    GUIUtils.selectAllTextWhenFocused(searchFT2);

    // [Jan2006]: avoid focus on the UI comps
    activateAdvancedButton.setFocusable(false);
    deactivateAdvancedButton.setFocusable(false);


    // CTRL+F mapping
    //

    this.registerKeyboardAction(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          searchFT.requestFocus();
        }
      },
      KeyStroke.getKeyStroke(KeyEvent.VK_F, KeyEvent.CTRL_DOWN_MASK),
      JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT // BAD when two present: .WHEN_IN_FOCUSED_WINDOW
    );  // ### Maybe pass the parent as argument reference and register actions on it.
        // It makes sense if several internal frames have searches...

    // UI
    //activateAdvancedButton.setMargin(new Insets(0,0,0,0));

    activateAdvancedButton.setPreferredSize(new Dimension(
         searchFT2.getPreferredSize().height*2/3,
         searchFT2.getPreferredSize().height));

    deactivateAdvancedButton.setPreferredSize(new Dimension(
         searchFT2.getPreferredSize().height*2/3,
         searchFT2.getPreferredSize().height));

if(!GUIUtils.isNimbusLF())
{
    this.searchOperationCB.setPreferredSize(new Dimension(
         searchOperationCB.getPreferredSize().width,
         searchFT2.getPreferredSize().height));

    this.searchColumnCB.setPreferredSize(new Dimension(
         searchColumnCB.getPreferredSize().width,
         searchFT2.getPreferredSize().height));
}
    // initial state
    EventQueue.invokeLater(new Runnable(){public void run()
    {
      setAdvancedMode(advancedMode);
    }});


    //this.setBorder(new LineBorder(Color.red,1));
  }

  public void setSortableTableModel(SortableTableModel stm)
  {
    int fontSize = searchColumnCB.getFont().getSize();
    int maxWidth = 0;

    this.stm = stm;
    if(stm!=null)
    {
      Vector<String> colNames = new Vector<String>();
      colNames.add("All Columns");
      for(int i=0; i<stm.getBasicTableModel().getColumnCount(); i++)
      {
        String name = stm.getBasicTableModel().getColumnName(i);
        colNames.add( name );

        if(name.length()>maxWidth) maxWidth = name.length();
      }
      searchColumnCB.setModel(new DefaultComboBoxModel(colNames));
    }
    else
    {
      searchColumnCB.setModel(new DefaultComboBoxModel(new Vector<String>()));
    }

    if(searchColumnCB.getModel().getSize()<3)
    {
      searchColumnCB.setVisible(false);
    }


    Dimension dim = new Dimension(fontSize*maxWidth, searchColumnCB.getPreferredSize().height);
    searchColumnCB.setSize(dim);
    searchColumnCB.setPreferredSize(dim);

    //todo: maybe optional ?
    _installCompletion(searchColumnCB, searchFT);

    doSearch();
  }


  /** must be called in the EDT !
  */
  public void setAdvancedMode(boolean active)
  {
      advancedMode = active;
      searchFT2.setVisible(active);
      deactivateAdvancedButton.setVisible(active);
      searchOperationCB.setVisible(active);
      searchColumnCB.setVisible(active);

      this.regExSearchCB.setVisible( allowRegEx && active );

      activateAdvancedButton.setVisible(!active);

      doSearch();
  }


  /** Must be called in the EDT !
      All the searches are done from here. This also notify the listeners
  */
  public void doSearch()
  {
    if(!SwingUtilities.isEventDispatchThread())
    {
       new Throwable("Should be called from EDT !").printStackTrace();
    }


    if(searchFT.getText().length()>0 || (this.advancedMode && searchFT2.getText().length()>0) )
    {
      backPanelToAnimate.activateAnimation(true);
      backPanelToAnimate.setOpaque(true);
    }
    else
    {
      backPanelToAnimate.activateAnimation(false);
      backPanelToAnimate.setOpaque(false);
    }

    if(advancedMode)
    {
      boolean andSearch = searchOperationCB.getSelectedIndex()==0;
      int col = searchColumnCB.getSelectedIndex()-1;  // -1 => all
      if(stm!=null)
      {
        stm.advancedSearch(searchFT.getText(), searchFT2.getText(), andSearch, regExSearchCB.isSelected(), col);
      }
    }
    else
    {
      // the second field is invisible => don't use it
      if(stm!=null)
      {
        stm.search(searchFT.getText(), "", regExSearchCB.isSelected());
      }
    }

    notifySearchChanged();
  }

  public boolean hasSearchText() { return searchFT.getText().length()>0 || searchFT2.getText().length()>0; }

  public String getSearchText() { return searchFT.getText(); }
  public JTextField getTextField() { return searchFT; }


  /** must be called in the EDT !
  */
  public void setSearchText(String t1, String t2)
  {
     searchFT.setText(t1);
     searchFT2.setText(t2);
     // do the search
     doSearch();
  }

  /** [Sep2008]
  */
  private void _installCompletion(final JComboBox columnCB, final JTextField field)
  {
     final TextComponentCompletion<String> tcc = new TextComponentCompletion<String>(field, false, true, 3, "");

     tcc.setCompletionListener(new TextComponentCompletion.CompletionListener<String>()
     {
        public void itemSelected(String item)
        {
           doSearch();
        }
     } );

     columnCB.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {

        int selCol = columnCB.getSelectedIndex();
        if(selCol<=0)  // ALL
        {
           tcc.setCompletions();  // no comp for "all"
        }
        else
        {
           Set<String> vals = SortableTableModelAnalysis.getDifferentColumnModValues(stm.getBasicTableModel(), selCol-1);
           //System.out.println("Set sel "+vals);

           tcc.setCompletions(vals);
        }
     }});
  }


  //
  // Listeners
  //

  public void addSearchChangeListener(ChangeListener cl )
  {
    searchChangeListeners.add(cl);
  }

  private void notifySearchChanged()
  {
    for(ChangeListener cl : searchChangeListeners)
    {
      cl.stateChanged(new ChangeEvent(this));
    }
  }


}