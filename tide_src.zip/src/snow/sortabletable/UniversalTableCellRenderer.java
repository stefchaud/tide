package snow.sortabletable;

import snow.utils.gui.Colors;
import java.awt.Font;
import java.awt.Component;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Graphics;
import java.lang.reflect.Method;
import snow.utils.gui.GUIUtils;
//1.6.0_10 import com.sun.java.swing.Painter;
import javax.swing.table.*;
import javax.swing.*;
import javax.swing.border.*;
import java.text.*;
import java.util.*;

/** Alternative to  DefaultTableCellRenderer
*  Accepts Double, Strings, Icons, and any Component (please if possible set them to setOpaque(false); to enable nice table selection).
*/
public class UniversalTableCellRenderer implements TableCellRenderer
{
  // TOO ugly!!
  //protected final DoubleRenderer doubleRenderer = new DoubleRenderer();
  protected final StringRenderer stringRenderer = new StringRenderer();
  protected final ColorRenderer colorRenderer = new ColorRenderer();
  protected final BooleanRenderer booleanRenderer = new BooleanRenderer();
  protected final IconRenderer iconRenderer = new IconRenderer();
  protected final PainterRenderer painterRenderer = new PainterRenderer();

  // don't work now, seems that a JComponent only renders if in a UI tree...
  //protected final ComponentRenderer componentRenderer = new ComponentRenderer();

  static Border noFocusBorder = new EmptyBorder(1, 1, 1, 1);

  protected final /*@org.checkerframework.checker.nullness.qual.Nullable*/ SortableTableModel sortableTableModel;

  private /*@org.checkerframework.checker.nullness.qual.Nullable*/ String customFontText = null;
  public final void setCustomFontText(String a) { this.customFontText = a; }

  // [mai2011]: more flexibility !
  private Map<Integer,Format> formatterForColumn = new HashMap<Integer,Format>();
  public void setFormatForColumn(int col, Format fmt)
  {
     formatterForColumn.put(col, fmt);
  }



  int fontSize = 10;

  public UniversalTableCellRenderer(JTable table)
  {
     this.sortableTableModel = null;
     if(table!=null)
     {
        installGUI(table);
     }
  }

  /** @param sortableTableModel is used to set column alignments (left, right)
  */
  public UniversalTableCellRenderer(SortableTableModel sortableTableModel, JTable table)
  {
     setupUI();
     this.sortableTableModel = sortableTableModel;

     if(table!=null)
     {
        installGUI(table);
     }
  }

  public void installGUI(JTable table)
  {
    table.setDefaultRenderer(Object.class, this);  // MUST be set to accept DerivedColor and other derived UI comps.
    table.setDefaultRenderer(Double.class, this);
    table.setDefaultRenderer(Integer.class, this);
    table.setDefaultRenderer(Color.class, this);
    table.setDefaultRenderer(Boolean.class, this);
    table.setDefaultRenderer(Long.class, this);  // dates, sizes
    table.setDefaultRenderer(Date.class, this);  // dates
  }

/*
  public void setDecimalAlignmentPixelPos(int pos)
  {
    this.doubleRenderer.posPoint = pos;
  }*/

  /** Must be called after each L&F changes
  */
  private void setupUI()
  {
     fontSize = UIManager.getFont("Table.font").getSize();
     noFocusBorder = new EmptyBorder(fontSize/4, fontSize/4, fontSize/4, fontSize/4);

     //doubleRenderer.setupUI();
     stringRenderer.setupUI();
  }


  public Component getTableCellRendererComponent(JTable table, Object value,
     boolean isSelected, boolean hasFocus, int row, int column)
  {

    int coltm = table.convertColumnIndexToModel(column);

   /* if(value instanceof Date)
    {
       System.out.println("Date in column "+column+" ("+coltm+")");
    } */

    BasicRenderer comp = getRendererFor(value, coltm);

    if(value instanceof Font)
    {
       Font font = (Font) value;
       if(customFontText!=null && customFontText.trim().length()>0)
       {
          comp.setValue(customFontText);
       }
       else
       {
         comp.setValue("Font "+font.getFontName()+", size="+font.getSize());
       }
       comp.setFont(font);
    }
    else
    {
       comp.setFont(table.getFont());
       comp.setValue(value);
    }

/*
    if(comp instanceof ComponentRenderer)
    {
      // important: also works with "free" elements not being displayed
      int cw = table.getColumnModel().getColumn(coltm).getWidth();
      int ch = table.getRowHeight();
      ((JComponent) value).setSize(cw, ch);
      //((JComponent) value).setOpaque(true);

    }*/

    if(value instanceof Color) // || value instanceof javax.swing.plaf.UIResource)
    {
       //System.out.println("Color renderer comp");
    }
    else
    {

       if (isSelected) {
          // that's ok
          comp.setForeground( table.getSelectionForeground() );
          comp.setBackground( table.getSelectionBackground() );
       }
       else
       {
          if(GUIUtils.isNimbusLF())
          {
              Color background =  null; //Color.magenta; //table.getBackground();
              if (background == null || background instanceof javax.swing.plaf.UIResource) {
                  Color alternateColor = UIManager.getColor("Table.alternateRowColor");
                  if (alternateColor != null && row % 2 == 0)
                  {
                      background = alternateColor;
                  }
                  else
                  {
                     // Bug ? only works when "purified"
                     background = GUIUtils.createPureColor( UIManager.getColor("Table.background") );
                  }
              }
              comp.setForeground( table.getForeground());
              comp.setBackground(background);
          }
          else
          {
              comp.setForeground(table.getForeground());
              comp.setBackground(table.getBackground());
          }
       }
    }

    if(sortableTableModel!=null && coltm==sortableTableModel.sortedColumnInBasicModel)
    {
       comp.setBackground( Colors.createContrastedColor( comp.getBackground(), 6f) );
    }

    if(value instanceof Component)
    {
       Component ret = (Component) value;
       if(ret instanceof JComponent)
       {
         ((JComponent) ret).setOpaque(true);
       }
       ret.setBackground(comp.getBackground());
       return ret;
    }

    return (Component) comp;
  }


  private BasicRenderer getRendererFor(Object value, int coltm)
  {
    if(value==null) return stringRenderer; // [March2008]: was doubleRenderer;

 /*   if(value instanceof Double)
    {
      return doubleRenderer;
    }*/

    if(value instanceof Color)
    {
      return this.colorRenderer;
    }

    if(value instanceof Boolean)
    {
       return booleanRenderer;
    }

    /* [Feb2009]: with 1.6.0_11 !!!!!
    Exception in thread "AWT-EventQueue-0" java.lang.ClassCastException: snow.sortabletable.UniversalTableCellRenderer$IconRenderer cannot be cast to javax.swing.JCheckBox
    */

    else if(
       //GUIUtils.isNimbusLF() &&
        value instanceof ImageIcon)  // [Feb2009]: replaced Icon with ImageIcon to avoid conflicts causing the above exception
    {
       return iconRenderer;
    }
   /* else if(value instanceof AbstractButton)
    {
       return componentRenderer; //stringRenderer;
    }*/
    else if(GUIUtils.isNimbusLF() && (value instanceof Border
         || value.getClass().getName().endsWith("Painter")))   // Tricky, Painter only exists since 1.6.0_10, => don't import it to remain compilable !!
    {
       // [Mai2008] UniversalTableCellRenderer$PainterRenderer cannot be cast to javax.swing.AbstractButton

       return painterRenderer;
    }
   /* else if(value instanceof Component)  // [dec2008]
    {
       return componentRenderer;
    }*/
    else // String & defaults  (and int)
    {

      // System.out.println(""+value.getClass().getName());
      if(sortableTableModel!=null)
      {
        int col = sortableTableModel.getColumnForViewIndex(coltm);
        stringRenderer.setHorizontalAlignment(sortableTableModel.getBasicTableModel().getColumnAlignment(col));
        stringRenderer.setFormatter(formatterForColumn.get(col));
      }
      else
      {

        stringRenderer.setFormatter(formatterForColumn.get(coltm));
      }

      //stringRenderer.setFormatter(formatterForColumn.get(viewColumn));

    }

    // default
    return stringRenderer;
  }

  //
  // Renderers
  //

  interface BasicRenderer // extends Component
  {
     public void setValue(Object value);
     public void setFont(Font f);
     public void setForeground(Color c);

     public void setBackground(/*@org.checkerframework.checker.nullness.qual.Nullable*/ Color c);
     public Color getBackground();
  }

// NOT NICE:
/*
  class DoubleRenderer extends JComponent implements BasicRenderer
  {
    String value = "";
    DecimalFormat format = new DecimalFormat("#.###");
    int posPoint = 80;
    AffineTransform identityTransform = new AffineTransform();
    FontRenderContext fontRenderContext = new FontRenderContext(identityTransform, false, false);
    int posX = 0;

    public DoubleRenderer()
    {
    }

    public void setupUI()
    {
      setBorder(noFocusBorder);
      setOpaque(true);
    }

    @Override
    public void paintComponent(Graphics g)
    {
       // fill background and set foreground color.
       Graphics2D g2 = (Graphics2D) g;
       g.setColor(this.getBackground());
       g2.fill(g.getClipBounds());
       g.setColor(this.getForeground());


       int fs = g.getFont().getSize();
       int posY = this.getSize().height/2 + fs/2;

       //fontRenderContext
       //SwingUtilities.

       g.drawString(value, posX, posY);
    }

    public void setValue(Object o)
    {
       if(o == null)
       {
         System.out.println("Double renderer: null value passed !");
         value = "<NULL>";
       }
       else if(o instanceof Number)  // [March2008]: not always Double !
       {
         value = format.format((Number) o);
       }
       else
       {
         System.out.println("Double renderer: not a number !: "+o.getClass()+": "+o);
         value = ""+o;
       }


       int pos = value.indexOf('.');
       if(pos<0) pos = value.length();
       String beforePoint = value.substring(0,pos);
       //System.out.println(""+beforePoint+" "+value);


       TextLayout textLayout = new TextLayout(beforePoint, this.getFont(), fontRenderContext);
       Rectangle2D bounds = textLayout.getBounds();
       posX = posPoint - (int) bounds.getWidth();
       if(posX<4) posX=4;

    }
  }*/

/* DOESN'T WORK !!!
*
  class DoubleRenderer extends JTextField implements BasicRenderer
  {
     DecimalFormat format = new DecimalFormat("0.000");
     DefaultStyledDocument document = new DefaultStyledDocument();
     SimpleAttributeSet attributes;

     public DoubleRenderer()
     {
       super();
       setOpaque(true);

       this.setEditable(false);
       this.setDocument(document);

       TabSet tabset = new TabSet(
             new TabStop[]{
                new TabStop(160.2f, TabStop.ALIGN_DECIMAL, TabStop.LEAD_THICKLINE)
             });
       attributes = new SimpleAttributeSet();
       StyleConstants.setTabSet(attributes, tabset);
       StyleConstants.setForeground(attributes, Color.green);

     }

     public void setupUI()
     {
       setBorder(noFocusBorder);
       setOpaque(true);
     }

     public void setValue(Object o)
     {
       if(o==null)
       {
         setText("ERROR: null");
         //setText("");
         return;
       }

       if(o instanceof Double)
       {
         double value = ((Double) o).doubleValue();
         try
         {
           document.remove(0, document.getLength());
           document.setParagraphAttributes(document.getLength(), 0, attributes, true);
           document.insertString(document.getLength(), "\t"+format.format(value), attributes);
         } catch(Exception e){ e.printStackTrace(); }
         //setText("\t"+format.format(value));
         return;
       }

       try
       {
         document.replace(0,document.getLength(), "Bad class "+o.getClass(), attributes);
       } catch(Exception e){}

     }
  }  */

  class StringRenderer extends JLabel implements BasicRenderer
  {
     public StringRenderer()
     {
       super();
       setOpaque(true);
     }

     /*@org.checkerframework.checker.nullness.qual.Nullable*/ Format fmt = null;
     void setFormatter(/*@org.checkerframework.checker.nullness.qual.Nullable*/ Format fmt)
     {
        this.fmt = fmt;
     }

     public void setupUI()
     {
       setBorder(noFocusBorder);
       setOpaque(true);
     }

     public void setValue(Object o)
     {
        if(fmt!=null)
        {
           try{
              setText( fmt.format(o) );
           }
           catch(final Exception e) {
              setText( "<fmt err> "+o );
           }

           return;
        }

        if(o instanceof Object[])
        {
          setText(Arrays.toString((Object[])o));
        }

        else
        {
          setText(""+o);
        }
     }
  }

  class IconRenderer extends JLabel implements BasicRenderer
  {
     public IconRenderer()
     {
       super();
       setOpaque(true);
     }

     public void setupUI()
     {
       setBorder(noFocusBorder);
       setOpaque(true);
     }

     public void setValue(Object o)
     {
        if(o instanceof Icon)
        {
             Icon icon = (Icon) o;
             setIcon(icon );
        }
        else
        {
             setText("Not an icon: "+o);
        }
     }
  }

/*
  static class ComponentRenderer extends JPanel implements BasicRenderer
  {
     public ComponentRenderer()
     {
       super();
       setOpaque(true);
     }

     public void setupUI()
     {
       setBorder(noFocusBorder);
       setOpaque(true);
     }

     /*@org.checkerframework.checker.nullness.qual.Nullable/ Component comp = null;
     public void setValue(Object o)
     {
       comp = (Component) o;
     }

     @Override public final void paintComponent( Graphics g )
     {
       super.paintComponent(g);

       if(comp==null) return;

       g.setColor( getBackground() );
       g.fillRect(0, 0, comp.getWidth(), comp.getHeight());

       //System.out.println("filled "+comp.getWidth()+" "+comp.getHeight()+" with "+getBackground());

       //TRICKY: JComponent .paintComponents(g);  // don't work if the comp is not in a valid UI tree i.e. added in some parent.
       // so we always use the Component's paint

       // important: the component's size must have been set before.

       comp.paint(g);
     }

  }*/

/* Painter interface only from 1.6.0_10 !! => uses reflection to access the interface and remains compatible (compilable)
  with 1.6.0 !!  (TRICKY!) */
  public static class PainterRenderer extends JPanel implements BasicRenderer
  {
     public PainterRenderer()
     {
       super();
       setOpaque(true);
     }

     public void setupUI()
     {
       setBorder(noFocusBorder);
       setOpaque(true);
     }

     /*@org.checkerframework.checker.nullness.qual.Nullable*/ Object painter = null;
     public void setValue(Object o)
     {

        /*if(o instanceof Painter)
        {
           painter = (Painter) o;

            //setIcon((Icon) o );
           //BufferedImage ret = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_ARGB);
          //BufferedImage.TYPE_BYTE_GRAY);
           //p.paint( ret.getGraphics(), null, getWidth(), getHeight());

           repaint();
        }
        else*/

        if(o instanceof Border)
        {
           setBorder((Border) o);
        }
        else
        {
           // try as painter, below...
           painter = o;
        }
     }

     @Override public final void paintComponent( Graphics g )
     {
       super.paintComponent(g);  // [May2008] was "paintComponents" !
       Graphics2D g2 = (Graphics2D) g;
       if(painter!=null && getWidth()>0 && getHeight()>0)
       {
          /*try
          {
            p.paint( g2, null, getWidth(), getHeight());
          }catch(Exception ignore) {
             */
          try
          {
            //  public void paint(Graphics2D g, T object, int width, int height);
            //  in  com.sun.java.swing.Painter<T>,    T=JComponent for example
            Method m = painter.getClass().getMethod("paint", Graphics2D.class, Object.class, Integer.TYPE, Integer.TYPE);
            m.invoke(painter, g, this, getWidth(), getHeight());
          }catch(Exception ignore) {} //{ ignore.printStackTrace();}

//??? 1.6.0_10beta Exception in thread "AWT-EventQueue-0" java.lang.NullPointerException
// UIKeysViewer> 	at com.sun.java.swing.plaf.nimbus.ToolBarSeparatorPainter.doPaint(ToolBarSeparatorPainter.java:49)

// sometimes also: java.lang.reflect.InvocationTargetException


       }
     }
  }


  public static class ColorRenderer extends JPanel implements BasicRenderer
  {
     List<Color> cols = new ArrayList<Color>();

     public ColorRenderer()
     {
       super();
       setOpaque(true);
     }

     public void setupUI()
     {
       setBorder(noFocusBorder);
       setOpaque(true);
     }

     public void setValue(Object o)
     {
       cols.clear();
       if(o==null)
       {
         return;
       }

       if(o instanceof Color)
       {
         String rep = ""+o;
         if(rep.startsWith("DerivedColor"))
         {
            //System.out.println("DC");
            cols.addAll( UIKeysViewer.parseDerivedColorsForTable(rep) );
         }

         this.setBackground(GUIUtils.createPureColor((Color) o));
         //repaint();
       }
     }

     @Override public void paintComponent(Graphics g)
     {
        //g.setColor(getBackground());
        super.paintComponent(g);  // Mai2008: was calling componentS
        //System.out.println("Paint comp "+g.getColor());
        if(cols.isEmpty()) return;

        int hi = getHeight();
        if(getWidth()==0) return;
        if(hi==0) return;

        int dw = getWidth()/(cols.size());

        for(int i=0; i<cols.size(); i++)
        {
           g.setColor(Color.black);
           g.drawRect(i*dw,0 ,dw,hi);
           if(cols.get(i)!=null)
           {
             g.setColor(cols.get(i));
             g.fillRect(i*dw+2,2 ,dw-4,hi-4);
           }
          /* else
           {

           }*/
        }

     }
  }


  class BooleanRenderer extends JCheckBox implements BasicRenderer
  {
     public BooleanRenderer()
     {
        super();
        setupUI();
     }

     public void setupUI()
     {
        setBorder(noFocusBorder);
        setOpaque(true);  // to see the alternating background
     }

     public void setValue(Object o)
     {
        if(o instanceof Boolean)
        {
           this.setSelected(((Boolean)o).booleanValue());
        }
        else
        {
           try{
              this.setSelected( Boolean.parseBoolean(""+o));
           }
           catch(final Exception e) {
           }
        }
     }
  }

 /** Standalone test.
  */
  public static void main( String[] arguments )
  {
     Test.main(arguments);
  }

}