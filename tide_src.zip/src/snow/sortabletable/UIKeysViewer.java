package snow.sortabletable;

import snow.utils.JavasDetector;
import tide.GlobalTideProps;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.event.*;
import javax.swing.plaf.*;
import snow.texteditor.SimpleDocument;
import snow.utils.ProcessUtils;
import snow.utils.StringUtils;
import snow.utils.gui.EnumUtils;
import snow.utils.gui.files.FileField;
import snow.utils.gui.GUIUtils;
import snow.utils.gui.GridLayout3;
import snow.utils.gui.JGridPanel;
import snow.utils.gui.LayoutUtils;
import tide.editor.MainEditorFrame;
import tide.editor.TideUtils;
import tide.project.ProjectSettings;
import tide.project.ProjectUtils;

/** A simple app to view the UI Keys. + code generation for the selected item.
*
*/
public class UIKeysViewer extends JFrame
{
   // DO NOT OBFUSCATE   <snow.sortabletable.UIKeysViewer>

  private final Vector<String> standardKeys = new Vector<String>();
  {
     standardKeys.add("Primary1");
  }

  final private UIKeysTableModel basicTableModel = new UIKeysTableModel();
  final private SortableTableModel sortableTableModel = new SortableTableModel(basicTableModel, 0, true);
  final private JTable table = new JTable(sortableTableModel);
  final private JTextField codeField = new JTextField(50);

  private final SimpleDocument detailsDoc = new SimpleDocument();
  private final JTextPane detailsPane = new JTextPane(detailsDoc);
  private final JPanel southPanel = new JPanel(new BorderLayout());

  public UIKeysViewer(boolean standalone)
  {
    super("Swing UI Keys explorer  [UIManager.getLookAndFeel() is "+UIManager.getLookAndFeel()+"]");

    if(standalone)
    {
      this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    GUIUtils.addCloseWithEscapeKey(this);

    setLayout(new BorderLayout());

    JPanel tablePan = new JPanel(new BorderLayout());
    tablePan.add(new JScrollPane(table), BorderLayout.CENTER);

    JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT, tablePan, southPanel);
    add(split, BorderLayout.CENTER);


    JPanel sp = new JPanel();
    sp.setLayout(new BoxLayout(sp, BoxLayout.X_AXIS));
    southPanel.add(sp, BorderLayout.SOUTH);

    southPanel.add(new JScrollPane(detailsPane), BorderLayout.CENTER);
    detailsPane.setEditable(false);


    sp.add(new JLabel("Code to paste: "));
    sp.add(codeField);
    GUIUtils.selectAllTextWhenFocused(codeField);
    codeField.setEditable(false);


      JGridPanel infoPanel = new JGridPanel(3);
      add(infoPanel, BorderLayout.NORTH);


      infoPanel.addG("Runtime");
      infoPanel.addG(System.getProperty("java.home"));
      infoPanel.addG("");

      if(System.getenv("swing.defaultlaf")!=null)
      {
        infoPanel.addG("System.getenv(\"swing.defaultlaf\")");
        infoPanel.addG(System.getenv("swing.defaultlaf"));
        infoPanel.addG("");
      }


      infoPanel.addG("Platform LAF");
      infoPanel.addG(UIManager.getCrossPlatformLookAndFeelClassName());
      infoPanel.addG("");


      infoPanel.addG("Current Look And Feel");
      LookAndFeel laf = UIManager.getLookAndFeel();
      if(laf!=null)
      {
         infoPanel.addG(""+UIManager.getLookAndFeel().getName());
      }
      else
      {
         infoPanel.addG("< null >");
      }


    if(TideUtils.getTideJarMaybeFromPreviousRun()!=null)
    {
      JButton newInstanceVM = new JButton("new instance with another VM...");
      newInstanceVM.setBackground(Color.orange);

      GUIUtils.makeSmall(newInstanceVM);

      newInstanceVM.setAlignmentY(0.5f);
      //infoPanel.addG("");
      infoPanel.addG(newInstanceVM, false);
      infoPanel.getGridLayout().addSeparator();
      newInstanceVM.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         newInstanceOtherVM();
      } });
    }
    else
    {
       infoPanel.addG("");
    }


    sortableTableModel.installGUI(table);

    UniversalTableCellRenderer ucr = new UniversalTableCellRenderer(sortableTableModel, table);
    table.getColumnModel().getColumn(2).setCellRenderer( ucr );

    MultiSearchPanel asp = new MultiSearchPanel(sortableTableModel);
    //add(asp, BorderLayout.NORTH);
    tablePan.add(asp, BorderLayout.NORTH);

    table.getSelectionModel().addListSelectionListener(new ListSelectionListener()
    {
        public void valueChanged(ListSelectionEvent lse) {
           codeField.setText(generateCode());
           updateDetailsPane();
        }
    });

    table.addMouseListener(new MouseAdapter(){
      @Override public void mouseClicked(MouseEvent me)
      {
         if(me.getClickCount()==2)
         {
            int sel = table.getSelectedRow();
            if(sel<0) return;

            // Todo: display details (for icon, painter, ...)
            int posMod = sortableTableModel.getIndexInUnsortedFromTablePos(sel);
            Object o = basicTableModel.getValueAt(posMod, 2);
            if(o instanceof Component)
            {
               GUIUtils.displayInDialog(UIKeysViewer.this, ""+basicTableModel.getValueAt(posMod, 0), (Component) o);
            }
            else if(o instanceof Icon)
            {
               GUIUtils.displayInDialog(UIKeysViewer.this, ""+basicTableModel.getValueAt(posMod, 0),
                  new JLabel((Icon) o));
            }
            else  if(o instanceof Border || o.getClass().getName().endsWith("Painter"))
            {
               UniversalTableCellRenderer.PainterRenderer pr = new UniversalTableCellRenderer.PainterRenderer();
               pr.setValue(o);
               GUIUtils.displayInDialog(UIKeysViewer.this, ""+basicTableModel.getValueAt(posMod, 0),pr);
            }
            else  if(o instanceof Color)  //TODO: DerivedColor
            {
               //DerivedColor;  don't import, Nimbus only exists from 1.6.0_10 !!
               //  access the pColor with reflection ?

               String ns = ""+o;
               if(ns.startsWith("DerivedColor("))
               {
                  GUIUtils.displayInDialog(UIKeysViewer.this, ""+basicTableModel.getValueAt(posMod, 0), derivedColorPanel(ns));
               }
               else
               {
                  JPanel p = new JPanel();
                  p.setOpaque(true);
                  p.setBackground(GUIUtils.createPureColor((Color) o));
                  // TODO: add text for derivedColor ?
                  GUIUtils.displayInDialog(UIKeysViewer.this, ""+basicTableModel.getValueAt(posMod, 0), p);
               }
            }
            else
            {
               System.out.println("Selected: "+o);
            }
         }
      }
    });

    this.setSize(850, 800);
    this.setLocationRelativeTo(null);
    LayoutUtils.ensureWithinScreen(this);
    this.setVisible(true);

    asp.requestKeyFocus();


  } // Constructor


  private void updateDetailsPane()
  {
     detailsPane.setText("");
     int sel = table.getSelectedRow();
     if(sel==-1) return;

     final int posMod = sortableTableModel.getIndexInUnsortedFromTablePos(sel);
     final String key = ""+basicTableModel.getValueAt(posMod, 0);
     final String className = ""+basicTableModel.getValueAt(posMod, 1);
     final Object obj = basicTableModel.getValueAt(posMod, 2);

     String name = StringUtils.extractFromFirstToNext_Excluded(className, ".", "UIResource");
     detailsPane.setText(""+obj);
     detailsPane.setCaretPosition(0);
  }


  private String generateCode()
  {
     int sel = table.getSelectedRow();
     if(sel==-1) return "";

     final int posMod = sortableTableModel.getIndexInUnsortedFromTablePos(sel);
     final String key = ""+basicTableModel.getValueAt(posMod, 0);
     final String className = ""+basicTableModel.getValueAt(posMod, 1);
     final Object obj = basicTableModel.getValueAt(posMod, 2);

     String name = StringUtils.extractFromFirstToNext_Excluded(className, ".", "UIResource");

     if(name!=null && name.length()>0)
     {
        name = StringUtils.keepAfterLastExcl(name, ".");
     }
     else if(obj instanceof Integer)
     {
        name = "Int";
     }
     else
     {
        if(obj!=null && !obj.equals("null value"))
        {
           String simpleName = obj.getClass().getSimpleName();
           if(simpleName.indexOf('$')<0 && !simpleName.endsWith(";") && !simpleName.endsWith("]"))
           {
              name = simpleName;
           }
        }
     }

     if(name!=null&& name.endsWith("$"))
     {
        name = name.substring(0,name.length()-1);
     }

     StringBuilder sb = new StringBuilder();
     sb.append("UIManager.get");
     if(name!=null && (name.equals("Boolean") || name.equals("Int") || name.equals("String")
                   || name.equals("Font") || name.equals("Insets")
                   || name.equals("Border") || name.equals("Icon")
                   || name.equals("Dimension")))
     {
       sb.append(""+name);
     } // let the rest be accessed with get()
     else if( name!=null && name.endsWith("Color"))
     {
       sb.append("Color");
     }
     else if( name!=null && name.endsWith("Icon"))
     {
       sb.append("Icon");
     }
     /*else
     {
       System.out.println("UIKeysViewer: not a simple name: "+name+" for "+className);
     }*/

     sb.append("(\""+key.replace("\"", "\\\"")+"\")");

     return sb.toString();
  }

  final private static Pattern derColorElt = Pattern.compile("(\\w*)=(\\S*)");
  final private static String oneColEltFloat = "(\\d+\\.\\d+)";
  final private static Pattern color3f = Pattern.compile(oneColEltFloat+","+oneColEltFloat+","+oneColEltFloat+"[,"+oneColEltFloat+"]?");
  final private static Pattern color3int = Pattern.compile("(\\d+),(\\d+),(\\d+)[,(\\d+)]?");

// tricky: gets details about a derivedColor, but without accessing it
//  but parsing its string representation, so we remains compilable prior to 1.6.0_10 !
//  and also early openJDK and JDK7
  @SuppressWarnings("nullness")
  public static JPanel derivedColorPanel(String der)
  {

     try
     {
        JPanel pan = new JPanel();
        GridLayout3 gl3 = new GridLayout3(2, pan);

        Matcher mat = derColorElt.matcher(der);
        while(mat.find())
        {
           //System.out.println(""+mat.group(0));
           gl3.add(mat.group(0));
           try
           {
              String nam = mat.group(1);
              String n = mat.group(2);

              if(nam.equals("offsets"))
              {
                 gl3.add("");
              }
              else if(UIManager.getColor(n)!=null)
              {
                 JLabel lab = new JLabel();
                 lab.setOpaque(true);
                 lab.setBackground(GUIUtils.createPureColor(UIManager.getColor(n)));
                 lab.setPreferredSize(new Dimension(50,20));
                 gl3.add(lab);
              }
              else
              {
                 try
                 {
                    Matcher m = color3f.matcher(n);
                    if(m.find())
                    {
                       JLabel lab = new JLabel();
                       lab.setOpaque(true);
                       lab.setBackground(new Color(Float.parseFloat(m.group(1)),Float.parseFloat(m.group(2)),Float.parseFloat(m.group(3))));
                       lab.setPreferredSize(new Dimension(50,20));
                       gl3.add(lab);
                       continue;
                    }
                 }
                 catch(Exception ex2)
                 {

                 }

                 try
                 {
                    Matcher m = color3int.matcher(n);
                    if(m.find())
                    {
                       JLabel lab = new JLabel();
                       lab.setOpaque(true);
                       lab.setBackground(new Color(Integer.parseInt(m.group(1)),Integer.parseInt(m.group(2)),Integer.parseInt(m.group(3))));
                       lab.setPreferredSize(new Dimension(50,20));
                       gl3.add(lab);
                       continue;
                    }
                 }
                 catch(Exception ex2)
                 {

                 }

                 gl3.add("?: "+n+" ");

              }
           }
           catch(Exception ex)
           {
              gl3.add( ""+ex.getMessage());
           }

        }
        return pan;
     }
     catch(Exception e)
     {
        JPanel p = new JPanel();
        p.add(new JLabel("Error: "+e.getMessage()));
        return p;
     }

  }

  /** small horizontal version.
  *   normally four colors, the third, null is for the "offsets"
  *   (color=0,0,0 parent=text offsets=0.0,0.0,0.0,0 pColor=0,0,0)
  */
@SuppressWarnings("nullness") //todo
  public static List<Color> parseDerivedColorsForTable(String der)
  {
     List<Color> cols = new ArrayList<Color>();
     try
     {
        JPanel pan = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pan.setOpaque(false);

        Matcher mat = derColorElt.matcher(der);
        while(mat.find())
        {
           //System.out.println(""+mat.group(0));
           //gl3.add(mat.group(0));
           try
           {
              String nam = mat.group(1);
              String n = mat.group(2);

              if(nam.equals("offsets"))
              {
                 cols.add( null );
              }
              else if(UIManager.getColor(n)!=null)
              {
                 cols.add( GUIUtils.createPureColor(UIManager.getColor(n)) );
              }
              else
              {
                 try
                 {
                    Matcher m = color3f.matcher(n);
                    if(m.find())
                    {
                       cols.add(  new Color(Float.parseFloat(m.group(1)),Float.parseFloat(m.group(2)),Float.parseFloat(m.group(3))));
                       continue;
                    }
                 }
                 catch(Exception ex2)
                 {

                 }

                 try
                 {
                    Matcher m = color3int.matcher(n);
                    if(m.find())
                    {
                       cols.add( new Color(Integer.parseInt(m.group(1)),Integer.parseInt(m.group(2)),Integer.parseInt(m.group(3))));
                       continue;
                    }
                 }
                 catch(Exception ex2)
                 {

                 }
              }
           }
           catch(Exception ex)
           {

           }

        }
     }
     catch(Exception e)
     {
     }

     return cols;
  }


  //Proguard: to KEEP
  /** used as standalone app
  */
  public static void main(String[] a) throws Exception
  {

     //GUIUtils.setNimbusLookAndFeel_IfPossible();
     //System.out.println("Is Nimbus: "+GUIUtils.isNimbusLF());
     //System.out.println(""+UIManager.getColor("CheckBox.foreground"));   // small SUN bug: closing ")" forgotten

     EventQueue.invokeLater(new Runnable()
     { public void run()
       {
         new UIKeysViewer(true);
       }
     });
  }



  class UIKeysTableModel extends FineGrainTableModel
  {
     final private Vector<Object> keys = new Vector<Object>();

     public UIKeysTableModel()
     {
        Enumeration<Object> enume = UIManager.getLookAndFeelDefaults().keys();
        while(enume.hasMoreElements())
        {
          keys.addElement(enume.nextElement());
        }
     }

     public UIKeysTableModel(Vector<String> keys)
     {
        this.keys.addAll(keys);
     }


     //private char[] representableCharsetChars = null;

     String[] COLUMN_NAMES = new String[]{"name", "class", "value" };

     int[] COLUMN_PREFERRED_SIZES = new int[]{20, 20, 25};
  @Override
     public int getPreferredColumnWidth(int column)
     {
       if(column>=0 && column<COLUMN_PREFERRED_SIZES.length) return COLUMN_PREFERRED_SIZES[column];
       return -1;
     }

  @Override
     public String getColumnName(int col) { return COLUMN_NAMES[col]; }

  @Override
     public int getColumnAlignment(int column)
     {
       return JLabel.LEFT;
     }

     @Override
     public Class<?> getColumnClass ( int column )
     {
        //if(column==0) return String.class;
        //if(column==1) return String.class;
        return Object.class; // important...
     }

     public int getColumnCount() { return COLUMN_NAMES.length; }
     public int getRowCount()    { return keys.size(); }

     @SuppressWarnings("unchecked")
     public Object getValueAt(int row, int col)
     {
       Object key = keys.get(row);
       Object val = UIManager.get(key);
       if(col==0) return key;
       if(col==1)
       {
         if(val==null) return "null value";
         return (""+val.getClass()).replace("class ", "");
            //  + ClassUtils.toStringGenericTypeDeclaration(val.getClass()); //.getName();
       }
       if(col==2)
       {
         if(val==null) return "null value";

        if(val instanceof Object[])
        {
          return (Arrays.toString((Object[])val)).replace("javax.swing", "");
        }
        else if(val instanceof List)
        {
          return (""+val).replace("javax.swing", "");
        }
        else if(val instanceof InputMap)
        {
          InputMap im = (InputMap) val;
          return (""+ im.keys().length+" keys: "+Arrays.toString(im.keys()));  // not Allkeys, only the one defined
        }
        else if(val instanceof ActionMap)
        {
          ActionMap im = (ActionMap) val;
          return (""+ im.keys().length+" keys: "+Arrays.toString(im.keys()));  // not Allkeys, only the one defined
        }
        else if(val instanceof Enum)
        {
           // ? not occuring...
          return "ENUMERATION: "+val+" "+EnumUtils.getEnumItems(((Enum) val).getClass());
        }

         return val;
       }

       return "?";
     }

  @Override
     public boolean isCellEditable(int row, int col)
     {
       return col==2;
     }


  @Override
     public void setValueAt(Object value, int row, int col)
     {
       if(col!=2) return;

       //boolean updateUI = false;
       if(value instanceof Color)
       {
         value = new ColorUIResource((Color) value);
         //updateUI = true;
       }

       if(value instanceof Font)
       {
         value = new FontUIResource((Font) value);
         //updateUI = true;
       }

       if(row>=keys.size())
       {
          System.out.println("Key position "+row+" son't exist, keys size is only "+keys.size());
          return;
       }

       String key = (String) keys.get(row);
       Object old = UIManager.get(key);

       // [nov2012]
       if(old!=null && value!=null && !(old.getClass() == value.getClass()))
       {
          if(old instanceof Boolean)
          {
             value = Boolean.parseBoolean(""+value);
          }
       }



       if(old!=null && value!=null && !(old.getClass() == value.getClass()))
       {
         System.out.println("Attemp to changing class type ! set value cancelled");
         System.out.println(old.getClass().getName()+" => "+value.getClass().getName());

         return;
       }

       this.fireTableModelWillChange();

       UIManager.put(key, value);

       this.fireTableDataChanged();
       this.fireTableModelHasChanged();
     }
  }


  /** let's explore the props of another UI in another VM
  */
  public void newInstanceOtherVM()
  {
     JGridPanel gp = new JGridPanel(2);

     final File tideJar = TideUtils.getTideJarMaybeFromPreviousRun();
     gp.getGridLayout().addExplanationArea("You can launch another instance from another VM\nThis lets you explore UI properties\n");


     FileField customJRE = new FileField("", false, "Choose the java executor (java.exe) to use", JFileChooser.FILES_ONLY);
     gp.addG("JRE");
     gp.addG(customJRE);
     //GUIUtils.makeSameHeight(autoJRE, customJRE.getTextField(), -1);

     if(MainEditorFrame.hasInstance())
     {
       customJRE.setPath( MainEditorFrame.getActualProject().getProperty(ProjectSettings.CUSTOM_JRE , null) );

       //customJRE.offerRememberedGlobalCompletion(GlobalTideProps.getGlobalProps(), "Global_ customJREs" );  // java.exe list
     }
     else
     {
        try{
           customJRE.setPath( new File(System.getProperty("java.home"), "bin/java") );
        }
        catch(final Exception e) {
           e.printStackTrace();
        }
     }

     customJRE.setAlternatePaths( JavasDetector.getKnownRuntimes_withFavorites(false) );

     Vector<Object> opts = new Vector<Object>();
     opts.add("");
     opts.add("-Dswing.defaultlaf=javax.swing.plaf.nimbus.NimbusLookAndFeel");
     opts.add("-Dswing.defaultlaf=com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");

     for(final UIManager.LookAndFeelInfo it : UIManager.getInstalledLookAndFeels())
     {
        String n = "-Dswing.defaultlaf="+it.getClassName();
        if(!opts.contains(n))
        {
           opts.add(n);
        }
     }

     JComboBox vmOpts = new JComboBox(opts);
     vmOpts.setEditable(true);
     gp.addG("VM args");
     gp.addG(vmOpts);

     int rep = gp.showOptionPane(this, "Launch Another UI Keys Viewer", new String[]{"Cancel", "Lanuch"}, 1);
     if(rep!=1) return;
     try
     {
        List<String> args = new ArrayList<String>();
        args.add(""+customJRE.getPath().getAbsolutePath());
        String ooo = ""+vmOpts.getSelectedItem();
        if(!ooo.isEmpty())
        {
           args.addAll( ProjectUtils.splitArgs(ooo, false) );
        }
        args.add(  "-cp" );
        args.add(  "."+File.pathSeparator+tideJar );
        args.add( "snow.sortabletable.UIKeysViewer" );

        ProcessUtils.executeProcessAndGobbleToConsole("", null, args.toArray(new String[args.size()]));
     }
     catch(final Exception e) {
        e.printStackTrace();
     }
  }


}