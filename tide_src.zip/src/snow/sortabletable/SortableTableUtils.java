package snow.sortabletable;

import java.awt.Component;
import java.awt.Window;
import java.awt.EventQueue;
import java.beans.PropertyChangeEvent;
import snow.utils.gui.CustomEtchedBorder;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.beans.PropertyChangeListener;
import java.awt.event.*;
import javax.swing.event.*;
import java.awt.Point;
import java.awt.FlowLayout;
import snow.utils.gui.LayoutUtils;
import snow.utils.gui.GUIUtils;
import java.awt.BorderLayout;
import javax.swing.*;


public final class SortableTableUtils
{
   private SortableTableUtils()
   {
   }


   /** Just adds a search bar at north and the table at center.
   */
   public static JPanel createTableWithSearchBar(final SortableTableModel stm, final JTable table)
   {
      JPanel p = new JPanel(new BorderLayout(0,0));
      p.add(GUIUtils.makeSmall(new JScrollPane(table)), BorderLayout.CENTER);

      MultiSearchPanel asp = new MultiSearchPanel(stm);
      p.add(asp, BorderLayout.NORTH);

      return p;
   }


   public static void main(String[] args) throws Exception
   {
      GUIUtils.setNimbusLookAndFeel_IfPossible();

      EventQueue.invokeLater(new Runnable() { public void run() {
          testSortableTable();
      }});
   }

   static void testSortableTable()
   {
      final JFrame f = new JFrame("test");
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

      final SortableTableModel stm = new SortableTableModel(new TestModel());
      final JTable table = new JTable(stm);
      stm.installGUI(table);
      table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

      //UniversalTableCellRenderer utr = new UniversalTableCellRenderer(stm, table);
      //utr.set


      final JScrollPane scrollPane = new JScrollPane(table);
      f.add(scrollPane, BorderLayout.CENTER);
      f.add(new JLabel("Some status"), BorderLayout.SOUTH);
      f.setJMenuBar(new JMenuBar());
      f.getJMenuBar().add(new JMenu("File"));

      final MultiSearchPanel msp = new MultiSearchPanel(stm);
      msp.setAdvancedState(false);

      installSearchAsInternalToolbar(msp, table, true); //, scrollPane, f);

      f.setSize(640, 460);
      f.setLocation(120,180);
      f.setVisible(true);

   }

   public static void installSearchAsInternalToolbar(final MultiSearchPanel msp, final JTable table, boolean visible)
   {
       final Component scrollPane =  table.getParent();
       final Window topFrame = SwingUtilities.windowForComponent(table);
       final JLayeredPane layeredPane = SwingUtilities.getRootPane(table).getLayeredPane();

      // Search panel
      //

      final JPanel searchPanel = new JPanel();
      searchPanel.setBorder(new CustomEtchedBorder(false, true, true, true));
      searchPanel.setBackground(new Color(250,250,250, 200));    // transparent !
      searchPanel.add(LayoutUtils.createDraggerPanel(searchPanel));
      searchPanel.add(LayoutUtils.createHideButton(searchPanel));
      searchPanel.add(msp);

      // important.
      msp.addPropertyChangeListener(MultiSearchPanel.queriesChangedProperty, new PropertyChangeListener()
      {
         public final void propertyChange( final PropertyChangeEvent evt ) {
            searchPanel.setSize(searchPanel.getPreferredSize());
            LayoutUtils.setLocationTopRight(searchPanel, scrollPane, new Point(0,30));
         }
      });

      searchPanel.setVisible(false);

      layeredPane.add( searchPanel, JLayeredPane.PALETTE_LAYER);

      searchPanel.setSize(searchPanel.getPreferredSize());  // mandatory

      // Search action


      LayoutUtils.setLocationTopRight_andTrack(searchPanel, scrollPane, new Point(0,30));

      final AbstractAction searchAction = new AbstractAction() { public void actionPerformed(final ActionEvent ae)
      {
         searchPanel.setSize(searchPanel.getPreferredSize());
         searchPanel.setVisible(true);
         layeredPane.moveToFront(searchPanel);
         msp.getFirstTextField().requestFocus();
      } };

      table.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_F, KeyEvent.CTRL_MASK, false),  // with "true": a lot of misses
        "Search");
      table.getActionMap().put("Search", searchAction);

      msp.viewHitsCount = true;

      if(visible)
      {
         EventQueue.invokeLater(new Runnable() { public void run() {
            searchAction.actionPerformed(null);
         }});
      }
      else
      {

         //todo idea: let appear at topright too and if user goes with mouse, show the search...
         LayoutUtils.showTipp("<html><h1>Tipp: Press Ctrl+F", scrollPane, 3000);
      }

   }

   //todo: react on some event! so the user can change it
   public static void addHitLabel(final MultiSearchPanel msp, final JTable table)
   {
       final Component scrollPane =  table.getParent();
       //final Window topFrame = SwingUtilities.windowForComponent(table);
       final JLayeredPane layeredPane = SwingUtilities.getRootPane(table).getLayeredPane();


      // Hit status
      final JPanel hitStatusPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT,4,0));
      final JLabel hitStatusLabel = new JLabel();
      hitStatusLabel.putClientProperty("JComponent.sizeVariant","small");
      hitStatusLabel.updateUI();

      hitStatusLabel.setText("Hello there are X hits in the pane");
      hitStatusPanel.setBorder(new EmptyBorder(0,0,0,0));
      hitStatusLabel.setBorder(new EmptyBorder(0,0,0,0));
      //hitStatusLabel.setBorder(new LineBorder(Color.red));
      hitStatusPanel.setBackground(new Color(210,210,210,190));  // light grey transparent


      hitStatusPanel.add(LayoutUtils.createDraggerPanel(hitStatusPanel));
      hitStatusPanel.add(LayoutUtils.createHideButton(hitStatusPanel));
      hitStatusPanel.add(hitStatusLabel);

      hitStatusPanel.setSize( hitStatusPanel.getPreferredSize() );

      hitStatusPanel.setVisible(false);

      layeredPane.add( hitStatusPanel, JLayeredPane.PALETTE_LAYER);



      // Hit action
      //don't work hideWhenMouseOver(hitStatusPanel);
      LayoutUtils.setLocationLowerRight_andTrack(hitStatusPanel, scrollPane, new Point(0,0));


      table.getSelectionModel().addListSelectionListener(new ListSelectionListener()
      {
         public final void valueChanged( final ListSelectionEvent e ) {
            int[] sr = table.getSelectedRows();
            if(sr.length==0)
            {
              hitStatusPanel.setVisible(false);
              return;
            }
            hitStatusPanel.setVisible(true);
            layeredPane.moveToFront(hitStatusPanel);

            hitStatusLabel.setText(""+sr.length+" selected rows");
            hitStatusPanel.setSize(hitStatusPanel.getPreferredSize());
         }
      });



   }

}