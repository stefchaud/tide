package snow.sortabletable;

import java.awt.*;
import java.awt.event.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import javax.swing.*;
import javax.swing.table.*;
import snow.utils.gui.GUIUtils;

public class Test extends JFrame
{

  TestModel mod;
  SortableTableModel stm;
  JCheckBox simpleViewCB = new JCheckBox("Simple view", false);

  public Test()
  {
    super();
    this.setTitle( "Test sortable table" );

    mod = new TestModel();
    stm = new SortableTableModel(mod, 0, true);

    final JTable table = new JTable(stm)
    {
       public Component _prepareEditor(TableCellEditor editor, int row, int col)
       {
          Component comp = editor.getTableCellEditorComponent(this,"", true,row,col);
          return comp;
       }
    };

    table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    stm.installGUI(table);

    UniversalTableCellRenderer utr = new UniversalTableCellRenderer(stm, table);

    utr.setFormatForColumn(0, new DecimalFormat("#.00"));
    utr.setFormatForColumn(8, new SimpleDateFormat("MM.yyyy"));
    utr.setFormatForColumn(9, new SimpleDateFormat("MMM.yyyy"));


    UniversalTableEditor ute = new UniversalTableEditor();
    table.setDefaultEditor(Object.class, ute);
    table.setDefaultEditor(Double.class, ute);
    table.setDefaultEditor(Integer.class, ute);


//    table.setFont(new Font("Dialog", Font.PLAIN, 14));
//    table.setRowHeight(30);

    JPanel content = new JPanel(new BorderLayout());
    setContentPane(content);
    content.add(new JScrollPane(table), BorderLayout.CENTER);

    JPanel controlPanel = new JPanel();
    content.add(controlPanel, BorderLayout.SOUTH);

    JButton addBT = new JButton("Add");
    controlPanel.add(addBT);
    addBT.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        mod.addRandom();
      }
    });

    JButton removeBT = new JButton("Remove Last");
    controlPanel.add(removeBT);
    removeBT.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        mod.removeLast();
      }
    });

    JButton removeSel = new JButton("Remove Selected");
    controlPanel.add(removeSel);
    removeSel.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        int[] sels = table.getSelectedRows();
        // retrieve the selected items list
        TestModelItem[] selit = new TestModelItem[sels.length];
        for(int i=0; i<sels.length; i++)
        {
          int pos = stm.getIndexInUnsortedFromTablePos(sels[i]);
          selit[i] = mod.getItemAt(pos);
        }

        // remove them, per reference, to avoid index iteration conflicts
        for(int i=0; i<sels.length; i++)
        {
          mod.remove(selit[i]);
        }
      }
    });


    // search
    final MultiSearchPanel searchPanel = new MultiSearchPanel(stm);
    searchPanel.setAdvancedState(false);
    JPanel wrap = new JPanel(new FlowLayout(FlowLayout.LEFT,0,0));
    //JPanel wrap = new JPanel();
    //wrap.setLayout(new BoxLayout(wrap, BoxLayout.X_AXIS)); //new FlowLayout(FlowLayout.LEFT,0,0));
    wrap.add(searchPanel);
    wrap.add(Box.createHorizontalStrut(40));
    wrap.add(simpleViewCB);
    simpleViewCB.setOpaque(false);
    simpleViewCB.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        if(!simpleViewCB.isSelected())
        {
          int[] allCols = new int[mod.getColumnCount()];
          for(int i=0; i<allCols.length; i++) allCols[i] = i;
          stm.setVisibleColumns(allCols);
        }
        else
        {
          stm.setVisibleColumns(new int[]{0,3});
        }
        stm.setPreferredColumnSizesFromModel();
      }
    });

    add(wrap, BorderLayout.NORTH);

    this.addWindowListener( new WindowAdapter()
     {
       @Override public void windowClosing(WindowEvent e)
       {
           terminateFrame(); // calls System.exit();
       }
       @Override public void windowClosed(WindowEvent e)
       {
           terminateFrame(); // calls System.exit();
       }
     }
    );


    final Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
    this.setSize(800,600);
    this.setLocation(180,120);
    this.setVisible(true);

    searchPanel.requestKeyFocus();

  } // Constructor




  private void terminateFrame()
  {
    System.exit(0);
  }

  public static void main( String[] arguments )
  {
     //JFrame.setDefaultLookAndFeelDecorated(true);

     GUIUtils.setNimbusLookAndFeel_IfPossible();


     EventQueue.invokeLater(new Runnable()
     {
       public void run()
       {
         new Test();
       }
     });
   }


   public static void numericalTest()
   {
     // numerical test described by sun in an article, showing ULP and addition errors.
     //
     long t0 = System.currentTimeMillis();
     double f=0.0;
     for(int i=0;i<=1000000000;i++)
     {
        f += Math.sqrt(i);
     }
     System.out.println(f+",  t="+(t0-System.currentTimeMillis())/1000+" sec");

     t0 = System.currentTimeMillis();
     double newsum;
     double sumerr=0.0;
     double err, sum=0;
     for(int i=1;i<=1000000000;i++)
     {
          f= Math.sqrt(i);
          newsum = sum + f;
          err = (newsum - sum ) - f;
          sumerr += err;
          sum = newsum;
     }
     System.out.println((sum-sumerr)+",  t="+(t0-System.currentTimeMillis())/1000+" sec");

  } // main



  static JComponent test_multires_renderer()
  {
     JTable t = new JTable(new Object[][]{{"a", "b"},{11, 12}}, new Object[]{"c1", "c2"});
     return new JScrollPane(t);
  }


}