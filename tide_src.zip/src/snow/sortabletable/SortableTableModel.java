package snow.sortabletable;

import snow.utils.gui.Colors;
import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.event.*;
import javax.swing.table.*;
import snow.utils.gui.CustomEtchedBorder;
import snow.utils.gui.GUIUtils;
import snow.utils.gui.Icons;

/** Wraps a basic model and allow sorting of his columns
    the basic model remains unchanged. Only this model is sorted !

    Features :
      + The selection is maintained after table updates.
      + Can installGUI() without corrupting model/view separation

    usage:
      1) make a FineGrain table model (like AbstractTableModel...)
      2) make this class, pass 1)
      3) make a table with this model 2)
      4) call installGUI() with the table 3) to allow sorting

    Caution: almost everything should be called from the EDT because
    tight coupling with the UI. Therefore, this class is not designed as threadsafe
    but is "safe" when manipulated from the EDT.
*/
public class SortableTableModel extends AbstractTableModel
{
  //for helpers
  private String name = "";

  // these are the indices in the unsirted model corresponding to the position in this
  // sorted model. element i is for position i in this table
  // WITHOUT SEARCH HITS
  final Vector<Integer> sortedRowIndices = new Vector<Integer>();

  // i-th element is the index in the basic model of the ith found element
  final Vector<Integer> foundBasicIndices = new Vector<Integer>();

  // this is the unsorted model
  private FineGrainTableModel basicTableModel;

  public final static Icon SORT_ASC  = new SortDirectionSelfDrawingIcon(SortDirectionSelfDrawingIcon.Ascending);
  public final static Icon SORT_DESC = new SortDirectionSelfDrawingIcon(SortDirectionSelfDrawingIcon.Descending);

  // used to remember selection when table change
  JTable tableReference;
  private JTable tableRowHeadersReference;
  int numberOfColumnAsRowHeaders = 0;


  // contain the basic model column indices to show (selected = visible)
  // 0, 1, 3, 4    for example if column2 is not visible
  final Set<Integer> selectedColumns = new TreeSet<Integer>();

  private boolean columnVisibilitiesChangeEnable = true;
  public boolean autoSelectFirstHitIfNoOtherSelect = true;

  private boolean multiSearch = false;
  private Query /*@org.checkerframework.checker.nullness.qual.Nullable*/ [] queries = null;

  /** wraps a sortable feature around your basic table model

    Easy usage:
      1) just create your model, pass it here
      2) use this model as tablemodel for your jtable.
      3) After that, call installGUI and pass your JTable as argument.
  */
  public SortableTableModel(FineGrainTableModel basicTableModel)
  {
     this(basicTableModel, 0, true);
  }

  public FineGrainTableModel getBasicTableModel()
  {
    return basicTableModel;
  }

  private TableModelListener tableModelListener = null;
  private TableModelChangeListener tableModelChangeListener = null;


  /** wraps a sortable feature around your basic table model

    Easy usage:
      1) just create your model, pass it here
      2) use this model as tablemodel for your jtable.
      3) After that, call installGUI and pass your JTable as argument.
  */
  public SortableTableModel(FineGrainTableModel basicTableModel,
                            int sortedColumn, boolean ascending)
  {
     setBasicTableModel(basicTableModel, sortedColumn, ascending);
  }


  public void setBasicTableModel(FineGrainTableModel basicTableModel,
                            int sortedColumn, boolean ascending)
  {
     removeOldListeners();

     this.basicTableModel = basicTableModel;
     this.sortedColumnInBasicModel = sortedColumn;
     this.ascending       = ascending;

     tableModelListener = new TableModelListener()
     {
        // called after the table has changed
        public void tableChanged(TableModelEvent e)
        {
           //System.out.println("received tableChanged event from unsortedModel");
           createRangeForSorting();   // range 0,...,n-1
           internalSort();
           //internal_multisearch();

           // pass the event in same EDT for this listener
           fireTableDataChanged();
           //tableChanged(e);  // index mismatch... should convert them... ###
        }
     };
     basicTableModel.addTableModelListener(tableModelListener);

     tableModelChangeListener = new TableModelChangeListener()
     {
         public void tableModelWillChange(ChangeEvent e)
         {
           storeTableSelection();
         }

         public void tableModelHasChanged(ChangeEvent e)
         {
           restoreTableSelections();
         }
     };
     basicTableModel.addModelChangeListener(tableModelChangeListener);

     // all columns are selected
     for(int i=0; i<basicTableModel.getColumnCount(); i++)
     {
        selectedColumns.add(i);
     }

     // initial sort
     createRangeForSorting();
     sort(sortedColumn, ascending);
     //internal_multisearch();


     restoreTableSelections();  // ??? not now, but when table installed !!

  } // Constructor


  public void removeOldListeners()
  {
     if(basicTableModel!=null)
     {
       if(tableModelListener!=null) basicTableModel.removeTableModelListener(tableModelListener);
       if(tableModelChangeListener!=null) basicTableModel.removeModelChangeListener(tableModelChangeListener);
     }

     if(tableHeadClickMouseAdapter!=null)
     {
        tableRowHeadersReference.removeMouseListener(tableHeadClickMouseAdapter);
     }
     if(tableRefClickMouseAdapter!=null)
     {
        tableReference.removeMouseListener(tableRefClickMouseAdapter);
     }
  }

  /** free resource, listeners and so on...
  */
  public void terminate()
  {
     removeOldListeners();

     if(basicTableModel!=null)
     {
       this.basicTableModel.terminate();
       //basicTableModel = null;
     }
  }


  /** Only call this when you terminate the table,
      to keep selection stored in model (if implemented)
  */
  public void storeTableSelection()
  {
      //System.out.println("Store sel");
      if(!SwingUtilities.isEventDispatchThread())
      {
         new Throwable("Must be called from EDT !").printStackTrace();
      }

      if(tableReference==null) return;

      // store the selection (store indices of the basic model
      int[] sel = tableReference.getSelectedRows();
      basicTableModel.clearRowSelection();
      for(int i=0; i<sel.length; i++)
      {
         int indexThis = sel[i];
         int indexBase = getIndexInUnsortedFromTablePos(indexThis);
         basicTableModel.setRowSelection(indexBase, true);
      }
  }

  private void restoreTableSelections()
  {
     if(tableReference==null) return;
     if(this.getRowCount()==0) return;
     if(!SwingUtilities.isEventDispatchThread())
     {
       new Throwable("Must be called from EDT !").printStackTrace();
     }

     // restore selection
     tableReference.getSelectionModel().clearSelection();
     int[] sel = basicTableModel.getSelectedRows();
     for(int i=0; i<sel.length; i++)
     {
        int indexBase = sel[i];
        int pos = getIndexInFoundFromBasicIndex(indexBase);

        if(pos>=0 && pos<tableReference.getRowCount())
        {
          if(tableReference.getSelectionModel().getSelectionMode()==ListSelectionModel.SINGLE_SELECTION)
          {
            tableReference.setRowSelectionInterval(pos, pos);
          }
          else
          {
            tableReference.addRowSelectionInterval(pos, pos);
          }
        }
     }

     int minsel = tableReference.getSelectionModel().getMinSelectionIndex();

     if(autoSelectFirstHitIfNoOtherSelect && minsel<0 && tableReference.getRowCount()>0)
     {
        //System.out.println("autoselect first hit");
        tableReference.setRowSelectionInterval(0,0);
     }

     // ### needed to display correctly !!!
     if(tableReference!=null) tableReference.revalidate();   // .repaint();
     if(tableRowHeadersReference!=null) tableRowHeadersReference.revalidate();
  }


  /** This just creates a range 0.. size-1 used to sort.
  */
  private void createRangeForSorting()
  {
     // nothing to do if the size is ok
     if(sortedRowIndices.size()==basicTableModel.getRowCount()) return;

     sortedRowIndices.removeAllElements();
     for(int i=0; i<basicTableModel.getRowCount(); i++)
     {
        sortedRowIndices.add(i);
     }
  }


  public void search(String str1, String str2, boolean useRegEx)
  {
    if(!SwingUtilities.isEventDispatchThread())
    {
      new Throwable("Must be called from EDT !").printStackTrace();
    }

    Query q1 = new Query(-1, str1, Query.Combine.And, (useRegEx ? Query.Comparison.RegEx : Query.Comparison.Contains));
    Query q2 = new Query(-1, str2, Query.Combine.And, (useRegEx ? Query.Comparison.RegEx : Query.Comparison.Contains));

    this.multiSearch(new Query[]{q1,q2});
  }

  public void advancedSearch(String str1, String str2, boolean andSearch, boolean useRegEx, int column)
  {
    if(!SwingUtilities.isEventDispatchThread())
    {
      new Throwable("Must be called from EDT !").printStackTrace();
    }

    Query q1 = new Query(column, str1, Query.Combine.And, (useRegEx ? Query.Comparison.RegEx : Query.Comparison.Contains));
    Query q2 = new Query(column, str2, (andSearch? Query.Combine.And:Query.Combine.Or), (useRegEx ? Query.Comparison.RegEx : Query.Comparison.Contains));

    this.multiSearch(new Query[]{q1,q2});
  }


  /** SPECIAL CASE: Table with row index.
      the two tables have the same selection model.
  */
  public void installGUI(JTable tHead, JTable table)
  {
    // synchronize the selections => simply use the same models !!
    tHead.setSelectionModel( table.getSelectionModel() );

    this.tableReference = table;
    this.tableRowHeadersReference = tHead;

    numberOfColumnAsRowHeaders = tHead.getColumnCount();

    // we just install header renderers
    setHeaders();
    installHeaderClickListeners();

    Border bor = BorderFactory.createCompoundBorder(BorderFactory.createRaisedBevelBorder(),
                                                    BorderFactory.createEmptyBorder(1,0,1,0));

    table.getTableHeader().setBorder( bor );
    tHead.getTableHeader().setBorder( bor );

    installCopyAction(this.tableReference);
    installCopyAction(this.tableRowHeadersReference);

  }


  /** used to render headers...
  */
  public void installGUI(JTable _tableReference)
  {
    this.tableReference = _tableReference;
    setHeaders(); // calls setHeadersForIndexTable()

    installHeaderClickListeners();

    // this is the first sel, from model, when the three methods
    // are implemented
    EventQueue.invokeLater(new Runnable() { public void run() {
       restoreTableSelections();

       int fontSize = UIManager.getFont("Label.font").getSize();
       for(int i=0; i<tableReference.getColumnCount(); i++)
       {
         int w = basicTableModel.getPreferredColumnWidth(i);
         if(w>0)
         {
           tableReference.getColumnModel().getColumn(i).setPreferredWidth(w*fontSize);
         }
       }

    }});

    Border bor = BorderFactory.createCompoundBorder(BorderFactory.createRaisedBevelBorder(),
                                                    BorderFactory.createEmptyBorder(1,0,1,0));

    _tableReference.getTableHeader().setBorder( bor );

    installCopyAction(_tableReference);

  }


  void installCopyAction(JTable ttt)
  {
    ttt.registerKeyboardAction(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
       SortableTableModelAnalysis.viewCopyDialog( SortableTableModel.this );
    } },
    KeyStroke.getKeyStroke(KeyEvent.VK_P, KeyEvent.CTRL_MASK, true),
    JComponent.WHEN_FOCUSED);

  }


  public void setColumnVisibilityToggle(boolean enable)
  {
    columnVisibilitiesChangeEnable = enable;
  }


  /** actually only for tables without header
    Must be caled after installGUI !
  */
  public void setPreferredColumnSizesFromModel()
  {
    if(tableReference==null) return;

    int fontSize = UIManager.getFont("Label.font").getSize();
    for(int i=0; i<tableReference.getColumnCount(); i++)
    {
      int pos = this.getColumnForViewIndex(i);
      int w = this.basicTableModel.getPreferredColumnWidth(pos);
      if(w>0)
      {
        tableReference.getColumnModel().getColumn(i).setPreferredWidth(w*fontSize);
      }
    }

  }


  private   MouseAdapter tableRefClickMouseAdapter = null;
  private  MouseAdapter tableHeadClickMouseAdapter = null;

  //-1 if not found
  private int getBasicColumnModelFromMouseX(int mx)
  {
        int columnView = tableReference.getColumnModel().getColumnIndexAtX(mx);
        int colMod = tableReference.convertColumnIndexToModel(columnView);


        if (colMod < 0) return -1;

        //TableColumn tc = tableReference.getColumnModel().getColumn(columnModel);
        // convert to model taking in account the columns that are not visible
        return getModelIndexForClickedColumn(colMod);
  }

  /** Listen to click on the table headers used to toggle sorting.
  *    Popup shows options to view/hide columns and perform statistics
  */
  private void installHeaderClickListeners()
  {
    if(tableRefClickMouseAdapter!=null)
    {
       tableReference.removeMouseListener(tableRefClickMouseAdapter);
    }

    // listen to click on the table headers used to toggle sorting
    tableRefClickMouseAdapter = new MouseAdapter()
    {
      @Override public void mouseReleased(MouseEvent e)
      {
        if(e.isPopupTrigger() && columnVisibilitiesChangeEnable)
        {
          // on windows
          showColumnSelectionPopup(e);
          //e.consume();
        }
      }


      @Override public void mousePressed(MouseEvent e)
      {
        if(e.isPopupTrigger() && columnVisibilitiesChangeEnable)
        {
          // on linux
          showColumnSelectionPopup(e);
          //e.consume();
        }
      }

      @Override public void mouseClicked(MouseEvent e)
      {
        // [EDT]

        int columnView = tableReference.getColumnModel().getColumnIndexAtX(e.getX());

        // Yes, this is correct.
        int columnModel = tableReference.convertColumnIndexToModel(columnView);

        if (columnModel >= 0)
        {
           //TableColumn tc = tableReference.getColumnModel().getColumn(columnModel);

           // convert to model taking in account the columns that are not visible
           int columnIndexInModel = getModelIndexForClickedColumn(columnModel);

           // if this is the column already selected, invert the order
           if (sortedColumnInBasicModel == columnIndexInModel + numberOfColumnAsRowHeaders)
           {
             ascending = !ascending;
           }
           else
           {
             ascending = true;
           }
           sortedColumnInBasicModel = columnIndexInModel + numberOfColumnAsRowHeaders;
           //System.out.println("Sorted column in basic model = " + sortedColumnInBasicModel);

           storeTableSelection();

           internalSort();
           //internal_multisearch();

           fireTableDataChanged();

           restoreTableSelections();

           setHeaders(); // calls setHeadersForIndexTable()
           // strange... when not invoked, is sometimes not repainted
           if(tableReference!=null)
           {
              tableReference.getTableHeader().repaint(); // we're in the EDT... ok
           }
           if(tableRowHeadersReference!=null)
           {
              tableRowHeadersReference.getTableHeader().repaint(); // we're in the EDT... ok
           }
           //tableHeader.invalidate();
        }
      }
    };
    tableReference.getTableHeader().addMouseListener(tableRefClickMouseAdapter);


    // index table
    //
    if(tableRowHeadersReference==null) return;

    if(tableHeadClickMouseAdapter!=null)
    {
       tableRowHeadersReference.removeMouseListener(tableHeadClickMouseAdapter);
    }


    tableRowHeadersReference.getTableHeader().addMouseListener(tableHeadClickMouseAdapter = new MouseAdapter()
    {
      @Override public void mouseClicked(MouseEvent e)
      {
        //final int column = tableReference.columnAtPoint(new Point(e.getX(), e.getY()));
        int columnView = tableRowHeadersReference.getColumnModel().getColumnIndexAtX(e.getX());
        int columnModel = tableRowHeadersReference.convertColumnIndexToModel(columnView); // xes

        //System.out.println("Click column "+columnModel);

        if (columnModel >= 0)
        {
           //TableColumn tc = tableRowHeadersReference.getColumnModel().getColumn(columnModel);
           if (sortedColumnInBasicModel==columnModel)
           {
             ascending = !ascending;
           }
           else
           {
             ascending = true;
           }
           sortedColumnInBasicModel = columnModel;
           //System.out.println("Sort column "+sortedColumn);

           //setHeadersForMainTable();
           //tableHeader.repaint();

           storeTableSelection();

           internalSort();
           //internal_multisearch();

           fireTableDataChanged();

           restoreTableSelections();

           setHeaders();
           // strange... when not invoked, is sometimes not repainted
           if(tableReference!=null) tableReference.getTableHeader().repaint(); // we're in the EDT... ok
           if(tableRowHeadersReference!=null) tableRowHeadersReference.getTableHeader().repaint(); // we're in the EDT... ok
           //tableHeader.invalidate();
        }
      }
    });
  }

  /** @return {0,1,3} for example if column 2 is not visible.
  *
  */
  public int[] getVisibleColumnsIndex()
  {
    synchronized(this)
    {
      int[] rep = new int[selectedColumns.size()];
      Integer[] sc = selectedColumns.toArray(new Integer[selectedColumns.size()]);
      for(int i=0; i<selectedColumns.size(); i++)
      {
         rep[i] = sc[i].intValue();
      }
      return rep;
    }
  }

  /** Caution: index should be before tranformated from table.viewToModel( int )
  */
  private int getModelIndexForClickedColumn(int col)
  {
    int[] visibleIndex = getVisibleColumnsIndex();
    return visibleIndex[col];
  }

  public void setVisibleColumns(int[] cols)
  {
    synchronized(this)
    {
      selectedColumns.clear();
      for(int i=0; i<cols.length; i++)
      {
        if(cols[i]<this.basicTableModel.getColumnCount())
        {
          selectedColumns.add(new Integer(cols[i]));
        }
      }
    }
    storeTableSelection();
    fireTableStructureChanged(); // structure has changed, give a TableModelEvent with ROW_HEADERS row as argument
    restoreTableSelections();
    setHeaders();

    this.setPreferredColumnSizesFromModel();


  }

  public boolean isColumnVisible(int column)
  {
     return selectedColumns.contains(new Integer(column));
  }

  /** @param column in the base model
  */
  public void setColumnVisible(int column, boolean visible)
  {
     if(visible)
     {
       selectedColumns.add(column);
     }
     else
     {
       // avoid zero columns !!!
       if(selectedColumns.size()>1)
       {
         selectedColumns.remove(column);
       }
     }

     storeTableSelection();
     fireTableStructureChanged(); // structure has changed, give a TableModelEvent with ROW_HEADERS row as argument
     restoreTableSelections();
     setHeaders();

     // [Feb2007]
     this.setPreferredColumnSizesFromModel();
  }

  /** Must be called in the edt ! */
  public void setAllColumnsVisible()
  {
     for(int i=0; i<this.getBasicTableModel().getColumnCount(); i++)
     {
        selectedColumns.add(i);
     }
     storeTableSelection();
     fireTableStructureChanged(); // structure has changed, give a TableModelEvent with ROW_HEADERS row as argument
     restoreTableSelections();
     setHeaders();

     this.setPreferredColumnSizesFromModel();
  }

  public List<String> getAllBasicColumnNames()
  {
    List<String> ls = new ArrayList<String>();
    for(int i=0; i<this.basicTableModel.getColumnCount(); i++)
    {
      ls.add(this.basicTableModel.getColumnName(i));
    }
    return ls;
  }


  /** popup when clicking in a header
  */
  private void showColumnSelectionPopup(final MouseEvent e)
  {
      JPopupMenu popup = new JPopupMenu();
      JMenuItem col = new JMenuItem("Columns...");
      popup.add(col);
      col.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         SortableTableModelAnalysis.showAdvancedColumnExplorer(SortableTableModel.this, e.getLocationOnScreen());
      } });

      final int selCol = getBasicColumnModelFromMouseX(e.getX());

      final String selColName;
      if(selCol <0l)
      {
         selColName = "no?<>";
      }
      else
      {
         popup.addSeparator();

         selColName = this.getBasicTableModel().getColumnName(selCol);
         JMenuItem stat = new JMenuItem("Stats for <"+selColName+">...", Icons.sharedStat);
         popup.add(stat);
         stat.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
            SortableTableModelAnalysis.viewSatsForColumn(SortableTableModel.this, selCol, selColName);
         } });
      }

      popup.addSeparator();

      int ncols = this.basicTableModel.getColumnCount();
      // numberOfColumnAsRowHeaders first col are always visible

      if(ncols<20)
      {
         for(int i=numberOfColumnAsRowHeaders; i<this.basicTableModel.getColumnCount(); i++)
         {
            String name = basicTableModel.getColumnName(i);
            final Integer index = new Integer(i);
            final JCheckBoxMenuItem cb = new JCheckBoxMenuItem(name, selectedColumns.contains(index));
            if(selColName.equals(name))
            {
               cb.setOpaque(true);
               cb.setBackground(Color.white);
            }
            popup.add(cb);
            cb.addActionListener(new ActionListener()
            {
              public void actionPerformed(ActionEvent ae)
              {
                 setColumnVisible(index, cb.isSelected());
              }
            });
         }
      }
      else
      {
         int start = 1;    // 1 based !
         int end = Math.min(20, ncols);
         JMenu act = new JMenu("Columns "+start+" - "+end);
         popup.add(act);

         for(int i=0; i<ncols; i++)
         {
           if(i>=end)
           {
             start = end+1;
             end = Math.min(20+end, ncols);
             act = new JMenu("Columns "+start+" - "+end);
             popup.add(act);
           }

           String name = basicTableModel.getColumnName(i);
           final Integer index = new Integer(i);
           final JCheckBoxMenuItem cb = new JCheckBoxMenuItem(name, selectedColumns.contains(index));
           if(selColName.equals(name))
           {
              cb.setOpaque(true);
              cb.setBackground(Color.white);
           }
           act.add(cb);
           cb.addActionListener(new ActionListener()
           {
             public void actionPerformed(ActionEvent ae)
             {
                setColumnVisible(index, cb.isSelected());
             }
           });
         }

      }

      popup.show( (Component) e.getSource(), e.getX(), e.getY());
  }



  /** Set the headers with sort icons.
    [Called from EDT]
  */
  protected void setHeaders()
  {
    if(tableReference == null) return;

    setHeadersForIndexTable();

    //System.out.println("SC="+sortedColumn);

    // for the index table
    if (tableRowHeadersReference!=null)
    {
      for (int i=0; i<numberOfColumnAsRowHeaders; i++)
      {
        int indexModel = i;
        int indexView = tableRowHeadersReference.convertColumnIndexToView(i);
        //TableColumn column = tableRowHeadersReference.getColumnModel().getColumn(indexView);
        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
        headerRenderer.setBackground(UIManager.getColor("TableHeader.background"));
        headerRenderer.setForeground(UIManager.getColor("TableHeader.foreground"));
        headerRenderer.setBorder(UIManager.getBorder("Table.focusSelectedCellHighlightBorder"));

        if(indexModel==sortedColumnInBasicModel)
        {
          if (ascending) headerRenderer.setIcon(getAscIcon(indexModel));
          else           headerRenderer.setIcon(getDescIcon(indexModel));
        }
        else
        {
          headerRenderer.setIcon(getNoSortIcon(indexModel));
        }

        tableRowHeadersReference.getColumnModel().getColumn(indexView).setHeaderRenderer(headerRenderer);

        // ??? needed, otherwise, does not correctly display.
        tableRowHeadersReference.getTableHeader().repaint();
      }
    }

    // table

    for (int i=0; i<tableReference.getColumnCount(); i++)
    {
      //int indexModel = i;
      int indexView  = tableReference.convertColumnIndexToView(i);
      //TableColumn column = tableReference.getColumnModel().getColumn(indexView);

      DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
// orange is "ok", but this is better
      if(UIManager.getColor("nimbusInfoBlue")!=null)
      {
         headerRenderer.setBackground(GUIUtils.createPureColor(UIManager.getColor("TableHeader.background")));
         headerRenderer.setForeground(GUIUtils.createPureColor(UIManager.getColor("TableHeader.foreground")));
         //Or blue & headerRenderer.setForeground(Color.white);
      }
      else
      {
        headerRenderer.setBackground(UIManager.getColor("TableHeader.background"));
        headerRenderer.setForeground(UIManager.getColor("TableHeader.foreground"));
      }

      if(i%2==1)
      {
         headerRenderer.setBackground(Colors.createContrastedColor(UIManager.getColor("TableHeader.background"), 4f));
      }

      //no infl ?
      headerRenderer.setBorder(new CustomEtchedBorder(true, true, true, true, Color.black, Color.darkGray));
      //headerRenderer.setBorder(UIManager.getBorder("Table.focusSelectedCellHighlightBorder"));

      int sortedColViewIndex = getColumnForViewIndex(i);

      if(sortedColViewIndex+numberOfColumnAsRowHeaders == sortedColumnInBasicModel)
      {
         if (ascending)
         {
            headerRenderer.setIcon(getAscIcon(sortedColViewIndex));
         }
         else
         {
            headerRenderer.setIcon(getDescIcon(sortedColViewIndex));
         }

         headerRenderer.setBackground( new Color(204, 255, 204, 25) );  // mint transparent
      }
      else
      {
         headerRenderer.setIcon(getNoSortIcon(sortedColViewIndex));
      }

      tableReference.getColumnModel().getColumn(indexView).setHeaderRenderer(headerRenderer);
      // ??? needed, otherwise, does not correctly display.
      tableReference.getTableHeader().repaint();
    }
  }


  private void setHeadersForIndexTable()
  {
    if(tableRowHeadersReference == null) return;

    //JTableHeader tableHeader = tableRowHeadersReference.getTableHeader();
    for (int i=0; i<tableRowHeadersReference.getColumnCount(); i++)
    {
      int indexModel = i;
      int indexView = tableRowHeadersReference.convertColumnIndexToView(i);

      //TableColumn column = tableRowHeadersReference.getColumnModel().getColumn(indexView);
      DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
      headerRenderer.setBackground(UIManager.getColor("TableHeader.background"));

      if(indexModel==sortedColumnInBasicModel)
      {
        if (ascending)
        {
            headerRenderer.setIcon(getAscIcon(indexModel));
        }
        else
        {
            headerRenderer.setIcon(getDescIcon(indexModel));
        }
      }
      else
      {
        headerRenderer.setIcon(getNoSortIcon(indexModel));
      }

      tableRowHeadersReference.getColumnModel().getColumn(indexView).setHeaderRenderer(headerRenderer);
      //tableReference.repaint();
    }
  }

  // keep in mind what sorting is wanted, because each update must re-sort
  int sortedColumnInBasicModel  = 0;
  boolean ascending = true;

  // with UI
  public void sort(int column, boolean ascending)
  {
    synchronized(this)
    {
      this.sortedColumnInBasicModel = column;
      this.ascending = ascending;
      internalSort();
      //internal_search();

      // pass the event in same EDT for this listener
      fireTableDataChanged();

      // [Jan2010]
      setHeaders();
    }
  }

  /** @return true if the actual sorting order is ascending (default).
  */
  public boolean getSortOrderIsAscending() { return ascending;}

  /** @return index in the basic tabel model.
  */
  public int getSortedColumn()  { return sortedColumnInBasicModel; }

  // without UI
  public void setSortedColumnAndOrder(int col, boolean ascending)
  {
    this.sortedColumnInBasicModel = col;
    this.ascending = ascending;
  }

  private void internalSort()
  {
    Comparator<Integer> comp = new Comparator<Integer>()
    {
      public int compare(Integer ind1, Integer ind2)
      {
        if(ascending)
        {
          return basicTableModel.compareForColumnSort(ind1, ind2, sortedColumnInBasicModel);
        }
        else
        {
          return basicTableModel.compareForColumnSort(ind2, ind1, sortedColumnInBasicModel);
        }
      }
    };

    Collections.sort(sortedRowIndices, comp);
    internal_multisearch();
  }

  //
  // TableModel
  //


  /** @param pos id the index in this table,
      @return the position of the element in the unsorted model
  */
  private int getIndexInUnsortedModel(int pos)
  {
     if(pos==-1) return -1;
     if(pos>=sortedRowIndices.size()) return -1;

     return sortedRowIndices.get(pos);
  }

  /** Positions in the unsorted model from the view (JTable indices, sorted).
  */
  public int getIndexInUnsortedFromTablePos(int tablePos)
  {
     if(tablePos==-1) return -1;
     if(tablePos>=foundBasicIndices.size())
     {
//       System.out.println("tp="+tablePos+", fi="+foundBasicIndices.size());
       return -1;
     }

     return foundBasicIndices.get(tablePos);
  }

  /** Positions in the unsorted model from the view (JTable indices, sorted).
  */
  public int[] getIndexInUnsortedFromTablePos(int[] tablePos)
  {
     int[] ret = new int[tablePos.length];
     int i=0;
     for(int ti : tablePos)
     {
        ret[i] = getIndexInUnsortedFromTablePos(ti);
        i++;
     }
     return ret;
  }



  /** get the view index corresponding to the one in the basicIndex
  */
  public int getIndexInFoundFromBasicIndex(int basicIndex)
  {
    if(basicIndex==-1) return -1;
    if(basicIndex>=0 && basicIndex<basicTableModel.getRowCount())
    {
      int pos = foundBasicIndices.indexOf(Integer.valueOf(basicIndex));
      return pos;
    }
    else
    {
      return -1;
    }
  }

  @Override
   public Object getValueAt(int row, int col)
   {
       int pos = getIndexInUnsortedFromTablePos(row);
       return basicTableModel.getValueAt(pos, getColumnForViewIndex(col));
   }

   /** The sorted and filtered items count.
   */
   public int getRowCount()
   {
      //System.out.println("grc="+foundBasicIndices.size());
      return foundBasicIndices.size();
      //#  return unsortedTableModel.getRowCount();
   }

   public int getRowCountOfUnfilteredModel()
   {
      return basicTableModel.getRowCount();
   }


   public int getColumnCount()
   {
      return selectedColumns.size();
      //[Old] return basicTableModel.getColumnCount();
   }

   /** if visible columns are {0,1,3}, view=2, return 3
       BE CAREFUL: used in getColumName and getColumnClass !
       NOT TAKING IN ACCOUNT THE TRANSFORMATIONS MADE IN JTABLE !!
   */
   public int getColumnForViewIndex(int viewCol)
   {
         synchronized(this)
         {
            int pos = -1;
            // iterate over all visible columns
            Iterator<Integer> it = selectedColumns.iterator();
            while(it.hasNext())
            {
               Integer ind = it.next();
               pos++;
               if(pos==viewCol)
               {
                  return ind.intValue();
               }
            }
            return -1;
         }
   }

@Override
   public boolean isCellEditable(int row, int col)
   {
       int pos = getIndexInUnsortedFromTablePos(row);
       return basicTableModel.isCellEditable(pos, getColumnForViewIndex(col));
   }
@Override
   public void setValueAt(Object val, int row, int col)
   {
       int pos = getIndexInUnsortedFromTablePos(row);
       basicTableModel.setValueAt(val, pos, getColumnForViewIndex(col));
   }
@Override
   @SuppressWarnings ("rawtypes")
   public Class getColumnClass ( int column )
   {
      return basicTableModel.getColumnClass(getColumnForViewIndex(column));
   }
@Override
   public String getColumnName(int column)
   {
      return basicTableModel.getColumnName(getColumnForViewIndex(column));
   }



   /** Count stats. over all elements
   */
   public Map<String, Integer> getDifferentColumnModValuesStats(final int colMod, boolean onlyOnVisibleElements)
   {
      Map<String, Integer> map = new HashMap<String, Integer>();
      //int colMod = this.getModelIndexForClickedColumn(col);

      if(onlyOnVisibleElements)
      {
         //on visible elements
         int rc = this.tableReference.getRowCount();
         for(int i=0; i<rc; i++)
         {
            int pos = this.getIndexInUnsortedFromTablePos(i);
            String val = ("" + this.getBasicTableModel().getValueAt(pos, colMod)).trim();
            if(map.containsKey(val)) map.put(val, map.get(val)+1);
            else map.put(val, 1);
         }
      }
      else
      {
         //over all elements
         for(int i=0; i<this.getBasicTableModel().getRowCount(); i++)
         {
            String val = ("" + this.getBasicTableModel().getValueAt(i, colMod)).trim();
            if(map.containsKey(val)) map.put(val, map.get(val)+1);
            else map.put(val, 1);
         }
      }

      return map;
   }




  public void multiSearch(final Query /*@org.checkerframework.checker.nullness.qual.Nullable*/ [] _queries)
  {
    multiSearch = true;
    queries = _queries;
    storeTableSelection();

    internal_multisearch();
    fireTableDataChanged();

    restoreTableSelections();
  }

  @SuppressWarnings("nullness") //buggy
  private void internal_multisearch()
  {
    synchronized(this)
    {
      foundBasicIndices.clear();
      for(int i=0; i<basicTableModel.getRowCount();i++)
      {
        int basicIndex = getIndexInUnsortedModel(i);

        if (basicTableModel.hitForTextSearch(basicIndex, queries))
        {
           foundBasicIndices.add(basicIndex);
        }
      }
    }
  }

  /**
   * @return the ascending/descending sort icons.
   * This method may be overwritten by subclasses in order to provide their own icons.
   */
  protected Icon getAscIcon(    final int column )  { return SORT_ASC;  }
  protected Icon getDescIcon(   final int column )  { return SORT_DESC; }
  protected /*@org.checkerframework.checker.nullness.qual.Nullable*/ Icon getNoSortIcon( final int column )  { return null;      }


  /** Important: this returns a list of indices in the basic model in ascending order
  *   suitable for reverse iterating, for example when removing elements.
  *   silently ignore bad positions (-1).
  *   @param table uses the passed table to fetch the view selected rows.
  */
  public List<Integer> getSelectedRows_sortedBasicIndices(JTable table)
  {
     int[] sel = table.getSelectedRows();
     List<Integer> ind = new ArrayList<Integer>();
     for(int i=0; i<sel.length; i++)
     {
        int pos = getIndexInUnsortedFromTablePos( sel[i] );
        if(pos>=0) ind.add(pos);
     }
     Collections.sort(ind);
     return ind;
  }

  public final String getName() { return name; }
  public final void setName(String a) { this.name = a; }

}