package snow.sortabletable;

import snow.utils.gui.Icons;
import javax.swing.JCheckBox;

public class TestModelItem implements EditableTableRow
{

  public TestModelItem()
  {
     checked = Math.random()>0.5;
  }

  public double col1;
  public String col2;
  public int col3;
  public int col4;
  public int col5;
  public long col6;
  public JCheckBox lt = new JCheckBox(Math.random()<0.5?"<html>Hello <i>World!</i>":"Hallo", Icons.sharedLeftArrow, true);
  {
      lt.setOpaque(false);
  }

  public boolean checked = false;

  // for selection only
  public boolean selected = false;


  public Object getValueForColumn(int col)
  {
     if(col==0) return col1;
     if(col==1) return col2;
     if(col==2) return col3;
     if(col==3) return col4;
     if(col==4) return col5;
     if(col==5) return checked;
     return "";
  }


  public void setValueForColumn(int col, Object obj)
  {
     if(col==1) col1 = Double.parseDouble(""+obj);
     if(col==2) col2 = ""+obj;
     if(col==3) col3 = Integer.parseInt(""+obj);

      //...
  }


}