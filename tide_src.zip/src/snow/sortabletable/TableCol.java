package snow.sortabletable;

/** [july2012] brings more semantics
*/
public final class TableCol
{
   final private String name;

   public TableCol(String name)
   {
      this.name = name;
   }


}