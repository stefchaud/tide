package snow.sortabletable;

import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;

public class SortDirectionSelfDrawingIcon implements Icon
{

  // types :
  public static final int Ascending = 1;
  public static final int Descending = 2;
  public static final int Left = 3;  // used for "expand" buttons
  public static final int Right = 4;

  // Member attributes :
  private final Color shapeBorderColor;

  private int height = 0;
  private int width  = 0;


  GradientShapeEntity shape;

  private final int fs;

  private int strokeThickness = 1;



 /**
  *  Creates a filetreeicon with the specified type.
  *  The available types are defined static in this class.
  */
  public SortDirectionSelfDrawingIcon( final int iconStyle )
  {
    Font basisFont = UIManager.getFont("Tree.font");
    fs = basisFont.getSize();
    this.strokeThickness = 1 + fs/16;

    final Color bg = UIManager.getColor("TextField.background");
    final Color fg = UIManager.getColor("TextField.foreground");

    // border color [UI dependant] :
    int r = ( bg.getRed()   + 4*fg.getRed()   ) / 5;
    int g = ( bg.getGreen() + 4*fg.getGreen() ) / 5;
    int b = ( bg.getBlue()  + 4*fg.getBlue()  ) / 5;
    this.shapeBorderColor = new Color(r,g,b);

    // Icon size :

    this.height = (7*fs/6);
    this.width = this.height/2;

    // The shape entities :
    int verticalOffset = this.height/4;
    int h2 = this.height*3/4;
    Color shapeInsideColor = new Color(130,242,110);
    Color shapeInsideSelectedColor = new Color(190,250,170);
    shape = new GradientShapeEntity( this.shapeBorderColor,
                                     this.shapeBorderColor,
                                     shapeInsideColor,
                                     shapeInsideSelectedColor,
                                     1f * this.width,
                                     0f,
                                     this.strokeThickness );
    switch( iconStyle )
    {
       case Ascending :
            shape.moveTo(0,verticalOffset);
            shape.lineTo(this.width/2,h2);
            shape.lineTo(this.width,verticalOffset);
            shape.closePath();
            break;

       case Descending :
            shape.moveTo(0,h2);
            shape.lineTo(this.width/2,verticalOffset);
            shape.lineTo(this.width,h2);
            shape.closePath();
            break;


       case Left :
            shape.moveTo(width*3/4,height*5/6);
            shape.lineTo(width/4, height/2);
            shape.lineTo(width*3/4,height/6);
            shape.closePath();
            break;

       case Right :
            shape.moveTo(width/4,height*5/6);
            shape.lineTo(width*3/4, height/2);
            shape.lineTo(width/4,height/6);
            shape.closePath();
            break;

       default:
    }
  }



 /**
  *   Draws the icon at the specified location.  Icon implementations
  *   may use the Component argument to get properties useful for
  *   painting, e.g. the foreground or background color.
  */
  //@SuppressWarnings("nullness")
  public void paintIcon( /*@org.checkerframework.checker.nullness.qual.Nullable*/ Component unusedHere, Graphics g, int x, int y )
  {
    final Graphics2D graphics2D = (Graphics2D)g;
    // Backup:
    final Color saveColor = graphics2D.getColor();
    final AffineTransform backupTransform = graphics2D.getTransform();
    g.translate(x,y);
    final Stroke backupStroke = graphics2D.getStroke();
    final Paint savePaint = graphics2D.getPaint();

    final Object backupAntiAliasRendering = graphics2D.getRenderingHint( RenderingHints.KEY_ANTIALIASING );
    final Object backupQualityRendering = graphics2D.getRenderingHint( RenderingHints.KEY_RENDERING );

    // Reconfigure / draw:

    graphics2D.setRenderingHint( RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON );
    graphics2D.setRenderingHint( RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY );


    shape.paint( graphics2D );

    // Restore :
    graphics2D.setTransform( backupTransform );
    graphics2D.setColor(saveColor);
    graphics2D.setStroke(backupStroke);

    graphics2D.setRenderingHint( RenderingHints.KEY_ANTIALIASING,backupAntiAliasRendering );
    graphics2D.setRenderingHint( RenderingHints.KEY_RENDERING,backupQualityRendering );

    graphics2D.setPaint(savePaint);
  }

  public int getIconWidth()
  {
    return this.width + 1 + fs/10; // always add a small offset
  }


  public int getIconHeight()
  {
    return this.height + 1 + fs/10; // always add a small offset
  }

}