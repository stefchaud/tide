package snow.sortabletable;

import snow.font.FontsExplorer;
import javax.swing.table.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class UniversalTableEditor extends AbstractCellEditor implements TableCellEditor
{

  protected final ColorCellEditor   colorCellEditor           = new ColorCellEditor();
  protected final DefaultCellEditor textFieldDefaultCellEditor= new DefaultCellEditor(new JTextField());
  protected final DefaultCellEditor comboBoxDefaultCellEditor = new DefaultCellEditor(new JComboBox());
  protected final DefaultCellEditor checkBoxDefaultCellEditor = new DefaultCellEditor(new JCheckBox());
  protected final FontCellEditor    fontCellEditor            = new FontCellEditor();
  protected final NumberTableCellEditor numberTableCellEditor = new NumberTableCellEditor();

  private /*@org.checkerframework.checker.nullness.qual.Nullable*/ CellEditor selectedEditor = null;


  public UniversalTableEditor()
  {
  }

  // CELL EDITOR INTERFACE
  //
@Override
  public void addCellEditorListener(CellEditorListener l)
  {
    if(selectedEditor!=null)
    {
      selectedEditor.addCellEditorListener(l);
    }
  }

@Override
  public void removeCellEditorListener(CellEditorListener l)
  {
    if(selectedEditor!=null)
    {
      selectedEditor.removeCellEditorListener(l);
    }

  }
@Override
  public void cancelCellEditing()
  {
    if(selectedEditor!=null)
    {
      selectedEditor.cancelCellEditing();
    }

  }
@Override
  public boolean stopCellEditing()
  {

    if(selectedEditor!=null)
    {
      return selectedEditor.stopCellEditing();
    }
    return true;
  }


  @SuppressWarnings ("nullness") //ok
  public Object getCellEditorValue()
  {
    if(selectedEditor!=null)
    {
      return selectedEditor.getCellEditorValue();
    }
    return null;
    //textFieldDefaultCellEditor.getCellEditorValue();
  }
@Override
  public boolean isCellEditable(EventObject anEvent)
  {
    //System.out.println(""+anEvent);
    if(selectedEditor!=null)
    {
      return selectedEditor.isCellEditable(anEvent);
    }
    // if false, nothing will be editable !!
    return true;
  }
@Override
  public boolean shouldSelectCell(EventObject anEvent)
  {
    if(selectedEditor!=null)
    {
      return selectedEditor.shouldSelectCell(anEvent);
    }
    return true;  // normally true, maybe no for checkboxes...
  }


  /** TableCellEditor interface impl
  */
  public Component getTableCellEditorComponent(JTable table,
                                               Object value,
                                               boolean isSelected,
                                               int row,
                                               int column)
  {
     // is null allowed ?? yes, may be casted for example to color
     // if(value==null) return new JLabel("No editor for null value");

     if(value instanceof Color)
     {
       selectedEditor =  colorCellEditor;
       return colorCellEditor.getTableCellEditorComponent(table, (Color) value, isSelected, row, column);
     }
     else if(value instanceof Boolean)
     {
       selectedEditor = checkBoxDefaultCellEditor;
       return checkBoxDefaultCellEditor.getTableCellEditorComponent(table, value, isSelected, row, column);
     }
     else if(value instanceof Font)
     {
       selectedEditor = fontCellEditor;
       return fontCellEditor.getTableCellEditorComponent(table, value, isSelected, row, column);
     }
     else if(value instanceof Double
           ||value instanceof Float
           ||value instanceof Integer)
     {
       selectedEditor = numberTableCellEditor;
       return numberTableCellEditor.getTableCellEditorComponent(table, value, isSelected, row, column);
     }
     else
     {
       // default
       selectedEditor = textFieldDefaultCellEditor;
       return textFieldDefaultCellEditor.getTableCellEditorComponent(table, value, isSelected, row, column);
     }


    // return new JLabel("NO EDITOR FOR "+value.getClass().getName());
  }


 class FontCellEditor extends AbstractCellEditor
                         implements TableCellEditor,
                                    ActionListener {
    Font currentFont;
    JButton button;
    //FontSelector fontChooser;
    JDialog dialog;
    protected static final String EDIT = "edit";

    public FontCellEditor() {
        button = new JButton();
        button.setActionCommand(EDIT);
        button.addActionListener(this);
        button.setBorderPainted(false);
    }

    public void actionPerformed(ActionEvent e) {
        if (EDIT.equals(e.getActionCommand()))
        {
            currentFont = FontsExplorer.chooseFont(currentFont, "Choose a font", button);
            fireEditingStopped(); //Make the renderer reappear.
        }

    }

    //Implement the one CellEditor method that AbstractCellEditor doesn't.
    public Object getCellEditorValue() {
        return currentFont;
    }

    //Implement the one method defined by TableCellEditor.
    public Component getTableCellEditorComponent(JTable table,
                                                 Object value,
                                                 boolean isSelected,
                                                 int row,
                                                 int column)
    {
        if(value instanceof Font)
        {
          currentFont = (Font) value;
        }
        return button;
    }
}

}