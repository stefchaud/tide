package snow.sortabletable;

/** Optional interface for use in the FineGrainTableModelBuilder
*   to easily build a sortabletablemodel with FineGrainTableModelBuilder (for example).
*/
public interface TableRow
{
  Object getValueForColumn(int col);
}