package snow.sortabletable;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.util.*;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/** Helper to build a finegraintablemodel from a list of TableRow.
*  This may be easier to implement the get/set values from the items
* Note: the most general way to create a sortable table is to use directly the FineGrainTableModel, not this helper.
*
* Note: must be created within EDT. Some add/remove methods are safe for use in another thread.

* Note: You may in addition override
*   public int compareForColumnSort(int row1, int row2, int col)  for custom sorting
* and
*   public int getColumnAlignment(int column) { return JLabel.LEFT; }
*  for use with the UniversalTableCellRenderer
* and
*  public Class getColumnClass ( int column ) in case of null values or class mix within the same column !
*
* Note: this may be also used as a "normal" non sortable/filterable table model, just pass it to a JTable
* java.lang.String
*/
public class FineGrainTableModelBuilder<T extends TableRow> extends FineGrainTableModel
{
   private final List<T> rows; // = new ArrayList<T>();
   private int columnCount;
   private int /*@org.checkerframework.checker.nullness.qual.Nullable*/[] editableCols = null;
   private int/*@org.checkerframework.checker.nullness.qual.Nullable*/[] prefColsWidth = null;
   private String/*@org.checkerframework.checker.nullness.qual.Nullable*/[] colNames = null;

   /** @param rows represent the rows.
   *  CAUTION: passed reference
   */
   @Deprecated
   public FineGrainTableModelBuilder(List<T> rows, int columnCount)
   {
      this.rows = rows;
      this.columnCount = columnCount;
      //addAll_RAW(rows);
   }


   public FineGrainTableModelBuilder(int columnCount)
   {
      this.columnCount = columnCount;
      rows = new ArrayList<T>();
   }

   public final List<T> getRowsREF() { return rows; }
   public final List<T> getRowsCopy()
   {
      return new ArrayList<T>(rows);
   }


   /** not edt safe, no UI update.
   */
   public void addAll_RAW(List<T> r)
   {
      rows.addAll(r);
   }

   /** not edt safe, no UI update.
   */
   public void setAll_RAW(List<T> r)
   {
         fireTableModelWillChange();

      rows.clear();
      rows.addAll(r);

         this.fireTableStructureChanged();
         fireTableModelHasChanged();

   }

   // Config
   //

   public void setEditableColumns(int... cols)
   {
      // should be ordered
      editableCols = cols.clone() ;
      Arrays.sort(editableCols);
   }

   public void setPreferredColumnWidth(int... w)
   {
      prefColsWidth = w;
   }

   public void setColumnNames(String... n)
   {
      colNames = n;
   }

   /** edt-safe */
   public void setColumnCount(final int columnCount_)
   {
      if(EventQueue.isDispatchThread())
      {
         fireTableModelWillChange();
         this.columnCount = columnCount_;
         this.fireTableStructureChanged();
         fireTableModelHasChanged();
      }
      else
      {
         EventQueue.invokeLater(new Runnable() { public void run() {
            fireTableModelWillChange();
            columnCount = columnCount_;
            fireTableStructureChanged();
            fireTableModelHasChanged();
         }});
      }
   }

   /** edt-safe */
   public void addRows(final T... nrow)
   {
      if(EventQueue.isDispatchThread())
      {
         this.fireTableModelWillChange();
         for(T ri : nrow) { rows.add(ri); }
         this.fireTableModelHasChanged();
         this.fireTableDataChanged();
      }
      else
      {
         EventQueue.invokeLater(new Runnable() { public void run() {
            fireTableModelWillChange();
            for(T ri : nrow) { rows.add(ri); }
            fireTableModelHasChanged();
            fireTableDataChanged();
         }});
      }
   }

   /** edt-safe */
   public void removeRows(final Collection<T> nrow)
   {
      if(EventQueue.isDispatchThread())
      {
         this.fireTableModelWillChange();
         for(T ri : nrow) { rows.remove(ri); }
         this.fireTableModelHasChanged();
         this.fireTableDataChanged();
      }
      else
      {
         EventQueue.invokeLater(new Runnable() { public void run() {
            fireTableModelWillChange();
            for(T ri : nrow) { rows.remove(ri); }
            fireTableModelHasChanged();
            fireTableDataChanged();
         }});
      }
   }

   /** edt-safe */
   public void removeRows(final T... nrow)
   {
      if(EventQueue.isDispatchThread())
      {
         this.fireTableModelWillChange();
         for(T ri : nrow) { rows.remove(ri); }
         this.fireTableModelHasChanged();
         this.fireTableDataChanged();
      }
      else
      {
         EventQueue.invokeLater(new Runnable() { public void run() {
            fireTableModelWillChange();
            for(T ri : nrow) { rows.remove(ri); }
            fireTableModelHasChanged();
            fireTableDataChanged();
         }});
      }
   }


   /** edt-safe */
   public void removeAllRows()
   {
      if(EventQueue.isDispatchThread())
      {
         this.fireTableModelWillChange();
         rows.clear();
         this.fireTableModelHasChanged();
         this.fireTableDataChanged();
      }
      else
      {
         EventQueue.invokeLater(new Runnable() { public void run() {
            fireTableModelWillChange();
            rows.clear();
            fireTableModelHasChanged();
            fireTableDataChanged();
         }});
      }
   }

   // FineGrainTableModel impl
   //

   public Object getValueAt( final int rowIndex, final int columnIndex ) {
      if(rowIndex<0 || rowIndex>=rows.size()) return ""; //"bad row "+row;
      return rows.get(rowIndex).getValueForColumn(columnIndex);
   }

   public int getRowCount(  ) {
      return rows.size();
   }

   public int getColumnCount(  ) {
      return columnCount;
   }

   @Override public boolean isCellEditable(int r, int c)
   {
      if(editableCols==null) return false;
      return Arrays.binarySearch(editableCols, c)>=0;
   }

   @Override
   public void setValueAt(Object val, int row, int col)
   {
      this.fireTableModelWillChange();

      TableRow tr = rows.get(row);
      if(tr instanceof EditableTableRow)
      {
         ((EditableTableRow) tr).setValueForColumn(col, val);
      }

      // just refresh
      this.fireTableDataChanged();
      this.fireTableModelHasChanged();
   }

   @Override
   public String getColumnName(int c)
   {
      if(colNames==null || c>=colNames.length) return "Col"+c;
      return colNames[c];
   }

   @Override
   public int getPreferredColumnWidth(int c)
   {
      if(prefColsWidth==null) return 6;
      if(c>=prefColsWidth.length) return 6;
      return prefColsWidth[c];
   }

   // Helpers
   //

   /** @return a list (copy) of the selected rows in the view.
   */
   public List<T> getSelectedItems(JTable ref, SortableTableModel stm)
   {
      List<T> seli = new ArrayList<T>();
      try
      {
         int[] srview = ref.getSelectedRows();
         int[] srmod = stm.getIndexInUnsortedFromTablePos(srview);
         for(int ri : srmod)
         {
            if(ri<rows.size())
            {
              seli.add( rows.get(ri) );
            }
            else
            {
               System.out.println("NO ROW "+ri);
            }
         }
      }
      catch(final Exception e)
      {
         e.printStackTrace();
      }
      return seli;
   }

   public void activateIfRowSelected(final JTable ref, final boolean activateOnlyIfExactelyOne, final AbstractButton... buttons)
   {
      ref.getSelectionModel().addListSelectionListener(new ListSelectionListener()
      {
         public final void valueChanged( final ListSelectionEvent e ) {
            int n = ref.getSelectedRows().length;
            boolean enable = activateOnlyIfExactelyOne ? n==1 : n>0;
            for(final AbstractButton bi : buttons) {
               bi.setEnabled( enable );
            }
         }
      });
   }

   // just for debug, you mostly will copy this to your code
   public JFrame viewInFrame(String title)
   {
      JFrame f = new JFrame(title);

      SortableTableModel stm = new SortableTableModel(this);
      JTable t = new JTable(stm);
      stm.installGUI(t);
      f.add(new JScrollPane(t), BorderLayout.CENTER);

      UniversalTableCellRenderer utr = new UniversalTableCellRenderer(stm, t);


      MultiSearchPanel msp = new MultiSearchPanel(stm);
      f.add(msp, BorderLayout.NORTH);

      int prefw = 0;
      for(int i=0; i<this.getColumnCount(); i++)
      {
         //todo: filter visible columns!
         prefw += this.getPreferredColumnWidth(i) *10;
      }

      int sw=Toolkit.getDefaultToolkit().getScreenSize().width;
      if(prefw>sw)
      {
         prefw = sw*9/10;
      }
      f.setSize(prefw, 600);
      f.setLocationRelativeTo(null);
      f.setVisible(true);

      return f;
   }


   /**
   */
   public STView<T> createView()
   {
      return new STView<T>(this);

   }

}