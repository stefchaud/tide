package snow.sortabletable;

/** Optional interface for use in the FineGrainTableModelBuilder
*   to easily build a sortabletablemodel with FineGrainTableModelBuilder (for example).
*/
public interface EditableTableRow extends TableRow {

  /** Just do nothing if not editable.
  */
  void setValueForColumn(int col, Object obj);

}