package snow.sortabletable;

import snow.utils.gui.LayoutUtils;
import snow.utils.gui.ComponentResizer;
import javax.swing.event.*;
import java.awt.Component;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.tree.*;

/** Purpose: create a tree from a list column...
*   And explore tree's usability & tools.
*
*/
public final class TreeMaker<T>
{
   interface TreeComp<T>
   {
       boolean isChildOf(T elt, T parent);
       boolean equals(T elt, T parent);
   }

   static class StringTreeComp implements TreeComp<String>
   {
      public boolean isChildOf(String elt, String parent)
      {
         return elt.length()>parent.length() && elt.startsWith(parent);
      }
      public boolean equals(String elt, String parent)
      {
         return elt.equals(parent);
      }
   }

   static class Node<T> implements TreeNode
   {
      /*@org.checkerframework.checker.nullness.qual.Nullable*/ Node<T> parent;
      final T item;

      final List<Node<T>> childs = new ArrayList<Node<T>>();

      int count = 1;

      Node(T e)
      {
         this.item = e;
      }

      public final TreeNode getParent(  ) {
         return parent;
      }

      public final int getIndex( final TreeNode node ) {
         return childs.indexOf(node);
      }

      public final Enumeration children(  ) {
         return Collections.enumeration(childs);
      }

      public final int getChildCount(  ) {
         return childs.size();
      }

      public final boolean isLeaf(  ) {
         return childs.isEmpty();
      }

      public final boolean getAllowsChildren(  ) {
         return true;
      }

      public final TreeNode getChildAt( final int childIndex ) {
         return childs.get(childIndex);
      }

      @Override public final String toString() {
         return ""+item;
      }
   }

   final ArrayList<Node<T>> roots = new ArrayList<Node<T>>();
   final TreeComp<T> comp;


   /** Constructor.
   */
   public TreeMaker(List<T> sortedItems, TreeComp<T> comp)
   {
      this.comp = comp;

      if(sortedItems.isEmpty()) return;

      addAsRoot(sortedItems.get(0));

      // we could be much clever and efficient here :::
      // supposing the elements is mostly child of previous and "climb up" if not

      for(int i=1; i<sortedItems.size(); i++) // first is always a "root"
      {
         T ti = sortedItems.get(i);
         addToTree(ti);
      }
   }

   void addAsRoot(T e)
   {
      System.out.println("New root:: <"+e+">");
      Node<T> root = new Node<T>(e); // no parent
      roots.add(root);
   }

   /** try adding to existing roots, if not, defines a new root
   */
   void addToTree(T e)
   {
      // iterate over roots  (from last may be the mostly probable)
      for(int i=roots.size()-1; i>=0; i--)
      {
         Node<T> root = roots.get(i);
         if(addToTree(e, root))
         {
            return;  // success
         }
      }

      // failed to add => create a new root.
      addAsRoot(e);

   }

   /** @return true if successful.
   * Recursive method call.
   */
   @SuppressWarnings("unchecked")
   boolean addToTree(T e, Node<T> root)
   {
      if(comp.equals( e, root.item))
      {
         root.count++;
         return true;
      }

      if(!comp.isChildOf( e, root.item)) return false;


      // locate branch at first level
      for(Enumeration<Node<T>> enu = root.children(); enu.hasMoreElements();)
      {
         Node<T> childi = enu.nextElement();

         // recurse
         if( addToTree( e, childi)) return true;
      }

      // not in the branches => add it here
      Node<T> nn = new Node<T>(e);
      nn.parent = root;
      root.childs.add(nn);

      return true;
   }


   static JTree example1_trivial_simple()
   {
      List<String> items = Arrays.asList("", "AABAA", "AAAAA", "AA", "A", "B", "AA", "AB", "AAA", "C", "CC");
      Collections.sort(items);
      TreeMaker<String> tm = new TreeMaker<String>(items, new  StringTreeComp());
      JTree tree = new JTree(tm.roots.get(0));
      //tree.expa);
      return tree;
   }

   static JComponent example2()
   {
      List<String> items = Arrays.asList("", "AABAA", "AAAAA", "AA", "A", "B", "AA", "AB", "AAA", "C", "CC", "DD", "EE", "EEEE", "EEE", "FFFABAB");
      return splitAsTree(items);
   }

   static JComponent example3()
   {
      List<String> items = Arrays.asList("", "FK100", "FK100a");
      return splitAsTree(items);
   }

   public static JComponent splitAsTree(List<String> items)
   {
      if(!items.contains(""))
      {
         items.add("");  // root !
      }
      System.out.println("splitting "+items.size()+" items as tree");
      Collections.sort(items);
      TreeMaker<String> tm = new TreeMaker<String>(items, new  StringTreeComp());
      final JTree tree = new JTree(tm.roots.get(0));


      // purpose: make the name relative
      // Note: may also use tree.convertValueToText subclassing
      tree.setCellRenderer(new DefaultTreeCellRenderer()
      {
         // @Implements("TreeCellRenderer")
         public final Component getTreeCellRendererComponent( final JTree tree, final Object value, final boolean selected, final boolean expanded, final boolean leaf, final int row, final boolean hasFocus ) {
            super.getTreeCellRendererComponent(tree, value, selected, expanded,leaf,row,hasFocus);

            if(value instanceof Node)
            {
               Node n = (Node) value;
               if(n.parent!=null)
               {
                  String pn = n.parent.toString();
                  if(n.count>1)
                  {
                    setText( n.toString().substring(pn.length())+" ("+n.count+")" );
                  }
                  else
                  {
                    setText( n.toString().substring(pn.length()) );
                  }
               }
            }
            return this;
         }

      });

      tree.addMouseListener(new MouseAdapter() {
        @Override public void mousePressed(MouseEvent me)
        {
           if(me.isPopupTrigger())
           {
              pop(me);
           }
        }
        @Override public void mouseReleased(MouseEvent me)
        {
           if(me.isPopupTrigger())
           {
              pop(me);
           }
        }

        void pop(MouseEvent me)
        {
           JPopupMenu pop = new JPopupMenu();

           int row = tree.getRowForLocation(me.getX(), me.getY());
           final TreePath clicked;
           if(row>=0)
           {
              clicked = tree.getPathForRow(row);

              pop.add("<"+clicked.getLastPathComponent()+">  level="+clicked.getPathCount());
              int[] cc = getDirectChildCount(tree, clicked.getLastPathComponent());
              pop.add("direct childs: "+cc[0]+" branch, "+cc[1]+" leafs");
           }
           else
           {
              pop.add("No clicked node");
              clicked = null;
           }

           pop.addSeparator();

           // main options...
           JMenuItem exAll = new JMenuItem("expand all");
           pop.add(exAll);
           exAll.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
              expandAll(tree);
           } });

           if(clicked!=null) {
             JMenuItem cAll = new JMenuItem("collapse all but this");
             pop.add(cAll);
             cAll.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
                collapseAllBut(tree, clicked);
             } });
           }
           else
           {
             JMenuItem cAll = new JMenuItem("collapse all");
             pop.add(cAll);
             cAll.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
                collapseAllBut(tree, clicked);  // clicked is here null
             } });
           }

           pop.show(tree, me.getX(), me.getY());
        }
      });

      tree.setRootVisible(false);

      final JScrollPane sp = new JScrollPane(tree);
      final JPanel pp = createSelectedNodeExplorerToolPanel(tree);

      //works (but not nice as toolbox),
      // would be a good idea however for auto popping menus ! when mouse is over some node for some time !
      // ## or to place the "lines" for a tree table component !
      //tree.add(pp);

      sp.addAncestorListener(new AncestorListener()
      {
         boolean added = false;
         public final void ancestorMoved( final AncestorEvent event ) {
         }

         public final void ancestorAdded( final AncestorEvent event ) {
            if(added) return;

            JRootPane rp = LayoutUtils.getRootPane(sp);
            rp.getLayeredPane().add(pp, JLayeredPane.PALETTE_LAYER);   // just adding without 2nd arg => moves with the tree!

            added = true;

         }

         public final void ancestorRemoved( final AncestorEvent event ) {
         }
      });


      return sp;
   }

   /** please add the returned component to the parent frame toolbar layer
   *    pw.getLayeredPane().add(pp, JLayeredPane.PALETTE_LAYER)
   */
   static JPanel createSelectedNodeExplorerToolPanel(final JTree tree)
   {
      final JPanel p= new JPanel();
      p.add(new JLabel("Selected node: "));

      p.setBounds(130,30, 50,20);
      new ComponentResizer(p);

      // moves with the tree when scrolled...
      //tree.add(p);

      return p;
   }

   static void expandAll(JTree tree)
   {
      Object root = tree.getModel().getRoot();
      List<Object> nodes = new ArrayList<Object>();
      getAllNodesNonLeafDepthFirst(tree, nodes, tree.getModel().getRoot());
      for(Object ni : nodes)
      {
         tree.expandPath( createPathFromNode(ni) );
      }
   }

   static void collapseAllBut(JTree tree, /*@org.checkerframework.checker.nullness.qual.Nullable*/ TreePath keep)
   {
      Object root = tree.getModel().getRoot();
      List<Object> nodes = new ArrayList<Object>();
      getAllNodesNonLeafDepthFirst(tree, nodes, tree.getModel().getRoot());
      for(Object ni : nodes)
      {
         TreePath pi = createPathFromNode(ni);
         if(keep!=null && pi.isDescendant(keep)) continue;
         if(pi.getParentPath()==null) continue;  // don't collapse the root
         tree.collapsePath( pi );
      }

      if(keep!=null)
      {
        tree.makeVisible(keep);
      }
   }

   static TreePath createPathFromNode(Object ni)
   {
      if(ni instanceof TreeNode)
      {
         TreeNode tn = (TreeNode) ni;

         List<Object> ppp = new ArrayList<Object>();

         while(tn!=null)
         {
             ppp.add(0, tn);  // caution to order !
             final Object otnp = tn.getParent();

             if(otnp==null) break;

             if(otnp instanceof TreeNode)
             {
                tn = (TreeNode) otnp;
             }
             else if(otnp!=null)
             {
                System.out.println("Not a TreeNode ? "+otnp);
                break;
             }
         }

         return new TreePath(ppp.toArray());
      }
      else
      {
         System.out.println("?? not a tree node: "+ni);
         return new TreePath(ni);
      }
   }

   static void getAllNodesNonLeafDepthFirst(JTree tree, List<Object> nodes, Object from)
   {
      if(tree.getModel().isLeaf(from)) return;  // no leafs

      int cc = tree.getModel().getChildCount(from);
      for(int i=0; i<cc; i++)
      {
         Object ni = tree.getModel().getChild(from, i);

         // recurse: depth first
         getAllNodesNonLeafDepthFirst(tree, nodes, ni);
      }

      // add
      nodes.add(from);
   }

   /** {childs folders, child nodes}
   */
   static int[] getDirectChildCount(JTree tree, Object node)
   {
      int folders = 0;
      int leafs = 0;

      int cc = tree.getModel().getChildCount(node);

      for(int i=0; i<cc; i++)
      {
         Object ni = tree.getModel().getChild(node, i);
         if(tree.getModel().isLeaf(ni))
         {
            leafs++;
         }
         else
         {
            folders++;
         }

      }
      return new int[]{folders, leafs};

   }






   public static void main(String[] args) throws Exception
   {
       example2();
   }




}