package snow.sortabletable;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Insets;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import snow.completion.*;
import snow.concurrent.DelayedMergedUpdater2;
import snow.tplot.model.ListPlotElement;
import snow.tplot.TPlot;
import snow.utils.CollectionUtils;
import snow.utils.gui.*;

/**
 * A search panel which allows the user to specify multiple search queries.
 * Many thanks to Peter B for this class.
 *
 * DON'T ADD CUSTOM COMPONENTS TO THE LAYOUT. It's being modified during search.
 * [Jan2010]: use of DelayedMergedUpdater.
 */
public class MultiSearchPanel extends AnimatedColorPanel
{
  // used to refresh the UI (parent container size), in some situations
  public final static String queriesChangedProperty = "MSP.querieschange";

  public static boolean compactUI = false;

  private GridLayout3 layout;
  protected final JTextField firstSearchTF;
  protected final JComboBox firstSearchColumnCB = new JComboBox();

  protected final JComboBox firstComparisonCB = new JComboBox(Query.comparisonTypeNames);
  protected final JButton firstDelSearchBtn;
  protected final JButton addCriteriaBtn = GUIUtils.createMiniIconButton(Icons.sharedPlus); //"+"

  protected DelayedMergedUpdater2 delayedMergedUpdater;

  protected SortableTableModel sortableTableModel;
  // first being <all columns>
  protected final Vector<String> colNames = new Vector<String>();

  private final ArrayList<JComboBox> searchComparisonCBList = new ArrayList<JComboBox>();
  private final ArrayList<JTextField> searchTFList      = new ArrayList<JTextField>();
  private final ArrayList<JComboBox> searchColumnCBList = new ArrayList<JComboBox>();
  private final ArrayList<JComboBox> searchOperationCBList = new ArrayList<JComboBox>();
  private final ArrayList<JButton> searchDelBtnList     = new ArrayList<JButton>();

  private final TextFieldPopupListener textFieldPopupListener = new TextFieldPopupListener();

  private final JToggleButton toggleAdvanced = new JToggleButton("", true);
  private final JButton colSelectorButton = GUIUtils.createMiniIconButton(Icons.sharedStat);


  public void viewColumSelectorButton()
  {
     colSelectorButton.setVisible(true);
  }

  public void viewColumSelectorButton(boolean visible)
  {
     colSelectorButton.setVisible(visible);
  }


  public boolean viewHitsCount = false;
  private JLabel hitsLabel = new JLabel();

  final JLabel sLabel;  // head label


  /*never used? let GC work !
  * Call at end to liberate resources
  *
  private void terminate()
  {
     // (remark: a lot of other listeners are still bound... problem ?)
     //firstSearchTF.removeKeyListener(keyAdapter);
     firstSearchTF.getDocument().removeDocumentListener(delayedMergedUpdater);
     this.activateAnimation(false);
     delayedMergedUpdater.terminateUpdater();
  }*/

  public MultiSearchPanel(final SortableTableModel stm)
  {
     this("Filter", null, stm);
  }


  public MultiSearchPanel(final String searchLabelText, final /*@org.checkerframework.checker.nullness.qual.Nullable*/ Icon searchIcon, final SortableTableModel stm)
  {
    super(100);

    firstSearchTF = GUIUtils.createTextFieldWithPromptString(searchLabelText, true); //new JTextField(compactUI ? 4 : 8);    // [nov2010]
    firstSearchTF.setColumns(compactUI ? 4 : 8);

    layout = new GridLayout3(6, this);
    layout.setColumnWeights(new double[]{0,0,0,0,0,100});

    this.sortableTableModel = stm;

    colNames.add(compactUI ? "all" : "all columns");
    for(int i=0; i<stm.getBasicTableModel().getColumnCount(); i++)
    {
      colNames.add( stm.getBasicTableModel().getColumnName(i));
    }
    firstSearchColumnCB.setModel(new DefaultComboBoxModel(colNames));
    firstSearchColumnCB.setMaximumRowCount(20);


    formatComboBoxUI( firstSearchColumnCB );
    formatComboBoxUI( firstComparisonCB );

    ActionListener updateListener_ = new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        doSearch();
      }
    };

    delayedMergedUpdater = new DelayedMergedUpdater2(200L, true, updateListener_);

    // first row is fixed
    this.firstDelSearchBtn =GUIUtils.createMiniIconButton(Icons.sharedCross);  //"X"
    firstDelSearchBtn.setToolTipText("Remove this query");
    this.firstDelSearchBtn.setEnabled(false);
    this.firstDelSearchBtn.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        // move one up
        firstSearchTF.setText(searchTFList.get(0).getText());

        firstSearchColumnCB.setSelectedIndex(searchColumnCBList.get(0).getSelectedIndex());
        firstComparisonCB.setSelectedIndex(searchComparisonCBList.get(0).getSelectedIndex());
        removeCriteriaAt(0);
      }
    });

    sLabel = new JLabel("" /*searchLabelText*/, searchIcon, JLabel.LEFT);  // [nov2010]
    sLabel.putClientProperty("JComponent.sizeVariant", compactUI ? "small": "small");

    JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT,3,0));
    p.setOpaque(false);
    toggleAdvanced.setSelected(!compactUI);

    toggleAdvanced.setSelectedIcon(  Icons.sharedMinus);
    toggleAdvanced.setIcon( Icons.sharedPlusBlack);

    toggleAdvanced.setMargin(new Insets(0,0,0,0));
    toggleAdvanced.setFocusPainted(false);
    toggleAdvanced.putClientProperty("JComponent.sizeVariant", "small");

    toggleAdvanced.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
       setAdvancedState( toggleAdvanced.isSelected() );
    } });
    p.add(sLabel);
    p.add(toggleAdvanced);
    layout.add(p);
    layout.add(firstSearchColumnCB);
    layout.add(firstComparisonCB);
    layout.add(firstSearchTF);

    if(GUIUtils.isNimbusLF())
    {
      firstSearchTF.putClientProperty("JComponent.sizeVariant", compactUI ? "small": "small");
      toggleAdvanced.setPreferredSize(new Dimension(12, firstSearchTF.getPreferredSize().height-4));
    }
    else
    {
      toggleAdvanced.setPreferredSize(new Dimension(12, firstSearchTF.getPreferredSize().height-4));
    }


    addCriteriaBtn.setToolTipText("Add another query");
    addCriteriaBtn.setFocusPainted(false);
    addCriteriaBtn.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        addCriteria();
        firePropertyChange(queriesChangedProperty, 0,1);
      }
    });
    addCriteriaBtn.setMargin(new Insets(0,0,0,0));
    layout.add(this.firstDelSearchBtn);

    JPanel pp = new JPanel(new FlowLayout(FlowLayout.LEFT,0,0));
    pp.setOpaque(false);
    layout.add(pp);
    pp.add(addCriteriaBtn);
    pp.add(colSelectorButton);

    colSelectorButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        SortableTableModelAnalysis.showAdvancedColumnExplorer(stm, colSelectorButton.getLocationOnScreen());
      }
    });


    firstSearchColumnCB.addActionListener(delayedMergedUpdater);
    firstComparisonCB.addActionListener(delayedMergedUpdater);
    firstSearchTF.getDocument().addDocumentListener(delayedMergedUpdater);

    registerTextFieldForPopup(firstSearchTF);

    installCompletion(firstSearchColumnCB, firstSearchTF);
    setAdvancedState( toggleAdvanced.isSelected() );

    // only this causes the Nimbus small size to be effective!
    SwingUtilities.updateComponentTreeUI(this);
    this.setOpaque(false);

  } // constr

  /** [Sep2008]
  */
  private void installCompletion(final JComboBox columnCB, final JTextField field)
  {
     final TextComponentCompletion<String> tcc = new TextComponentCompletion<String>(field, false, true, 2, "");
     tcc.setCompletionListener(new TextComponentCompletion.CompletionListener<String>()
     {
        public void itemSelected(String item)
        {
           doSearch();
        }
     } );

     columnCB.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae)
     {
        int selCol = columnCB.getSelectedIndex();
        if(selCol<=0)  // ALL
        {
           tcc.setCompletions();  // no comp for "all"
        }
        else
        {
           Set<String> vals = SortableTableModelAnalysis.getDifferentColumnModValues(sortableTableModel.getBasicTableModel(), selCol-1);
           //System.out.println("Set sel "+vals);

           tcc.setCompletions(vals);
        }
     }});
  }

  // must be visible
  public void requestKeyFocus()
  {
    EventQueue.invokeLater(new Runnable()
    {
      public void run()
      {
        getFirstTextField().requestFocus();
      }
    });
  }

  public void setAdvancedState(boolean is)
  {
     toggleAdvanced.setSelected(is);  // don't trigger, but synchronize state
     if(!is)
     {
       // reduce
       setQueries(Query.simpleSearchQuery(firstSearchTF.getText()));
     }

     addCriteriaBtn.setVisible(is);
     firstDelSearchBtn.setVisible(is);
     firstSearchColumnCB.setVisible(is);
     firstComparisonCB.setVisible(is);

     if(is)
     {
        toggleAdvanced.setToolTipText("Simple mode");
     }
     else
     {
        toggleAdvanced.setToolTipText("Advanced mode");
     }

     firePropertyChange(queriesChangedProperty, 0,1);
  }

  @Override
  public void requestFocus()
  {
     //System.out.println("RFOC");
    firstSearchTF.requestFocus();
  }


  /** Used in special cases where the model reference may change but the view not
  */
  public void setSortableTableModel(SortableTableModel stm)
  {
     this.sortableTableModel = stm;
     // cause a reload...
     this.setQueries( this.getQueries() );
  }

  public boolean isSearchActive()
  {
    return firstSearchTF.getText().length() > 0
        || searchOperationCBList.size()>0;   // Added [Feb2008]
  }

  /** Enabled for all search fields.
  */
  private void registerTextFieldForPopup(final JTextField tf)
  {
     tf.addMouseListener(textFieldPopupListener);
  }

  class TextFieldPopupListener extends MouseAdapter
  {
     @Override public void mousePressed(MouseEvent me)
     {
        if(me.isPopupTrigger())
        {
           showPopup(me);
        }
     }

     @Override public void mouseReleased(MouseEvent me)
     {
        if(me.isPopupTrigger())
        {
           showPopup(me);
        }
     }


  }

  /** when right clicking in a filter field (only for a perticular column, NOT for "ALL columns")
  */
  public void showPopup(MouseEvent me)
  {
     JPopupMenu pop = new JPopupMenu();

     // is called from any text field. figure which one !
     if(!(me.getSource() instanceof JTextField)) return;
     final JTextField tf = (JTextField) me.getSource();

     int columnForClickedField = -1;  // -1=all
     String colName = "column";
     if(tf==firstSearchTF)
     {
        columnForClickedField = firstSearchColumnCB.getSelectedIndex()-1;  // first is "all"
        colName = ""+firstSearchColumnCB.getSelectedItem();
     }
     else
     {
        int pos = searchTFList.indexOf(tf);
        if(pos>=0)
        {
           JComboBox cb = searchColumnCBList.get( pos);
           columnForClickedField = cb.getSelectedIndex()-1;
           colName = ""+cb.getSelectedItem();
        }
     }

    // if(getQueries().length>1)
     {
        JMenuItem reset = new JMenuItem("Reset search", Icons.sharedBlueCross);
        pop.add(reset);
        pop.addSeparator();
        reset.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
           setQueries(Query.emptySearchQuery());
        } });
     }

     //System.out.println("columnForClickedField="+columnForClickedField);
     if(columnForClickedField>=0)
     {
        final int c = columnForClickedField;
        final String fcolName = colName;

        //
        Set<String> vals = SortableTableModelAnalysis.getDifferentColumnModValues( sortableTableModel.getBasicTableModel(), columnForClickedField);
        Map<String, Integer> stats = sortableTableModel.getDifferentColumnModValuesStats(columnForClickedField, true);
        List<CountItem> sorted = sort(stats);

        final JMenuItem plot = new JMenuItem("Plot");
        pop.add(plot);
        plot.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae)
        {
               final List<Double> allVals = SortableTableModelAnalysis.getAllDoubleValuesForModColumn(sortableTableModel, c, true);

               if(allVals==null)
               {
                  JOptionPane.showMessageDialog(tf, "No valid numerical data found to plot in column "+fcolName,
                     "No numerical data", JOptionPane.INFORMATION_MESSAGE);
                  return;
               }

               TPlot tp = new TPlot("Plot column "+fcolName);
               tp.listPlot1D("vals", allVals);
               tp.autoscale();
               tp.viewInDialog(MultiSearchPanel.this);
        } });

        final JMenuItem plot2 = new JMenuItem("Plot f(other col)...");
        pop.add(plot2);
        plot2.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {

               // pre check
               final List<Double> allValsY = SortableTableModelAnalysis.getAllDoubleValuesForModColumn(sortableTableModel, c, true);
               if(allValsY==null)
               {
                  JOptionPane.showMessageDialog(tf, "No valid numerical data found to plot in column "+fcolName,
                     "No numerical data", JOptionPane.INFORMATION_MESSAGE);
                  return;
               }

               // let choose column X
               JGridPanel gp = new JGridPanel(2);
               JComboBox colXCB = new JComboBox(getColNamesWithoutAll());
               gp.addG("Column X");
               gp.addG(colXCB);

               JComboBox splitColCB = new JComboBox(getColNamesWithoutAll());
               JCheckBox split = new JCheckBox("split according", false);
               gp.addG(split);
               gp.addG(splitColCB);
               GUIUtils.enableWhenSelected(split, splitColCB);

               int rep = JOptionPane.showConfirmDialog(tf, gp, "Choose the X column", JOptionPane.OK_CANCEL_OPTION);
               if(rep!=JOptionPane.OK_OPTION) { return; }

               final int colXIndex = colXCB.getSelectedIndex();  // first is "all"
               final String colNameX = ""+colXCB.getSelectedItem();
               final List<Double> allValsX = SortableTableModelAnalysis.getAllDoubleValuesForModColumn(sortableTableModel, colXIndex, true);

               if(allValsX==null)
               {
                  JOptionPane.showMessageDialog(tf, "No valid numerical data found to plot in column "+colNameX,
                     "No numerical data", JOptionPane.INFORMATION_MESSAGE);
                  return;
               }

               if(allValsX.size() != allValsY.size())
               {
                  JOptionPane.showMessageDialog(tf, "X and Y column sizes are not compatible",
                     "Not plottable", JOptionPane.INFORMATION_MESSAGE);
                  return;
               }

               if(split.isSelected())
               {
                  final int colSplit = splitColCB.getSelectedIndex();  // first is col 0, no "all" here
                  final String colSplitName = ""+splitColCB.getSelectedItem();
                  final List<String> crit = SortableTableModelAnalysis.getAllValuesForColumnMOD(sortableTableModel, colSplit, true);


                  final Map<String, List<double[]>> splittedValues = new HashMap<String,List<double[]>>();
                  for(int i=0; i<crit.size(); i++)
                  {
                     CollectionUtils.addToMapList(splittedValues, crit.get(i), new double[]{allValsX.get(i), allValsY.get(i)});
                  }
                  final String tit = ""+fcolName+" = f("+colNameX+") splitted against "+colSplitName;
                  TPlot tp = new TPlot(tit);

                  Colors.initRandomReproducible();
                  TreeSet<String> keys = new TreeSet<String>(splittedValues.keySet());
                  for(final String ski : keys)
                  {
                     List<double[]> vals = splittedValues.get(ski);
                     ListPlotElement lpe = new ListPlotElement(ski);
                     lpe.setLineStyle(Colors.getRandomColorReproductible(true), 1);
                     lpe.setPoints(vals);
                     tp.add(lpe);
                  }

                  tp.autoscale();
                  tp.viewInDialog(MultiSearchPanel.this);
               }
               else
               {
                  String tit = ""+fcolName+" = f("+colNameX+")";
                  TPlot pp = new TPlot(tit);
                  pp.listPlot(tit, allValsX, allValsY);
                  pp.autoscale();
                  pp.viewInDialog(MultiSearchPanel.this);
               }
        } });

        //3: let choose a column to use as splitter


        int maxToDisplay = 30;

        if(vals.size()<=maxToDisplay)
        {
           pop.addSeparator();
           pop.add("<html><body>"+vals.size()+" distinct value"+(vals.size()==1?"":"s")+" in "+colName+": ");
           TreeSet<String> hs = new TreeSet<String>(vals);
           for(final CountItem ci : sorted)
           {
              JMenuItem mi = new JMenuItem(ci.toString());
              pop.add(mi);
              mi.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
                 tf.setText(ci.item);
                 doSearch();
              } });
           }
           hs.clear();
        }
        else
        {
           if(sortableTableModel.getRowCount()>2)
           {
             JMenuItem mis = new JMenuItem("Stats", new Icons.StatIcon(18,18));
             pop.add(mis);
             pop.addSeparator();
             mis.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
                SortableTableModelAnalysis.viewSatsForColumn(sortableTableModel, c, fcolName);
             } });
           }

           pop.add(""+vals.size()+" distinct values in column. The "+maxToDisplay+" first are:");
           TreeSet<String> hs = new TreeSet<String>(vals);
           int n =0;
           for(final CountItem ci : sorted)
           {
              n++;
              if(n>=maxToDisplay)
              {
                 JMenuItem mi = new JMenuItem("... "+(hs.size()-maxToDisplay)+" more ... ("+hs.size()+" total)");
                 pop.add(mi);
                 mi.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
                    // explore them in a sortable clickable table ? that writes back in this field ?
                 } });
                 break;
              }

              JMenuItem mi = new JMenuItem(ci.toString());
              pop.add(mi);
              mi.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
                 tf.setText(ci.item);
                 doSearch();
              } });
           }
           hs.clear();
        }
     }

     if(pop.getComponentCount()>0)
     {
        pop.show((Component) me.getSource(), me.getX(), me.getY()+12);
     }
  }

  public static List<CountItem> sort(Map<String, Integer> stats)
  {
     List<CountItem> ci = new ArrayList<CountItem>();

     for(String it : stats.keySet())
     {
        ci.add(new CountItem(it, stats.get(it)));
     }

     Collections.sort(ci);


     return ci;
  }

  private Vector<String> getColNamesWithoutAll()
  {
     Vector<String> ret = new Vector<String>();
     for(int i=1; i<colNames.size(); i++)
     {
        ret.add(colNames.get(i));
     }
     return ret;
  }

  static class CountItem implements Comparable<CountItem>
  {
     public CountItem(String it, int count)
     {
        this.count = count;
        this.item = it;
     }

     // @Implements("Comparable")
     public final int compareTo( final CountItem o ) {
        return Integer.valueOf(o.count).compareTo(count);
     }

     @Override public final String toString()
     {
        StringBuilder sb = new StringBuilder();
        sb.append("\""+item+"\"");
        if(count>1) sb.append("   count = "+count);
        return sb.toString();
     }

     int count;
     String item;
  }

  public JTextField getFirstTextField()
  {
     return firstSearchTF;
  }

@SuppressWarnings("nullness")  //todo: remove,
  public void doSearch()
  {
    if(!SwingUtilities.isEventDispatchThread())
    {
       new Throwable("Should be called from EDT !").printStackTrace();
    }

    this.activateAnimation(isSearchActive());
    this.setOpaque(isSearchActive());  // [Oct2010]

    Query /*@org.checkerframework.checker.nullness.qual.Nullable*/ [] queries = getQueries();
    if(queries!=null)
    {
      for(Query qi : queries ) { qi.hitsCount = 0; }
    }

    // nullness checker ERROR !
//  found   : @NonNull snow.sortabletable.Query @Nullable []
//  required: @NonNull snow.sortabletable.Query @NonNull []

    sortableTableModel.multiSearch( queries );


    if(queries!=null && queries.length>0)
    {
       int tot = sortableTableModel.getRowCount();
       this.firstSearchTF.setToolTipText(""+queries[0].hitsCount+" hits"
        +(queries.length>1 ? "/"+tot : "")+" for \""+queries[0].searchTxt+"\"");

       for(int i=1; i<queries.length; i++)
       {
          this.searchTFList.get(i-1).setToolTipText(""+queries[i].hitsCount+" hits/"+tot+" for \""+queries[i].searchTxt+"\"");
       }
    }

    hitsLabel.setText("");
    if(viewHitsCount && isSearchActive())
    {
       int nh = sortableTableModel.getRowCount();
       if(nh>2)
       {
         hitsLabel.setText(""+nh+" hits"); // of "+sortableTableModel.getRowCountOfUnfilteredModel());
         firePropertyChange(queriesChangedProperty, 0,1);
       }
       //System.out.println(""+sortableTableModel.getRowCount()+" hits of "+sortableTableModel.getRowCountOfUnfilteredModel());
    }
  }

  public Query /*@org.checkerframework.checker.nullness.qual.Nullable*/ [] getQueries()
  {
    if (!isSearchActive())
    {
      return null;
    }

    int subCnt = searchOperationCBList.size();
    Query[] result = new Query[subCnt+1]; // first is fixed

    int col = firstSearchColumnCB.getSelectedIndex()-1;  // -1 => all
    String searchTxt = firstSearchTF.getText();
    int boolOp = 0;
    int compMode = firstComparisonCB.getSelectedIndex();
    Query.Comparison type = Query.Comparison.forIndex(compMode);

    result[0] = new Query(col, searchTxt, Query.Combine.And, type);

    for (int i=0; i<subCnt; i++)
    {
      col = searchColumnCBList.get(i).getSelectedIndex()-1;  // -1 => all
      searchTxt = searchTFList.get(i).getText();
      boolOp = searchOperationCBList.get(i).getSelectedIndex();
      compMode = searchComparisonCBList.get(i).getSelectedIndex();
      type = Query.Comparison.forIndex(compMode);

      result[i+1] = new Query(col, searchTxt, Query.Combine.forIndex(boolOp), type);
    }

    return result;
  }


  public void setQueries(final Query/*@org.checkerframework.checker.nullness.qual.Nullable*/[] _queries)
  {
    // remove all
    for (JComboBox item : searchOperationCBList)
    {
      MultiSearchPanel.this.remove(item);
    }
    for (JTextField item : searchTFList)
    {
      MultiSearchPanel.this.remove(item);
    }
    for (JComboBox item : searchComparisonCBList)
    {
      MultiSearchPanel.this.remove(item);
    }
    for (JComboBox item : searchColumnCBList)
    {
      MultiSearchPanel.this.remove(item);
    }
    for (JButton item : searchDelBtnList)
    {
      MultiSearchPanel.this.remove(item);
    }

    searchOperationCBList.clear();
    searchTFList.clear();
    searchComparisonCBList.clear();
    searchColumnCBList.clear();
    searchDelBtnList.clear();

    layout.invalidateLayout(MultiSearchPanel.this);
    layout.layoutContainer(MultiSearchPanel.this);

    if ( (_queries == null) || (_queries.length == 0) )
    {
      this.firstSearchColumnCB.setSelectedIndex(0);
      this.firstSearchTF.setText("");
    }
    else
    {
      // set first
      this.firstSearchColumnCB.setSelectedIndex(_queries[0].column+1);
      this.firstSearchTF.setText(_queries[0].searchTxt);
      this.firstComparisonCB.setSelectedIndex(_queries[0].comparison.ordinal());

      // set others
      for (int i=1; i<_queries.length; i++)
      {
        addCriteria( _queries[i].boolOp.ordinal(), _queries[i].searchTxt, _queries[i].column, _queries[i].comparison.ordinal() );
      }
    }

    if(viewHitsCount)
    {
       this.layout.insertLineBreakAfterNextComponent();
       this.layout.add(hitsLabel, true);
    }

    doSearch();

    this.firePropertyChange(queriesChangedProperty, 0,1);

  }

  /** sets the size */
  private void formatComboBoxUI(JComboBox cb )
  {
    cb.setMaximumRowCount(30);
    if(!GUIUtils.isNimbusLF())
    {
      cb.setPreferredSize(new Dimension(cb.getPreferredSize().width, firstSearchTF.getPreferredSize().height));
      cb.setFont( GUIUtils.getSmallFont() );
    }
    else
    {
      cb.putClientProperty("JComponent.sizeVariant", compactUI ? "small": "small");
      GUIUtils.makeSmall(cb);
    }
  }

  private void addCriteria()
  {
    addCriteria(-1, null, -1, 0);
  }

  private void addCriteria( int opIndex, /*@org.checkerframework.checker.nullness.qual.Nullable*/ String qStr, int colIndex, int compMode )
  {
    final JComboBox searchOperationCB = new JComboBox(new String[]{ "and", "or", "and not", "or not"}); // xor?
    if (opIndex >= 0)
    {
      searchOperationCB.setSelectedIndex(opIndex);
    }
    searchOperationCB.putClientProperty("JComponent.sizeVariant", compactUI ? "small": "small");
    searchOperationCBList.add(searchOperationCB);
    GUIUtils.makeSmall(searchOperationCB);

    final JTextField searchTF = new JTextField(compactUI ? 4 : 8);
    searchTF.putClientProperty("JComponent.sizeVariant", compactUI ? "small": "small");
    registerTextFieldForPopup(searchTF);
    if (qStr != null)
    {
      searchTF.setText(qStr);
    }
    searchTFList.add(searchTF);

    final JComboBox comparisonCB = new JComboBox(Query.comparisonTypeNames);
    comparisonCB.putClientProperty("JComponent.sizeVariant", compactUI ? "small": "small");
    comparisonCB.setSelectedIndex(compMode);
    GUIUtils.makeSmall(comparisonCB);
    searchComparisonCBList.add(comparisonCB);

    final JComboBox searchColumnCB = new JComboBox();
    searchColumnCB.putClientProperty("JComponent.sizeVariant", compactUI ? "small": "small");
    searchColumnCB.setModel(new DefaultComboBoxModel(colNames));
    searchColumnCB.setSelectedIndex(colIndex+1);
    GUIUtils.makeSmall(searchColumnCB);

    searchColumnCBList.add(searchColumnCB);

    installCompletion(searchColumnCB, searchTF);

    final JButton delCriteriaBtn = GUIUtils.createMiniIconButton(Icons.sharedCross);
    /*delCriteriaBtn.setMargin(new Insets(0,0,0,0));
    delCriteriaBtn.setPreferredSize(new Dimension(18,18));  // ok, is an icon.*/
    delCriteriaBtn.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        int arrayPos = searchOperationCBList.indexOf(searchOperationCB);

        removeCriteriaAt(arrayPos);
      }
    });
    searchDelBtnList.add(delCriteriaBtn);
    layout.add(searchOperationCB);
    layout.add(searchColumnCB);
    layout.add(comparisonCB);
    layout.add(searchTF);
    layout.insertLineBreakAfterNextComponent();
    layout.add(delCriteriaBtn);

    firstDelSearchBtn.setEnabled(true);

    searchOperationCB.addActionListener(delayedMergedUpdater);
    searchColumnCB.addActionListener(delayedMergedUpdater);
    comparisonCB.addActionListener(delayedMergedUpdater);
    //searchTF.addKeyListener(keyAdapter);
    searchTF.getDocument().addDocumentListener(delayedMergedUpdater);

    // focus behaviour
    /*// not nice when completion works
    GUIUtils.selectAllTextWhenFocused(searchTF);
    */

    this.updateUI();

    formatComboBoxUI(searchColumnCB);
    formatComboBoxUI(searchOperationCB);
    formatComboBoxUI(comparisonCB);

    // only this causes the Nimbus small size to be effective!
    SwingUtilities.updateComponentTreeUI(this);
  }

  /**
   * note:
   * 0 is the index of the first SUB-criteria,
   * the first (main) criteria cannot be removed.
   */
  private void removeCriteriaAt(int pos)
  {
    MultiSearchPanel.this.remove(searchOperationCBList.get(pos));
    MultiSearchPanel.this.remove(searchTFList.get(pos));
    MultiSearchPanel.this.remove(searchComparisonCBList.get(pos));
    MultiSearchPanel.this.remove(searchColumnCBList.get(pos));
    MultiSearchPanel.this.remove(searchDelBtnList.get(pos));

    searchOperationCBList.remove(searchOperationCBList.get(pos));
    searchTFList.remove(searchTFList.get(pos));
    searchComparisonCBList.remove(searchComparisonCBList.get(pos));
    searchColumnCBList.remove(searchColumnCBList.get(pos));
    searchDelBtnList.remove(searchDelBtnList.get(pos));

    firstDelSearchBtn.setEnabled(searchOperationCBList.size() > 0);

    layout.invalidateLayout(MultiSearchPanel.this);
    layout.layoutContainer(MultiSearchPanel.this);
    updateUI();

    doSearch();

    firePropertyChange(queriesChangedProperty, 0,1);
  }

 /** Standalone test.
  */
  public static void main( String[] arguments )
  {
     GUIUtils.setNimbusLookAndFeel_IfPossible();
     Test.main(arguments);
  }
}
