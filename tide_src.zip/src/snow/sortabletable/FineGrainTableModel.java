package snow.sortabletable;

import javax.swing.text.JTextComponent;
import javax.swing.table.*;
import java.util.*;
import javax.swing.event.*;
import javax.swing.*;


/** This table model define a new TableModelChangeListener
   this model should be used with the SortableTableModel to allow
   keeping the selection when table model changes.

   HOWTO use:
    + by each modification of this model (i.e. in SetValue())
      First call before change :  fireModelWillChange()
      After change             :  fireTableDataChanged() and fireModelHasChanged()
*/
public abstract class FineGrainTableModel extends AbstractTableModel
{
  private final List<TableModelChangeListener> modelListeners = new ArrayList<TableModelChangeListener>();

  public FineGrainTableModel()
  {
  }


 /** Important, this allow the table to determine which renderer to use
     (checkbox for Boolean, ...)
  */
@Override
  public Class<?> getColumnClass ( int column )
  {
     if(this.getColumnCount()==0 || this.getRowCount()==0)
     {
        return Object.class.getClass();
     }

     Object val = this.getValueAt(0,column);
     if(val==null) return String.class;
     return val.getClass();
  }


  /** To sort columns... owerwrite if you need a better (or faster) sorting
  */
  @SuppressWarnings({"unchecked", "cast", "rawtypes"})
  public int compareForColumnSort(int pos1, int pos2, int col)
  {
    Object val1 = this.getValueAt(pos1,col);
    Object val2 = this.getValueAt(pos2,col);

    if(val1==null && val2==null) return 0;  // [May2009]
    if(val1==null ) return 1;
    if(val2==null ) return -1;

    if(val1 instanceof Comparable && val1.getClass()==val2.getClass())
    {
       return ((Comparable) val1).compareTo(val2);  //ERRONEOUS Compiler warning : says redundant cast
    }
    else if(val1 instanceof Boolean && val2 instanceof Boolean)
    {
       return compareBooleans((Boolean) val1, (Boolean) val2);
    }
    else if(val1 instanceof JLabel && val2 instanceof JLabel)
    {
       return (""+((JLabel) val1).getText()).compareToIgnoreCase(""+((JLabel) val2).getText());
    }
    else if(val1 instanceof JTextComponent && val2 instanceof JTextComponent)
    {
       return ((JTextComponent) val1).getText().compareToIgnoreCase(((JTextComponent) val2).getText());
    }
    else if(val1 instanceof Icon && val2 instanceof Icon)
    {
       // not very useful...
       return compareDoubles(((Icon) val1).getIconWidth(), ((Icon) val2).getIconWidth());
    }
    else
    {
       // compare as a String
       return (""+val1).compareTo(""+this.getValueAt(pos2,col));
    }
  }


  /** @return true if the txt appears in the given row

      overwrite this method if you want a special search (Approximate, Numerical, ...)
      @param p if not null, regex search p should be used.
  *
  public boolean hitForTextSearch(int row, String txt, Pattern p)
  {
     if(txt==null || txt.equals("")) return true;
     String search = txt.toUpperCase();

     for(int col=0; col<this.getColumnCount(); col++)
     {
        String val = this.getValueAt(row,col).toString();
        if(p!=null)
        {
          Matcher m = p.matcher(val);
          return m.matches();
        }
        else
        {
          if(val.toUpperCase().indexOf(search)>=0) return true;
        }
     }
     return false;
  }*/

  /** @return true if the txt appears in the given row and column
  *  if column is -1, searches in all cols
  */
  @tide.annotations.Recurse
  boolean hit1QForTextSearch(int row, int column, String txt, Query query)
  {
     if(txt==null || txt.equals("")) return true;

     if(column==-1)
     {
        for(int col=0; col<this.getColumnCount(); col++)
        {
           if( hit1QForTextSearch(row, col, txt, query)) return true;
        }
        return false;
     }

     String search = txt.toUpperCase();
     String val = this.getValueAsStringAt(row,column);
     switch(query.comparison)
     {
        case Contains:  if(  val.indexOf(search)>=0) { return true; } break;
        case Equals:    if(  val.equals(search))     { return true; } break;
        case StartsWith:if(  val.startsWith(search)) { return true; } break;
        case EndsWith:  if(  val.endsWith(search))   { return true; } break;
        case RegEx:
        {
           assert query.pattern!=null;  // checkers 0.9.7: not considering this [Aug2009]
           if( query.pattern!=null && query.pattern.matcher(val).matches()) { return true; } break;
        }
     }
     return false;
  }


  /**
   * for the multi search (can be boosted)
   */
  public boolean hitForTextSearch(int row, final Query[] queries)
  {
    if (queries == null)
    {
       return true;
    }

    // pre eval (first and second order boolean bindings (not / and)
    final List<Boolean> matches = new ArrayList<Boolean>();

    for(final Query q : queries)
    {
      // ignore empty queries
      if (q.isEmpty())
      {
        q.hitsCount++;
        continue;
      }

      boolean hit = hit1QForTextSearch(row, q.column, q.searchTxt, q);

      if (q.isNegation())
      {
        hit = !hit;
      }

      if ( matches.size()>0
       && (q.boolOp == Query.Combine.And || q.boolOp == Query.Combine.AndNot) )
      {
        // and
        matches.set(matches.size()-1, matches.get(matches.size()-1) && hit );
      }
      else  // first criteria or OR operation
      {
        matches.add(hit);
      }

      if(hit) q.hitsCount++;
    }

    if(matches.isEmpty()) return true;  // empty query...

    // eval (third order boolean binding (=or)
    boolean match = false;
    for (Boolean b : matches)
    {
      match = match || b;
    }

    return match;
  }

  /** overwrite this is you want to specify a default width... (measured in Label.font size).
      -1 do nothing. Any positive value will be used as preferred width.

      To be effective, the table must be set in
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
      before call installGUI()
  */
  public int getPreferredColumnWidth(int column)
  {
    return -1;
  }

  public int getColumnAlignment(int column)
  {
    return JLabel.LEFT;
  }


  /**
   * @return the value of a cell as a String
   * for the multi search.
   * this method may be overwritten if the normal
   * toString() of a value is not suitable for a search (e.g. dates)
   */
  public String getValueAsStringAt(int row, int col)
  {
    return (""+getValueAt(row,col)).toUpperCase();
  }

  // Selection
  //
  // These four methods are not abstract,
  //     public void setRowSelection(int row, boolean isSelected)
  //     public boolean isRowSelected(int row)
  //     public void clearRowSelection()
  //     public int[] getSelectedRows()
  //
  // Here implemented is a non persistant selection mechanism.
  // overwrite it to provide a selection that is stored in your model
  //
  //

  private HashSet<Integer> selectedRows = new HashSet<Integer>();


  /** Used to select/deselect a given row.
      this method doesn't fire any events
      overwrite this AND THE TWO OTHERS selection method to provide your
      selection mechanism. (maybe storing it in the model items)

 public void setRowSelection(int row, boolean isSelected)
 public boolean isRowSelected(int row)
 public void clearRowSelection()


      EACH model row deletion will destroy sense of this selection.
      => MUST NORMALLY BY OVERWRITTEN
      + for bosting big tables: public int[] getSelectedRows()
  */
  public void setRowSelection(int row, boolean isSelected)
  {
    if(isSelected)
    {
      selectedRows.add( row );
    }
    else
    {
      selectedRows.remove( row );
    }
  }

  /** Tells if the row is selected.
  */
  public boolean isRowSelected(int row)
  {
    return selectedRows.contains( row );
  }

  public void clearRowSelection()
  {
    for(int i=0; i<this.getRowCount(); i++)
    {
      this.setRowSelection(i, false);
    }
  }

  /** overwrite only if you want to boost.
     This method use isRowSelected(row) to detect which rows are selected.
  */
  public int[] getSelectedRows()
  {
    // slow but robust
    //
    Vector<Integer> sel = new Vector<Integer>();
    synchronized(this)
    {
      for(int i=0; i<getRowCount(); i++)
      {
        if(isRowSelected(i)) sel.add(i);
      }
      int[] rep = new int[sel.size()];
      for(int i=0; i<rep.length; i++)
      {
        rep[i] = sel.get(i);
      }
      return rep;
    }

  }




  // Model Listener
  //
  public void addModelChangeListener(TableModelChangeListener listener)
  {
     synchronized(modelListeners)
     {
       modelListeners.add(listener);
     }
  }

  public void removeModelChangeListener(TableModelChangeListener listener)
  {
     synchronized(modelListeners)
     {
       modelListeners.remove(listener);
     }
  }

  public void fireTableModelWillChange()
  {
    final TableModelChangeListener[] tml;
    synchronized(modelListeners)
    {
       // do a copy of the listeners to decouple them from the vector
       // because they may perform operation on the vector in the notify loop (remove listener)
       // and caus concurrent modification exceptions
       tml = modelListeners.toArray(new TableModelChangeListener[modelListeners.size()]);
    }

    for(int i=tml.length-1; i>=0; i--) // last added first
    {
       tml[i].tableModelWillChange(new ChangeEvent(this));
    }
  }

  public void terminate()
  {
     synchronized(modelListeners)
     {
       modelListeners.clear();
     }
     selectedRows.clear();
  }

  public void fireTableModelHasChanged()
  {
    TableModelChangeListener[] tml = null;
    synchronized(modelListeners)
    {
       // do a copy of the listeners to decouple them from the vector
       // because they may perform operation on the vector in the notify loop (remove listener)
       // and caus concurrent modification exceptions
       tml = modelListeners.toArray(new TableModelChangeListener[modelListeners.size()]);
    }
    for(int i=tml.length-1; i>=0; i--) // last added first
    {
       tml[i].tableModelHasChanged(new ChangeEvent(this));
    }
  }


  // Some utilities for comparaison
  //

  public static int compareInts(int i1, int i2)
  {
    if(i1==i2) return 0;
    if(i1>i2)  return 1;
    return -1;
  }

/** same as Double.valueOf(i1).compareTo(i2), but 5 times quicker if one has not the Double class already available.
*   Use this also for ints...
*/
  public static int compareDoubles(double i1, double i2)
  {
    if(i1==i2) return 0;
    if(i1>i2)  return 1;
    return -1;
  }

/** equivalent to Boolean.valueOf(b1).compareTo(b2) but 3 times quicker
*/
  public static int compareBooleans(boolean b1, boolean b2)
  {
    if(b1==b2) return 0;
    if(b1)     return 1;
    return -1;
  }

  public static void main(String[] arguments)
  {
     Test.main(new String[0]);
  }

}