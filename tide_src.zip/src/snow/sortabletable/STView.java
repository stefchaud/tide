package snow.sortabletable;

import java.util.List;
import javax.swing.JScrollPane;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JTable;

/** Convenience class to manage a view from a given table model builder.
*  The view is accessed with getJPanel()
*/
public final class STView<T extends TableRow>
{
   final private FineGrainTableModelBuilder<T> tmb;

   final SortableTableModel stm;
   final MultiSearchPanel msp;
   final JTable table;
   final UniversalTableCellRenderer utcr;

   final JPanel p;

   /** Constructor. */
   public STView(FineGrainTableModelBuilder<T> tmb)
   {
      this.tmb = tmb;
      p = new JPanel(new BorderLayout());

      stm = new SortableTableModel(tmb);
      table = new JTable(stm);

      stm.installGUI(table);
      p.add(new JScrollPane(table), BorderLayout.CENTER);
      p.add(msp = new MultiSearchPanel(stm), BorderLayout.NORTH);
      msp.compactUI=true;
      msp.setAdvancedState(false);

      utcr = new UniversalTableCellRenderer(stm, table);

   }

   /** Contains the table in a scrollpane
   */
   public JPanel getJPanel(){ return p; }
   public final JTable getTable() { return table; }
   public final UniversalTableCellRenderer getUtcr() { return utcr; }
   public final SortableTableModel getStm() { return stm; }

   public List<T> getSelected()
   {
      return tmb.getSelectedItems(table, stm);
   }

   static <T extends TableRow> STView<T> create(FineGrainTableModelBuilder<T> tmb)
   {
      return new STView<T>(tmb);
   }

   public final MultiSearchPanel getMultiSearchPanel()
   {
     return msp;
   }


}