/** an internal benchmark
*   the caller calls the bench from another VM
* requires: 1) the tide.jar ref (known if installed)
* 2) snow.benchmark.BenchmarkMain not obfuscated in jar (Proguard)
*/
package snow.benchmark;
