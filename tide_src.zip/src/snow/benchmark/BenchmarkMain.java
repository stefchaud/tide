package snow.benchmark;

import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.util.concurrent.atomic.AtomicLong;
import java.text.DecimalFormat;
import java.util.concurrent.*;
import java.util.Date;

/** Some simple benchmarks.
*  Conviniently called from the JavasDetector  tool
*
* EEE:    102  (1.7.0_01 server)
* Ci7     452  (/: 19
*           1400
*
*  IN CONSTRUCTION !
*  called in a separate VM only !! (exit at end)
*/
public final class BenchmarkMain
{
   //@ Calls system exit !

   public static String benchEndLine = "tBench end.";

   //long size;

   /** .
   */
   public BenchmarkMain(int warmruns, long size)
   {
      final DecimalFormat df1 = new DecimalFormat("0.0");

      // effective run
      final int nOps=4;


      // warm up
      if(warmruns>0)
      {
         System.out.println("warming up with "+warmruns+" runs");
         for(int i=0; i<warmruns; i++)
         {
            long dt  = benchcore(nOps, size);
            //System.out.println("   "+dt+" ms");
         }
      }

      try{ Thread.sleep(1000); } catch(InterruptedException ex) { ; }

      long t0 = System.currentTimeMillis();

      long dt = benchcore(nOps, size);

      //System.out.println("dt="+dt+" ms");

      // last call
      double mflops = nOps*size / (dt/1000.0)*1e-6;
      System.out.println("SingleCoreSpeed="+df1.format(mflops)+" Mflops" );

      try{ Thread.sleep(1000); } catch(InterruptedException ex) { ; }

      // parallel
      int ncores = 4;
      try{
         // not working on mac
         ncores = Integer.parseInt(System.getenv("NUMBER_OF_PROCESSORS"));
      }
      catch(final Exception e)
      {
         // always works
         ncores = Runtime.getRuntime().availableProcessors();
         System.out.println("CAN't read NUMBER_OF_PROCESSORS, using runtime value = "+ncores);
      }

      System.out.println("ncores="+ncores);

      final ExecutorService executorService = Executors.newFixedThreadPool(ncores*2);
      t0 = System.currentTimeMillis();

      final AtomicLong effectiveStartTime = new AtomicLong(0);
      final CountDownLatch cdl = new CountDownLatch(ncores);

      // keep the same size
      final long sizePar = size;
      for(int i=0; i<ncores; i++)
      {
         executorService.submit(new Callable<Long>()
         {
            @Override public final Long call(  )
            {
               effectiveStartTime.compareAndSet(0,  System.currentTimeMillis());
               long dt = benchcore(nOps, sizePar);

               cdl.countDown();

               return dt;
            }
         });
      }

      try
      {
         //executorService.shutdown();
         //executorService.awaitTermination(5, TimeUnit.MINUTES);
         cdl.await(5, TimeUnit.MINUTES);

         t0 = effectiveStartTime.get();
         dt = System.currentTimeMillis()-t0;
         double mflopsPar = ncores*nOps*sizePar / (dt/1000.0)*1e-6;
         System.out.println("MultiCoreSpeed="+df1.format(mflopsPar)+" Mflops" );

         System.out.println("MultiCoreSpeedup="+df1.format(mflopsPar/mflops));
      }
      catch(final Exception e) {
         e.printStackTrace();
      }
   }

   // the core of the benchmark
   /**
   */
   long  benchcore(int nOps, long size)
   {
        //System.out.println("sbench start, size="+size);

        long t0 = System.currentTimeMillis();

        double[] ret = new double[17];  // tricks optimizer

        double a = 1;
        // double d = 1/0.254;

        for(int i=0; i<size; i++)
        {
           a = a + 1.063458;
           a = a + 1.063457;
           a = a + 1.063456;
           a = a + 1.063455;
           /*
           a = a + 1.063454;
           a = a + 1.063453;
           a = a + 1.063452;
           a = a + 1.063451;*/

           /* with loop in loop, we only reach speedup of 5 with 8 core !!  BAD !
           for(int j=0; j<nOps; j++)
           {
             a = a + 1.06345;
           }*/
        }
        ret[3] = a;
        return System.currentTimeMillis()-t0;

   }



   /** Called from BenchCaller in another JRE.
   */
   public static void main(String[] args) throws Exception
   {
      System.out.println("tBench 1.01");
      System.out.println("  StartTime="+System.nanoTime()+" ns  ("+new Date()+")");  // can be used for more accurate startup bench measurement
      System.out.println("  java.vm.name="+System.getProperty("java.vm.name"));
      System.out.println("  java.runtime.version="+System.getProperty("java.runtime.version"));
      System.out.println("  NUMBER_OF_PROCESSORS="+System.getenv("NUMBER_OF_PROCESSORS"));

      /* tide proprietary
      //NO SENSE ! we see here tide main app own args copied !
      //  as env variable passed to the subprocess.
      if(System.getenv("vmargs")!=null)
      {
        System.out.println("  vmargs="+System.getenv("vmargs"));   // not on XP!  no alternative ?  (some Management Bean??)
        System.out.println("  appargs="+System.getenv("appargs")); // not on XP   alternative System.getProperty("sun.java.command")
      }*/

      /*if(System.getenv("appargs")==null)
      {
        System.out.println("  sun.java.command="+System.getProperty("sun.java.command"));
      }*/

      // parse args of form key=val
      int warmruns = 2;
      long size = (long) 1e9;

      for(int i=0; i<args.length; i++)
      {
         String ai = args[i];
         if("-help".equals(ai))
         {
            System.out.println("Tide benchmark - 2013");
            System.out.println("Options");
            System.out.println("  -help\tprints this help and exit");
            System.out.println("  -exit\tdirectly exits, used to measure startup times.");
            System.out.println("  -size=value\tspecify the problem size, by default 1e8");
            System.out.println("  -warmruns=value\tspecify the number of times to run the bench to warm up before measuring");
            System.exit(0);
         }
         if("-exit".equals(ai))
         {
            System.out.println("tBench end.");
            System.exit(0);
         }
         if("-exit2".equals(ai))
         {
            EventQueue.invokeLater(new Runnable() { public void run()
            {
                 JFrame frame = new JFrame("tBench 1.01");
                 frame.add(new JLabel("this frame should disapear very quickly"), BorderLayout.CENTER);
                 frame.setSize(200, 200);
                 frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                 frame.setLocationRelativeTo(null);
                 frame.setVisible(true);

                 System.out.println("  StartTimeSwing="+System.nanoTime()+" ns  ("+new Date()+")");  // can be used for more accurate startup bench measurement

                 System.exit(0);
            }});
           // JOptionPane.showMessageDialog(null, "click me!", "tBench", JOptionPane.INFORMATION_MESSAGE);
            System.out.println("tBench end.");
            //System.exit(0);

            return;
         }
         if(ai.startsWith("-size="))
         {
            size = (long) Double.parseDouble(ai.substring(6).trim());
         }
         if(ai.startsWith("-warmruns="))
         {
            warmruns = Integer.parseInt(ai.substring(10).trim());
         }
      }

      System.out.println("  size="+size);
      System.out.println("  warmruns="+warmruns);


      new BenchmarkMain(warmruns, size);

      System.out.println(benchEndLine);
      System.exit(0);
   }

}