package snow.benchmark;

import snow.sortabletable.*;
import snow.sortabletable.FineGrainTableModelBuilder;
import java.awt.BorderLayout;
import java.awt.Component;
import java.io.File;
import java.text.DecimalFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.prefs.Preferences;
import javax.swing.*;
import snow.texteditor.SimpleDocument;
import snow.utils.DateUtils;
import snow.utils.ProcessUtils;
import snow.utils.StringUtils;
import snow.utils.gui.CloseControlPanel;
import snow.utils.gui.GUIUtils;
import snow.utils.gui.JGridPanel;
import snow.utils.storage.*;

/** Caller of the benchmark utility
*/
public final class BenchCaller
{

   public static void defineBenchOpts(final JDialog parent)
   {
      JDialog d = new JDialog(parent, "Banchmark options", true);

      JGridPanel gp = new JGridPanel(2);
      gp.addG("VM args (one per line)");
      JTextArea vmArgs = new JTextArea(5, 40);
      {
        final List<String> lines = PrefUtils.readList_nonempty("tideBenchVMArgs", Preferences.userRoot());
        for(String li : lines)
        {
           if(li.trim().isEmpty()) continue;
           vmArgs.append(li+"\r\n");
        }
      }
      gp.addG(new JScrollPane(vmArgs), true);

      gp.addG("App args (one per line)");
      JTextArea appArgs = new JTextArea(5, 40);
      {
        final List<String> lines = PrefUtils.readList_nonempty("tideBenchAppArgs", Preferences.userRoot());
        for(String li : lines)
        {
           if(li.trim().isEmpty()) continue;
           appArgs.append(li+"\n");
           //System.out.println("readli>"+li);
        }
      }
      gp.addG(new JScrollPane(appArgs), true);


      d.add(gp, BorderLayout.CENTER);
      CloseControlPanel ccp = new CloseControlPanel(d, true, true, "Ok");
      d.add( ccp, BorderLayout.SOUTH);

      d.pack();
      d.setLocationRelativeTo(null);
      d.setVisible(true);

      if(ccp.getWasCancelled()) return;


      {
        List<String> lines = StringUtils.splitLines(vmArgs.getText());
        removeEmpty(lines);
        PrefUtils.setList("tideBenchVMArgs", lines, Preferences.userRoot());
      }

      {
        List<String> lines = StringUtils.splitLines(appArgs.getText());
        removeEmpty(lines);
        //System.out.println("lines="+lines);
        PrefUtils.setList("tideBenchAppArgs", lines, Preferences.userRoot());
      }

   }

   static void removeEmpty(List<String> lines)
   {
        Iterator<String> it = lines.iterator();
        while(it.hasNext()){
           String l = it.next();
           if(l.trim().isEmpty()) it.remove();
        }
   }



   /** Calls some benchmarks defined in snow.benchmark.BenchmarkMain with the given runtime
   */
   public static void tideBenchmarkCall(final Component parent, final File javaExe, final File tidejar, final List<String> vmArgs,  final List<String> appArgs)
   {
         SwingWorker<String, Object> sw = new SwingWorker<String, Object>()
         {
            long startTimeNanos;
            long totalTimeNanos = -1;

            @Override protected final void done(  )
            {
               try
               {
                  StringBuilder oneLiner = new StringBuilder();

                  TBench tb = new TBench();

                  String result = ""+get();

                  SimpleDocument doc = new SimpleDocument();
                  doc.appendBoldLine("Benchmark for "+javaExe);
                  doc.appendBoldLine("using "+tidejar);

                  if(vmArgs!=null)
                  {
                     doc.appendBoldLine("VM Args: "+vmArgs);
                     tb.vmArgs = ""+vmArgs;
                  }

                  doc.appendBoldLine("Args: "+appArgs);

                  // not so passionating
                  //doc.appendLine("\nTotal time = "+DateUtils.formatDurationNanos(totalTimeNanos));

                  String st = StringUtils.extractFromFirstToNext_Excluded(result,"StartTime=", "ns");
                  if(st!=null)
                  {
                     long ccc = Long.parseLong( st.trim() );
                     long stt = ccc- startTimeNanos;
                     doc.appendBoldLine("VM startup time = "+DateUtils.formatDurationNanos(stt));
                     tb.startupNs = stt;
                     oneLiner.append("Startup="+DateUtils.formatDurationNanos(stt));
                  }

                  st = StringUtils.extractFromFirstToNext_Excluded(result,"StartTimeSwing=", "ns");
                  if(st!=null)
                  {
                     long ccc = Long.parseLong( st.trim() );
                     long stt = ccc- startTimeNanos;
                     doc.appendBoldLine("Swing startup time = "+DateUtils.formatDurationNanos(stt));
                     tb.startupNs = stt;
                     oneLiner.append("SwingStartup="+DateUtils.formatDurationNanos(stt));
                  }


                try{
                  DecimalFormat df2 = new DecimalFormat("0.0#");
                  st = StringUtils.extractFromFirstToNext_Excluded(result,"SingleCoreSpeed=", "Mflops");
                  if(st!=null)
                  {
                     System.out.println("st="+st);
                     System.out.println("result="+result);
                     double mf = Double.parseDouble( st.trim() );
                     doc.appendBoldLine("SingleCoreSpeed = "+df2.format(mf)+" Mflops");
                     tb.mflops = mf;
                  }
                  st = StringUtils.extractFromFirstToNext_Excluded(result,"MultiCoreSpeed=", "Mflops");
                  if(st!=null)
                  {
                     double mf = Double.parseDouble( st.trim() );
                     doc.appendBoldLine("MultiCoreSpeed = "+df2.format(mf)+" Mflops");
                     tb.mflopsPar = mf;
                     oneLiner.append(", ParSpeed="+df2.format(mf)+" MFlops");
                  }
                  st = StringUtils.extractFromFirstToNext_Excluded(result,"MultiCoreSpeedup=", "\n");
                  if(st!=null)
                  {
                     double mf = Double.parseDouble( st.trim() );
                     doc.appendBoldLine("   speedup = "+df2.format(mf)+"");
                     tb.mult = mf;
                  }

                  st = StringUtils.extractFromFirstToNext_Excluded(result,"ncores=", "\n");
                  if(st!=null)
                  {
                     int mf = Integer.parseInt( st.trim() );
                     doc.appendBoldLine("   ncores = "+mf+"");
                     tb.nt = mf;
                  }
                 }
                 catch(final Exception e) {
                    e.printStackTrace();
                 }


                  tb.vm= StringUtils.extractFromFirstToNext_Excluded(result,"java.vm.name=", "\n");
                  tb.runtime= StringUtils.extractFromFirstToNext_Excluded(result,"java.runtime.version=", "\n");


                  doc.append("\n\n===== Output =====\n" +result);


                  //if(mflops>0) // do not store startup only
                  {
                    tb.made = System.currentTimeMillis();
                    writeToFile(tb);
                  }


                  JTextPane tp = new JTextPane(doc);
                  GUIUtils.displayInDialog(parent, "tide Java benchmark result", new JScrollPane(tp));


                  // nice.
                  // oneLiner

               }
               catch(final Exception e) {
                  e.printStackTrace();
               }
            }

            // Launch
            //Overrides abstract method of SwingWorker
            @Override protected final String doInBackground(  )
            {
                 try
                 {
                    final List<String> args = new ArrayList<String>();
                    args.add(javaExe.getAbsolutePath());
                    if(vmArgs!=null)
                    {
                      args.addAll(vmArgs);
                    }
                    args.add( "-cp");
                    args.add(""+tidejar);
                    args.add("snow.benchmark.BenchmarkMain");
                    args.addAll(appArgs);

                    startTimeNanos = System.nanoTime();
                    ProcessBuilder pb = new ProcessBuilder(args);
                    //NO NO NO. pb.environment().clear(); // if we remove, the processors count is lost !
                    //  but we remove these specific tide ones... (on windows, when started from batch)
                    Map env = pb.environment();
                    env.remove("appargs");
                    env.remove("vmargs");
                    pb.directory(javaExe.getParentFile());

                    String cont = ProcessUtils.readWholeProcessStack(pb.start(), TimeUnit.MINUTES.toMillis(10));
                    totalTimeNanos = System.nanoTime()- startTimeNanos;

                    return cont;
                 }
                 catch(final Exception e)
                 {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Can't read java version for "+javaExe+"\n\nerr="+e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    return "Error: "+e.getMessage();
                 }
            }
         };

         sw.execute();
         System.out.println("tBench called");
   }




   /** append to bench results !
   */
   static void writeToFile(TBench tb)
   {
      File benchFolder = new File(System.getProperty("user.home"), ".tide_global/benchs/");
      try
      {
         if(!benchFolder.exists())
         {
            benchFolder.mkdirs();
         }

         File f = new File(benchFolder, ""+System.currentTimeMillis()+".tbench");
         tb.writeToFile(f);
      }
      catch(final Exception e) {
         e.printStackTrace();
      }
   }

   static JFrame exploreBenchs()
   {
      final FineGrainTableModelBuilder<TBench> fgtmb = new FineGrainTableModelBuilder<TBench>(7);
      fgtmb.setColumnNames("Desc", "Date", "MFlops 1T", "MFlops NT", "Mult", "Start [ms]", "vm args");
      final File benchFolder = new File(System.getProperty("user.home"), ".tide_global/benchs/");

      JFrame f = fgtmb.viewInFrame("Benchs explorer");

      for(final File fi : FileUtils.getFilesOnly_notRecurse(benchFolder))
      {
         if(fi.isFile() && fi.getName().toLowerCase().endsWith(".tbench"))
         {
            try
            {
               TBench tb = new TBench(fi);
               fgtmb.addRows(tb);
            }
            catch(final Exception e) {
               e.printStackTrace();
            }
         }
      }
      return f;
   }

   static class TBench implements TableRow
   {
      public final Object getValueForColumn( final int col ) {
         if(col==0) return descr+" "+vm+" "+runtime;
         if(col==1) return new Date(made);
         if(col==2) return mflops;
         if(col==3) return mflopsPar;
         if(col==4) return mult;
         if(col==5) return (int) (startupNs*1e-6);
         if(col==6) return vmArgs;
         return null;
      }

      public TBench()
      {
      }

      public TBench(File f) throws Exception
      {
          StorageVector sv = FileUtils.loadVectorFromFile(f);

          made = sv.getLong(1);
          mflops = sv.getDouble(2);
          nt = sv.getInteger(3);
          mflopsPar = sv.getDouble(4);

          mult = sv.getDouble(5);
          startupNs = sv.getLong(6);
          descr = sv.getString(7);
          vm = sv.getString(8);
          runtime = sv.getString(9);
          if(sv.size()>10)
          {
            vmArgs = sv.getString(10);
          }

      }

      public final void writeToFile(File f) throws Exception
      {
         StorageVector sv = new StorageVector();
         sv.add(1); //v

         sv.add(made);
         sv.add(mflops);
         sv.add(nt);
         sv.add(mflopsPar);

         sv.add(mult);
         sv.add(startupNs);
         sv.add(descr);
         sv.add(vm);
         sv.add(runtime);
         sv.add(vmArgs);

         FileUtils.saveVectorToFile(f, sv);
      }

      long made=-1;
      double mflops=-1;
      int nt=-1;
      double mflopsPar=-1;
      double mult=-1;
      long startupNs=-1;

      String descr = "";
      String vm;
      String runtime;
      String vmArgs = "";
   }
}