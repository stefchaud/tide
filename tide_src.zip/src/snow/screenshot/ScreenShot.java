package snow.screenshot;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.GeneralPath;
import java.awt.image.*;
import java.io.*;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.*;
import java.util.prefs.Preferences;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.imageio.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import snow.im.ImageEditor;
import snow.runtimechecks.CheckEDTViolationRepaintManager;
import snow.utils.gui.*;
import snow.utils.gui.files.FileField;
import snow.utils.storage.FileUtils;
import snow.utils.storage.PrefUtils;

/** A general purpose screenshot utility, with export to file, clipboard and film options.
*  with a list of icons (made of buttons) to allow later save (to clip, to file).
*/
public class ScreenShot implements MouseMotionListener, MouseListener
{

  // to make the screenshot
  final private Robot robot = new Robot();  // throws an exception (in the constructor !!!)

  final private JFrame mainFrame = new JFrame("ScreenShot");

  final private JDialog up;
  final private JDialog left;
  final private JDialog right;
  final private JDialog down;

  // on windows, not really useful, the button printscreen is working well.
  final private JCheckBoxMenuItem fullScreenMode = new JCheckBoxMenuItem("Ignore size, take fullscreen", false);

  final private JCheckBoxMenuItem alwaysOnTop = new JCheckBoxMenuItem("Always on top", true);
  final private JCheckBoxMenuItem transparent = new JCheckBoxMenuItem("Transparent frame", false);  //[aug2011]
  final private JCheckBoxMenuItem showMousePointer = new JCheckBoxMenuItem("Show mouse pointer", false);
  final private JCheckBoxMenuItem showFrameWithShadow = new JCheckBoxMenuItem("Show frame with shadow", false);

  final private JCheckBoxMenuItem collectShots = new JCheckBoxMenuItem("Collect all screenshots", true);

  private int x,y,w,h;
  int border = 12;

  private int clickedX = -1, clickedY = -1;
  private int clickedW = -1, clickedH = -1;

  private final JLabel titleLabel = new JLabel("ScreenShot", JLabel.CENTER);
  private final JLabel sizeLabel = new JLabel("", JLabel.RIGHT);

  private  JDialog filmDialog = null;
  final private JPanel filmParamPanel = new JPanel();
  // used in the mode "save only if changed".
  private /*@org.checkerframework.checker.nullness.qual.Nullable*/ BufferedImage previousShot = null;



  final static int[][] predefinedQuickSizes = new int[][]{
          {16, 16},  {32, 32},  {48, 48},  {64, 64},
                                       {320,200},   // CGA
                                       {640,480},   // VGA
                                       {800,600},   // SVGA
                                       {1024,768},    //XGA
                                       {1366,768}
                                       /*{1440,810},     //16/9
                                       {1600,900},    // HD Plus notebooks
                                       {1600,1200},  // UXGA
                                       {1920,1080},  // HD1080
                                       {2550,1600},   // WQXGA */
                                       };

  final static int[][] predefinedSizes = new int[][]{{16, 16}, {32, 32}, {48, 48}, {64, 64},
                                       {320, 200},   // CGA
                                       {320, 240},   // QVGA
                                       {640, 480},   // VGA
                                       {720, 480},   // EDTV 480p
                                       {720, 576},   // EDTV 576p
                                       {768, 576},   // PAL
                                       {800, 480},   // WVGA
                                       {800, 600},   // SVGA
                                       {854, 480},   // WVGA
                                       {1024, 600},  // WSVGA
                                       {1000, 618},
                                       {1024, 768},    //XGA
                                       {1152, 864},
                                       {1280, 720},   // HD720
                                       {1280,768},
                                       {1280,800},  // WXGA
                                       {1280,960},
                                       {1280,1024},   // SXGA
                                       {1366,768},     // HD notebooks
                                       {1400,1050},   //SXGA+
                                       {1440,810},     //16/9
                                       {1440,900},
                                       {1600,900},    // HD Plus notebook
                                       {1600,1024},
                                       {1600,1200},  // UXGA
                                       {1680,1050},  // WSXGA+
                                       {1776,1000},
                                       {1920,1080},  // HD1080
                                       {1920,1200},
                                       {2048,1536},   // QXGA
                                       {2550,1440},
                                       {2550,1600},   // WQXGA
                                       {2550,2048}    //QSXGA
                                      };

  static int[][] knownRatios = {
      {1,1},   // square
      {3,2},   // 720 x 480
      {5,4},   // 1280 x 1024
      {4,3},   // 800 x 600
      {8,5},   // 1280 x 800   // also 16/10
      {5,3},   // 800 x 480
      {16,9} , // 1280 x 720
      {25,16}
      //{1000,618}, // golden ratio 1.618
     }  ;

   /** For example 16/9
   */
  static String getNearRatioStringOrEmpty(double w, double h)
  {
     double r = w/h;
     if(r==1) return "";  // square

     // exact
     for(int[] rs : knownRatios)
     {
        double ri = (double) rs[0]/rs[1];
        if(Math.abs( ri-r) < 0.005) return ""+rs[0]+"/"+ rs[1];
     }

     // approx
     for(int[] rs : knownRatios)
     {
        double ri = (double) rs[0]/rs[1];
        if(Math.abs( ri-r) < 0.05) return "~"+rs[0]+"/"+ rs[1];
     }

     return "";
  }

  static void test()
  {
     for(int[] rs : knownRatios)
     {
        double ri = (double) rs[0]/rs[1];
        System.out.println(""+ri);
     }

     for(int[] si : predefinedSizes)
     {
        System.out.println(""+si[0]+" x "+si[1]+":   \t"+getNearRatioStringOrEmpty(si[0], si[1]));
     }
  }

  final boolean standalone;
  public ScreenShot() throws Exception
  {
     this(false);
  }

  public ScreenShot(final boolean standalone) throws Exception
  {
     super();

     // create the frames as undecorated ones, but remember the global setting
     //boolean rememberLFD = JDialog.isDefaultLookAndFeelDecorated();
     //JDialog.setDefaultLookAndFeelDecorated(false);
     mainFrame.setIconImage(Icons.createImage(Icons.photoIcon(23,23)));

     up    = new JDialog(mainFrame);  // Tricky !
     left  = new JDialog(mainFrame);
     right = new JDialog(mainFrame);
     down  = new JDialog(mainFrame);

     //JDialog.setDefaultLookAndFeelDecorated(rememberLFD);

     Preferences prefs = Preferences.userNodeForPackage(ScreenShot.class);
     PrefUtils.rememberState(alwaysOnTop, "ScreenShot.alwaysOnTop", prefs);
     PrefUtils.rememberState(showMousePointer, "ScreenShot.showMousePointer", prefs);
     PrefUtils.rememberState(showFrameWithShadow, "ScreenShot.showFrameWithShadow", prefs);
     PrefUtils.rememberState(collectShots, "ScreenShot.collectShots", prefs);


     /* ugly artifacts when over native (java3d) frames
     *
     GUIUtils.setWindowTransparency(up, 0.34f);
     GUIUtils.setWindowTransparency(down, 0.34f);
     GUIUtils.setWindowTransparency(left, 0.34f);
     GUIUtils.setWindowTransparency(right, 0.34f);
     */


     //CAUTION: setBackground don't work...
     up.getContentPane().setBackground(Color.magenta);
     down.getContentPane().setBackground(Color.magenta);
     left.getContentPane().setBackground(Color.magenta);
     right.getContentPane().setBackground(Color.magenta);

     mainFrame.setUndecorated(true);   // must be called early ! this allow to "hide" the frame but keep his entry as application !

     this.standalone = standalone;
     setSize(new Rectangle(100,100,400,300));

     // Drag & drop the edges: chenge position and size, depending on the part
     up.setUndecorated(true);
     up.addMouseListener(this);
     up.addMouseMotionListener(this);

     down.setUndecorated(true);
     down.addMouseListener(this);
     down.addMouseMotionListener(this);

     right.setUndecorated(true);
     right.addMouseListener(this);
     right.addMouseMotionListener(this);

     left.setUndecorated(true);
     left.addMouseListener(this);
     left.addMouseMotionListener(this);

     up.addMouseWheelListener(new MouseAdapter()
     {
        //Overrides method of MouseAdapter
        @Override public final void mouseWheelMoved( final MouseWheelEvent e ) {

              // zoom
              if(e.getWheelRotation()<0 || e.getPreciseWheelRotation()<0)
              {
                if(w<10) w+=1;
                if(h<10) h+=1;
                h*=1.1;
                w*=1.1;
              }
              else
              {
                h=h*9/10;
                w=w*9/10;
              }

              updatePositionAndSize();
        }
     });

     up.setLayout(new BorderLayout(0,0));
     up.add(titleLabel , BorderLayout.CENTER);

     JPanel shotPanel = new JPanel(new FlowLayout(FlowLayout.LEFT,4,0));
     shotPanel.setLayout(new BoxLayout(shotPanel, BoxLayout.X_AXIS));
     shotPanel.setOpaque(false);
     shotPanel.setBorder(null);
     up.add(shotPanel, BorderLayout.WEST);


     final JButton bt = createMiniButton("clip", null);
     bt.setToolTipText("right click for more powerful features");
     shotPanel.add(bt);

     bt.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent ae)
       {
          if(GUIUtils.isShiftDown(ae))
          {
             Thread t = new Thread()
             { public void run() {
                try{ Thread.sleep(3000); } catch(InterruptedException ex) { ; }
                EventQueue.invokeLater(new Runnable() { public void run() {
                      copyToClipboard();
                }});
             }};
             t.start();
          }
          else if(GUIUtils.isCtrlDown(ae))
          {
             editAction();
          }
          else
          {
             copyToClipboard();
          }
       }
     });

     // [21.12.2011]: better
     bt.setComponentPopupMenu(new JPopupMenu()
     {
        // General remark because of the popup ::
        //   delay, otherwise this popup menu is present on the picture !

        @Override public final void show( final Component invoker, final int x, final int y )
        {
           removeAll();

           JMenuItem toc = new JMenuItem("Shot to clipboard");
           add(toc);
           toc.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
              delayedCopyToClipboard(200);
           }});


           JMenuItem to3 = new JMenuItem("Shot to clipboard in 3 seconds  (Shift+click)");
           add(to3);
           to3.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
              delayedCopyToClipboard(3000);
           } });

           JMenuItem to10 = new JMenuItem("Shot to clipboard in 10 seconds");
           add(to10);
           to10.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
              delayedCopyToClipboard(10000);
           } });

           addSeparator();

           JMenuItem toce = new JMenuItem("Shot to clipboard and edit  (Ctrl+click)");
           add(toce);
           toce.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
              Thread t = new Thread()
              { public void run() {
                 try{ Thread.sleep(200); } catch(InterruptedException ex) { ; }
                 EventQueue.invokeLater(new Runnable() { public void run() {
                       editAction();
                 }});
              }};
              t.start();
           }});

           JMenuItem tos = new JMenuItem("Shot to temp galery only");
           add(tos);
           tos.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {

              Thread t = new Thread()
              { public void run() {
                 try{ Thread.sleep(200); } catch(InterruptedException ex) { ; }
                 EventQueue.invokeLater(new Runnable() { public void run() {

                    if(!collectShots.isSelected())
                    {
                       ScreenShotSet.getInstance().addImage(capture(), ScreenShot.this);
                    }
                    else
                    {
                       capture();  // already
                    }

                 }});
              }};
              t.start();

           }});

           super.show(invoker, 0, bt.getHeight());
        }

     });

     final JButton tofile = createMiniButton("file", null);
     shotPanel.add(Box.createHorizontalStrut(4));
     shotPanel.add(tofile);
     tofile.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent ae)
       {
          if(GUIUtils.isShiftDown(ae))
          {
             //new SwingWorker().
             Thread t = new Thread()
             { public void run() {
                try{ Thread.sleep(3000); } catch(InterruptedException ex) { ; }
                EventQueue.invokeLater(new Runnable() { public void run() {
                       saveToFile();
                }});
             }};
             t.start();
          }
          else
          {
             saveToFile();
          }
       }
     });

     tofile.setComponentPopupMenu(new JPopupMenu(){

        @Override public final void show( final Component invoker, final int x, final int y ) {
           removeAll();

           JMenuItem toc = new JMenuItem("Shot to file...");
           add(toc);
           toc.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {

             Thread t = new Thread()
             { public void run() {
                try{ Thread.sleep(200); } catch(InterruptedException ex) { ; }
                EventQueue.invokeLater(new Runnable() { public void run() {
                       saveToFile();
                }});
             }};
             t.start();

           }});

           JMenuItem to3 = new JMenuItem("Shot to file in 3 seconds");
           add(to3);
           to3.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {

             Thread t = new Thread()
             { public void run() {
                try{ Thread.sleep(3000); } catch(InterruptedException ex) { ; }
                EventQueue.invokeLater(new Runnable() { public void run() {
                       saveToFile();
                }});
             }};
             t.start();

           }});


           super.show(invoker, 0, tofile.getHeight());
        }

     });

     if(SystemTray.isSupported())
     {
        JButton red = createMiniButton("", Icons.sharedDownWedge);
        red.setToolTipText("Reduce in System Tray");
        shotPanel.add(Box.createHorizontalStrut(4));
        shotPanel.add(red);
        red.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent ae)
          {
             reduceAsTrayIcon();
          }
        });
     }

     down.setLayout(new BoxLayout(down.getContentPane(), BoxLayout.X_AXIS));

     JButton clBT = createMiniButton("", Icons.sharedCross);
     down.add(clBT);

     clBT.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent ae)
       {
          terminate();
       }
     });

     final JButton settings = createMiniButton("opts", null);
     down.add(Box.createHorizontalStrut(10));
     down.add(settings);

     settings.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent ae)
       {
          optionsPopup(settings);
       }
     });

     down.add(Box.createHorizontalGlue());
     down.add(sizeLabel);
     // Caution TIPP Warning BUG:  if a tooltip is set on the sizeLabel,
     // the mousemotionlistener that sets the cursor don't work anymore
     settings.setToolTipText("Tipp: press arrows, *, /, W or H to increase size by one pixel, with Shift to reduce. C to Center, Home, End, ...");

     alwaysOnTop.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent ae)
       {
         mainFrame.setAlwaysOnTop(alwaysOnTop.isSelected());
       }
     });
     mainFrame.setAlwaysOnTop(alwaysOnTop.isSelected());

     transparent.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent ae)
       {
         float t = 1f;  // opaque
         if(transparent.isSelected())
         {
            t = 0.3f;
         }
         GUIUtils.setWindowTransparency(up, t);
         GUIUtils.setWindowTransparency(down, t);
         GUIUtils.setWindowTransparency(left, t);
         GUIUtils.setWindowTransparency(right, t);
       }
     });


     mainFrame.addWindowListener(new WindowListener()
     {
        public void windowClosed(WindowEvent we) { terminate(); }
        public void windowClosing(WindowEvent we) { terminate(); }
        public void windowDeactivated(WindowEvent we) {  }
        public void windowActivated(WindowEvent we) {  }
        public void windowDeiconified(WindowEvent we) {  }
        public void windowIconified(WindowEvent we) {  }
        public void windowOpened(WindowEvent we) {  }
     });

     installControlWithKeyboard();

     up.setVisible(true);
     down.setVisible(true);

     left.setVisible(true);
     right.setVisible(true);

     mainFrame.setSize(0,0);
     //mainFrame.setDefaultLookAndFeelDecorated(true);
     //mainFrame.setState(JFrame.ICONIFIED);

     mainFrame.setMaximumSize(new Dimension(0,0));
     mainFrame.setVisible(true);

     up.toFront();

  } // Constructor


  public void delayedCopyToClipboard(final long delayMS)
  {
       Thread t = new Thread()
       { public void run() {
          try{ Thread.sleep(delayMS); } catch(InterruptedException ex) { ; }
          EventQueue.invokeLater(new Runnable() { public void run() {
                copyToClipboard();
          }});
       }};
       t.start();
  }

  /** map arrow keys and W and H
  *    Shift pressed: arrow boost and W H inversion.
  *   Page Up/down, ... * / C
  *
  *  N: nearest *round ratio*
  *  F: quick shot to file (increment file name)
  */
  void installControlWithKeyboard()
  {

     // CAUTION keylistener don't work on the up and down parts. (if works on the vertical bars however)
     //  registering always work...

      registerActionWithShift(KeyEvent.VK_F,  new ActionListener(){
        public void actionPerformed(ActionEvent ae){

              // use the last file and increment the name if any
              System.out.println("Quick save to file action !");

              String autoIncFileName = null;
              try{
                 String prev = Preferences.userRoot().get("ScreenShot_lastFile", "");
                 //System.out.println("def="+def);
                 if(prev!=null)
                 {
                    File prevFile = new File(prev);
                    String nn = incrementFileNameIfNumberFound(prevFile.getName());
                    if(nn!=null)
                    {
                       autoIncFileName = new File(prevFile.getParentFile(), nn).getAbsolutePath();
                    }
                 }
              }
              catch(final Exception e) {
              }

              if(autoIncFileName==null)
              {
                 saveToFile();
              }
              else
              {
                 // auto mode
                 System.out.println("Auto file name : "+autoIncFileName);

                 try{
                    String format = FileUtils.getExtension(autoIncFileName);

       ImageIO.write( capture(), format, new File(autoIncFileName));
       //System.out.println("image saved to "+file);

                    // remember
                    Preferences.userRoot().put("ScreenShot_lastFile", autoIncFileName);
                 }
                 catch(final Exception e) {
                    e.printStackTrace();

                    // manual mode
                    saveToFile();
                 }
              }

      }});

      registerActionWithShift(KeyEvent.VK_N,  new ActionListener(){
         public void actionPerformed(ActionEvent ae){
              resizeToNearestRoundRatio();
      }});

// ESC to terminate, C to center, 0 =home
      registerActionWithShift(KeyEvent.VK_ESCAPE,  new ActionListener(){
         public void actionPerformed(ActionEvent ae){
              terminate();
      }});

      registerActionWithShift(KeyEvent.VK_C,  new ActionListener(){
        public void actionPerformed(ActionEvent ae){
              x = Toolkit.getDefaultToolkit().getScreenSize().width/2 - w/2;
              y  = Toolkit.getDefaultToolkit().getScreenSize().height/2 - h/2;
              updatePositionAndSize();
      }});

      registerActionWithShift(KeyEvent.VK_0,  new ActionListener(){
        public void actionPerformed(ActionEvent ae){
              x = 0; y=0;
              updatePositionAndSize();
      }});

      registerActionWithShift(KeyEvent.VK_NUMPAD0,  new ActionListener(){
        public void actionPerformed(ActionEvent ae){
              x = 0; y=0;
              updatePositionAndSize();
      }});

// arrows for position
      registerActionWithShift(KeyEvent.VK_LEFT,  new ActionListener(){
         public void actionPerformed(ActionEvent ae){
              x -= GUIUtils.isShiftDown(ae) ? 20 : 1;
              updatePositionAndSize();
      }});
      registerActionWithShift(KeyEvent.VK_RIGHT,  new ActionListener(){
         public void actionPerformed(ActionEvent ae){
              x += GUIUtils.isShiftDown(ae) ? 20 : 1;
              updatePositionAndSize();
      }});

      registerActionWithShift(KeyEvent.VK_UP,  new ActionListener(){
         public void actionPerformed(ActionEvent ae){
              y -= GUIUtils.isShiftDown(ae) ? 20 : 1;
              updatePositionAndSize();
      }});
      registerActionWithShift(KeyEvent.VK_DOWN,  new ActionListener(){
         public void actionPerformed(ActionEvent ae){
              y += GUIUtils.isShiftDown(ae) ? 20 : 1;
              updatePositionAndSize();
      }});

// w and h for size
      registerActionWithShift(KeyEvent.VK_W,  new ActionListener(){
        public void actionPerformed(ActionEvent ae){
              w+=GUIUtils.isShiftDown(ae) ? -1 : 1;
              updatePositionAndSize();
      }});
      registerActionWithShift(KeyEvent.VK_H,  new ActionListener(){
        public void actionPerformed(ActionEvent ae){
              h+=GUIUtils.isShiftDown(ae) ? -1 : 1;
              updatePositionAndSize();
      }});

// page up, down, ins and home to place at screen boundary
      registerActionWithShift(KeyEvent.VK_HOME,  new ActionListener(){
        public void actionPerformed(ActionEvent ae){
              x = 0;
              updatePositionAndSize();
      }});
      registerActionWithShift(KeyEvent.VK_END,  new ActionListener(){
        public void actionPerformed(ActionEvent ae){
              x = Toolkit.getDefaultToolkit().getScreenSize().width - w;
              updatePositionAndSize();
      }});

      registerActionWithShift(KeyEvent.VK_PAGE_UP,  new ActionListener(){
        public void actionPerformed(ActionEvent ae){
              y=0;
              updatePositionAndSize();
      }});
      registerActionWithShift(KeyEvent.VK_PAGE_DOWN,  new ActionListener(){
        public void actionPerformed(ActionEvent ae){
              y = Toolkit.getDefaultToolkit().getScreenSize().height - h;
              updatePositionAndSize();
      }});


// * and / for size
      registerActionWithShift(KeyEvent.VK_MULTIPLY,  new ActionListener(){
        public void actionPerformed(ActionEvent ae){
              if(w<10) w+=1;
              if(h<10) h+=1;
              h*=1.1;
              w*=1.1;
              updatePositionAndSize();
      }});
      registerActionWithShift(KeyEvent.VK_DIVIDE,  new ActionListener(){
        public void actionPerformed(ActionEvent ae){
              h=h*9/10;
              w=w*9/10;
              updatePositionAndSize();
      }});

      // to cLip
      registerActionWithShift(KeyEvent.VK_L,  new ActionListener(){
        public void actionPerformed(ActionEvent ae){
              capture();
      }});

  }


  /** Register the action to the key and key + shift keyboard to the 4 frames
  */
  private void registerActionWithShift(int keyEvent_code, ActionListener ali )
  {
       ((JComponent)up.getContentPane()).registerKeyboardAction(ali, "nomatter", KeyStroke.getKeyStroke(keyEvent_code, 0, false), JComponent.WHEN_IN_FOCUSED_WINDOW);
       ((JComponent)up.getContentPane()).registerKeyboardAction(ali, "nomatter", KeyStroke.getKeyStroke(keyEvent_code, KeyEvent.SHIFT_DOWN_MASK, false), JComponent.WHEN_IN_FOCUSED_WINDOW);

       ((JComponent)down.getContentPane()).registerKeyboardAction(ali, "nomatter", KeyStroke.getKeyStroke(keyEvent_code, 0, false), JComponent.WHEN_IN_FOCUSED_WINDOW);
       ((JComponent)down.getContentPane()).registerKeyboardAction(ali, "nomatter", KeyStroke.getKeyStroke(keyEvent_code, KeyEvent.SHIFT_DOWN_MASK, false), JComponent.WHEN_IN_FOCUSED_WINDOW);

       ((JComponent)left.getContentPane()).registerKeyboardAction(ali, "nomatter", KeyStroke.getKeyStroke(keyEvent_code, 0, false), JComponent.WHEN_IN_FOCUSED_WINDOW);
       ((JComponent)left.getContentPane()).registerKeyboardAction(ali, "nomatter", KeyStroke.getKeyStroke(keyEvent_code, KeyEvent.SHIFT_DOWN_MASK, false), JComponent.WHEN_IN_FOCUSED_WINDOW);

       ((JComponent)right.getContentPane()).registerKeyboardAction(ali, "nomatter", KeyStroke.getKeyStroke(keyEvent_code, 0, false), JComponent.WHEN_IN_FOCUSED_WINDOW);
       ((JComponent)right.getContentPane()).registerKeyboardAction(ali, "nomatter", KeyStroke.getKeyStroke(keyEvent_code, KeyEvent.SHIFT_DOWN_MASK, false), JComponent.WHEN_IN_FOCUSED_WINDOW);
  }


  // due to a bug...
  final private Font miniSansSerifFont = new Font(Font.SANS_SERIF, Font.PLAIN, 9);  // very small !

  private JButton createMiniButton(String name, /*@org.checkerframework.checker.nullness.qual.Nullable*/ Icon ic)
  {
     JButton bt = ic !=null ? new JButton(name, ic): new JButton(name);

     bt.setBackground(Color.orange);
     bt.putClientProperty("JComponent.sizeVariant", "mini");
     bt.setFont(miniSansSerifFont);

     //System.out.println(""+bt.getBorder());

     if(GUIUtils.isNimbusLF())
     {
        // how remove the ugly round paint ???????????????

        // forget the original synth border, far too wide !
        bt.setBorder(null);
        //bt.setBorder(BorderFactory.createCompoundBorder(new LineBorder(Color.black, 1), new EmptyBorder(0,2,0,2)));
        bt.setMargin(new Insets(2,0,2,0));
        bt.setOpaque(false);  // don't work
     }
     else
     {
        bt.setBorder(null);
        bt.setMargin(new Insets(0,0,0,0));
     }

     return bt;
  }

  public void terminate()
  {
    if(standalone)
    {
      System.exit(0);
    }
    else
    {
      mainFrame.setVisible(false);
    }
  }

  private TrayIcon tic = null;


  public void reduceAsTrayIcon()
  {
     if(!SystemTray.isSupported()) return;

     try
     {
        if(tic == null)
        {
          int w = SystemTray.getSystemTray().getTrayIconSize().width;
          tic = new TrayIcon(Icons.createImage(Icons.photoIcon(w,w)), "ScreenShot Tool");
        }

        SystemTray.getSystemTray().add(tic);
        tic.addMouseListener(new MouseAdapter()
        {
           @Override public final void mouseClicked( final MouseEvent e )
           {
              restoreFromTray();
           }
        });

        mainFrame.setVisible(false);
     }
     catch(Exception e) {
        e.printStackTrace();
     }
  }

  boolean isVisible()
  {
     return mainFrame.isVisible();
  }

  void restoreFromTray()
  {
       mainFrame.setVisible(true);
       if(tic!=null)
       {
          try
          {
            SystemTray.getSystemTray().remove(tic);
          }
          catch(final Exception e) {
             e.printStackTrace();
          }
       }
  }

  public void mouseDragged(MouseEvent me)
  {
     JDialog src = (JDialog) me.getSource();
     if(src==up || src==left)
     {
       int dx = me.getX()-clickedX;
       int dy = me.getY()-clickedY;

       x+=dx;
       y+=dy;

       updatePositionAndSize();
     }
     else if(src==down)
     {
       int dx = me.getX()-clickedX;
       int dy = me.getY()-clickedY;

       w = clickedW +dx;
       h+=dy;

       if(h<0)
       {
          y = y+h;
          h = -h;
       }

       updatePositionAndSize();
     }
     else if(src==right)
     {
       int dx = me.getX()-clickedX;
       int dy = me.getY()-clickedY;

       w+=dx;
       h = clickedH +dy;

       if(w<0)
       {
          x = x+w;
          w = -w;
       }

       updatePositionAndSize();
     }
  }

  public void mouseMoved(MouseEvent me)
  {
  }

  public void mousePressed(MouseEvent me)
  {
    clickedX = me.getX();
    clickedY = me.getY();
    clickedW = w;
    clickedH = h;
  }
  public void mouseReleased(MouseEvent me) {}
  public void mouseClicked(MouseEvent me) {}
  public void mouseExited(MouseEvent me)
  {
    JDialog src = (JDialog) me.getSource();
    src.setBackground(Color.gray);
    src.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
  }

  public void mouseEntered(MouseEvent me)
  {
    JDialog src = (JDialog) me.getSource();
    //src.setBackground(Color.red);
    if(src==up || src==left)
    {
      src.setCursor(new Cursor(Cursor.MOVE_CURSOR));
    }
    else if(src==right)
    {
      src.setCursor(new Cursor(Cursor.SE_RESIZE_CURSOR));
    }
    else if(src==down)
    {
      src.setCursor(new Cursor(Cursor.SE_RESIZE_CURSOR));
    }
  }


  public void setSize(Rectangle rect)
  {
    x = (int) rect.getX();
    y = (int) rect.getY();

    w = rect.width;
    h = rect.height;

    updatePositionAndSize();

    // restore from tray
    restoreFromTray();
  }

  public Rectangle getActualScreenshotPositionAnSize()
  {
     Rectangle r = new Rectangle();
     r.setSize(w, h);
     r.setLocation(x, y);
     return r;
  }

  private void updatePositionAndSize()
  {
    String sl = getNearRatioStringOrEmpty(w, h);
    if(!sl.isEmpty()) sl = "   ("+sl+")";
    sizeLabel.setText(""+w+" x "+h+""+sl);

    up.setLocation(x-border/4,y-border);
    left.setLocation(x-border/4,y);

    right.setLocation(x+w,y);
    down.setLocation(x-border/4,y+h);

    up.setSize(w+2*border/4,border);
    down.setSize(w+2*border/4,border);

    right.setSize(border/4,h);
    left.setSize(border/4,h);

  }


  void resizeToNearestRoundRatio()
  {
     double r = 1.0*w/h;
     if(r>1)
     {
        double nr = nearestRatio(r);
        w = (int)(nr * h);
     }
     else
     {
        double nr = nearestRatio(1.0/r);
        w = (int)(nr * h);
     }

     updatePositionAndSize();
  }


  static double nearestRatio(double r)
  {
        double nearestRatio = 1.6;
        double nearestDiff = Math.abs(r-nearestRatio);

        for( final int[] ric : knownRatios)
        {
           double ri = (double) ric[0]/ric[1];
           double diff = Math.abs(ri-r);
           if(diff<0.001)
           {
              return ri;
           }

           if(diff<nearestDiff)
           {
              nearestDiff = diff;
              nearestRatio = ri;
           }
        }

        return  nearestRatio;
  }


  /** null if no number found.
  *
  *  "Hello_0001" => 0001
  */
  static /*@org.checkerframework.checker.nullness.qual.Nullable*/ String incrementFileNameIfNumberFound(String s)
  {
     // search for the "last" one
     Matcher m  = Pattern.compile("\\d+").matcher(s);
     String lastGp = null;
     int lastStart = -1;
     while( m.find() )
     {
        //System.out.println("gp="+m.group());
        lastStart = m.start();
        lastGp = m.group();
     }

     if(lastStart<0) return null;
     if(lastGp==null) return null;

     // ok we have one
     //System.out.println("Incrementing "+lastGp);

     long nb = Long.parseLong(lastGp)+1;
     // PAD
     String snb = ""+nb;
     while(snb.length()<lastGp.length())
     {
        snb= "0"+snb;
     }

     String nn = s.substring(0,lastStart) + snb + s.substring(lastStart+lastGp.length());

     return nn;
  }

  // As Standalone App
  public static void main(String[] aa)
  {
    CheckEDTViolationRepaintManager.installRuntimeChecker();
    //GUIUtils.setNimbusLookAndFeel_IfPossible();

    EventQueue.invokeLater(new Runnable() { public void run() {
          safeEDTMain();
    }});
  }

  static void safeEDTMain()
  {

    //JFrame.setDefaultLookAndFeelDecorated(true);
    //JDialog.setDefaultLookAndFeelDecorated(true);

    try
    {
      ScreenShot sc = new ScreenShot(true);
    } catch(Exception e) { e.printStackTrace(); }

  }

  private   GeneralPath cursor = null;

  /** Captures and decorates (pointer and/or frame).
  */
  public BufferedImage captureWithDecorations()
  {
       BufferedImage cap = captureWithoutPointer();

       if(this.showMousePointer.isSelected())
       {

          final PointerInfo pointerInfo = MouseInfo.getPointerInfo();
          //System.out.println(""+ pointerInfo.getLocation());

          int xs = 0;
          int ys = 0;
          if(!fullScreenMode.isSelected())
          {
             xs = x;
             ys = y;
          }

          Point loc = pointerInfo.getLocation();
          int xIm = loc.x - xs;
          int yIm = loc.y - ys;

          if(xIm>=0 && yIm>=0 && xIm<= w && yIm<=h)  //todo: use mouse dim !
          {
             //new PointerInfo()
             if(cursor==null)
             {
               this.cursor = new GeneralPath( GeneralPath.WIND_EVEN_ODD );
               cursor.moveTo(0,0);
               cursor.lineTo(0.6,0.266);
               cursor.lineTo(0.53,0.066);
               cursor.lineTo(1,0.066);
               cursor.lineTo(1,-0.066);
               cursor.lineTo(0.53,-0.06);
               cursor.lineTo(0.6,-0.266);
               this.cursor.closePath();

               cursor.transform(AffineTransform.getScaleInstance(24, 24));
               cursor.transform(AffineTransform.getRotateInstance(1.12));
             }

             final Graphics2D gr = cap.createGraphics();
             gr.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
             gr.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

             gr.translate(xIm, yIm);

             gr.setPaint(Color.white);
             gr.fill(cursor);
             gr.setPaint(Color.black);
             gr.draw(cursor);

             gr.dispose();
          }
       }

       if(this.showFrameWithShadow.isSelected())
       {
          return addFrame(cap, 1, 8);
       }

       return cap;

  }

  public static BufferedImage addFrame(BufferedImage im0, int frameThickness, int shadowSize)
  {
     final BufferedImage ret = new BufferedImage(im0.getWidth()+frameThickness*2+shadowSize, im0.getHeight()+frameThickness*2+shadowSize, im0.getType());
     final Graphics2D gr = ret.createGraphics();
     //gr.setColor(Color.white);
     gr.fillRect(0,0,ret.getWidth(), ret.getHeight()); // white back ?  => should be transparent
     gr.drawImage(im0, frameThickness, frameThickness, null);

     if(shadowSize>0)
     {
       gr.setColor(Color.lightGray);
       gr.setStroke(new BasicStroke(shadowSize));
       //gr.drawRect(0,0,im0.getWidth()+frameThickness, im0.getHeight()+frameThickness);
       int h = im0.getHeight()+2*frameThickness+shadowSize/2;
       gr.drawLine(shadowSize*2, h, im0.getWidth()+shadowSize, h);
       int w = im0.getWidth()+2*frameThickness+shadowSize/2;
       gr.drawLine(w, shadowSize*2, w, h+shadowSize);
     }

     if(frameThickness>0)
     {
       gr.setColor(Color.black);
       gr.setStroke(new BasicStroke(frameThickness));
       gr.drawRect(0,0,im0.getWidth()+frameThickness, im0.getHeight()+frameThickness);
     }

     gr.dispose();
     return ret;
  }

  private BufferedImage capture()
  {
     System.out.println("Performing screenshot");

     EventQueue.invokeLater(new Runnable() { public void run() {
           up.getContentPane().setBackground(Color.red);
           new Thread() { public void run() {
              try{ Thread.sleep(500); } catch(InterruptedException ex) { ; }
              EventQueue.invokeLater(new Runnable() { public void run() {
                  up.getContentPane().setBackground(Color.magenta);
              }});
           }}.start();
     }});

     final BufferedImage cap;

     if(showMousePointer.isSelected() || showFrameWithShadow.isSelected())
     {
        cap = captureWithDecorations();
     }
     else
     {
        cap = captureWithoutPointer();
     }

     if(collectShots.isSelected())
     {
        ScreenShotSet.getInstance().addImage(cap, this);
     }

     return cap;
  }

  /** All screen captures are done here.
  */
  private BufferedImage captureWithoutPointer()
  {
     final BufferedImage bim;

     // [jan2015] macOSX makes too much shadowing
     try
     {
       mainFrame.setVisible(false);

       if(fullScreenMode.isSelected())
       {
          Dimension ss = Toolkit.getDefaultToolkit().getScreenSize();
          bim = robot.createScreenCapture(new Rectangle(0, 0, ss.width, ss.height));
       }
       else
       {
          bim = robot.createScreenCapture(new Rectangle(x,y,w,h));
       }
     }
     finally
     {
       mainFrame.setVisible(true);
     }
     return bim;
  }


  private void copyToClipboard()
  {
      ImageUtils.copyToClipboard( this.capture() );
  }


  private void saveToFile()
  {
    final BufferedImage bim = this.capture();
    EventQueue.invokeLater(new Runnable() { public void run() {
        saveImage(bim, up, null);
    }});
  }

  @SuppressWarnings ("nullness")
  private void editAction()
  {
     BufferedImage bim = this.capture();
     try
     {
       new ImageEditor(bim, null, "Screenshot edit");
     }
     catch(Exception e) {
       JOptionPane.showMessageDialog(null, "Can't edit image:\n\nerror = "+e.getMessage(),
            "Error", JOptionPane.ERROR_MESSAGE);
       e.printStackTrace();
     }
  }


  volatile boolean doPause = false;
  volatile long frameNumber = 1;

  public void filmAction()
  {
     if(filmDialog!=null)
     {
       filmParamPanel.setVisible(true);
       filmDialog.pack();
       filmDialog.setVisible(true);

       return;
     }
     filmDialog = new JDialog(up, "Film", false);
     filmDialog.setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
     //CloseControlPanel ccp = new CloseControlPanel(d, true, true, "Start");
     //d.add(ccp, BorderLayout.SOUTH);
     //ccp.getOkButton().setIcon(Icons.StartIcon.shared10);
     final JLabel status = new JLabel("");
     JPanel cp = new JPanel();
     cp.setAlignmentX(1f);
     cp.setBorder(new EmptyBorder(1,1,1,1));
     cp.setLayout(new BoxLayout(cp, BoxLayout.X_AXIS));
     filmDialog.add(cp, BorderLayout.SOUTH);
     final JButton stop = new JButton(new Icons.StopIcon(10,10,true));
     cp.add(status);
     cp.add(Box.createHorizontalGlue());
     cp.add(stop);
     cp.add(Box.createHorizontalStrut(1));
     final JButton pause = new JButton(new Icons.PauseIcon(10,10,true));
     pause.setDisabledIcon(new Icons.PauseIcon(10,10,false));
     cp.add(pause);
     cp.add(Box.createHorizontalStrut(1));
     final JButton start = new JButton(Icons.sharedSmallStart);
     cp.add(start);
     cp.add(Box.createHorizontalStrut(1));

     stop.setMargin(new Insets(1,1,1,1));
     pause.setMargin(new Insets(1,1,1,1));
     start.setMargin(new Insets(1,1,1,1));


     GridLayout3 gl3 = new GridLayout3(2, filmParamPanel);
     filmDialog.add(filmParamPanel, BorderLayout.CENTER);

     String def = "";
     try
     {
       def = Preferences.userRoot().get("FilmSaveDest", System.getProperty("user.home",""));
     } catch(Exception e) {}

     final FileField ff = new FileField(def, true, "Choose the film destination", JFileChooser.DIRECTORIES_ONLY);

     final JTextPane ta = gl3.addExplanationArea("An utility to automatically take screenshots at regular intervals.\n");

     gl3.add("Storage folder");
     gl3.add(ff, true);
     final JTextField nameTF = new JTextField("screen_film_####", 12);
     gl3.add("File name template");
     gl3.add(nameTF);

     gl3.add("Start number");
     final JTextField startNB = new JTextField("1", 4);
     gl3.add(startNB);

     final JComboBox formatCB = new JComboBox( ImageUtils.getAvailableImageWriterFormatNames() );
     try
     {
       formatCB.setSelectedItem( Preferences.userRoot().get("FilmImgFormat", "png") );
     }catch(Exception e) { }
     gl3.add("Format");
     gl3.add(formatCB);

     gl3.add("Speed [FPS]");
     final JTextField fpsTF = new JTextField("0.5", 4);
     gl3.add(fpsTF);

     // A very cool feature, not ?
     final JCheckBox onlyIfChangedCB = new JCheckBox("Save only if image changed", false);
     gl3.add("");
     gl3.add(onlyIfChangedCB);

     // TODO: option: max duration [ min, hour, day, week, month, year ]

     filmDialog.setLocation(up.getLocationOnScreen());
     filmDialog.pack();
     filmDialog.setVisible(true);  // NOT modal.

     pause.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
        doPause = !doPause;
        if(doPause) status.setText("paused.");
     } });

     stop.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
        if(filmTimer!=null)
        {
          filmTimer.cancel();
          filmTimer = null;
        }
        status.setText("stopped.");
        pause.setEnabled(false);
        start.setEnabled(true);
        stop.setEnabled(false);
     } });

     start.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae)
     {
        final File base = ff.getPath();

        if(base==null) return;
        doPause = false;
        pause.setEnabled(true);
        start.setEnabled(false);
        stop.setEnabled(true);

        filmParamPanel.setVisible(false);
        status.setText("starting film ...");
        filmDialog.pack();

        double fps = 1;
        long periodMillis = 1000;
        try
        {  fps = Double.parseDouble(fpsTF.getText().trim());
           periodMillis = (long) (1000/fps);
           if(periodMillis<20) periodMillis = 20;  // 50 per sec!
        } catch(Exception e) {}

        try
        {
           frameNumber = Long.parseLong(startNB.getText().trim());
        }
        catch(Exception e) {}

        final String form = ""+formatCB.getSelectedItem();
        try{
           Preferences.userRoot().put("FilmSaveDest", base.getAbsolutePath());
           Preferences.userRoot().put("FilmImgFormat", form);
        }
        catch(Exception e) {
           e.printStackTrace();
        }


        //
        final NumberFormat nf = new DecimalFormat("000000");
        filmTimer = new java.util.Timer();
        filmTimer.scheduleAtFixedRate(new TimerTask()
        {
           public void run()
           {
              if(doPause) return;

              try
              {
                 String relname = nameTF.getText();
                 relname = relname.replace("####", nf.format(frameNumber)+"."+form);
                 File dest = new File(base, relname);
                 //ta.setText("Writing "+dest);
                 status.setText("frame "+frameNumber); //

                 BufferedImage bim = capture();

                 if(onlyIfChangedCB.isSelected())
                 {
                    if(previousShot!=null)
                    {
                       if(ImageUtils.imageEquals(bim, previousShot)) return;
                    }

                    previousShot = bim;
                 }

                 File pf = dest.getParentFile();
                 if(pf!=null && !pf.exists())
                 {
                    pf.mkdirs();
                 }

                 ImageIO.write( bim, form, dest);

                 frameNumber++;
              }
              catch(Exception e)
              {
                 if(filmTimer!=null)
                 {
                   filmTimer.cancel();
                   filmTimer = null;
                 }

                 JOptionPane.showMessageDialog(null, "Film error: "+e.getMessage(), "Film error", JOptionPane.ERROR_MESSAGE);
                 e.printStackTrace();
              }
           }
        }, 0, periodMillis);

     } });

     pause.setEnabled(false);
     start.setEnabled(true);
     stop.setEnabled(false);


  }

  private java.util. /*@org.checkerframework.checker.nullness.qual.Nullable*/ Timer filmTimer = null;

  private void optionsPopup(Component comp)
  {
     JPopupMenu pop = new JPopupMenu();

     JMenuItem sizeInfo = new JMenuItem(""+w+" x "+h);
     sizeInfo.setToolTipText("TIPP: press w or h to slightly change the size");
     pop.add(sizeInfo);
     pop.addSeparator();

     pop.add(alwaysOnTop);
     pop.add(transparent);
     pop.add(showMousePointer);
     pop.add(showFrameWithShadow);
     pop.addSeparator();

     pop.add(collectShots);
     pop.addSeparator();

     JMenuItem fa = new JMenuItem("Make a film...");
     pop.add(fa);
     fa.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent ae)
       {
          filmAction();
       }
     });

     pop.addSeparator();

     for(final int[] si : predefinedQuickSizes)
     {
        StringBuilder nn = new StringBuilder("    "+si[0]+" x "+si[1]);
        if(si[0]!=si[1])
        {
           nn.append( "        ("+ getNearRatioStringOrEmpty(si[0], si[1])+")" );
        }

        JMenuItem mi = new JMenuItem(nn.toString()  );
        pop.add(mi);
        mi.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
           if(GUIUtils.isShiftDown(ae))
           {
              // portrait
              setSize(new Rectangle(x,y,si[1],si[0]));
           }
           else
           {
              setSize(new Rectangle(x,y,si[0],si[1]));
           }
        } });
     }

     pop.addSeparator();

     JMenu moreSizes = new JMenu("More sizes");
     pop.add(moreSizes);
     for(final int[] si : predefinedSizes)
     {
        JMenuItem mi = new JMenuItem("    "+si[0]+" x "+si[1]  +"        ("+ getNearRatioStringOrEmpty(si[0], si[1])+")");
        moreSizes.add(mi);
        mi.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
           if(GUIUtils.isShiftDown(ae))
           {
              // portrait
              setSize(new Rectangle(x,y,si[1],si[0]));
           }
           else
           {
              setSize(new Rectangle(x,y,si[0],si[1]));
           }
        } });
     }

     pop.addSeparator();

     pop.add(fullScreenMode);

     pop.show(comp, 0,10);
  }

  /** Asks using the default folder
  */
  static void saveImage(BufferedImage im, Component parent, final /*@org.checkerframework.checker.nullness.qual.Nullable*/ File defaultPath)
  {
     String def = "";
     String imageType = "png";
     if(defaultPath!=null)
     {
        def = defaultPath.getAbsolutePath();
     }
     else
     {
        try
        {
          def = Preferences.userRoot().get("ImageSaveDest", System.getProperty("user.home",""));
          imageType = Preferences.userRoot().get("ImageSave_format", imageType);
        }
        catch(Exception e) {}
     }

     if(im==null)
     {
       JOptionPane.showMessageDialog(
             parent, "Unable to save image, image is null", "Error",
             JOptionPane.ERROR_MESSAGE);
       return;
     }

     JFileChooser fs = new JFileChooser(def);
     ImageUtils.SaveDialogAccessoryPanel sda = new ImageUtils.SaveDialogAccessoryPanel(fs, im, imageType);

     // modal
     int rep = fs.showSaveDialog(parent);

     if(rep!=JFileChooser.APPROVE_OPTION) return;  // CANCELLED

     File file = fs.getSelectedFile();
     String format = sda.getSelectedFormat();
     if(!file.getName().toLowerCase().endsWith("."+format.toLowerCase()))
     {
       file = new File(file.getAbsolutePath()+"."+format);
     }

     try
     {
       ImageIO.write( im, format, file);
       System.out.println("image saved to "+file);

       try
       {
          Preferences.userRoot().put("ScreenShot_lastFile", file.getAbsolutePath());
          Preferences.userRoot().put("ImageSave_format", format);

          if(file.getParent()!=null)  // found by the checker
          {
            Preferences.userRoot().put("ImageSaveDest", file.getParent());
          }
       } catch(Exception e2) {}

     }
     catch(Exception e)
     {
       e.printStackTrace();

       JOptionPane.showMessageDialog(
           parent, "Unable to save image in "+file+"\nError : "+e.getMessage(), "Error",
           JOptionPane.ERROR_MESSAGE);
     }

  }



}