package snow.screenshot;

import java.awt.Rectangle;
import snow.utils.gui.JGridPanel;
import snow.utils.storage.PrefUtils;
import java.util.prefs.Preferences;
import snow.utils.gui.files.FileField;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import javax.imageio.ImageIO;
import javax.imageio.stream.FileImageOutputStream;
import javax.imageio.stream.ImageOutputStream;
import javax.swing.*;
import snow.datatransfer.ClipboardUtils;
import snow.files.JFileChooser2;
import snow.im.GifSequenceWriter;
import snow.im.ImageEditor;
import snow.runtimechecks.CheckEDTViolationRepaintManager;
import snow.utils.DateUtils;
import snow.utils.gui.Icons;

/** An utility to manage a set of screenshots.
*
*/
public final class ScreenShotSet extends JFrame
{
   //todo: Causes fatal errors on close !!!
   //todo: rename to image sequence

   // singleton, thread safe & init on demand (JavaOne2009)
   //

   private static class SingletonHolder {
      private static final ScreenShotSet instance = new ScreenShotSet();
   }

   public static ScreenShotSet getInstance() {
      return SingletonHolder.instance;
   }


   boolean isActive = true;

   private final JPanel imagesPanel = new JPanel();

   private JButton opts = new JButton("opts...");

   private final List<ImageButton> images = new ArrayList<ImageButton>();

   static class ImageButton
   {
      final private JButton bt;
      final private BufferedImage bim;
      final private ScreenShot ref;

      ImageButton(JButton bt, BufferedImage bim, ScreenShot ref)
      {
         this.bt = bt;
         this.bim = bim;
         this.ref = ref;
      }
   }

   private ScreenShotSet()
   {
      super("Screenshots");

      this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);

      int defaultW = 150;

      setSize(defaultW, 500);


      imagesPanel.setLayout(new BoxLayout(imagesPanel, BoxLayout.Y_AXIS));
      add(new JScrollPane(imagesPanel), BorderLayout.CENTER);

      add(opts, BorderLayout.SOUTH);
      defineGlobalActions();

      // dock right on screen
      setLocation( Toolkit.getDefaultToolkit().getScreenSize().width-defaultW-40, 50);

      setVisible(true);
   }


   /** Called from the screenshot tool
   */
   public void addImage(final BufferedImage bim, final ScreenShot ss)
   {
      final Rectangle rect = ss.getActualScreenshotPositionAnSize();

      EventQueue.invokeLater(new Runnable() { public void run()
      {

          int w = bim.getWidth();
          int h = bim.getHeight();

          final int wAvailable = getWidth()-50;

          final ImageIcon imi;
          if(w>wAvailable)
          {
             double fact = (double) w / wAvailable;
             imi = new ImageIcon(bim.getScaledInstance((int)(w/fact), (int)(h/fact), BufferedImage.SCALE_FAST));
          }
          else
          {
             imi = new ImageIcon(bim);
          }

          final JButton imageButton = new JButton(imi);
          imagesPanel.add(imageButton);

          imagesPanel.updateUI();  // NEEDED

          definePopup(imageButton, bim, ss, rect);

          if(!isVisible())
          {
             setVisible(true);
          }

          images.add( new ImageButton( imageButton, bim, ss ));
      }});

   }


   void createAnimatedGif_dialog()
   {

         //Preferences prefs = Preferences.userNodeForPackage(ScreenShotSet.class);
         String pa = PrefUtils.getStringFromGlobalPref("LastGifSaveFolder", new File(System.getProperty("user.home"), "dest.gif").getAbsolutePath());

         FileField ff = new FileField(pa, true, "specify a gif to store to", JFileChooser.FILES_ONLY);

         JGridPanel gp = new JGridPanel(2);

         gp.addExplanationArea("An animated gof will be produced from all pictures");

         gp.addG("Dest");
         gp.addG(ff);

         JTextField tfp = new JTextField(PrefUtils.getStringFromGlobalPref("LastGif_delay","200"), 8);
         gp.addG("Delay");
         gp.addG(tfp);

         JCheckBox loop = new JCheckBox("loop infinitely", false);

         gp.addG("");
         gp.addG(loop);

         if(!gp.showInDialogOkCancel(null, "Animated gif", "Create & save")) return;

         if(!ff.isPathValid())
         {
            System.out.println("path not valid "+ff);
            return;
         }

         int delay = Integer.parseInt(tfp.getText());
         if(delay<=0)
         {
           return;
         }

         PrefUtils.putStringInGlobalPref("LastGif_delay", ""+delay);

         PrefUtils.putStringInGlobalPref("LastGifSaveFolder", ff.getPathName());
         //ff.rememberPathForGlobalCompletion();


         //GIF Creation

         try
         {
            // grab the output image type from the first image in the sequence
            BufferedImage firstImage = images.get(0).bim;
            ImageOutputStream output = new FileImageOutputStream( ff.getPath() );

            // create a gif sequence with the type of the first image, 1 second
            // between frames, which loops continuously
            GifSequenceWriter writer = new GifSequenceWriter(output, firstImage.getType(), delay, loop.isSelected());

            // write out the first image to our sequence...
            writer.writeToSequence(firstImage);
            for(int i=1; i<images.size(); i++)
            {
               BufferedImage nextImage = images.get(i).bim;
               writer.writeToSequence(nextImage);
            }

            writer.close();
            output.close();

         }catch(final Exception e) {
            e.printStackTrace();
         }
   }


   /** save to zip and gif
   */
   void defineGlobalActions()
   {
      opts.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae)
      {
           JPopupMenu pop = new JPopupMenu();


           JMenuItem agi = new JMenuItem("Create an animated gif...");
           agi.setToolTipText(""+images.size()+" images");
           if(images.size()>0)
           {
             pop.add(agi);
           }
           agi.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae)
           {
              createAnimatedGif_dialog();
           }});


           boolean hasHidden = false;
           for(ImageButton im : images)
           {
              if(!im.ref.isVisible())
              {
                 hasHidden = true;
              }
           }

           if(hasHidden)
           {
               final JMenuItem ns = new JMenuItem("Restore hidden tools...");
               pop.add(ns);
               ns.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae)
               {
                  for(ImageButton im : images)
                  {
                     im.ref.restoreFromTray();
                  }
               }});
           }



           final JMenuItem ns = new JMenuItem("Open New Screenshot Tool...");
           pop.add(ns);
           ns.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae)
           {
              try{
                new ScreenShot(false);
              }
              catch(final Exception e) {
                 e.printStackTrace();
              }
           }});

           pop.addSeparator();

           final JMenuItem toc = new JMenuItem("Save all to zip (jpeg)...");
           toc.setToolTipText(""+images.size()+" images");
           pop.add(toc);
           toc.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae)
           {

              final JFileChooser2 jfs = new JFileChooser2(opts);
              jfs.remember("screenshot_zips");
              jfs.addChoosableType("zip", ".zip");

              File f = jfs.chooseToSave();
              if(f==null) return;

              // Zip

              try
              {
                 FileOutputStream fos = new FileOutputStream(f);
                 BufferedOutputStream bos = new BufferedOutputStream(fos);
                 ZipOutputStream zos = new ZipOutputStream(bos);

                 // nice sortable !
                 String prefix = DateUtils.dateFormatYMDhmFileName.format(System.currentTimeMillis());

                 DecimalFormat df = new DecimalFormat("0000");
                 int n=0;
                 for(ImageButton im : images)
                 {
                    n++;
                    ZipEntry ze = new ZipEntry(""+prefix+"__image"+df.format(n));

                    System.out.println("wrote "+ze);

                    zos.putNextEntry(ze);
                    ImageIO.write( im.bim, "jpeg", zos);
                    zos.closeEntry();

                 }

                 zos.flush();
                 zos.close();

                 System.out.println("wrote "+f);
              }
              catch(final Exception e) {
                 e.printStackTrace();
              }

           }});

           /*
           final JMenuItem res = new JMenuItem("Resize thumbs...");
           pop.add(res);
           res.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae)
           {

           }});*/

           pop.show(opts, 0,opts.getHeight());
      } });
   }


   /** Define the popup for 1 button
   */
   void definePopup(final JButton bt, final BufferedImage bim, final ScreenShot ref, final Rectangle rect)
   {

      bt.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         JPopupMenu pop = new JPopupMenu();


           JMenuItem toc = new JMenuItem("to clipboard");
           pop.add(toc);
           toc.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
              ClipboardUtils.copyToClipboard(bim);
           }});

           JMenuItem tof = new JMenuItem("to file...");
           pop.add(tof);
           tof.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
              ScreenShot.saveImage(bim, ScreenShotSet.this, null);
           }});
/*todo
           JMenuItem tofp = new JMenuItem("to file (+1)");
           add(tofp);
           tofp.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
              ScreenShot.saveImage(bim, ScreenShotSet.this, null);
           }});*/

           pop.addSeparator();

           JMenuItem ed = new JMenuItem("View / zoom / edit");
           pop.add(ed);
           ed.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
              try{
                 new ImageEditor(bim, null, "Screenshot edit");
              }
              catch(final Exception e) {
                 e.printStackTrace();
              }
           } });

           pop.addSeparator();

/*todo
           JMenuItem up = new JMenuItem("move up");
           pop.add(up);
           up.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {

           } });
*/

           JMenuItem rem = new JMenuItem("Remove", Icons.sharedCross);
           pop.add(rem);
           rem.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
              imagesPanel.remove( bt );
              imagesPanel.updateUI();  // NEEDED
              images.remove(bim);
           }});

           JMenuItem rema = new JMenuItem("Remove ALL", Icons.sharedCross);
           pop.add(rema);
           rema.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
              imagesPanel.removeAll( );
              imagesPanel.updateUI();  // NEEDED
              images.clear();
           }});

           pop.addSeparator();

           JMenuItem rs = new JMenuItem("Reuse same position and size for next shot");
           pop.add(rs);
           rs.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
              ref.setSize(rect);

           } });

           // maybe "save all to zip", ...

           pop.show(bt, 0, bt.getHeight());
        }

     });
   }


  // As Standalone App
  public static void main(String[] aa)
  {
    CheckEDTViolationRepaintManager.installRuntimeChecker();
    //GUIUtils.setNimbusLookAndFeel_IfPossible();

    EventQueue.invokeLater(new Runnable() { public void run() {
          ScreenShot.safeEDTMain();
    }});
  }


}