package snow.postit;

import java.util.prefs.Preferences;
import java.util.List;
import java.util.ArrayList;
import it.sauronsoftware.junique.*;

/** Unique instance on a machine.
*    Using JUnique.
*/
public final class PostitFramework
{
  final boolean isTheUniqueInstance;

  // this singleton is not over the various VMs, there is one per VM.
  // singleton PostitFramework, thread safe & init on demand (JavaOne2009)
  private static class SingletonHolder {
     private static final PostitFramework instance = new PostitFramework();
  }

  private PostitFramework() {
     isTheUniqueInstance = _initialize();
  }

  public static PostitFramework getInstance()
  {
     return SingletonHolder.instance;
  }

  public void createNew()
  {
     if(isTheUniqueInstance)
     {
        return;
     }

     JUnique.sendMessage("postit", "create");
  }

/*
  public void remove(PostIt pit)
  {
  }*/



  /** calls the start action on the unique instance
  *  return true if we created a new right now.
  *  return false if it exits => should exit
  */
  private boolean _initialize()
  {
     try
     {
        // succeed only once on a machine !
        JUnique.acquireLock("postit", new MessageHandler(){
           public final String handle( final String message ) {
              System.out.println("Handle "+message);
              if("start".equals(message))
              {
                 getInstance().startAction();
                 //startAction();
              }
              else if("create".equals(message))
              {
                 getInstance().createNewPostIt();
                 //startAction();
              }
              return null;
           }
        });

        System.out.println("Unique instance of postit framework started successfully");
        startAction();
        return true;
     }
     catch(final AlreadyLockedException e) {
        //e.printStackTrace();
        // instance already exists => pass the message
        System.out.println("PostIt fw exist=> pass message");
        JUnique.sendMessage("postit", "start");
     }
     return false;
  }

  private final List<PostIt> postIts = new ArrayList<PostIt>();

  void createNewPostIt()
  {
     PostIt pit = new PostIt("PostIt"+(postIts.size()+1));
     postIts.add(pit);

     try
     {
        Preferences.userRoot().putInt("PostIt_count", postIts.size());
        //System.out.println("put n="+postIts.size());
     }
     catch(final Exception e) {
        e.printStackTrace();
     }

     viewAll();
  }

  void viewAll()
  {
      for(PostIt pi : postIts)
      {
         pi.restore();
      }
  }


  private void startAction()
  {
     // must be read before written
     final int n = Preferences.userRoot().getInt("PostIt_count", 1);

     System.out.println("Start action");
     if(postIts.isEmpty())
     {
        // one always exist
        // otherwise => create it !
        createNewPostIt();
     }
     else
     {
        // make them visible
        viewAll();
     }

        // restore the others

        System.out.println("recreate "+n);
        for(int i=1; i<n; i++)
        {
           createNewPostIt();
        }


  }



  public static void main(String[] args) throws Exception
  {
     getInstance();
  }

}