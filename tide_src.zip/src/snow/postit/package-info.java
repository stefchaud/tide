/** A simple post-it framework.
 */
package snow.postit;
