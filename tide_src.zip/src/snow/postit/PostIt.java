package snow.postit;

import java.util.prefs.Preferences;
import javax.swing.event.ChangeEvent;
import javax.swing.border.CompoundBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.event.ChangeListener;
import java.awt.EventQueue;
import snow.utils.gui.*;
import java.awt.BorderLayout;
import javax.swing.*;
import snow.utils.storage.PrefUtils;
import java.awt.event.*;

/** Represents a single Post-It UI,
*    as a floating transparent dialog.
*/
public final class PostIt
{
   final private JDialog ww = new JDialog(new JFrame(), false);
   final private JTextField tf = new JTextField("Title");
   final private JTextPane tep = new JTextPane();
   final private String keyword;

   final private Preferences prefs = Preferences.userRoot();


   /** Solely created from the framework */
   PostIt(final String keyword)
   {
      this.keyword = keyword;

      ww.setTitle(keyword);
      ww.setAlwaysOnTop(true);
      ww.setIconImage( Icons.createImage( Icons.sharedShellIcon) );
      ww.setUndecorated(true);
      new ComponentResizer(ww);

      ((JComponent) ww.getContentPane()).setBorder(new CompoundBorder(new LineBorder(Color.lightGray, 1), new EmptyBorder(8,3,3,3)));  // 8: enough place on top to move
      GUIUtils.setWindowTransparency(ww, 0.9f);
      ww.getContentPane().setBackground(Color.yellow);

      JButton cl = GUIUtils.createMiniIconButton(Icons.sharedCross);

      final JButton opts = GUIUtils.createMiniIconButton(Icons.sharedPlusBlack);
      opts.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {

           JPopupMenu pop = new JPopupMenu();
           pop.add(keyword);
           pop.addSeparator();
           final JCheckBoxMenuItem atop = new JCheckBoxMenuItem("Always on top", ww.isAlwaysOnTop());
           pop.add(atop);
           atop.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
               ww.setAlwaysOnTop( atop.isSelected() );
           } });

           pop.add("Opacity :");
           final JSlider sltrans = new JSlider(5, 100, (int)(100*GUIUtils.getWindowTransparency(ww,0.9f)));
           pop.add(sltrans);
           sltrans.addChangeListener(new ChangeListener(){
              public final void stateChanged( final ChangeEvent e ) {
                 GUIUtils.setWindowTransparency(ww, (float) (sltrans.getValue()/100.0));
              }
           });

           pop.addSeparator();
           JMenuItem newP = new JMenuItem("Create a new Post-It", Icons.sharedPlus);
           pop.add(newP);
           newP.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
              PostitFramework.getInstance().createNewPostIt();
           } });


            // pop in XX minutes

           pop.show(opts,0,opts.getHeight());

      } });


      cl.setMaximumSize(cl.getPreferredSize());


      JGridPanel lp = new JGridPanel(3);
      lp.getGridLayout().setColumnWeights(new double[]{10, 0.1, 0.1});
      lp.addG(tf);
      lp.addG(opts);
      lp.addG(cl);
      lp.setOpaque(false);

      ww.add(lp, BorderLayout.NORTH);
      ww.add(new JScrollPane(tep), BorderLayout.CENTER);



      String tt = prefs.get(keyword+"_title", null);
      if(tt!=null)
      {
         tf.setText(tt);
      }

      String tet = prefs.get(keyword+"_content", null);
      if(tet!=null)
      {
         tep.setText(tet);
      }

      cl.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
          saveAction();
           ww.setVisible(false);
           // not disposed..., may be reanimated
      } });

      ww.addWindowListener(new WindowAdapter()
      {
         @Override public final void windowClosed( final WindowEvent e ) {
            // called when pressing X
             saveAction();
         }

         @Override public final void windowClosing( final WindowEvent e ) {
            // called on Ctrl+F4
             saveAction();
         }
      });

      ww.setSize(200,100);
      ww.setLocationRelativeTo(null);

      PrefUtils.setSizeAndLoc(ww, keyword, prefs);

      EventQueue.invokeLater(new Runnable() { public void run() {
         ww.setVisible(true);
      }});
   }


   void saveAction()
   {
            System.out.println("save");
            PrefUtils.saveSizeAndLoc(ww, keyword, prefs);
            prefs.put(keyword+"_title", tf.getText());
            prefs.put(keyword+"_content", tep.getText());
            try{
               prefs.flush();
            }
            catch(final Exception e2) {
               e2.printStackTrace();
            }
   }

   void hide()
   {
      ww.setVisible(false);
   }

   void restore()
   {
      ww.setVisible(true);
      LayoutUtils.ensureWithinScreen(ww);
   }



   public static void main(String[] args) throws Exception
   {
      PostitFramework.getInstance();
   }

}