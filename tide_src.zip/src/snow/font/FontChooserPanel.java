package snow.font;

import snow.utils.gui.GUIUtils;
import java.awt.font.TextAttribute;
import java.text.AttributedCharacterIterator;
import java.util.*;
import java.awt.Dimension;
import java.awt.event.*;
import javax.swing.event.*;
import java.awt.GraphicsEnvironment;
import java.awt.Font;
import javax.swing.*;

/** class FontChooserPanel.
*/
public final class FontChooserPanel extends JPanel
{
   final /*@org.checkerframework.checker.nullness.qual.Nullable*/ Font initialValue;
   private Font selectedFont = new Font("Lucida Sans", Font.PLAIN,12) ;

   final JComboBox fontNames = new JComboBox(GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames());
   final JSpinner sizeSpinner = createIntSpinner(12,1,999,1);
   // not if derived
   final JComboBox styleCB= new JComboBox(new String[]{"plain", "bold", "italic", "bold+italic"});
   // advanced attr
   final JSpinner weightSpinnerM10 = createIntSpinner(100,1,400,10);  // 2 is bold
   final JSpinner widthSpinnerM10 = createIntSpinner(100,50,999,10);
   final JSpinner slopeSpinnerM10 = createIntSpinner(0,-200,200,10);  // 0 or 0.2



   final JTextArea preview = new JTextArea("Preview\nArea  +-*/ @ * ?\n0123456789");
   private JDialog previewDialog = null;

   /** Spinner with wheel support
   */
   public static JSpinner createIntSpinner(int val, int min, int max, int incr)
   {
      final SpinnerNumberModel snb = new SpinnerNumberModel(val,min,max,incr);
      final JSpinner sizeSpinner = new JSpinner(snb);

      sizeSpinner.addMouseWheelListener(new MouseWheelListener()  // not automatic !
      {
         public final void mouseWheelMoved( final MouseWheelEvent e ) {
            //System.out.println("mo");
            if(e.getWheelRotation()<0)
            {
              if(snb.getNextValue()!=null)
              {
                 snb.setValue(snb.getNextValue());
              }
            }
            else
            {
              if(snb.getPreviousValue()!=null)
              {
                 snb.setValue(snb.getPreviousValue());
              }
            }
         }
      });

      return sizeSpinner;

   }

   boolean advancedMode = true;
   Map <AttributedCharacterIterator.Attribute,Object> advancedAttributes = new HashMap<AttributedCharacterIterator.Attribute,Object>();

   public final Font getSelectedFont()
   {
      return selectedFont;
   }

   /** Constructor. */
   public FontChooserPanel(/*@org.checkerframework.checker.nullness.qual.Nullable*/ Font initialValue)
   {
      super();

      this.initialValue = initialValue;
      if(initialValue!=null) {
        selectedFont = initialValue;
      }

      final ActionListener updater = new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         updateSelectedFont();
      } };

      fontNames.addActionListener(updater);
      ChangeListener changeListener = new ChangeListener()
      {
         public final void stateChanged( final ChangeEvent e ) {
            updater.actionPerformed(null);
         }
      };
      sizeSpinner.addChangeListener( changeListener);


      add(fontNames);
      GUIUtils.makeSmall(fontNames);
      fontNames.setMaximumRowCount(32);
//      fontNames.setPreferredSize(new Dimension(w, h));


      if(initialValue!=null)
      {
         fontNames.setSelectedItem(initialValue.getName());
         sizeSpinner.setValue( initialValue.getSize());
         initFontStyleCB(initialValue.getStyle());
      }

      int h = fontNames.getPreferredSize().height;
      int w = sizeSpinner.getPreferredSize().width*2/3;
      sizeSpinner.setPreferredSize(new Dimension(w*5/4, h));
      add(sizeSpinner);

      if(!advancedMode)
      {
         add(styleCB);
         styleCB.addActionListener(updater);
      }
      else
      {
         add(widthSpinnerM10);
         widthSpinnerM10.addChangeListener( changeListener); // works in continuous
         widthSpinnerM10.setToolTipText("width %");

         add(weightSpinnerM10);
         weightSpinnerM10.addChangeListener( changeListener);  // only 2 vals
         weightSpinnerM10.setToolTipText("weight bold=200%");

         add(slopeSpinnerM10);
         slopeSpinnerM10.addChangeListener( changeListener);  // only 2 vals


         widthSpinnerM10.setPreferredSize(new Dimension(w*3/2, h));
         weightSpinnerM10.setPreferredSize(new Dimension(w*3/2, h));
         slopeSpinnerM10.setPreferredSize(new Dimension(w*3/2, h));


         final JButton previewBt = new JButton(">");
         previewBt.setToolTipText("Preview Area");
         previewBt.setPreferredSize(new Dimension(w, h));
         GUIUtils.makeSmall(previewBt);
         add( previewBt);
         previewBt.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
             if(previewDialog!=null)
             {
                previewDialog.setVisible(true);
                return;
             }
             previewDialog = new JDialog(GUIUtils.getWindowForComponent(FontChooserPanel.this), "Preview", JDialog.ModalityType.MODELESS);
             previewDialog.add(preview);
             previewDialog.setSize(300,150);
             previewDialog.setLocation( previewBt.getLocationOnScreen());
             previewDialog.setVisible(true);
         } });;

      }
   }

   private int getFontStyle()
   {
      switch(styleCB.getSelectedIndex())
      {
         case 0 : return Font.PLAIN;
         case 1 : return Font.BOLD;  // TextAttribute.WEIGHT_BOLD
         case 2 : return Font.ITALIC;
         case 3 : return Font.BOLD | Font.ITALIC;
      }
      return Font.PLAIN;
   }


   private static int initFontStyleCB(int c)
   {
      if(c== Font.PLAIN) return 0;
      if(c== Font.BOLD) return 1;
      if(c== Font.ITALIC) return 2;
      if(c==  (Font.BOLD | Font.ITALIC)) return 3;

      return 0;
   }


   static Font test()
   {
      GUIUtils.setNimbusLookAndFeel_IfPossible();

      final FontChooserPanel p = new FontChooserPanel(null);
      if(JOptionPane.showConfirmDialog(null, p, "Choose the font", JOptionPane.OK_CANCEL_OPTION)!=JOptionPane.OK_OPTION) return null;
      System.out.println(""+p.getSelectedFont().hasLayoutAttributes());

      return p.getSelectedFont();
   }

   private void  updateSelectedFont()
   {
      selectedFont = new Font(""+fontNames.getSelectedItem(), getFontStyle(), (Integer) sizeSpinner.getValue());

      if(advancedMode)
      {
        advancedAttributes.put( TextAttribute.WEIGHT, Float.parseFloat(""+weightSpinnerM10.getValue())*0.01f);
        advancedAttributes.put( TextAttribute.POSTURE, Float.parseFloat(""+slopeSpinnerM10.getValue())*0.01f);
        advancedAttributes.put( TextAttribute.WIDTH, Float.parseFloat(""+widthSpinnerM10.getValue())*0.01f);
      }

      if(!advancedAttributes.isEmpty())
      {

         selectedFont = selectedFont.deriveFont(advancedAttributes);
      }

      preview.setFont(selectedFont);
   }

}