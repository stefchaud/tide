package snow.font;

import snow.veg.ShapeEd;
import java.awt.Shape;
import snow.chars.CharUtils;
import snow.concurrent.DelayedMergedUpdater2;
import snow.chars.CharsExplorer;
import snow.utils.gui.*;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import javax.swing.border.EmptyBorder;
import java.awt.geom.AffineTransform;
import java.awt.font.*;
import java.util.*;
import javax.swing.event.*;
import java.awt.event.*;
import javax.swing.table.*;
import java.awt.GraphicsEnvironment;
import snow.sortabletable.*;
import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.Font;

/** Modal dialog. Explores available fonts.
*    Can be used as chooser.
*    TODO: filter exotic fonts (that can't display Abc123+-*)
*
*/
public final class FontsExplorer extends JDialog
{
   boolean isReady = false;

   private FontRenderContext frc = new FontRenderContext(new AffineTransform(1,0,0,1,0,0), true, true);


   class JFont
   {
      final private String name;
      public JFont(String name)
      {
         this.name = name;
      }

      // delayed !
      Font font = null;
      boolean isMono = false;
   }

   private final List<JFont> fonts = new ArrayList<JFont>();

   final private JTable table;
   private SortableTableModel stm;
   final private JTextField customText = new JTextField("ABCDEF abcdef 1234567880 +-*/()[]<>,;.-# éü", 25);
   final private JTextField codeText = new JTextField("new Font(Font.PLAIN)");
   private final UniversalTableCellRenderer utr;
   private final CloseControlPanel ccp;

   private final JTextField sizeTF = new JTextField("12", 2);
   private final JCheckBox boldCB = new JCheckBox("Bold", false);
   private final JCheckBox italicCB = new JCheckBox("Italic", false);

   final JTextArea previewTF = new JTextArea( customText.getText()+"\n"+customText.getText() );

   final FacePanel facePanel = new FacePanel();


   class FacePanel extends JPanel
   {

      public FacePanel()
      {
         super(new BorderLayout());

         //setBorder(new TitledBorder("Preview"));

         //LayoutUtils.
         JGridPanel gp = new JGridPanel(1);
         //gp.getGridLayout().setColumnWeights(new double[]{222});
         gp.addG( GUIUtils.addComponentsToLine( "  Size: ",sizeTF, boldCB, italicCB ) );
         gp.addG( GUIUtils.addComponentsToLine("  Code: ", codeText), true);
         GUIUtils.selectAllTextWhenFocused(codeText);

         JButton unicex = new JButton("Unicode Explorer");
         GUIUtils.makeSmall(unicex);
         //ssp.add(unicex);
         unicex.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
            try{
               CharsExplorer.launch(false);
            }
            catch(Exception e) {
               e.printStackTrace();
            }
         } });

         gp.addG( GUIUtils.addComponentsToLine("  Tools: ", unicex), true);
         codeText.setEditable(false);

         add(gp, BorderLayout.NORTH);

         add(previewTF, BorderLayout.CENTER);
         //why not previewTF.setEditable(false);
         previewTF.setBorder(new EmptyBorder(10,5,10,2));
         previewTF.setMinimumSize(new Dimension(260,100));
         previewTF.setPreferredSize(new Dimension(260,100));


         ActionListener al = new ActionListener()
         {
            public final void actionPerformed( final ActionEvent e ) {
               updatePreview();
            }
         };
         DelayedMergedUpdater2 dmu = new DelayedMergedUpdater2(200, true, al);

         sizeTF.getDocument().addDocumentListener(dmu);
         boldCB.addActionListener(dmu);
         italicCB.addActionListener(dmu);
      }

      public void setFontPreview(Font f)
      {
         if(f!=null)
         {
           previewTF.setFont(f);

           String style = "";

           if(f.isPlain())
           {
              style+="Font.PLAIN";
           }
           if(f.isBold())
           {
              if(!style.isEmpty()) style+= " | ";
              style+="Font.BOLD";
           }
           if(f.isItalic())
           {
              if(!style.isEmpty()) style+= " | ";
              style+="Font.ITALIC";
           }
           codeText.setText("new Font(\""+f.getFamily()+"\", "+style+", "+sizeTF.getText()+")");
         }
         else
         {
            codeText.setText("");
         }
      }
   }


   /**
   */
   public FontsExplorer(final Font selectedFont, Component comp, String title, boolean monospacedFirst)
   {
      super(comp!=null ? SwingUtilities.windowForComponent(comp) : new JFrame("Parent"), title, JDialog.ModalityType.DOCUMENT_MODAL);


      // quick
      JFont sel0 = null;
      for(String fn : GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames())
      {
         JFont jfi = new JFont(fn);
         fonts.add( jfi );
         if(selectedFont!=null && fn.equals(selectedFont.getName()))
         {
            sel0 = jfi;
         }
      }
      final JFont fsel0 = sel0;

      final TM tm = new TM();
      stm = new  SortableTableModel(tm, monospacedFirst ? 4 : 0, !monospacedFirst);
      table = new JTable(stm);
      table.setRowHeight(30);
      stm.installGUI(table);

      // slow
      Thread t = new Thread()
      {
         public void run()
         {
            for(JFont fi : fonts)
            {
               fi.font = new Font(fi.name, Font.PLAIN, 15);
               fi.isMono = isMonospaced(fi.font);
            }

            isReady = true;

            //table.repaint();
            EventQueue.invokeLater(new Runnable() { public void run() {
               tm.fireTableStructureChanged();
               stm.setAllColumnsVisible();
               stm.setPreferredColumnSizesFromModel();
               //tm.fireTableDataChanged();
               if(fsel0!=null)
               {
                  int pos = stm.getIndexInFoundFromBasicIndex( fonts.indexOf(fsel0) );
                  if(pos>=0)
                  {
                    table.getSelectionModel().setSelectionInterval(pos, pos);
                    table.scrollRectToVisible( table.getCellRect(pos, 0, true) );
                  }
               }
            }});

         }
      };
      t.start();

      add(facePanel, BorderLayout.NORTH);
      if(selectedFont!=null)
      {
         sizeTF.setText(""+selectedFont.getSize());
         boldCB.setSelected(selectedFont.isBold());
         italicCB.setSelected(selectedFont.isItalic());
      }

      JPanel tablePanel = new JPanel(new BorderLayout());
      tablePanel.add(new JScrollPane(table), BorderLayout.CENTER);

      utr = new UniversalTableCellRenderer(stm, table);
      add(tablePanel, BorderLayout.CENTER);

      SearchPanel ssp = new SearchPanel("", Icons.sharedSearch, stm, false, false);
      tablePanel.add(ssp, BorderLayout.NORTH);
      ssp.add(new JLabel("  Display text: "));
      ssp.add(customText);
      ActionListener ali = new ActionListener() { public void actionPerformed(final ActionEvent ae) {
            utr.setCustomFontText( customText.getText() );
            previewTF.setText( customText.getText()+"\n"+customText.getText() );
            table.repaint();
      } };

      final JButton qj = new JButton(" add chars ...");
      GUIUtils.makeSmall(qj);
      qj.setToolTipText("Selected characters");
      ssp.add(qj);
      qj.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         final JPopupMenu pop = CharUtils.charExplorerPopup(table.getFont(),
             new ActionListener() { public void actionPerformed(final ActionEvent ae) {
                String bt = ((JButton)ae.getSource()).getText();
                customText.setText( customText.getText() +bt );
             }}
         );
         pop.show(qj,0,0);
      } });

      JButton ed = new JButton("E");
      GUIUtils.makeSmall(ed);
      ssp.add(ed);
      ed.setToolTipText("View/Modify the glyphvector");
      ed.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae)
      {
             String str = customText.getText().trim();
             if(str.isEmpty()) str+="@";

             GlyphVector glv = table.getFont().createGlyphVector(frc, str);
             Shape fs = glv.getOutline(5,20);
             ShapeEd.edit(fs, false);
      } });


      DelayedMergedUpdater2 dmu = new DelayedMergedUpdater2(200, true, ali);
      customText.getDocument().addDocumentListener(dmu);
      utr.setCustomFontText(customText.getText());

      table.getSelectionModel().addListSelectionListener(
         new ListSelectionListener()
         {
            public final void valueChanged( final ListSelectionEvent e ) {
               updatePreview();
            }
         });

      ccp = new CloseControlPanel(this, true, true, "Choose font");
      add(ccp, BorderLayout.SOUTH);

      setSize(610, 400);

      setLocationRelativeTo(comp);

      updatePreview();

      setVisible(true);        // MODAL !
   }

   void updatePreview()
   {
        Font sf = getSelectedFont();
        facePanel.setFontPreview(sf);
   }

   public Font getSelectedFont()
   {
      if(ccp==null) return null;

      if(ccp.getWasCancelled()) return null;
      if(table.getSelectedRow()<0) return null;

      int posM = stm.getIndexInUnsortedFromTablePos( table.getSelectedRow());
      int size = 12;
      int style = Font.PLAIN;
      if(italicCB.isSelected())
      {
         style = Font.ITALIC;
      }
      if(boldCB.isSelected())
      {
         style = style | Font.BOLD;
      }

      try{
         size = Integer.parseInt(sizeTF.getText());
      }
      catch(Exception e) {
      }
      return new Font(fonts.get(posM).name, style, size);
   }

   class TR extends DefaultTableCellRenderer
   {

   }

   class TM extends FineGrainTableModel
   {
      // abstract in snow.sortabletable.FineGrainTableModel:

      public final Object getValueAt( final int row, final int col ) {
         JFont jf = fonts.get(row);
         if(col==0) return jf.name;
         if(jf.font==null)
         {
            return "-";
         }

         //if(col==1) return fonts[row].getFamily();
         if(col==1) return fonts.get(row).font;
         if(col==2) return fonts.get(row).font.getNumGlyphs();
         if(col==3) return fonts.get(row).font.canDisplayUpTo(customText.getText() )==-1;
         if(col==4) return fonts.get(row).isMono;

         return "?";
      }

      public final int getColumnCount(  ) {
         return isReady ? 5 : 1;
      }

      public final int getRowCount(  ) {
         return fonts.size();
      }


      public final String  getColumnName(int col  ) {
         if(col==0) return "name";
         //if(col==1) return "family";
         if(col==1) return "preview";
         if(col==2) return "glyphs";
         if(col==3) return "can display";
         if(col==4) return "mono";
         return "?";
      }

      public int getPreferredColumnWidth(int column)
      {
        if(column==0) return 12;
        //if(column==1) return 8;
        if(column==1) return 28;
        if(column==2) return 4;
        if(column==3) return 4;
        return 4;
      }
   }

   public static List<Font> getMonospacedFontsThatCanDisplay(String str)
   {

      List<Font> ret = new ArrayList<Font>();
      String[] fontNames = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
      //System.out.println(""+fontNames.length+" fonts");
      for(String fi : fontNames)
      {
         Font df = new Font(fi, Font.PLAIN, 12);   // SLOW !  (2 seconds for all fonts)
         if(df.canDisplayUpTo(str)!= -1) continue;

         if(isMonospaced(df))
         {
            ret.add(df);
         }
      }
      return ret;
   }

   /** true iff +, -, / and w have the same width.
   */
   public static boolean isMonospaced(Font df)
   {
      if(df.canDisplayUpTo( " +-w/.")!=-1) return false;

      FontRenderContext frc = new FontRenderContext(new AffineTransform(), false, true);
      double w = -1;
      for( char ci : " +-w/.".toCharArray())  // space, +, - and / should have same width
      {
         // ex: 3.99609375
         double wi = df.createGlyphVector(frc, ""+ci).getLogicalBounds().getWidth();
         if(w<0)
         {
            w = wi; // first
         }
         else
         {
            if(Math.abs(w-wi)>0.01)
            {
               return false;
            }
         }
      }

      return true;
   }

   public static Font chooseFont(Font sel, String tit, Component comp)
   {
      return new FontsExplorer(sel, comp, tit, true).getSelectedFont();
   }



   public static void main(String[] args)
   {
      Font f1 = chooseFont(new Font("Lucida Sans", Font.ITALIC, 17), "Standalone FontExplorer test", null);

      //chooseFont(f1, "Hello choosed:"+f1, null);

      System.exit(0);
   }

}