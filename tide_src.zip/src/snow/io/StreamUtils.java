package snow.io;

import java.io.*;

/** see FileUtils
*/
public final class StreamUtils
{
   private StreamUtils()
   {
   }


   /** Copy in to out, flushing out but NOT closing any of them.
   *    Uses an internal buffer if 256 bytes, found to be optimal.
   *  Returns the total bytes copied
   *
   *    NOT thread safe, call with <code>synchronized(in) { synchronized(out) { } }</code>. (only if used from several threads, what may be very unusual (for me)).
   *    NOT buffered, call with new BufferedInputStream and new BufferedOutputStream for better I/O performance.
   */
   public static long copy(final InputStream in, final OutputStream out) throws IOException
   {
      return copy(in, out, new byte[256]);
   }

   /** Copy in to out, flushing out but NOT closing any of them. Uses the passed buffer.
   *    A length of 256 seems optimal over networks, 1024 seems nice when buffered streams are involved...
   *
   *    NOT thread safe, call with <code>synchronized(in) { synchronized(out) { } }</code>. (only if used from several threads, what may be very unusual (for me)).
   *    NOT buffered, call with new BufferedInputStream and new BufferedOutputStream for better I/O performance.
   */
   public static long copy(final InputStream in, final OutputStream out, byte[] buf) throws IOException
   {
        long totRead=0;
        int read = -1;
        while((read=in.read(buf))!=-1)
        {
          out.write( buf,0,read);
          totRead+=read;
        }
        out.flush();

        return totRead;
    }


   public static long copy(final Reader in, final Writer out) throws IOException
   {
      return copy(in, out, new char[256]);
   }

   public static long copy(final Reader in, final Writer out, char[] buf) throws IOException
   {
        long totRead=0;
        int read = -1;
        while((read=in.read(buf))!=-1)
        {
          out.write( buf,0,read);
          totRead+=read;
        }
        out.flush();

        return totRead;
    }

}