package snow.im;

import javax.imageio.ImageIO;
import snow.utils.storage.AppProperties;
import tide.GlobalTideProps;
import snow.utils.gui.files.FileField;
import snow.veg.DrawTool;
import java.awt.color.ColorSpace;
import snow.utils.gui.*;
import snow.screenshot.ScreenShot;
import javax.swing.*;
import java.io.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import java.awt.image.*;

/** An image viewer.
*  With some useful features, as zoom and save through screenshot utility and rotate, background image, ...
*/
public class ImageViewerPanel extends JPanel
{
  final private ImagePanel ip = new ImagePanel();
  private /*@org.checkerframework.checker.nullness.qual.Nullable*/ Image im;
  final private JScrollPane scrollPane = new JScrollPane(ip);
  private final /*@org.checkerframework.checker.nullness.qual.Nullable*/ JFrame parent;

  final private JPanel controlPanel = GUIUtils.boxLayout(2); //new JPanel();//new FlowLayout(FlowLayout.LEFT,4,4));
  final private JButton zoomPlus = new JButton(Icons.searchIcon(14,14,true, "+"));
  final private JButton zoomMinus = new JButton(Icons.searchIcon(14,14,true, "-"));
  final private JButton rotLeft = new JButton("RotLeft");
  final private JButton rotRight = new JButton("RotRight");

  final private JButton bgColorBT = new JButton("Opts");  // white, black, cust, image !
  private Color bgColor = Color.white;
  private /*@org.checkerframework.checker.nullness.qual.Nullable*/ Image bgIm = null;

  final private JCheckBox limitToFrameDims = new JCheckBox("Limit to frame", true);
  private final JCheckBox    scaleToFrameCB = new JCheckBox("Autoscale", true);

  private double zoomFact = 1;
  private double angle = 0;
  private AffineTransform imTr = new AffineTransform(1,0,0,1,0,0);


  private /*@org.checkerframework.checker.nullness.qual.Nullable*/ Composite comp = null;
  private float compAlpha = 0.5f;
  private int compIndex = 0;
  private boolean backgroundAfter = false;
  private boolean centerBackImage = true;

  private final ComponentAdapter resizeListener;

  public void zoomIn()
  {
     zoomFact *= 1.16;
     if(limitToFrameDims.isSelected()) limitToFrameDims.setSelected(false);  // don't trigger: ok
     if(scaleToFrameCB.isSelected()) scaleToFrameCB.setSelected(false);  // [june2011]
     update();
  }

  public void rotate(double a)
  {
     angle += a;
     update();
  }

  public void zoomOut()
  {
     zoomFact /= 1.16;
     if(limitToFrameDims.isSelected()) limitToFrameDims.setSelected(false);  // don't trigger: ok
     if(scaleToFrameCB.isSelected()) scaleToFrameCB.setSelected(false);  // [june2011]
     update();
  }


  public ImageViewerPanel(final /*@org.checkerframework.checker.nullness.qual.Nullable*/ JFrame parent)
  {
     super(new BorderLayout());

     this.parent = parent;
     createOps();

     add(scrollPane, BorderLayout.CENTER);
     //System.out.println("BIN "+scrollPane.getVerticalScrollBar().getUnitIncrement());
     //scrollPane.getVerticalScrollBar().setBlockIncrement(50);
     scrollPane.getVerticalScrollBar().setUnitIncrement(30);

     add(controlPanel, BorderLayout.NORTH);

     controlPanel.setMinimumSize(new Dimension(20,20));  // allow resizing below buttons sizes

     zoomPlus.setToolTipText("Press Ctrl to reset");
     controlPanel.add(zoomPlus);
     zoomPlus.setMargin(new Insets(0,2,0,2));
     zoomPlus.setFocusPainted(false);
     controlPanel.add(zoomMinus);
     zoomMinus.setMargin(new Insets(0,3,0,3));
     zoomMinus.setFocusPainted(false);



     controlPanel.add(rotLeft);
     rotLeft.setToolTipText("Rotates 90° left. Press Shift for small increments, Ctrl to reset" );
     rotLeft.setMargin(new Insets(0,3,0,3));
     rotLeft.setFocusPainted(false);

     controlPanel.add(rotRight);
     rotRight.setToolTipText("Rotates 90° right. Press Shift for small increments" );
     rotRight.setMargin(new Insets(0,3,0,3));
     rotRight.setFocusPainted(false);

     controlPanel.add(limitToFrameDims);
     controlPanel.add(bgColorBT);
     bgColorBT.setMargin(new Insets(0,3,0,3));
     bgColorBT.setFocusPainted(false);

     final JButton txtBT = new JButton("tDraw", Icons.toFrontIcon(14,14,true));
     controlPanel.add(txtBT);
     txtBT.setMargin(new Insets(0,3,0,3));
     txtBT.setFocusPainted(false);
     txtBT.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae)
     {
        DrawTool dt = new DrawTool(false);
        dt.setBackgroundImage( ImageUtils.getAsBufferedImage_ARGB(im) );
     }});

     controlPanel.add(scaleToFrameCB);

     JButton ss = new JButton(Icons.photoIcon(14,14));
     ss.setToolTipText("Use to save in any format or copy to clipboard");
     controlPanel.add(ss);
     ss.setMargin(new Insets(0,3,0,3));
     ss.setFocusPainted(false);
     ss.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae)
     {
        try
        {
           new ScreenShot(false);
        }
        catch(Exception e) {
           e.printStackTrace();
        }
     }});

     JButton load = new JButton("Load");
     load.setToolTipText("Loads an image from file or from clipboard");
     controlPanel.add(load);
     load.setMargin(new Insets(0,3,0,3));
     load.setFocusPainted(false);
     load.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae)
     {
        try
        {
          Image im = ImageUtils.getImageDialog();
          if(im!=null)
          {
             setImage(im);
          }
        }catch(Exception e) {
           e.printStackTrace();
        }
     }});

     zoomPlus.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae)
     {
        if(GUIUtils.isCtrlDown(ae))
        {
           if(limitToFrameDims.isSelected()) limitToFrameDims.setSelected(false);  // don't trigger: ok
           if(scaleToFrameCB.isSelected()) scaleToFrameCB.setSelected(false);  // [june2011]

           zoomFact = 1;
           update();
           return;
        }
        zoomIn();
     }});

     zoomMinus.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae)
     {
        zoomOut();
     }});

     rotLeft.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae)
     {
        if(GUIUtils.isCtrlDown(ae))
        {
           angle = 0;
           update();
           return;
        }

        if(GUIUtils.isShiftDown(ae))
          rotate(-Math.PI/36/5);
        else
          rotate(-Math.PI/2);
     }});
     rotRight.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae)
     {
        if(GUIUtils.isShiftDown(ae))
        {
          rotate( Math.PI/36/5);  // 1 degree
        }
        else
          rotate( Math.PI/2);
     }});

     bgColorBT.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae)
     {
        JPopupMenu pop = new JPopupMenu();

        final JMenuItem bl = new JMenuItem("Black back");
        pop.add(bl);
        bl.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
           bgColor = Color.black;
              update();
        }});

        final JMenuItem whi = new JMenuItem("White back");
        pop.add(whi);
        whi.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
           bgColor = Color.white;
              update();
        }});

        final JMenuItem miCust = new JMenuItem("Custom background color");
        pop.add(miCust);
        miCust.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {

           Color newCol = JColorChooser.showDialog(bgColorBT, "Background Color", bgColor);
           if(newCol!=null)
           {
              bgColor = newCol;
              update();
           }

        } });

        pop.addSeparator();


        if(parent !=null && GUIUtils.canSetWindowTransparency(parent))
        {
           final JMenu transp = new JMenu("Frame opacity");
           transp.setToolTipText("Sets editor's opacity (see through)");
           pop.add(transp);
              final String[] descr = new String[]{"1 (opaque)", "0.95 (a little bit transparent)", "0.9", "0.8", "0.7", "0.6"};
              final float[] opacity = new float[]{ 1f,  0.95f,  0.9f,  0.8f,  0.7f,  0.6f};

              for(int i=0; i<descr.length; i++)
              {
                final JMenuItem mi = new JMenuItem(descr[i]);
                final float oi = opacity[i];
                transp.add(mi);
                mi.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
                   GUIUtils.setWindowTransparency(parent, oi);
                } });
              }
        }
        // aditionally to the color...


        final JMenuItem ci = new JMenuItem("Background image and options...");
        pop.add(ci);
        ci.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae)
        {
           backgroundOptions();
        } });

        final JMenuItem rr = new JMenuItem("Reset zoom and rotation");
        pop.add(rr);
        rr.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae)
        {
           resetZoomAndTurn();
        } });
        final JMenuItem ss = new JMenuItem("Save with transparency...");
        pop.add(ss);
        ss.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae)
        {
           export();
        } });

        pop.show(bgColorBT, 0, bgColorBT.getHeight());

     }});

     scaleToFrameCB.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae)
     {
        update();
     }});

     limitToFrameDims.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae)
     {
        if(!limitToFrameDims.isSelected())
        {
          zoomFact = 1;
        }
        update();
     }});


     resizeListener = new ComponentAdapter()
     {
       @Override public void componentResized(ComponentEvent ce)
       {
         if(limitToFrameDims.isSelected())
         {
           update();
         }
       }
     };
     ip.addComponentListener(resizeListener);

     ip.addMouseWheelListener(new MouseAdapter()
     {

        //Overrides method of MouseAdapter
        @Override public final void mouseWheelMoved( final MouseWheelEvent e ) {

           if(e.isControlDown())
           {
              // zoom
              if(e.getWheelRotation()<0
              ||e.getPreciseWheelRotation()<0)  // to work on mac
              {
                 zoomOut();
              }
              else
              {
                 zoomIn();
              }
           }
           else
           {
              // normal scroll (must be reconstitued because adding a wheel listener to ip invalidates the default behaviour)

              if(scrollPane.getVerticalScrollBar().isShowing())
              {
                 int dx = (int) Math.copySign( scrollPane.getVerticalScrollBar().getUnitIncrement(), e.getWheelRotation() );
                 scrollPane.getVerticalScrollBar().setValue( scrollPane.getVerticalScrollBar().getValue() + dx);
              }
           }
        }

     });

  } // Constructor

  public void terminate()
  {
     ip.removeComponentListener(resizeListener);
     this.im = null;
  }

  public JPanel _getToolBar() { return  controlPanel; }

  public void setImage(Image im)
  {
     this.im = im;
     this.zoomFact = 1.0;
     angle = 0;
     update();
  }

  public void resetZoomAndTurn()
  {
           if(limitToFrameDims.isSelected()) limitToFrameDims.setSelected(false);  // don't trigger: ok
           if(scaleToFrameCB.isSelected()) scaleToFrameCB.setSelected(false);  // [june2011]

     this.zoomFact = 1.0;
     angle = 0;
     update();
  }


  /** with options (as transparency...)
  */
  void export()
  {
     JGridPanel gp = new JGridPanel(2);
     gp.addExplanationArea(
             "This tool saves the original passed image, without any further transformation."
       +"\nUse the screenshot tool to capture a part or a rotated or zoomed view."
       +"\nNote: gif supports transparency, png supports translucency."
     );

     gp.addG("Format");
     JComboBox cb = new JComboBox(ImageUtils.getAvailableImageWriterFormatNames());
     gp.addG(cb, false);

     FileField ff = new FileField("", true, "Image destination", JFileChooser.FILES_ONLY);
     gp.addG("Destination");
     gp.addG(ff);

     AppProperties pp = GlobalTideProps.getInstance().getGlobalProps();
     String defs = pp.getStringLCK("image_dest", "image.png");
     ff.setPath(defs);

     String it = pp.getStringLCK("image_type", "gif");
     cb.setSelectedItem(it);

     if(!gp.showInDialogOkCancel(this, "Export image", "Export")) return;

     pp.setStringLCK("image_dest", ff.getPathName());
     pp.setStringLCK("image_type", ""+cb.getSelectedItem());

     // export the image
     String type = ""+cb.getSelectedItem();
     String destName = ff.getPathName();

     if(!destName.toLowerCase().endsWith("."+type.toLowerCase()))
     {
        destName += "."+type;
     }

     System.out.println("save image to "+destName);

     int w = im.getWidth(null);
     int h = im.getHeight(null);
     System.out.println("w x h = "+w+" x "+h);
     File out = new File(destName);
     if(!out.getParentFile().exists())
     {
        out.getParentFile().mkdirs();
     }

     try
     {
        // rgba ONLY for gif and png
        if("png".equalsIgnoreCase(type) || "gif".equalsIgnoreCase(type))
        {
           ImageIO.write(ImageUtils.getAsBufferedImage_ARGB(im), type, out);
        }
        else
        {
           //
           ImageIO.write(ImageUtils.convertToBufferedRGBImage(im), type, out);
        }
     }
     catch(final Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Can't write file "+out+"\nerr="+e.getMessage(),
           "Error", JOptionPane.ERROR_MESSAGE);
     }

  }


  void update()
  {
    if(im!=null)
    {
      ip.setBackground( bgColor ) ;

      double imw = im.getWidth(this)  + 15;
      double imh = im.getHeight(this) + 15;

      if(this.limitToFrameDims.isSelected())
      {
         double f = 1;

         double wp = scrollPane.getWidth();
         if(wp<=0) wp = this.getPreferredSize().getWidth();
         if(wp < imw) f = wp / imw;

         double hp = scrollPane.getHeight();
         if(hp<=0) hp = this.getPreferredSize().getHeight();
         if(hp < imh)
         {
           double f2 = hp / imh;
           if(f2<f) f = f2;
         }
         this.zoomFact = f;
      }


      if(scaleToFrameCB.isSelected())
      {
         double f = 1;

         double wp = scrollPane.getWidth();
         if(wp <= 0) wp = this.getPreferredSize().getWidth();
         f = wp/imw;

         double hp = scrollPane.getHeight();
         if(hp <= 0) hp = this.getPreferredSize().getHeight();

         double f2 = hp/imh;
         if(f2<f) f = f2;

         this.zoomFact = f;
      }

      Dimension dim = new Dimension((int)(im.getWidth(this)*zoomFact), (int)(im.getHeight(this)*zoomFact));
      ip.setSize( dim );
      ip.setPreferredSize( dim );  // don't forget, or the scroll pane will never appear !

    }
    else
    {
      ip.setPreferredSize(new Dimension(2,2));
    }
    repaint();
  }

  int redOpInd = 0;
  int greenOpInd = 0;
  int blueOpInd = 0;
  int alphaOpInd = 0;

  void backgroundOptions()
  {
      final String[] names = new String[]{
       "None",
       "Clear", "Src", "Dst",
       "Src over", "Dst over", "Src in",
       "Dst in", "Src out", "Dst out",
       "Src atop", "Dst atop", "Xor"};

      final int[] composites = new int[]{ -1,
                 AlphaComposite.CLEAR, AlphaComposite.SRC, AlphaComposite.DST,
                 AlphaComposite.SRC_OVER, AlphaComposite.DST_OVER, AlphaComposite.SRC_IN,
                 AlphaComposite.DST_IN, AlphaComposite.SRC_OUT, AlphaComposite.DST_OUT,
                 AlphaComposite.SRC_ATOP, AlphaComposite.DST_ATOP, AlphaComposite.XOR};

      JDialog d = new JDialog(parent, "Transformation and background options", true);
      JPanel p = new JPanel();
      d.add(p, BorderLayout.CENTER);
      GridLayout3 gl3 = new GridLayout3(2, p);

      //gl3.addSeparator();
      gl3.addTitleSeparator("Background");

      final JButton miIm = new JButton("Image...");
      gl3.add("");
      gl3.add(miIm);
      miIm.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {

           bgIm = ImageUtils.getImageDialog();
           update();
      } });

      gl3.add("");
      final JCheckBox centerBack = new JCheckBox("Center image", centerBackImage  );
      gl3.add(centerBack);

      final JComboBox cb = new JComboBox(names);
      cb.setMaximumRowCount(20);
      cb.setSelectedIndex(compIndex);
      gl3.add("Rule");
      gl3.add(cb);

      gl3.add("Alpha [0..1]");
      final JTextField alphaTF = new JTextField(4);
      alphaTF.setText(""+compAlpha);
      gl3.add(alphaTF);

      gl3.add("");
      final JCheckBox revertBack = new JCheckBox("Draw background on top", backgroundAfter);
      gl3.add(revertBack);

      gl3.addSeparator();
      gl3.addTitleSeparator("Global image transformation");
      final JComboBox cop = new JComboBox(convolveOpsNames);
      cop.setMaximumRowCount(20);
      cop.setSelectedIndex(copIndex);
      gl3.add("ConvolveOp");
      gl3.add(cop);

      gl3.addSeparator();
      gl3.addTitleSeparator("Color transform");
      final JComboBox redOp = new JComboBox(chanelTransformNames);
      redOp.setMaximumRowCount(20);
      redOp.setSelectedIndex(redOpInd);
      gl3.add("Red");
      gl3.add(redOp);

      final JComboBox greenOp = new JComboBox(chanelTransformNames);
      greenOp.setMaximumRowCount(20);
      greenOp.setSelectedIndex(greenOpInd);
      gl3.add("Green");
      gl3.add(greenOp);

      final JComboBox blueOp = new JComboBox(chanelTransformNames);
      blueOp.setMaximumRowCount(20);
      blueOp.setSelectedIndex(blueOpInd);
      gl3.add("Blue");
      gl3.add(blueOp);

      final JComboBox alphaOp = new JComboBox(chanelTransformNames);
      alphaOp.setMaximumRowCount(20);
      alphaOp.setSelectedIndex(alphaOpInd);
      gl3.add("Alpha");
      gl3.add(alphaOp);

      ActionListener updater = new ActionListener()
      {

        public void actionPerformed(ActionEvent ae) {

          try
          {
             compAlpha = Float.parseFloat(alphaTF.getText());
          }catch(Exception e) {}

          compIndex = cb.getSelectedIndex();
          if(compIndex==0)
          {
             comp = null;
          }
          else
          {
             comp = AlphaComposite.getInstance(composites[cb.getSelectedIndex()], compAlpha);
          }

          copIndex = cop.getSelectedIndex();
          if(copIndex==0)
          {
             convolveOp = null;
          }
          else
          {
             convolveOp = convolveOps[copIndex];
          }

          redOpInd   = redOp.getSelectedIndex();
          greenOpInd = greenOp.getSelectedIndex();
          blueOpInd  = blueOp.getSelectedIndex();
          alphaOpInd = alphaOp.getSelectedIndex();


          backgroundAfter = revertBack.isSelected();
          centerBackImage = centerBack.isSelected();

          update();
      } };

      alphaTF.addActionListener(updater);
      cb.addActionListener(updater);
      revertBack.addActionListener(updater);
      centerBack.addActionListener(updater);
      cop.addActionListener(updater);

      redOp.addActionListener(updater);
      greenOp.addActionListener(updater);
      blueOp.addActionListener(updater);
      alphaOp.addActionListener(updater);

      final CloseControlPanel ccp = new CloseControlPanel(d, true, true, "Ok");
      d.add(ccp, BorderLayout.SOUTH);
      d.pack();
      d.setLocationRelativeTo(this);
      d.setVisible(true); // Modal

      if(ccp.getWasCancelled()) return;

      // update necessary because of textfield (not uptodate, only on enter)
      updater.actionPerformed(null);
  }

  private String [] convolveOpsNames =  new String[]{
        "None", "Edge detect", "Sharpening", "Brightening", "Blur", "Invert",
        "gray",
        "scale 0.5 0", "scale 0.5 64" };
  private BufferedImageOp /*@org.checkerframework.checker.nullness.qual.Nullable*/ [] convolveOps = null;


  // todo: allow a list of ops to apply !  (gray, blur, edge, ...)
  private /*@org.checkerframework.checker.nullness.qual.Nullable*/ BufferedImageOp convolveOp = null;
  private int copIndex = 0;

  short[] zero = new short[256];
  short[] straight = new short[256];
  short[] invert = new short[256];
  short[] brighten = new short[256];
  short[] darken = new short[256];
  short[] brighten2 = new short[256];
  short[] posterize = new short[256];

  String[] chanelTransformNames = new String[]{"ident", "zero", "brighten", "brighten2", "darken", "posterize", "invert"};
  short[][] chans = new short[][]{straight, zero, brighten, brighten2, darken, posterize, invert};

  @SuppressWarnings("nullness")
  void createOps()
  {
    final Kernel edgeDetect = new Kernel(3,3,new float[]{0f,-1f,0f, -1f,4f,-1f, 0f,-1f,0f});
    final ConvolveOp edgeOp = new ConvolveOp(edgeDetect, ConvolveOp.EDGE_NO_OP, null);

    final Kernel sdK = new Kernel(3,3,new float[]{0f,-1f,0f, -1f,5f,-1f, 0f,-1f,0f});
    final ConvolveOp sharpOp = new ConvolveOp(sdK, ConvolveOp.EDGE_NO_OP, null);

    final float nt = 1.0f/9.0f;
    final Kernel blurK = new Kernel(3,3,new float[]{nt,nt,nt,nt,nt,nt,nt,nt,nt});
    final ConvolveOp blurOp = new ConvolveOp(blurK, ConvolveOp.EDGE_ZERO_FILL, null);

    //

    for (int i=0; i<256; i++)
    {
      straight[i] = (short) i;
      invert[i]   = (short) (255 -i);
      brighten[i] = (short)(Math.sqrt(i / 255.0) * 255.0);
      brighten2[i] = (short)(128 + i / 2);
      darken[i] = (short)(Math.pow(i / 255.0, 2) * 255.0);
      posterize[i] = (short)(i - (i % 32));
    }

    LookupOp invertOp = new LookupOp(new ShortLookupTable(0,  new short[][]{ invert, invert, invert, straight }), null);

    LookupOp brightenOp = new LookupOp(new ShortLookupTable(0,  new short[][]{brighten, brighten, brighten, straight}), null);



    convolveOps = new BufferedImageOp[]{ null,
        edgeOp, sharpOp, brightenOp, blurOp, invertOp,
        new ColorConvertOp(ColorSpace.getInstance(ColorSpace.CS_GRAY), null),
        new RescaleOp(new float[]{0.5f,0.5f,0.5f,1f}, new float[]{0f,0f,0f,0f}, null),
        new RescaleOp(new float[]{0.5f,0.5f,0.5f,1f}, new float[]{64f,64f,64f,0f}, null)
    };

  }

  /** Where the image is displayed / transformed.
  */
  class ImagePanel extends JPanel
  {
     public ImagePanel()
     {
       super();
       setBackground(Color.black);
     }

     private void drawBackground(Graphics2D g2)
     {
          if(bgIm==null)
          {
            //super.paintComponent(g2);
            return;
          }

          if(centerBackImage)
          {
             int x0 = (getWidth()-bgIm.getWidth(this))/2;
             int y0 = (getHeight()-bgIm.getHeight(this))/2;
             g2.drawImage(bgIm, x0, y0, this);
          }
          else
          {
             g2.drawImage(bgIm, 0, 0, this);
          }
     }

     @Override public void paintComponent(Graphics g)
     {
       // draws the background (and the text)
       super.paintComponent(g);

       Graphics2D g2 = (Graphics2D) g;

       int ct = redOpInd + greenOpInd + blueOpInd + alphaOpInd;

       if(convolveOp != null || ct>0)
       {
          BufferedImage bim = new BufferedImage(getWidth(), getHeight(), copIndex==1 ? BufferedImage.TYPE_INT_RGB : BufferedImage.TYPE_INT_ARGB);
          final Graphics2D gr = bim.createGraphics();
          customDraw(gr);
          gr.dispose();

          // and now transform :::
          BufferedImage dst = bim;
          if(convolveOp!=null)
          {
            // uses the alpha info
            dst = new BufferedImage(bim.getWidth(), bim.getHeight(), BufferedImage.TYPE_INT_ARGB);
            dst = convolveOp.filter(bim, dst);

            /*
            // don't uses the alpha
            ConvolveOp cop = (ConvolveOp) convolveOp;
            dst = new BufferedImage( bim.getColorModel(), cop.filter(bim.getData(), null), true, null);
            */
          }

          if(ct>0)
          {
             short[][] tt = null;
             if( bim.getType() == BufferedImage.TYPE_INT_RGB )
             {
                tt = new short[][]{ chans[redOpInd], chans[greenOpInd], chans[blueOpInd] };
             }
             else
             {
                tt = new short[][]{ chans[redOpInd], chans[greenOpInd], chans[blueOpInd], chans[alphaOpInd] };
             }

             LookupOp lop = new LookupOp(new ShortLookupTable(0, tt), null);
             dst = lop.filter(dst, dst);
          }

          // and draw
          g2.drawImage(dst, 0, 0, this);
       }
       else
       {
         // just draw.
         customDraw(g2);
       }


       //super.paintComponent(g2);

     }

     private void customDraw(Graphics2D g2)
     {
       //g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
       g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);  // { speed, quality, default }

       // for nimbus

       Color oc = g2.getColor();
       g2.setColor(bgColor);
       //  if so, the text is no more written correctly.
       //g2.fillRect(0,0,getWidth(), getHeight());
       g2.setColor(oc);

       imTr.setToIdentity();

       if(bgIm!=null && !backgroundAfter)
       {
          drawBackground(g2);
       }

       if(comp!=null)
       {
          g2.setComposite(comp);
       }

       if(im!=null)
       {
         double x0 = 0;
         double y0 = 0;
         if(im.getWidth(this)*zoomFact < scrollPane.getWidth())   x0 = (scrollPane.getWidth()-im.getWidth(this)*zoomFact )/2.0;
         if(im.getHeight(this)*zoomFact < scrollPane.getHeight()) y0 = (scrollPane.getHeight()-im.getHeight(this)*zoomFact )/2.0;

         if(angle!=0)
         {
            double xt  = (scrollPane.getWidth() )/2.0;
            double yt  = (scrollPane.getHeight() )/2.0;
            imTr.translate(xt,yt);
            imTr.rotate(angle);
            imTr.translate(-xt,-yt);
         }
         imTr.scale(zoomFact, zoomFact);

         g2.transform( imTr );

         g2.drawImage(im, (int) (x0/zoomFact), (int) (y0/zoomFact), ImageViewerPanel.this);
       }

       if(bgIm!=null && backgroundAfter)
       {
          g2.setTransform( AffineTransform.getRotateInstance(0f));
          drawBackground(g2);
       }
       //super.paintComponent(g2);
     }
  }



  public static void main(String[] args) throws Exception
  {
     GUIUtils.setNimbusLookAndFeel_IfPossible();
     ImageEditor.main(args);
  }

}