package snow.im;

import java.awt.Image;
import java.awt.BorderLayout;
import java.awt.image.*;
import java.io.*;
import javax.imageio.*;
import javax.swing.*;
import snow.utils.gui.Icons;
import snow.utils.gui.ImageUtils;
import tide.TideIcons;

/** Not really an editor but either a viewer (zoom, rotate)
*/
public final class ImageEditor extends JFrame
{
   private BufferedImage original;
   final private File file;
   private final ImageViewerPanel iv;

   /** If file is not null, it will be used as default for saving back.
   *  One of both arguments image/file must be non null.
   */
   @SuppressWarnings ("nullness")
   public ImageEditor(final /*@org.checkerframework.checker.nullness.qual.Nullable*/ BufferedImage original,
                final /*@org.checkerframework.checker.nullness.qual.Nullable*/ File file, String title)
                // throws Exception
   {
      super(title);

      iv = new ImageViewerPanel(this);

      try{
            this.original = (original !=null ? original : ImageIO.read(file));
      }catch(final Exception e) {
        add(new JLabel("Error: cannot read image "+e.getMessage()), BorderLayout.NORTH);
      }

      this.file = file;

      add(iv, BorderLayout.CENTER);

      iv.setImage(this.original);

      setSize(800, 600);
      setLocationRelativeTo(null);
      setVisible(true);
   }

   public void setDisplayedImage(final BufferedImage im, String title)
   {
      setTitle(title);
      original = im;
      iv.setImage(im);
   }

   public void resetZoomAndTurn()
   {
      iv.resetZoomAndTurn();
   }

   public static void main(String[] args) throws Exception
   {
      Image im = Icons.createImage( TideIcons.tIDE_big );
      BufferedImage bim = ImageUtils.getAsBufferedImage_ARGB(im); // transparent

      new ImageEditor(bim, null, "test").resetZoomAndTurn();
   }

}