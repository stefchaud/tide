package snow.lookandfeel;

import java.awt.Color;
import java.awt.Font;
import java.util.*;
import javax.swing.*;
import javax.swing.plaf.*;
import javax.swing.plaf.metal.*;
import snow.utils.storage.AppProperties;

public class CustomOceanTheme extends OceanTheme
{
  final private String customName;

  // the properties, maybe customized by the user, keys always starting with customName
  final private AppProperties props;

  // each subclass may defins its own defaults (efcn => dark, cloud => bright)
  final private AppProperties themeDefaults = new AppProperties();

  public final static String COLOR_BLACK        = "Black";
  public final static String COLOR_White        = "White";

  public final static String COLOR_Green        = "Green";
  public final static String COLOR_Red          = "Red";

  public final static String COLOR_Primary1     = "Primary 1";
  public final static String COLOR_Primary2     = "Primary 2";
  public final static String COLOR_Primary3     = "Primary 3";

  public final static String COLOR_Secondary1   = "Secondary 1";
  public final static String COLOR_Secondary2   = "Secondary 2";
  public final static String COLOR_Secondary3   = "Secondary 3";

  public final static String COLOR_tide_Comments   = "tIDE Comments";
  public final static String COLOR_tide_Keywords   = "tIDE Keywords";
  public final static String COLOR_tide_Text       = "tIDE Text";
  public final static String COLOR_tide_Litterals  = "tIDE Litteral";
  public final static String COLOR_tide_Numbers   = "tIDE Numbers";
  public final static String COLOR_tide_Background = "tIDE EditorBackground";
  public final static String COLOR_tide_Annotations= "tIDE Annotation";
  public final static String COLOR_tide_Todos      = "tIDE Todo";
  public final static String COLOR_tide_Warning      = "tIDE Warning";
  public final static String COLOR_tide_Old = "tIDE Old Comments";

  public final static String COLOR_ControlText  = "ControlTextColor";
  public final static String COLOR_DesktopColor = "DesktopColor";
  public final static String COLOR_InactiveControlText    = "InactiveControlTextColor";
  public final static String COLOR_MenuDisabledForeground = "MenuDisabledForegroundColor";

  public final static String COLOR_TextHighlight = "TextHighlightColor";
  public final static String COLOR_UserText = "UserTextColor";

  public static final String FONT_SubText     = "SubTextFont";
  public static final String FONT_System      = "SystemFont";
  public static final String FONT_UserText    = "UserTextFont";
  public static final String FONT_WindowTitle = "WindowTitleFont";
  public static final String FONT_ControlText = "ControlTextFont";
  public static final String FONT_MenuText    = "MenuTextFont";
  public static final String FONT_CodeEditor    = "CodeEditorFont";

  private ImageIcon backgroundImage;

  public CustomOceanTheme(final String customName, final AppProperties props, final ImageIcon backgroundImage)
  {
     super();

     this.customName = customName;
     this.props = props;
     this.backgroundImage = backgroundImage;

     this.setDefaultColor(COLOR_Green, new ColorUIResource(180,250,180));
     this.setDefaultColor(COLOR_Red,   new ColorUIResource(250,100,100));   // [Nov2007]: 180 => 100

// default: black text white background

     this.setDefaultColor(COLOR_tide_Text,     new ColorUIResource(Color.black));  // 0,0,0
     this.setDefaultColor(COLOR_tide_Comments, new ColorUIResource(30,30,160));
     this.setDefaultColor(COLOR_tide_Keywords, new ColorUIResource(160,30,30));
     this.setDefaultColor(COLOR_tide_Litterals, new ColorUIResource(30,160,30));
     this.setDefaultColor(COLOR_tide_Numbers, new ColorUIResource(30,160,30));
     this.setDefaultColor(COLOR_tide_Background, new ColorUIResource(Color.white));
     this.setDefaultColor(COLOR_tide_Todos, new ColorUIResource(Color.magenta));
     this.setDefaultColor(COLOR_tide_Warning, new ColorUIResource(Color.orange));
     this.setDefaultColor(COLOR_tide_Old, new ColorUIResource(Color.lightGray));
     this.setDefaultColor(COLOR_tide_Annotations, new ColorUIResource(new Color(0, 104, 104)));

//[Sep2010] no more fixed width
     this.setDefaultFont(FONT_CodeEditor, new Font("Lucida Sans", Font.PLAIN, 12));
  }

  /** Overwrite this if you change something to the theme.
  */
  public void writeDefaults()
  {
  }

  @Override
  public String getName() { return customName; }

 /**
  *  Returns the background image for this theme if it exists,
  *  and null otherwise.
  */
  public ImageIcon getBackgroundImage()
  {
    return this.backgroundImage;
  }

@Override
  public void addCustomEntriesToTable(UIDefaults table)
  {
    //System.out.println("COT::addCustomEntriesToTable "+getName());

    super.addCustomEntriesToTable(table);
    // [July2008]: put in UIManager, not in table !!
    table.put( "ScrollBar.width", 12);      // instead 17
    table.put( "SplitPane.dividerSize", 8); // instead 10
    table.put( "TabbedPane.contentBorderInsets", new InsetsUIResource(4,0,0,0));
    table.put( "Tree.leftChildIndent",	4);  // instead 7
    table.put( "Tree.rightChildIndent",	9);  // instead 13

    //System.out.println("Set CEF 12 in "+this.getName());
    // [Sep2010]: thanks Guillaume: no need for fixed width font !!!
    table.put(FONT_CodeEditor, new Font("Lucida Sans", Font.PLAIN, 12));
  }

  //
  // COLORS
  //
  @Override
  public final ColorUIResource getBlack()             { return getColor(COLOR_BLACK);        }
  @Override
  public ColorUIResource getWhite()                   { return getColor(COLOR_White);        }
  public ColorUIResource getGreen()                   { return getColor(COLOR_Green);        }
  //NO @Override
  public ColorUIResource getRed()                     { return getColor(COLOR_Red);          }
  @Override
  protected ColorUIResource getPrimary1()             { return getColor(COLOR_Primary1);     }
  @Override
  protected ColorUIResource getPrimary2()             { return getColor(COLOR_Primary2);     }
  @Override
  protected ColorUIResource getPrimary3()             { return getColor(COLOR_Primary3);     }
  @Override
  protected ColorUIResource getSecondary1()           { return getColor(COLOR_Secondary1);   }
  @Override
  protected ColorUIResource getSecondary2()           { return getColor(COLOR_Secondary2);   }
  @Override
  protected ColorUIResource getSecondary3()           { return getColor(COLOR_Secondary3);   }

  /** table text
  */
@Override
  public ColorUIResource getControlTextColor()         { return getColor(CustomOceanTheme.COLOR_ControlText);  }
  @Override
  public ColorUIResource getDesktopColor()             { return getColor(CustomOceanTheme.COLOR_DesktopColor); }
  @Override
  public ColorUIResource getInactiveControlTextColor() { return getColor(CustomOceanTheme.COLOR_InactiveControlText);  }
  @Override
  public ColorUIResource getMenuDisabledForeground()   { return getColor(CustomOceanTheme.COLOR_MenuDisabledForeground); }
  @Override
  public ColorUIResource getTextHighlightColor()       { return getColor(CustomOceanTheme.COLOR_TextHighlight); }
  @Override
  public ColorUIResource getUserTextColor()            { return getColor(CustomOceanTheme.COLOR_UserText); }

  // TIDE specific
  public ColorUIResource get_tideEditor_commentColor() { return getColor(CustomOceanTheme.COLOR_tide_Comments); }
  public ColorUIResource get_tideEditor_keywordColor() { return getColor(CustomOceanTheme.COLOR_tide_Keywords); }
  public ColorUIResource get_tideEditor_annotationColor() { return getColor(CustomOceanTheme.COLOR_tide_Annotations); }
  public ColorUIResource get_tideEditor_todoColor() { return getColor(CustomOceanTheme.COLOR_tide_Todos); }
  public ColorUIResource get_tideEditor_warningColor() { return getColor(CustomOceanTheme.COLOR_tide_Warning); }
  public ColorUIResource get_tideEditor_textColor()    { return getColor(CustomOceanTheme.COLOR_tide_Text); }
  public ColorUIResource get_tideEditor_litteralsColor()    { return getColor(CustomOceanTheme.COLOR_tide_Litterals); }
  public ColorUIResource get_tideEditor_numbersColor()    { return getColor(CustomOceanTheme.COLOR_tide_Numbers); }
  public ColorUIResource get_tideEditor_background() { return getColor(CustomOceanTheme.COLOR_tide_Background); }
  public ColorUIResource get_tideEditor_oldColor() { return getColor(CustomOceanTheme.COLOR_tide_Old); }

  //return new ColorUIResource(30,30,160);   }  // blue

  /** Retrieves a color for this theme.
  */
  public ColorUIResource getColor(String key)
  {
    // first look in the user props
    Color found = props.getColor(customName+key, null);
    if(found!=null) return new ColorUIResource(found);

    // if not found, look in the defaults
    found = themeDefaults.getColor(customName+key, null);
    if(found!=null) return new ColorUIResource(found);

    // Not found => look in the default ocean
    if(key.equals(COLOR_BLACK))          return super.getBlack();
    if(key.equals(COLOR_White))          return super.getWhite();
    if(key.equals(COLOR_Primary1))       return super.getPrimary1();
    if(key.equals(COLOR_Primary2))       return super.getPrimary2();
    if(key.equals(COLOR_Primary3))       return super.getPrimary3();
    if(key.equals(COLOR_Secondary1))     return super.getSecondary1();
    if(key.equals(COLOR_Secondary2))     return super.getSecondary2();
    if(key.equals(COLOR_Secondary3))     return super.getSecondary3();

    if(key.equals(COLOR_ControlText))    return super.getControlTextColor();
    if(key.equals(COLOR_DesktopColor))   return super.getDesktopColor();
    if(key.equals(COLOR_InactiveControlText))    return super.getInactiveControlTextColor();
    if(key.equals(COLOR_MenuDisabledForeground)) return super.getMenuDisabledForeground();
    if(key.equals(COLOR_TextHighlight))     return super.getTextHighlightColor();
    if(key.equals(COLOR_UserText))       return super.getUserTextColor();

    return new ColorUIResource(Color.cyan);  // default
  }

  /** if null, is removed
  */
  public void setDefaultColor(String key, Color c)
  {
    if(c==null)
    {
       themeDefaults.remove(customName+key);
    }
    else
    {
       themeDefaults.setColor(customName+key, c);
    }
  }

  //
  // Fonts
  //

  @Override
  public FontUIResource getSubTextFont()      { return getFont(FONT_SubText);     }
  @Override
  public FontUIResource getSystemTextFont()   { return getFont(FONT_System);      }
  @Override
  public FontUIResource getUserTextFont()     { return getFont(FONT_UserText);    }
  @Override
  public FontUIResource getWindowTitleFont()  { return getFont(FONT_WindowTitle); }
  @Override
  public FontUIResource getControlTextFont()  { return getFont(FONT_ControlText); }
  @Override
  public FontUIResource getMenuTextFont()     { return getFont(FONT_MenuText);    }
  //no
  //@Override
  public FontUIResource getFont(String key)
  {
    Font found = props.getFont(customName+key, null);
    if(found!=null) return new FontUIResource(found);

    found = this.themeDefaults.getFont(customName+key, null);
    if(found!=null) return new FontUIResource(found);

    // Maps defaults with parent
    if(key.equals(FONT_SubText))     return super.getSubTextFont();
    if(key.equals(FONT_System))      return super.getSystemTextFont();
    if(key.equals(FONT_UserText))    return super.getUserTextFont();
    if(key.equals(FONT_WindowTitle)) return super.getWindowTitleFont();
    if(key.equals(FONT_ControlText)) return super.getControlTextFont();
    if(key.equals(FONT_MenuText))    return super.getMenuTextFont();
    //if(key.equals(FONT_CodeEditor))

    return null;
  }

  public void setDefaultFont(String key, Font f)
  {
    //System.out.println("Set def font "+key+" "+getName()+": "+f);
    if(f==null)
    {
       themeDefaults.remove(customName+key);
    }
    else
    {
       themeDefaults.setFont(customName+key, f);
    }
  }

  //
  // Edition
  //

  public List<String> getKeysForEdition_tIDEEditorOnly()
  {
    List<String> keys = new ArrayList<String>();

    keys.add( FONT_CodeEditor  );

    keys.add(COLOR_tide_Text);
    keys.add(COLOR_tide_Background);


    keys.add(COLOR_tide_Comments);
    keys.add(COLOR_tide_Keywords);
    keys.add(COLOR_tide_Litterals);
    keys.add(COLOR_tide_Numbers);
    keys.add(COLOR_tide_Annotations);
    keys.add(COLOR_tide_Todos);
    keys.add(COLOR_tide_Warning);

    return keys;
  }

  public List<String> getKeysForEdition()
  {
    List<String> keys = new ArrayList<String>();
    keys.add( COLOR_BLACK );
    keys.add( COLOR_White );

    keys.add( COLOR_Green );
    keys.add( COLOR_Red );

    keys.add( COLOR_Primary1   );
    keys.add( COLOR_Primary2   );
    keys.add( COLOR_Primary3   );
    keys.add( COLOR_Secondary1 );
    keys.add( COLOR_Secondary2 );
    keys.add( COLOR_Secondary3 );

    keys.add( COLOR_ControlText );
    keys.add( COLOR_UserText );
    keys.add( COLOR_TextHighlight );
    keys.add( COLOR_DesktopColor );
    keys.add( COLOR_InactiveControlText );
    keys.add( COLOR_MenuDisabledForeground );

    keys.add( FONT_SubText  );
    keys.add( FONT_System   );
    keys.add( FONT_UserText );
    keys.add( FONT_WindowTitle );
    keys.add( FONT_ControlText );
    keys.add( FONT_MenuText    );


    keys.add( FONT_CodeEditor );

    keys.add(COLOR_tide_Text);
    keys.add(COLOR_tide_Background);


    keys.add(COLOR_tide_Comments);
    keys.add(COLOR_tide_Keywords);
    keys.add(COLOR_tide_Litterals);
    keys.add(COLOR_tide_Numbers);
    keys.add(COLOR_tide_Annotations);
    keys.add(COLOR_tide_Todos);
    keys.add(COLOR_tide_Old);

    return keys;
  }

  public Object getResource(String key)
  {
    FontUIResource f = this.getFont(key);
    if(f!=null) return f;
    ColorUIResource c = this.getColor(key);
    return c;
  }

  /** Used to set fonts of colors
  */
  public void setResource(String key, Object res)
  {
    if(res instanceof Font)
    {
      this.props.setFont(customName+key, (Font) res);
    }
    else if(res instanceof Color)
    {
      this.props.setColor(customName+key, (Color) res);
    }

  }

  public void clearUserSettings()
  {
    for(String s: getKeysForEdition())
    {
      props.setColor(customName+s, null);
      props.setFont(customName+s, null);
    }
    writeDefaults();
  }

  public static void main(String[] aaa)
  {
     ThemesManager.main(aaa);
  }


}