package snow.lookandfeel;

import java.beans.*;
import tide.editor.styler.CodeStyler;
import snow.texteditor.SimpleDocument;
import java.awt.EventQueue;
import java.awt.Insets;
import snow.utils.storage.AppProperties;
import snow.utils.gui.*;
import snow.sortabletable.*;

import javax.swing.*;
import javax.swing.plaf.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.*;
import java.util.*;

/** Let's edit a subset of theme's keys.
*/
public class CustomOceanEditor extends JDialog
{
  final private CustomOceanTheme theme;
  final private UIKeysTableModel tableModel;
  final private SortableTableModel sortableTableModel;
  final private JTable table;

  public CustomOceanEditor(JFrame parent, final CustomOceanTheme theme, final AppProperties props, boolean tIDEEditorOnly)
  {
    super(parent, "Theme editor", false);
    setLayout(new BorderLayout());

    this.theme = theme;

    tableModel = new UIKeysTableModel( tIDEEditorOnly ? theme.getKeysForEdition_tIDEEditorOnly() : theme.getKeysForEdition());
    sortableTableModel = new SortableTableModel(tableModel, 0, true);
    table = new JTable(sortableTableModel);
    sortableTableModel.installGUI(table);

    table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    sortableTableModel.installGUI(table);

    new UniversalTableCellRenderer(sortableTableModel, table);
    table.setDefaultEditor(Object.class, new UniversalTableEditor());

    AdvancedSearchPanel asp = new AdvancedSearchPanel("Search: ", null, sortableTableModel, false);
    add(asp, BorderLayout.NORTH);

    asp.add(Box.createHorizontalStrut(50));

    JButton clearButton = new JButton("Reset theme");
    clearButton.setMargin(new Insets(0,2,0,2));
    asp.add(clearButton);
    clearButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent ae)
      {
         theme.clearUserSettings();
         ThemesManager.getInstance().saveThemes();
         ThemesManager.getInstance().installSelectedTheme(false);
         tableModel.updateWholeTable();
      }
    });

    asp.add(Box.createHorizontalStrut(10));

    final JButton edOpts = new JButton("CodeEditor Options");
    edOpts.setMargin(new Insets(0,2,0,2));
    asp.add(edOpts);
    edOpts.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent ae)
      {
         JPopupMenu pop = new JPopupMenu();
         JMenuItem blackT = new JMenuItem("Black background (not standard, not optimal)");
         pop.add(blackT);
         blackT.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae)
         {
              if(GUIUtils.isNimbusLF())
              {
                 JOptionPane.showMessageDialog(null,
                    "Sorry, I can't set a JTextPane's background to black with the color resources only (ColorUIResource)."
                    +"\nHelp me if you can !"
                    +"\nIf you want a black editor, please use the Metal look and feel.",
                    "Nimbus Bug !", JOptionPane.ERROR_MESSAGE);
                 //return;

//GUIUtils;

              }

              final CustomOceanTheme cot = ThemesManager.getInstance().getSelectedTheme();

              cot.setResource(CustomOceanTheme.COLOR_tide_Background, new ColorUIResource(Color.black));
              cot.setResource(CustomOceanTheme.COLOR_tide_Text, new ColorUIResource(Color.white));

              cot.setResource(CustomOceanTheme.COLOR_tide_Comments, new ColorUIResource(230,230,120));
              cot.setResource(CustomOceanTheme.COLOR_tide_Keywords, new ColorUIResource(120,230,230));
              cot.setResource(CustomOceanTheme.COLOR_tide_Litterals, new ColorUIResource(230,120,230));
              cot.setResource(CustomOceanTheme.COLOR_tide_Numbers, new ColorUIResource(0,105,250));
              cot.setResource(CustomOceanTheme.COLOR_tide_Todos, new ColorUIResource(Color.magenta.brighter()));
              cot.setResource(CustomOceanTheme.COLOR_tide_Annotations, new ColorUIResource(new Color(250, 174, 174)));

              ThemesManager.getInstance().saveThemes();

              ThemesManager.getInstance().installSelectedTheme(false);
              tableModel.updateWholeTable();
         } });

         JMenuItem whiteT = new JMenuItem("White background (default)");
         pop.add(whiteT);
         whiteT.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae)
         {
              final CustomOceanTheme cot = ThemesManager.getInstance().getSelectedTheme();
              cot.setResource(CustomOceanTheme.COLOR_tide_Background, new ColorUIResource(Color.white));
              cot.setResource(CustomOceanTheme.COLOR_tide_Text, new ColorUIResource(Color.black));

              cot.setResource(CustomOceanTheme.COLOR_tide_Comments, new ColorUIResource(30,30,160));
              cot.setResource(CustomOceanTheme.COLOR_tide_Keywords, new ColorUIResource(160,30,30));
              cot.setResource(CustomOceanTheme.COLOR_tide_Litterals, new ColorUIResource(30,160,30));
              cot.setResource(CustomOceanTheme.COLOR_tide_Numbers, new ColorUIResource(0,105,250));
              cot.setResource(CustomOceanTheme.COLOR_tide_Todos, new ColorUIResource(Color.magenta));
              cot.setResource(CustomOceanTheme.COLOR_tide_Annotations, new ColorUIResource(new Color(0, 104, 104)));

              ThemesManager.getInstance().saveThemes();

              ThemesManager.getInstance().installSelectedTheme(false);
              tableModel.updateWholeTable();
         } });
         pop.show(edOpts, 0, edOpts.getHeight());
      }
    });


    add(new JScrollPane(table), BorderLayout.CENTER);

 //   CloseControlPanel ccp = new CloseControlPanel(this, false, false, "Close");
  //  add(ccp, BorderLayout.SOUTH);

    this.setLocation(300,300);
    setSize(550, 550);
    setVisible(true);

  } // Constructor



  private class UIKeysTableModel extends FineGrainTableModel
  {
     final private List<String> keys = new ArrayList<String>();
     public UIKeysTableModel(List<String> keys)
     {
        this.keys.addAll(keys);
     }

     final String[] COLUMN_NAMES = new String[]{"name", "value" };

     final int[] COLUMN_PREFERRED_SIZES = new int[]{20, 20, 25};
     @Override
     public int getPreferredColumnWidth(int column)
     {
       if(column>=0 && column<COLUMN_PREFERRED_SIZES.length) return COLUMN_PREFERRED_SIZES[column];
       return -1;
     }
     @Override
     public String getColumnName(int col) { return COLUMN_NAMES[col]; }
     @Override
     public int getColumnAlignment(int column)
     {
       return JLabel.LEFT;
     }

     public int getColumnCount() { return COLUMN_NAMES.length; }
     public int getRowCount()    { return keys.size(); }


     public Object getValueAt(int row, int col)
     {
       String key = keys.get(row);
       Object val = theme.getResource(key);

       if(col==0) return ""+key;
       if(col==1)
       {
         if(val==null) return "null value";
         return val;
       }

       return "?";
     }

     @Override
     public boolean isCellEditable(int row, int col)
     {
       return col==1;
     }

     public void updateWholeTable()
     {
       this.fireTableModelWillChange();
       this.fireTableDataChanged();
       this.fireTableModelHasChanged();
     }

     @Override
     public void setValueAt(Object value, int row, int col)
     {
       if(col!=1) return;

       boolean updateUI = false;
       if(value instanceof Color)
       {
         value = new ColorUIResource((Color) value);
         updateUI = true;
       }

       if(value instanceof Font)
       {
         value = new FontUIResource((Font) value);
         updateUI = true;
       }

       if(row>=keys.size())
       {
          System.out.println("Key position "+row+" son't exist, keys size is only "+keys.size());
          return;
       }

       String key =  keys.get(row);
       Object old = theme.getResource(key);

       if(old!=null && value!=null && !(old.getClass() == value.getClass()))
       {
         System.out.println("Attemp to changing class type ! set value cancelled");
         System.out.println(old.getClass().getName()+" => "+value.getClass().getName());

        // return;
       }

       this.fireTableModelWillChange();

       theme.setResource(key, value);

       this.fireTableDataChanged();
       this.fireTableModelHasChanged();

       ThemesManager.getInstance().saveThemes();
       if(updateUI)
       {
         ThemesManager.getInstance().installSelectedTheme(false);
       }
     }
  }


//cool...
//todo: offer as utility
  public static void main(String[] arguments)
  {
     standaloneThemesTest();
  }

  public static void standaloneThemesTest()
  {
    EventQueue.invokeLater(new Runnable() { public void run() {

     ThemesManager.getInstance();
     JFrame f =new JFrame("Test Theme");
     f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


     f.setJMenuBar(new JMenuBar());
     f.getJMenuBar().add( ThemesManager.getInstance().getThemesMenu() );

     JMenu menu2 = new JMenu("Utils");
     f.getJMenuBar().add(menu2);
     JMenuItem uikeys = new JMenuItem("Swing UI Keys explorer");
     menu2.add(uikeys);
     uikeys.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent ae)
       {
           new snow.sortabletable.UIKeysViewer(false);
       }
     });

     JDesktopPane desktop = new JDesktopPane();
     f.setContentPane(desktop);

     JTree tt = new JTree();
     JInternalFrame ji1 = new JInternalFrame("Tree test", true, true, true, true);
     ji1.add(new JScrollPane(tt), BorderLayout.CENTER);
     ji1.setSize(200,200);
     desktop.add(ji1);
     ji1.setVisible(true);
     try{
       ji1.setSelected(true);
     } catch(Exception e) {}

     JTable ta = new JTable();
     ta.setModel(new TestModel());
     JInternalFrame ji2 = new JInternalFrame("Table test", true, true, true, true);
     ji2.add(GUIUtils.makeSmall(new JScrollPane(ta)), BorderLayout.CENTER);
     ji2.setSize(400,300);
     ji2.setLocation(220,10);
     desktop.add(ji2);
     ji2.setVisible(true);
     try{
       ji2.setSelected(true);
     } catch(Exception ignored) { }  // NOPMD

     JInternalFrame ji3 = new JInternalFrame("Some components", true, true, true, true);
     JTabbedPane tp = new JTabbedPane();

     tp.addTab("A simple Label", new JLabel("Label"));

     GridLayout3 gl = new GridLayout3(2);

     tp.addTab("Hello", gl.getTargetPanel());
     gl.add("Label");
     gl.add(new JButton("Button"));
     gl.add("TextField:");
     gl.add( new JTextField("Some text", 30), true);

     gl.add("Checkbox:");
     gl.add( new JCheckBox("do you ?", true));

     gl.add("Combobox:");
     gl.add( new JComboBox(new String[]{"Hello", "This is a test !"}));

     gl.fillSouth();

     ji3.setContentPane(tp);
     ji3.setSize(400,250);
     ji3.setLocation(20,320);
     desktop.add(ji3);
     ji3.setVisible(true);
     try
     {
       ji3.setSelected(true);
     } catch(Exception e) {} // NOPMD

     final JTextPane tpa = new JTextPane(new SimpleDocument());
     tpa.setText("/** Hello\n*/@Override public void close() {}");

     tpa.setBackground( GUIUtils.createPureColor(ThemesManager.getInstance().get_tideEditor_background()) );
     new CodeStyler(tpa.getStyledDocument());
     UIManager.addPropertyChangeListener(new PropertyChangeListener()
     {
        public final void propertyChange( final PropertyChangeEvent evt ) {
           System.out.println("UIManager.PC: "+evt.getPropertyName());

           tpa.setBackground( GUIUtils.createPureColor(ThemesManager.getInstance().get_tideEditor_background()) );
           new CodeStyler(tpa.getStyledDocument());
        }
     });

     JInternalFrame ji4 = new JInternalFrame("Editor test", true, true, true, true);
     ji4.add(new JScrollPane(tpa), BorderLayout.CENTER);
     ji4.setSize(200,200);
     ji4.setLocation(390,400);
     desktop.add(ji4);
     ji4.setVisible(true);
     try{
       ji4.setSelected(true);
     } catch(Exception e) {}

     f.setSize(700, 700);
     f.setVisible(true);

    }});

  }


}