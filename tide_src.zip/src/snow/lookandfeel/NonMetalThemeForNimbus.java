package snow.lookandfeel;

import java.util.*;
import snow.utils.storage.AppProperties;

/** Trick !
*  This theme is to be used when no Metal look and feel is selected.
*  (GTK, Nimbus, ...)
*/
public final class NonMetalThemeForNimbus extends CustomOceanTheme
{
  public static final String name = "NonMetalThemeForNimbus";

  public NonMetalThemeForNimbus(AppProperties props)
  {
    super(name, props, null);
    writeDefaults();
  }

@Override
  public List<String> getKeysForEdition()
  {
    List<String> keys = new ArrayList<String>();
    keys.add( COLOR_Green );
    keys.add( COLOR_Red );

    keys.add( FONT_CodeEditor  );

    keys.add(COLOR_tide_Text);
    keys.add(COLOR_tide_Background);

    keys.add(COLOR_tide_Comments);
    keys.add(COLOR_tide_Keywords);
    keys.add(COLOR_tide_Litterals);
    keys.add(COLOR_tide_Numbers);
    keys.add(COLOR_tide_Annotations);
    keys.add(COLOR_tide_Todos);
    keys.add(COLOR_tide_Old);

    return keys;
  }
}