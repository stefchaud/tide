package snow.lookandfeel;

import snow.utils.storage.AppProperties;
import java.io.*;
import javax.swing.*;
import javax.swing.plaf.metal.*;
import javax.swing.plaf.*;
import java.awt.*;
import java.awt.event.*;

/** Should be called prior to any UI creation.
*  Manages Look and Feels and Themes.
*/
public class ThemesManager
{

/*TODO: also allow choosing, if present among com.jgoodies.looks feels...
    try
    {
         UIManager.setLookAndFeel("com.jgoodies.looks.windows.WindowsLookAndFeel");
       //UIManager.setLookAndFeel("com.jgoodies.looks.plastic.Plastic3DLookAndFeel");
       //UIManager.setLookAndFeel("com.jgoodies.looks.plastic.PlasticLookAndFeel");
       //UIManager.setLookAndFeel("com.jgoodies.looks.plastic.PlasticXPLookAndFeel");
    } catch (Exception e) { e.printStackTrace(); }
JSlider
   */
  final private AppProperties props = new AppProperties();

  CustomOceanTheme[] themes;
  NonMetalThemeForNimbus nonMetalThemeForNimbus;
  JMenu menu_ = null;
  JMenu customOceanLF = null;

  private File storage = new File("ThemesManager.props");

  static ThemesManager instance = null;

  // "-noTheme" startup sets this to disable all themes settings
  public static boolean disableThemeSetting = false;

  public static ThemesManager getInstance()
  {
    if(instance==null)
    {
      // System.out.println("create theme manager");
      instance = new ThemesManager();
    }

    return instance;
  }

  private ThemesManager()
  {
    props.load_XML( storage );
    initialize();
  }

  public void saveThemes()
  {
    props.save_XML( storage );
  }

  /** Should be called once only. Initializes the menu.
  */
  private void initialize()
  {
    themes = new CustomOceanTheme[]
    {
      new CustomOceanTheme("Ocean Theme", props, null),
      new CustomOceanTheme_Snow(props)
      //new CustomOceanTheme_SnowEFCNSmall(props)
      //new CustomOceanTheme_Forest(props)
    };

    nonMetalThemeForNimbus = new NonMetalThemeForNimbus(props);

    //JFrame.setDefaultLookAndFeelDecorated(true);
    installSelectedTheme(false); // prior to anything else

    // Now we can build UI.


    menu_ = new JMenu("Look and feel");

    if(disableThemeSetting)
    {
       menu_.add("DISABLED with startup option -noTheme");
    }
    else
    {
       defineMenuItems();

    }

  } // Constructor


  private void defineMenuItems()
  {
       JMenu otherLF = new JMenu("Base look and feel");
       menu_.add(otherLF);

       customOceanLF = new JMenu("Themes for metal (ocean)");
       menu_.add(customOceanLF);



       String selectedLF = props.getProperty("SelectedLookAndFeel", getDefaultLFName());
       ButtonGroup bg2 = new ButtonGroup();
       for(final UIManager.LookAndFeelInfo it : UIManager.getInstalledLookAndFeels()) {
          boolean isSelected = it.getName().equals(selectedLF);
          JCheckBoxMenuItem mi = new JCheckBoxMenuItem(it.getName(), isSelected);
          otherLF.add(mi);
          bg2.add(mi);
          mi.addActionListener(new ActionListener()
          {
           public void actionPerformed(ActionEvent ae)
           {
              props.setProperty("SelectedLookAndFeel", it.getName());
              props.save_XML( storage );

              //NO, ugly side effects
              //   installSelectedTheme(false);

              JOptionPane.showMessageDialog(null, "Please restart tIDE", "Look and Feel changed", JOptionPane.INFORMATION_MESSAGE);
           }
          });
       }

       //Todo: look if plastic3d classes are present

       ButtonGroup bg = new ButtonGroup();
       String selectedTheme = props.getProperty("SelectedTheme", "Ocean Theme");
       for(int i=0; i<themes.length; i++)
       {
         boolean isSelected = themes[i].getName().equals(selectedTheme) && selectedLF.equals("Metal");
         JCheckBoxMenuItem mi = new JCheckBoxMenuItem(themes[i].getName(), isSelected);
         customOceanLF.add(mi);
         bg.add(mi);

         final int ii = i;
         mi.addActionListener(new ActionListener()
         {
           public void actionPerformed(ActionEvent ae)
           {
              props.setProperty("SelectedLookAndFeel", "Metal");
              props.setProperty("SelectedTheme", themes[ii].getName());
              props.save_XML( storage );

              //no ugly side effects!
              //installSelectedTheme(false);

              JOptionPane.showMessageDialog(null, "Please restart tIDE", "Theme changed", JOptionPane.INFORMATION_MESSAGE);

              //MetalLookAndFeel.setCurrentTheme( themes[ii] );
           }
         });
       }

       menu_.addSeparator();
       JMenuItem editItem = new JMenuItem("Edit current theme");
       menu_.add(editItem);
       editItem.addActionListener(new ActionListener()
       {
         public void actionPerformed(ActionEvent ae)
         {
            editCurrentTheme();
         }
       });
  }


  public void editCurrentTheme()
  {
      CustomOceanTheme ct = getSelectedTheme();
      new CustomOceanEditor(frame, ct, props, false);
  }

  public void editCurrentTheme_tIDEEditorOnly()
  {
      CustomOceanTheme ct = getSelectedTheme();
      new CustomOceanEditor(frame, ct, props, true);
  }

  /** This is the main frame, used for dialogs in the menu
  */
  public static JFrame frame;

  /** Metal or Nimbus if present or GTK+
  * [Jan2009]
  */
  private String getDefaultLFName()
  {
      for(final UIManager.LookAndFeelInfo ti : UIManager.getInstalledLookAndFeels()) {
         if(ti.getName().equalsIgnoreCase("Nimbus")) return ti.getName();
         if(ti.getName().equalsIgnoreCase("GTK+")) return ti.getName();
      }
      return "Metal";
  }


  /** Installs or reinstall the selected theme
  *    Causes ugly side effects if reselected... therefore, no more called more than once,
  *   [2014] only set once in the initial setup
  */
  public void installSelectedTheme(boolean refresh)
  {
     if(disableThemeSetting) return;  // shortcup

    String selectedTheme = props.getProperty("SelectedTheme", "Ocean Theme");
    String selectedLF = props.getProperty("SelectedLookAndFeel", getDefaultLFName());

    //System.out.println("Install Selected theme: "+selectedTheme+", look = "+selectedLF);

    if(selectedLF.equals("Metal"))
    {
      for(final CustomOceanTheme ti : themes)
      {
        boolean isSelected = ti.getName().equals(selectedTheme);
        if(isSelected)
        {
           // important: gradients and all stuff is added here
           ti.addCustomEntriesToTable(UIManager.getDefaults());
           MetalLookAndFeel.setCurrentTheme( ti );
           try
           {
              UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");

              //com.sun.java.swing.plaf.windows.WindowsLookAndFeel
           }
           catch(Exception ignored)
           {
              ignored.printStackTrace();
           }
        }
      }
    }
    else
    {
       // just set the correct look
       for(final UIManager.LookAndFeelInfo it : UIManager.getInstalledLookAndFeels()) {
          if(it.getName().equals(selectedLF))
          {
             try
             {
                UIManager.setLookAndFeel(it.getClassName());
             }catch(Exception e) {
                e.printStackTrace();
             }
          }
       }
    }

    // complete refresh

    if(refresh)
    {
      Frame[] frames = JFrame.getFrames();
      for(int f=0; f<frames.length; f++)
      {
        if(frames[f] instanceof JFrame)
        {
          JFrame ff = (JFrame) frames[f];
          SwingUtilities.updateComponentTreeUI(ff);

          SwingUtilities.updateComponentTreeUI(ff.getContentPane());
          //ff.getContentPane().invalidate();
          //ff.getContentPane().repaint();

          ff.invalidate();
          ff.repaint();

        }
      }
    }

  }

  /** Returns never null.
  *  Returns nonMetalThemeForNimbus if no metal lf is set.
  */
  public CustomOceanTheme getSelectedTheme()
  {
    String lf = getSelectedLookAndFeel();
    if(lf.equals("Metal"))
    {

       String selectedTheme = props.getProperty("SelectedTheme", "Ocean Theme");
       for(CustomOceanTheme theme : themes)
       {
         if(theme.getName().equals(selectedTheme)) return theme;
       }
    }

    // default (Nimbus, GTK, ...) !
    return nonMetalThemeForNimbus;
  }

  public String getSelectedLookAndFeel()
  {
    return props.getProperty("SelectedLookAndFeel", getDefaultLFName());
  }


  public JMenu getThemesMenu()
  {
    return menu_;
  }

  public Color darkerColor(Color c)
  {
    return c.darker();
  }

  public Color brighterColor(Color c)
  {
    return c.brighter();
  }

  public Color getGreen()
  {
     CustomOceanTheme cot = getSelectedTheme();
     return cot.getGreen();
  }

  public Color getRed()
  {
     CustomOceanTheme cot = getSelectedTheme();
     return cot.getRed();
  }

  public Color getBlack()
  {
     CustomOceanTheme cot = getSelectedTheme();
     return cot.getBlack();
  }

  public Color getWhite()
  {
     CustomOceanTheme cot = getSelectedTheme();
     return cot.getWhite();
  }

  public ColorUIResource get_tideEditor_commentColor()
  {
     CustomOceanTheme cot = getSelectedTheme();
     return cot.get_tideEditor_commentColor();
  }

  public ColorUIResource get_tideEditor_litteralsColor()
  {
     CustomOceanTheme cot = getSelectedTheme();
     return cot.get_tideEditor_litteralsColor();
  }


  public ColorUIResource get_tideEditor_numbersColor()
  {
     CustomOceanTheme cot = getSelectedTheme();
     return cot.get_tideEditor_numbersColor();
  }

  public ColorUIResource get_tideEditor_keywordColor()
  {
     CustomOceanTheme cot = getSelectedTheme();
     return cot.get_tideEditor_keywordColor();
  }

  public ColorUIResource get_tideEditor_todoColor()
  {
     CustomOceanTheme cot = getSelectedTheme();
     return cot.get_tideEditor_todoColor();
  }

  public ColorUIResource get_tideEditor_warningColor()
  {
     CustomOceanTheme cot = getSelectedTheme();
     return cot.get_tideEditor_warningColor();
  }

  public ColorUIResource get_tideEditor_oldColor()
  {
     CustomOceanTheme cot = getSelectedTheme();
     return cot.get_tideEditor_oldColor();
  }

  public ColorUIResource get_tideEditor_annotationColor()
  {
     CustomOceanTheme cot = getSelectedTheme();
     return cot.get_tideEditor_annotationColor();
  }


  public ColorUIResource get_tideEditor_textColor()
  {
     CustomOceanTheme cot = getSelectedTheme();
     return cot.get_tideEditor_textColor();
  }

  public ColorUIResource get_tideEditor_background()
  {
     CustomOceanTheme cot = getSelectedTheme();
     return cot.get_tideEditor_background();
  }

  public Font getSmallFont()
  {
     CustomOceanTheme cot = getSelectedTheme();
     return cot.getSubTextFont();
  }

  public Font get_tideEditor_codeEditorFont()
  {
     CustomOceanTheme cot = getSelectedTheme();
     return cot.getFont(CustomOceanTheme.FONT_CodeEditor);
  }


  /** For convenience.
  */
  public static int getLabelFontSize()
  {
    return UIManager.getFont("Label.font").getSize();
  }

  /** Standalone test app.
  */
  public static void main(String[] aaa)
  {
     CustomOceanEditor.standaloneThemesTest();
  }

}