package snow.lookandfeel;

import snow.utils.storage.AppProperties;
import javax.swing.*;
import javax.swing.plaf.*;
import java.awt.*;

public class CustomOceanTheme_Snow extends CustomOceanTheme
{
  public static final String name = "Snow Theme";
  public CustomOceanTheme_Snow(AppProperties props)
  {
    super(name, props, null); //new ImageIcon(new SnowIcon(120,120).getIconAsImage()));
    writeDefaults();
  }

  /** Writes the defaults in the inifile
  */
@Override
  public void writeDefaults()
  {
    this.setDefaultFont(FONT_ControlText, new FontUIResource("Dialog", Font.PLAIN, 10));
    this.setDefaultFont(FONT_System,      new FontUIResource("Dialog", Font.PLAIN, 10));
    this.setDefaultFont(FONT_WindowTitle, new FontUIResource("Dialog", Font.BOLD, 11));
    this.setDefaultFont(FONT_UserText,    new FontUIResource("SansSerif", Font.PLAIN, 10));
    this.setDefaultFont(FONT_SubText,     new FontUIResource("Dialog", Font.PLAIN, 9));
    this.setDefaultFont(FONT_MenuText,     new FontUIResource("Dialog", Font.PLAIN, 10));
    // [Feb2008] don't work
    this.setDefaultFont("Menu.font",     new FontUIResource("Dialog", Font.PLAIN, 9));
    this.setDefaultFont("MenuBar.font",     new FontUIResource("Dialog", Font.PLAIN, 9));

    // Colors
    //
    this.setDefaultColor(COLOR_White,      new ColorUIResource(255, 255, 255 ));  // White is white
    this.setDefaultColor(COLOR_BLACK,      new ColorUIResource( 0,  0,  0 ));

    // [Feb2008] don't work
    Font font = new FontUIResource(UIManager.getFont("InternalFrame.titleFont"));
    UIManager.put("Menu.font", font);
    UIManager.put("MenuBar.font", font);
    UIManager.put("MenuItem.font", font);


    /*
    // Title back, ext frame borders
    this.setDefaultColor(this.COLOR_Primary1,   new ColorUIResource( 98,  88, 112 ));
    // Combobox selections, table, tree selections
    this.setDefaultColor(this.COLOR_Primary2,   new ColorUIResource( 84,  78,  96 ));
    // border of buttons when mouse over, tree selections
    this.setDefaultColor(this.COLOR_Primary3,   new ColorUIResource( 70,  65,  81 ));

    // all components border
    this.setDefaultColor(this.COLOR_Secondary1, new ColorUIResource( 53,  58,  73 ));
    // clicked background, focus checkbox, second button gradient
    this.setDefaultColor(this.COLOR_Secondary2, new ColorUIResource( 80,  84,  80 ));
    // panel background
    this.setDefaultColor(this.COLOR_Secondary3, new ColorUIResource(116, 122, 116 ));
    */

   // addCustomEntriesToTable(UIManager.getDefaults());
  }

  /*
  public void addCustomEntriesToTable(UIDefaults table)
  {

    super.addCustomEntriesToTable(table);

    java.util.List buttonGradient = Arrays.asList(
                 new Object[] { new Float(.3f), new Float(0f),
                   new ColorUIResource(0xDDE8F3),
                   this.getSecondary3(),
                   getSecondary2() });    // default: white & secondary2 !!!

    UIManager.put("Button.gradient", buttonGradient);
    UIManager.put("CheckBox.gradient", buttonGradient);
    //UIManager.put("CheckBox.foreground", new ColorUIResource(Color.red));
    //UIManager.put("Tree.rightChildIndent", 15);

  }  */

@Override
  public void addCustomEntriesToTable(UIDefaults table)
  {
    super.addCustomEntriesToTable(table);
  }

/*
  public static void main(String[] aaa)
  {
     ThemesManager.main(aaa);
  }*/


}