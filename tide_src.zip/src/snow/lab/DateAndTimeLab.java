package snow.lab;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.*;
import java.io.File;
import java.util.*;
import javax.swing.*;
import javax.swing.text.*;
import snow.numerical.histogram.Histogram;
import snow.tplot.*;
import snow.tplot.model.*;
import snow.utils.*;
import snow.utils.gui.*;
import snow.utils.storage.FileUtils;

/** Funny date analysis tool
*/
public final class DateAndTimeLab {

   private DateAndTimeLab() {
   }

   /**
   */
   public static long[] detectLastMachineStartStop()
   {
      // startup time
      // on windows: also given by "win/0.log"


      // seems that the nano time "starts" at system startup.
      long lastStartup = System.currentTimeMillis()-(long)(System.nanoTime()*1e-6);   // 292 years can be counted with Long in nanos !!
      // System.out.println(""+((Long.MAX_VALUE*1e-6)/3600/1000/24/365));
      System.out.println("Last machine startup? "+new Date(lastStartup) );

      // problem: if day light saving time change occured, the last startup is no more accurate !


      final File sf ;
    /*  if(SysUtils.is_Windows_OS())
      {
         sf = new File(System.getenv("SystemRoot")); //also ok: "System32");  // also ok: "user.home" !
      }
      else*/
      {
         sf = new File(System.getProperty("user.home", ""));  // universal
      }


      //System.out.println("looking system root "+sf);
      List<File> all = new ArrayList<File>();
      FileUtils.getAllFilesRecurseLim(sf, all, false, true, 2, null);
      System.out.println("found "+all.size()+" files");

      // look at dates before startup
      long smallestDiff = Long.MAX_VALUE;
      long lastStop = -1;
      File lastStopFile = null;

      for(File fi : all)
      {
         long lm = fi.lastModified();
         if(lm>lastStartup) continue;

         if(lastStartup - lm > 1000L*60*10)  // at least 10 min tolerance is required to work
         {
            // seek "smallest"
            long diff =  lastStartup - lm;
            if(diff<smallestDiff)
            {
               smallestDiff = diff;
               lastStop = lm;
               lastStopFile = fi;
            }
         }
      }

      System.out.println("Last stop is "+new Date(lastStop));
      System.out.println("    "+lastStopFile);   // ntuser.ini


      return new long[]{lastStartup, lastStop };

   }

   /** Converting Double to Long
   */
   public static void showAdvancedDateAnalysis_(final List<Double> dates_, final String title)
   {
      // convert
      List<Long> dates = new ArrayList<Long>();
      for(Double di : dates_)
      {
         dates.add(di.longValue());
      }

      showAdvancedDateAnalysis(dates, title);
   }

   /** Remove values < 1000
   */
   static List<Long> keepOnlyValidDates(final List<Long> dates)
   {
      final List<Long> ret = new ArrayList<Long>();
      for(long di : dates)
      {
         if(di>1000) ret.add(di);
      }
      return ret;
   }

   /** Dates will be sorted (<0 are also filtered).
   */
   public static void showAdvancedDateAnalysis(final List<Long> dates_, final String title)
   {
     final List<Long> dates = keepOnlyValidDates(dates_);

     Collections.sort(dates);

     StringBuilder sb = new StringBuilder();
     sb.append(title);
     sb.append("\nLast-modified statistics for "+dates.size()+" sorted dates:\n");

     // first of all, determine the range and make them being
     long min = Long.MAX_VALUE;
     long max = 0;
     TreeSet<Long> sortedDistinctDates = new TreeSet<Long>();

     final int[] daysStat = new int[7];  // Su, Mo, Tu, We, ...
     final int[] hrStat = new int[24];
     final int[] monthStat = new int[12];

     Calendar cal = GregorianCalendar.getInstance();
     for(long di : dates)
     {
        if(di<min) min = di;
        if(di>max) max = di;

        sortedDistinctDates.add(di);

        cal.setTimeInMillis(di);

        daysStat[ cal.get(Calendar.DAY_OF_WEEK)-1 ] ++;
        hrStat[ (int) Math.floor(cal.get(Calendar.HOUR_OF_DAY)) ] ++;
        monthStat[ (int) Math.floor(cal.get(Calendar.MONTH)) ] ++;
     }

     long dr = max-min;
     if(dr==0)
     {
        sb.append("\nAll dates identical: "+new Date(min));
     }
     else
     {
        long med = dates.get(dates.size()/2);

        sb.append("\nThere are "+sortedDistinctDates.size()+" distinct dates.");

        sb.append("\nFirst date \t"+DateUtils.formatDateAndTimeHuman(min)+"   \t"+DateUtils.formatDateDifferenceFromNow(min));
        sb.append("\nLast date \t"+DateUtils.formatDateAndTimeHuman(max)+"   \t"+DateUtils.formatDateDifferenceFromNow(max));
        sb.append("\nMedian date \t"+DateUtils.formatDateAndTimeHuman(med)+"   \t"+DateUtils.formatDateDifferenceFromNow(med));
        sb.append("\nRange    \t"+DateUtils.formatTimeDifference(dr));
        if(dr>1000L*3600*30)
        {
           sb.append("  \t("+DateUtils.formatTimeDifference(dr, true)+")");   // in hours
        }

        long diffMin = Long.MAX_VALUE;
        long diffMax = 0;
        double diffMean = 0;
        int ndiffs = 0;
        int mults2Sec = 0;
        TreeSet<Long> diffs = new TreeSet<Long>();
        for(int i=0; i<dates.size()-1; i++)
        {
           long di = dates.get(i+1) - dates.get(i);
           if(di==0) continue;
           diffs.add(di);

           ndiffs++;

           if((di % 2000) == 0)
           {
             mults2Sec++;
           }


           diffMean+=di;
           if(di>diffMax) diffMax = di;
           if(di<diffMin) diffMin = di;
        }

        if(ndiffs!=0)
        {
          diffMean /= ndiffs;
          int nZeroDiffs = dates.size()-1-ndiffs;
          sb.append("\n\nSorted subsequent differences");
          sb.append("\n  Ignoring "+nZeroDiffs+" zero values.");
          sb.append("\n  Count: "+ndiffs+" values, "+diffs.size()+" distinct diffs");
          sb.append("\n    diff min>0    \t"+DateUtils.formatTimeDifference(diffMin)+" ("+diffMin+" ms)");
          sb.append("\n    diff max    \t"+DateUtils.formatTimeDifference(diffMax));
          sb.append("\n    diff mean   \t"+DateUtils.formatTimeDifference((long) diffMean));

          if(diffs.size()>3)
          {
             final Iterator<Long> it = diffs.iterator();
             sb.append("\n    smallest diffs \t");
             int n =0;
             while(it.hasNext())
             {
                n++;
                sb.append(""+it.next()+"  ");
                if(n>8) break;
             }
          }

          // forensic 1: just for fun

          double percUnzip = 100.0*mults2Sec/ndiffs;
          if(percUnzip > 2)
          {
             sb.append("\n    "+(int) percUnzip+" % may have been unpacked (granularity of 2 sec)");
          }

          /*if(Math.abs(diffMin-2000L)<5)
          {
             sb.append("\n  Remark: the date granularity shows that the files may have been unzipped.");
          }*/

          sb.append("\n\nDays stats (Su, Mo, .., Sa):\t"+Arrays.toString(daysStat));
          sb.append("\nAM hour stats (0,11): \t"+Arrays.toString(Arrays.copyOfRange(hrStat,0,12)));
          sb.append("\nPM hour stats (12,23): \t"+Arrays.toString(Arrays.copyOfRange(hrStat,12,24)));
          sb.append("\nMonth stats (Jan..Dec):\t"+Arrays.toString(monthStat));

        }
     }

     JTextComponent expl = GUIUtils.createReadOnlyDescriptionArea(""+sb);
     final JFrame ff = GUIUtils.displayInFrame("Statistics for "+dates.size()+" dates ("+title+")", new JScrollPane(expl), false);

     final double fmin = min;
     final double fmax = max;

     JPanel fp = new JPanel(new FlowLayout(FlowLayout.LEFT,4,4));
     ff.add(fp, BorderLayout.NORTH);

     JButton dateAn = new JButton("Dates", Icons.sharedStat);
     GUIUtils.makeSmall(dateAn);
     fp.add(dateAn);
     dateAn.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {

          TPlot tp = new TPlot("Histo "+title);
          Histogram hi = new Histogram();
          hi.addData(dates);
          hi.setMinMax(fmin, fmax);
          hi.classify();
          tp.add(new HistogramElement(hi, "dates"));
          tp.autoscale();
          tp.viewInDialog(ff).setSize(700,300);
     } });


     JButton dayStat = new JButton("Days in week", Icons.sharedStat);
     GUIUtils.makeSmall(dayStat);
     fp.add(dayStat);
     dayStat.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae)
     {
          double[] xs = ArrayUtils.range(1,7,7);
          double[] xe = ArrayUtils.range(2,8,7);
          String[] tit = new String[]{" Su", " Mo", " Tu", " We", " Th", " Fr", " Sa"};

          TPlot tp = new TPlot("Days histo "+title);
          Histogram hi = new Histogram();
          hi.setHistogramFromCounts(xs, xe, daysStat, tit);
          tp.add(new HistogramElement(hi, "Days histo "+title));
          tp.autoscale();
          tp.getPlotPanel().setViewAxisXValues(false);

          tp.viewInDialog(ff).setSize(500,300);
     } });


     JButton hStat = new JButton("Hour in day", Icons.sharedStat);
     GUIUtils.makeSmall(hStat);
     fp.add(hStat);
     hStat.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae)
     {
          double[] xs = ArrayUtils.range(0,23,24);
          double[] xe = ArrayUtils.range(1,24,24);
          String[] tit = new String[24];
          for(int i=0; i<tit.length; i++) { tit[i] = " "+i; }

          TPlot tp = new TPlot("Hours histo "+title);
          Histogram hi = new Histogram();
          hi.setHistogramFromCounts(xs, xe, hrStat, tit);
          tp.add(new HistogramElement(hi, "Hours histo "+title));
          tp.autoscale();
          tp.getPlotPanel().setViewAxisXValues(false);

          tp.viewInDialog(ff).setSize(700,300);
     } });


     JButton mStat = new JButton("Month", Icons.sharedStat);
     GUIUtils.makeSmall(mStat);
     fp.add(mStat);
     mStat.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae)
     {
          double[] xs = ArrayUtils.range(1,12,12);
          double[] xe = ArrayUtils.range(2,13,12);
          String[] tit = new String[]{" Jan", " Feb", " Mar", " Apr", " Mai", " Jun", " Jul", " Aug", " Sep", " Oct", " Nov", " Dec"};

          TPlot tp = new TPlot("Months histo "+title);
          Histogram hi = new Histogram();
          hi.setHistogramFromCounts(xs, xe, monthStat, tit);
          tp.add(new HistogramElement(hi, "Months histo "+title));
          tp.autoscale();
          tp.getPlotPanel().setViewAxisXValues(false);
          tp.viewInDialog(ff).setSize(700,300);

     } });


     JButton dd = new JButton("  boot info");
     GUIUtils.makeSmall(dd);
     fp.add(dd);
     dd.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
        long[] staSto = detectLastMachineStartStop();
        JOptionPane.showMessageDialog(null,
           "Last startup: "+new Date(staSto[0])
           +"\n        "+DateUtils.formatDateDifferenceFromNow(staSto[0])+" ago"
           +"\n\nLast stop: "+new Date(staSto[1])
           +"\n        "+DateUtils.formatDateDifferenceFromNow(staSto[1])+" ago",

           "System Start/Stop Debug Info", JOptionPane.INFORMATION_MESSAGE);
     }});

     ff.pack();
  }



  // idea: "mark" files using stamps being multiple of some value, for ex: 317ms of 37sec (resists to zip)
  // idea: (stega) store hidden info using last mods !

  public static void main(String[] args) throws Exception {

     List<Long> dates = new ArrayList<Long>();
     List<File> files = new ArrayList<File>();
     File root = new File("C:/windows");

     System.out.println("collecting "+root+" ...");

     FileUtils.getAllFilesRecurse(root, files, false, true);
     System.out.println("analysing "+files.size()+" files...");
     for(final File fi : files)
     {
        long lm = fi.lastModified();
        if(lm<1000)
        {
           System.out.println("No valid date for "+fi+": "+lm);
        }
        else
        {
          dates.add(lm);
        }
     }

     showAdvancedDateAnalysis(dates, ""+root);
  }

}