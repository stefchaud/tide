package snow.lab;

import snow.concurrent.DelayedMergedUpdater2;
import java.awt.Component;
import snow.utils.gui.LayoutUtils;
import java.awt.Point;
import snow.utils.gui.GUIUtils;
import javax.swing.border.EmptyBorder;
import snow.utils.gui.ComponentResizer;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.awt.event.*;
import java.awt.BorderLayout;
import snow.texteditor.*;
import java.awt.EventQueue;
import javax.swing.*;

/** Extract parts of text with RegEx
*/
public final class TextLab extends JFrame
{
   SimpleDocument doc = new SimpleDocument();
   final JTextPane tp = new JTextPane(doc);
   final JScrollPane scrollPane = new JScrollPane(tp);

   /** Constructor.
   */
   public TextLab(boolean standalone)
   {
      super("TextLab");
      if(standalone) this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

      add(scrollPane, BorderLayout.CENTER);
      //doc.createView(true);


      JPanel cp = new JPanel();
      add(cp, BorderLayout.NORTH);

      final JTextField reg = new JTextField(8);
      cp.add(reg);

      reg.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae)
      {
         try{
            Pattern p = Pattern.compile(reg.getText());
            Matcher m = p.matcher(doc.getText());
            //Matcher m = new Matcher();

         }
         catch(final Exception e) {
            e.printStackTrace();
         }

      } });

      setSize(800,600);
      setLocationRelativeTo(null);
      setVisible(true);


//TODO: add

      final SearchPanel sp = new SearchPanel(tp, doc, true, null);
      sp.setLocation(100,100);
      sp.setBorder(new EmptyBorder(11,5,5,5));
      sp.setSize(sp.getPreferredSize());
      final ComponentResizer com = new ComponentResizer(sp, true);
      tp.add(sp);   // add it IN the text pane directly !, not in the palette
      sp.setVisible(true);

      // subtle: we cannot add the sp to the scrollPane, but we want to layout it relative to the sp  when scrolling
      setLocationTopRight_andTrack(sp, scrollPane, new Point(0,0));

   }


   public void setText(String t)
   {
      doc.setText(t);
   }



   /** Useful for custom layouts, as for layeredpane
   */
   public static void setLocationTopRight_andTrack(final Component component, final Component reference, final Point offset)
   {
      ActionListener action = new ActionListener()
      {
         public final void actionPerformed( final ActionEvent e ) {
            LayoutUtils.setLocationTopRight(component, reference, offset);
         }
      };

      final DelayedMergedUpdater2 dmu = new DelayedMergedUpdater2(10, true, action);


      if(reference instanceof JScrollPane)
      {
         // Special case !
         JScrollPane sp = (JScrollPane) reference;
         sp.getViewport().addChangeListener(dmu);
      }

      reference.addComponentListener(new ComponentAdapter()
      {
         @Override public final void componentShown( final ComponentEvent e ) {
            dmu.changeOccured();
         }

         public final void componentResized( final ComponentEvent e ) {
            dmu.changeOccured();
         }
      });


   }

   public static void main(String[] args) throws Exception
   {
      GUIUtils.setNimbusLookAndFeel_IfPossible();

      EventQueue.invokeLater(new Runnable() { public void run() {
               TextLab sl = new TextLab(true);
               StringBuilder sb = new StringBuilder();
               for(int i=0; i<30; i++)
               {
                  sb.append(""+i);
               }
               for(int i=0; i<20; i++)
               {
                  sb.append( "test \"1\" und {2}\noder x=32\t33\t34.\nand another line !" );
               }

               sl.setText(sb.toString());
      }});
   }

}