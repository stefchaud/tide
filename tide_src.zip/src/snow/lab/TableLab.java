package snow.lab;

import snow.tplot.model.ListPlotElement;
import snow.tplot.TPlotPanel;
import java.awt.Window;
import java.awt.event.*;
import java.awt.FlowLayout;
import snow.utils.gui.*;
import java.awt.BorderLayout;
import snow.sortabletable.*;
import java.util.*;
import javax.swing.*;

/** Tool to visualize, filter data in tabular format.
*   With data plot2D option.
*   Called from DataLab.
* Transforms:
*   Selected lines can be removed
* Features:
*   most from sortable table & mult search panel !!
*/
public final class TableLab extends JDialog {

   private final JCheckBox useColForX   = new JCheckBox("use column as x axis", false);
   private final JTextField columnAxisX = new JTextField("0", 3);

   private final JCheckBox splitPerYear   = new JCheckBox("Split x each year", false);
   private final JCheckBox shiftToStartAtZero   = new JCheckBox("Shift to start at zero", false);


   /** Constructor. */
   public TableLab(/*@org.checkerframework.checker.nullness.qual.Nullable*/ Window owner, final ArrayList<ArrayList<Object>> data, ArrayList<String> takenColNames) {

     super(owner, "TableLab "+data.size()+" lines", JDialog.ModalityType.MODELESS);

     if(data.size()>1)
     {
        // [Mar2010]: frequent when analysing logs.
        if(data.get(1).size()>1)
        {
           if(data.get(1).get(1) instanceof Number)
           {
              columnAxisX.setText("1");
              useColForX.setSelected(true);
           }
        }
     }

     // View
     final TM tm = new TM(takenColNames.toArray(new String[takenColNames.size()]), data);
     final SortableTableModel stm = new SortableTableModel(tm);
     final JTable table = new JTable(stm);
     table.setColumnSelectionAllowed(true);
     stm.installGUI(table);

     add(new JScrollPane(table), BorderLayout.CENTER);

     JPanel northPan = new JPanel(new BorderLayout());
     final MultiSearchPanel searchPanel = new MultiSearchPanel("Filter: ", null, stm);
     add(northPan, BorderLayout.NORTH);
     //searchPanel.setQueries(Query.simpleSearchQuery("", 1));

     northPan.add(searchPanel, BorderLayout.NORTH);

     northPan.add(new JLabel("Hint: Select a col and right click in filter above for statistics"), BorderLayout.SOUTH);

     final JPanel cp = new JPanel(new FlowLayout(FlowLayout.LEFT,3,2));
     add(cp, BorderLayout.SOUTH);

     JButton doPlot = new JButton("Plot filtered items", Icons.graphIcon(16,16));
     GUIUtils.setIsMainDialogButton(doPlot);
     cp.add(doPlot);
     doPlot.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent ae)
       {
          int colx = -1;  // if -1, uses {1,2,3,4, ...}
          if(useColForX.isSelected())
          {
             colx = Integer.parseInt(columnAxisX.getText().trim());
          }

          final ArrayList<ArrayList<Object>> selData = new ArrayList<ArrayList<Object>>();
          int ts = table.getRowCount();
          for(int i=0; i<ts; i++)
          {
             selData.add( data.get(stm.getIndexInUnsortedFromTablePos(i)) );
          }


          plot(selData, colx, splitPerYear.isSelected(), shiftToStartAtZero.isSelected());
       }
     });

     cp.add(useColForX);
     cp.add(columnAxisX);

     cp.add(splitPerYear);
     splitPerYear.setToolTipText("Dates are then in the range [1..365], one serie per year");

     cp.add(shiftToStartAtZero);

     table.addMouseListener(new MouseAdapter()
     {
        @Override public final void mousePressed( final MouseEvent e ) {
           if(e.isPopupTrigger()) showPopup(e);
        }

        @Override public final void mouseReleased( final MouseEvent e ) {
           if(e.isPopupTrigger()) showPopup(e);
        }

        void showPopup(MouseEvent e)
        {
           JPopupMenu pop = new JPopupMenu();

           final int[] selt = table.getSelectedRows();

           JMenuItem rem = new JMenuItem("Remove "+selt.length+" selected lines", Icons.sharedCross);
           pop.add(rem);
           rem.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {

              final ArrayList<ArrayList<Object>> selData = new ArrayList<ArrayList<Object>>();
              for(int si : selt)
              {
                 selData.add( data.get(stm.getIndexInUnsortedFromTablePos(si)));

              }
              tm.remove(selData);
           } });

           pop.show(table, e.getX(), e.getY());
        }
     });

     setSize(700, 600);
     setLocationRelativeTo(this);
     setVisible(true);  // not modal

   }


   public static void main(String[] args) throws Exception
   {
      // test() ;
      DataLab.main(args);
   }



  /** Only considers columns with numbers.
  *   Caution: invalid items are removed from data.
  */
  void plot(final ArrayList<ArrayList<Object>> data, int colx, boolean splitXPerYear, boolean shiftToStartAtZero)
  {
     if(colx<0) colx=0;

     int ncols = Integer.MAX_VALUE;
     int npts = 0;

     // prepare
     final List<List<Object>> toRemove = new ArrayList<List<Object>>();

     for(List<Object> line : data)
     {
        int nn = 0;
        for(Object col : line)
        {
           if(col instanceof Number)
           {
              nn++;
           }
           else
           { //second chance.
              try {
                 Double.parseDouble(""+col);
                 nn++;
              }
              catch(NumberFormatException ex) {
              }
           }
        }

        // ignores lines without numbers.
        if(nn==0)
        {
           toRemove.add(line);
           continue;
        }

        npts++;
        ncols = Math.min(ncols, nn);
     }

     data.removeAll(toRemove);

     List<List<Number>> columns = new ArrayList<List<Number>>();
     for(int i=0; i<ncols; i++)
     {
        columns.add(new ArrayList<Number>());
     }


     for(final List<Object> li : data)
     {
        int col = 0;
        for(Object ci : li)
        {
           if(ci instanceof Number)
           {
              columns.get(col).add((Number) ci);
              col++;
           }
           else
           {
              try{
                 columns.get(col).add(Double.parseDouble(""+ci));
                 col++;
              }
              catch(NumberFormatException ex)
              {
              }

              catch(Exception ex)
              {
                 System.out.println("Can't plot  "+li+" "+ex.getMessage());
              }
           }
        }
     }


     TPlotPanel pp2 = new TPlotPanel();
     pp2.setName("NumLab");

    // final PlotPanel pp = new PlotPanel();
     Colors.initRandomReproducible();

     //System.out.println(""+npts+" lines, "+ncols+" columns");

     // Creates a serie per column

     final List<Number> columnX = columns.get(colx);

     boolean isSplitPerYearSuccessful = false;
     if(splitXPerYear)
     {
        System.out.println("Split per year");


        System.out.println("from "+ columnX.get(0));
        System.out.println("to "+ columnX.get(columnX.size()-1));

        Calendar c = GregorianCalendar.getInstance();
        c.setTimeInMillis( columnX.get(0).longValue() );

        int actualYear = c.get(Calendar.YEAR);
        System.out.println("start year = "+actualYear);

        final List<Integer> years = new ArrayList<Integer>();
        final List<List<Number>> splittedDateColumn = new ArrayList<List<Number>>();  // as day in year [1..365]  (idea: or [1.0..12.99] ?? )

        List<Number> actualSplit = new ArrayList<Number>();
        years.add(actualYear);
        splittedDateColumn.add(actualSplit);

        // first must be added
        actualSplit.add( c.get(Calendar.DAY_OF_YEAR));


        for(int i=1; i<columnX.size(); i++)
        {
           c.setTimeInMillis( columnX.get(i).longValue() );
           int y = c.get(Calendar.YEAR);
           if(y!=actualYear)
           {
              actualYear = y;

              //System.out.println("new year: "+c.getTime());
              actualSplit = new ArrayList<Number>();

              years.add(y);
              splittedDateColumn.add(actualSplit);

           }

           actualSplit.add( c.get(Calendar.DAY_OF_YEAR));


        }

        System.out.println("SPLITTED dates:");
        System.out.println("years: "+years);
        System.out.println("splitted: "+splittedDateColumn);
        System.out.println("columnX:"+columnX);

        // let's go.
        for(int i=0; i<columns.size(); i++)
        {
          if(colx==i)
          {
            continue;
          }
          if(i==0) continue;    // also ignore col0, self-generated, but may be helpful to track initial sorting, in some cases...


          final List<Number> columnY =columns.get(i);

          List<List<Number>>  splittedY = splitAccordingToPlan(columnY, splittedDateColumn);

          for(int s =0; s<splittedY.size(); s++)
          {
             List<Number> valy = splittedY.get(s);
             String title = "C"+i+" for year "+years.get(s);
             if(shiftToStartAtZero)
             {
                double s0 = valy.get(0).doubleValue();
                title += " (starts at "+s0+")";
                valy = shiftToStartAtZero(valy);
             }
/*
             pp.addElements(
                new PlotStyle(title, Colors.getRandomColorReproductible(), i==1 ? 1.0 : i*0.3),
                PlotUtils.multiline(splittedDateColumn.get(s), valy));*/

             ListPlotElement lpp = new ListPlotElement(title);
             lpp.setPoints( splittedDateColumn.get(s), valy, null );
             lpp.setLineStyle(Colors.getRandomColorReproductible(), 2);

             pp2.addPlotObjects( lpp);
          }
        }

        // don't plot the original data !
        isSplitPerYearSuccessful = true;

     }

     boolean isDate = false;

     if(!isSplitPerYearSuccessful)
     {
        for(int i=0; i<columns.size(); i++)
        {
          if(colx==i)
          {
            continue;
          }
          if(i==0) continue;    // also ignore col0, self-generated, but may be helpful to track initial sorting, in some cases...

          List<Number> valy = columns.get(i);
          String title = "C"+i;
          if(shiftToStartAtZero)
          {
             double s0 = valy.get(0).doubleValue();
             title += " (starts at "+s0+")";
             valy = shiftToStartAtZero(valy);
          }
/*
          pp.addElements(
              new PlotStyle(title, Colors.getRandomColorReproductible(), i==1 ? 1.0 : i*0.3),
              PlotUtils.multiline(columnX, valy));*/

             ListPlotElement lpp = new ListPlotElement(title);
             lpp.setPoints( columnX, valy, null );
             lpp.setLineStyle(Colors.getRandomColorReproductible(), 2);
             pp2.addPlotObjects(lpp);

        }

        if(columnX.get(0).longValue() > 1e8)
        {
           isDate = true;
        }

     }




     //pp.addElements(new PlotStyle("bounds", Color.lightGray, 0.1), pp.autoscale());


     /*pp.isXDate = isDate;
     pp.addCooordinatesFrame();

     JPanel wp = new JPanel(new BorderLayout());
     wp.add(pp, BorderLayout.CENTER);
     wp.add(pp.statusBar, BorderLayout.SOUTH);

     GUIUtils.displayInFrame(""+npts+" lines and "+(ncols-1)+" columns plot", wp, false).setSize(600, 450);
     EventQueue.invokeLater(new Runnable() { public void run() {
        pp.autoscale();
        //[2010]
        pp.viewPlotLegend();
     }});*/

     pp2.fitToScale();
     GUIUtils.displayInFrame(""+npts+" lines and "+(ncols-1)+" columns plot", pp2, false).setSize(600, 450);



  }


  static List<Number> shiftToStartAtZero(List<Number> data)
  {
     List<Number> ret = new ArrayList<Number>();
     double s = data.get(0).doubleValue();
     for(int i=0; i<data.size(); i++)
     {
        ret.add( data.get(i).doubleValue() - s);
     }
     return ret;
  }


  static List<List<Number>> splitAccordingToPlan( final List<Number> column,  final List<List<Number>> splits)
  {
     // absolute posision of splits
     final Set<Integer> as = new HashSet<Integer>();
     int p=0;
     for(List<Number> li : splits)
     {
        p+=li.size();
        as.add(p);
     }

     System.out.println("Absolute split positions: "+as);


     List<List<Number>> ret = new ArrayList<List<Number>>();
     List<Number> actualSplit = new ArrayList<Number>();
     ret.add(actualSplit);

     for(int i=0; i<column.size(); i++)
     {
        if(as.contains(i))
        {
          actualSplit = new ArrayList<Number>();
          ret.add(actualSplit);
        }

        actualSplit.add(column.get(i));
     }


     return ret;
  }



  /* Table model for the data display.
  */
  class TM extends FineGrainTableModel
  {
     final private String[] COLUMN_NAMES;
     final private ArrayList<ArrayList<Object>> data;

     public TM(String[] elementsPatterns, ArrayList<ArrayList<Object>> d)
     {
        this.COLUMN_NAMES = new String[elementsPatterns.length+1];
        this.COLUMN_NAMES[0] = "Index";
        System.arraycopy(elementsPatterns, 0, this.COLUMN_NAMES, 1, elementsPatterns.length);

        for(int i=1; i<COLUMN_NAMES.length; i++)
        {
           COLUMN_NAMES[i] = "C"+i+": "+COLUMN_NAMES[i];   // because unique names are required
        }

        this.data = d;
     }

     public void remove(ArrayList<ArrayList<Object>> rem)
     {
        this.fireTableModelWillChange();

        data.removeAll(rem);

        this.fireTableDataChanged();
        this.fireTableModelHasChanged();
     }

     public Object getValueAt(int row, int column)
     {
        if(row>=data.size()) return "row not exists: "+row;
        if(column>=data.get(row).size()) return "col not exist: "+column;

        Object val = data.get(row).get(column);
        if(val==null) return "<null>";
        return val;
     }

     public int getRowCount() { return data.size(); }

     @Override
     public String getColumnName(int column)
     {
        if(column>=0 && column<COLUMN_NAMES.length) return COLUMN_NAMES[column];
        return "Bad column "+column;
     }

     public int getColumnCount() { return COLUMN_NAMES.length; }
   }



}