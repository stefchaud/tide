/**
* Some "laboratory" utils.
* Helping one to filter, sort, plot, stats, visualize, ...
*/
package snow.lab;
