package snow.lab;

import snow.texteditor.AlternateLineHighlighter;
import tide.utils.SyntaxUtils;
import snow.utils.StringUtils;
import snow.utils.DateUtils;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import javax.swing.*;
import snow.utils.gui.*;

/** Data Laboratory... parse, filter, plot
*    sort
*  Todo: stats (histo & mean, median, ...)
*  Todo: scatter plot, label plot, ...
*/
public final class DataLab extends JFrame
{
  private final JTextArea in     = new JTextArea();
  private final JTextField columnAxisX = new JTextField("0", 3);
  private final JTextField replaceWithSpace = new JTextField(",;}{[]$", 6);
  // let user perform replacements ?
  private final JCheckBox useColForX   = new JCheckBox("use column as x axis", false);
  //private final JCheckBox ignoreLinePrefix = new JCheckBox("Ignore line prefix", false);
  private final JTextField takeEachLine = new JTextField("1", 2);
  final JCheckBox ignoreErrors = new JCheckBox("Ignore errors", true);
  final private JCheckBox transposeBefore = new JCheckBox("Transpose before parse", false);
  final private JCheckBox sortAfterParse = new JCheckBox("Sort Col 1", false);
  private final JCheckBox ignoreComments   = new JCheckBox("ignore comments", true);
  private final JCheckBox takeFirstRowAsColumnName   = new JCheckBox("column names from first row", true);


  // Simple convenient syntax
  //   example:   D S I for double, string, integer
  //              (D) for a skipped double
  //              P{pattern}  for a user defined pattern
  //              T{dateformat} parses a date in fixed width as in T{dd.MM.yyyy HH:mm:ss}
  //       T (todo) parse a date using some predefined formats


  private final JTextField formatTF = new JTextField("", 25);
    // "(Line\\d+)\\s+(\\d+)\\s+(\\d+)\\s*(\\d+)", 25);

  public void setText(String t)
  {
     in.setText(t);
  }

  public DataLab(boolean standalone)
  {
     super("DataLab (Parse, filter, plot, stats)");

     if(standalone)
     {
       setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

       try
       {
          in.append("Name\tAge\tClass");
          for(int i=0; i<100; i++)
          {
            in.append("\n"+(System.currentTimeMillis()+(long) (Math.random()*1000*DateUtils.oneDayMs)));
            in.append("\t"+i);
            in.append("\t"+Math.sin(i*0.5));
           // in.append("\t"+(char) ('A'+(int) (Math.random()*26)));
          }
          //formatTF.setText("T{dd.MM.yyyy} D10");
       }
       catch(Exception e) {
          e.printStackTrace();
       }
     }

     add(new JScrollPane(in), BorderLayout.CENTER);
     new AlternateLineHighlighter(in, new Color(0,0,10,10));


     JPanel controlPanel = new JPanel();
     controlPanel.setLayout(new BoxLayout(controlPanel, BoxLayout.Y_AXIS));

     JPanel control1 = new JPanel();
     controlPanel.add(control1);
     add(controlPanel, BorderLayout.SOUTH);

     useColForX.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
        columnAxisX.setEnabled(  useColForX.isSelected() );
     } });
     columnAxisX.setEnabled(false);

     control1.add(new JLabel("Decimation (take only each Nth-Pt):  "));
     control1.add(takeEachLine);

     //control1.add(new JLabel("Decimation (take only each Nth-Pt):  "));


     control1.add(sortAfterParse);
     control1.add(new JLabel("  Blank: "));
     control1.add(replaceWithSpace);
     //replaceWithSpace.setFont(GUIUtils.fontnew Font(""));

     JPanel control3 = new JPanel();
     controlPanel.add(control3);
     control3.add(ignoreComments);
     ignoreComments.setToolTipText("ignores line content after // and between /* and */");
     control3.add(transposeBefore);
     control3.add(takeFirstRowAsColumnName);

     JPanel control2 = new JPanel();
     controlPanel.add(control2);
     JButton doPlot = new JButton(" Scan ");
     GUIUtils.setIsMainDialogButton(doPlot);
     JLabel lab = new JLabel("Format: ");

     final String helpToolTip =
        "<html><body>S: string, D: double, I: integer, *: rest of line, P{regex pattern, with groups, acts on the rest}, T{DateFormat}.<br>"
        +"use () to ignore an item.<br>Multiplicities: D3 is a shortcut for \"D D D\"."
        +"<br>Let the field empty to guess the format (using T,D,I,S).";
     lab.setToolTipText(helpToolTip);
     control2.add(lab);

     final JButton help = GUIUtils.createMiniIconButton(Icons.createHelpIcon(16, true));
     help.setToolTipText(helpToolTip);
     control2.add(help);
     help.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent ae)
       {
          JPopupMenu pop = new JPopupMenu();
          pop.add(helpToolTip+"<p>Examples:<ul><li>(S2) S T{dd/MMM/yyyy HH:mm:ss} S2 *<li>I S D2</ul>");
          pop.show(help, 0, 0);
       }
     });

     control2.add(formatTF);
     control2.add(ignoreErrors);

     control2.add(doPlot);
     doPlot.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent ae)
       {
         try
         {
           scan();
         }
         catch(Exception e)
         {
           JOptionPane.showMessageDialog(DataLab.this, ""+e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
           //e.printStackTrace();
         }
       }
     });

     setSize(800, 600);
     this.setLocationRelativeTo(null);
     this.setVisible(true);
  }

  /** null if not found.
  *   lokks at line start (lenient). pos contains the parse end position
  */
  static /*@org.checkerframework.checker.nullness.qual.Nullable*/ String guessDateAndTimeAtBeginning(String line, ParsePosition pos)
  {
     //todo: System.getProperty("user.language") .equals("de") ??
     // because we overridden the locale in the startup ?
     // or loop over all locales
     // long first !!
     String[] tryFormats = new String[]{
        "EEE MMM dd HH:mm:ss yyyy",
        "dd.MMM.yyyy HH:mm:ss",
        "dd MMM yyyy HH:mm:ss",
        "MM-dd-yyyy HH:mm:ss",
        "MM/dd/yyyy HH:mm:ss",
        "dd.MM.yyyy HH:mm:ss",
        "dd.MMM.yyyy HH:mm",
        "dd.MM.yyyy"
     };

     for(String fi : tryFormats)
     {
       {
        SimpleDateFormat sfd = new SimpleDateFormat(fi, Locale.ENGLISH);
        Date d = sfd.parse(line, pos);
        if(d!=null) return sfd.toPattern();
       }

       if(Locale.getDefault()!=Locale.ENGLISH)
       {
        SimpleDateFormat sfd = new SimpleDateFormat(fi, Locale.getDefault());
        Date d = sfd.parse(line, pos);
        if(d!=null) return sfd.toPattern();
       }
     }


     return null;
  }

  /** Date only recognized at the beginning.
  *   Idea for caller: recognize structures for all lines and keep most occuring.
  *       elements always present => ()
  *   other idea: look at line 1 and line 2 and keep common start + "*"
  *
  */
  static String guessFormat(String line)
  {
     //System.out.println("searching format for "+line);

     final List<String> formatTokens = new ArrayList<String>();

     final ParsePosition pos = new ParsePosition(0);
     String tf = guessDateAndTimeAtBeginning(line, pos);
     if(tf!=null)
     {
         formatTokens.add("T{"+tf+"}");
         line = line.substring(pos.getIndex());
     }


     Scanner s = new Scanner(line);

     //todo: date at beginnng

     int n=0;
     while(s.hasNext())
     {

        if(s.hasNextInt())
        {
           formatTokens.add("I");
           s.nextInt();
        }
        else if(s.hasNextDouble())
        {
           formatTokens.add("D");
           s.nextDouble();
        }
        else
        {
           formatTokens.add("S");
           s.next();
        }

        // just a small security
        n++;
        if(n>100) break;
     }

     // merge multiplicities
     if(formatTokens.isEmpty()) return "*";

     String prev = formatTokens.get(formatTokens.size()-1);
     int mult = 1;
     for(int i=formatTokens.size()-2; i>=0; i--)
     {
        String ti = formatTokens.get(i);
        if(ti.equals(prev))
        {
           mult++;
           formatTokens.remove(i+1);
        }
        else
        {
           //not same.
           if(mult>1)
           {
              formatTokens.set(i+1, prev+mult);
           }
           mult=1;
        }

        prev = ti;
     }

     if(mult>1)
     {
        formatTokens.set(0, prev+mult);
     }

     if(formatTokens.size()>1)
     {
        if(formatTokens.get(formatTokens.size()-1).startsWith("S"))
        {
           formatTokens.set(formatTokens.size()-1, "*");
        }
     }


     StringBuilder f = new StringBuilder();
     for(String ti : formatTokens)
     {
         f.append(ti+" ");
     }

     String fmt = f.toString().trim();
     return fmt;
  }

/**  { s with replaced elts #$(i), and the replaced items }
*/
static List<String> replaceCurlBraceWithCode(String s)
{
   // idea: not made yet: replace if already #$(i) items !
   StringBuilder s0 = new StringBuilder(s);
   List<String> ret = new ArrayList<String>();
   int rep =1;
   for(int i=0; i<s.length(); i++)
   {
      if(s.charAt(i)=='{')
      {
         int ep = s.indexOf('}',i);
         if(ep<0) break; // nothing to do.
         ep++;

         String cont = s.substring(i,ep);
         //System.out.println("cc="+cont);
         s0.replace(i,ep,"#$("+rep+")");
         rep++;

         ret.add(cont);
      }
   }


   ret.add(0, s0.toString());

   return ret;
}

  /** I (S) D3 => {I, (S), D, D, D}
  */
  private static List<String> scanFormat(String str)
  {
     // tricky: allow spaces within { } brackets. important for time format T{ }
     // => temporary replace them with #$(1), #$(2), ...

     List<String> ret = replaceCurlBraceWithCode(str);

     final String[] elementsPatterns = ret.get(0).split("\\s");
     final List<String> elts = new ArrayList<String>();
     for(String pi : elementsPatterns)
     {
        if(ret.size()>1)
        {
           for(int i=1; i<ret.size(); i++)
           {
              pi = pi.replace("#$("+i+")", ret.get(i));
           }
        }

        // D123 => mult is 123
        int mult = 0;
        int order = 1;
        boolean ignored = pi.startsWith("(");

        if(ignored)
        {
           pi = pi.substring(1,pi.length()-1);
        }

        while(pi.length()>1 && Character.isDigit(pi.charAt(pi.length()-1)))
        {
           int di = Character.getNumericValue(pi.charAt(pi.length()-1));
           pi = pi.substring(0,pi.length()-1);
           mult += di*order;
           order*=10;
        }

        if(mult<=0) mult = 1;

        for(int i=0; i<mult; i++)
        {
           if(ignored)
           {
              elts.add("("+pi+")");
           }
           else
           {
              elts.add(pi);
           }
        }
     }

     return elts;
  }

  /** splits with the scanner and applies tabs
  */
@SuppressWarnings("unchecked")
  public static String transpose(String txt) throws Exception
  {
     BufferedReader br = new BufferedReader(new StringReader(txt));
     final ArrayList<ArrayList<Object>> data = new ArrayList<ArrayList<Object>>();
     String line = null;
     while((line=br.readLine())!=null)
     {
       ArrayList<Object> dataLine = new ArrayList<Object>();
       data.add(dataLine);
       Scanner s = new Scanner(line);
       while(s.hasNext())
       {
          dataLine.add(s.next());
       }
     }

     StringBuilder out = new StringBuilder();
     int nlines = data.size();
     int ncols = -1;

     for(int i=0; i<nlines; i++)
     {
        ncols = Math.max(data.get(i).size(), ncols );
     }

     //System.out.println("Nlines, ncols = "+nlines+", "+ncols);

     for(int i=0; i<ncols; i++)
     {
        for(int j=0; j<nlines; j++)
        {
           out.append("\t");
           if(data.size()>j && data.get(j).size()>i)
           {
             out.append(data.get(j).get(i));
           }
        }
        out.append("\r\n");
     }

     return out.toString();
  }


  @SuppressWarnings({"unchecked", "rawtypes", "nullness"})
  private void scan() throws Exception
  {

     String text = in.getText();
     // makes sense to perform first
     if(this.ignoreComments.isSelected())
     {
        text = SyntaxUtils.removeAllComments(text);
     }

     for(char ci : replaceWithSpace.getText().toCharArray())
     {
        text = text.replace(ci, ' ');
     }

     if(transposeBefore.isSelected())
     {
        text = transpose(text);
     }


     ArrayList<String> takenColNames = new ArrayList<String>();


     if(formatTF.getText().isEmpty())
     {
        String firsDatatLine = StringUtils.firstLine(text.trim());

        if(takeFirstRowAsColumnName.isSelected())
        {
           takenColNames.addAll( Arrays.asList(firsDatatLine.split("\\s")) );

           String tt = text.trim();
           int p = text.indexOf(firsDatatLine);
           tt = tt.substring(firsDatatLine.length()).trim();
           firsDatatLine = StringUtils.firstLine(tt);
        }

        formatTF.setText( guessFormat(firsDatatLine) );
     }

     final List<String> elementsPatterns = scanFormat(formatTF.getText());

     int ignoredErrs = 0;

     final BufferedReader br = new BufferedReader(new StringReader(text));
     final ArrayList<ArrayList<Object>> data = new ArrayList<ArrayList<Object>>();
     String line;

     boolean firstLine = true;

     int lineNb = 1;

     int decimation = 1;
     try
     {
       decimation = Integer.parseInt(takeEachLine.getText().trim());
     }
     catch(Exception ignore) {
     }

     if(decimation<1)
     {
       decimation = 1;
     }

     while((line=br.readLine())!=null)
     {
       final ArrayList<Object> dataLine = new ArrayList<Object>();
       dataLine.add(lineNb);

       lineNb++;

       if(lineNb % decimation != 0) continue;

       if(line.isEmpty()) continue;

       try
       {
          Scanner s = new Scanner(line);

          for(String pi : elementsPatterns)
          {
             if(pi.isEmpty()) continue;

             Object res = null;
             boolean ignore = pi.charAt(0)=='(' && pi.charAt(pi.length()-1)==')';
             if(ignore)
             {
                pi = pi.substring(1, pi.length()-1);
             }

             //pi = pi.toUpperCase();

             if(pi.equalsIgnoreCase("D"))
             {
                res = s.nextDouble();
             }
             else if(pi.equalsIgnoreCase("I"))
             {
                res = s.nextLong();
             }
             else if(pi.equalsIgnoreCase("S"))
             {
                res = s.next();
             }
             else if(pi.equalsIgnoreCase("*"))
             {
                res = s.nextLine().trim();
             }
             else if(pi.startsWith("P{"))  // strange...
             {
                // own convention::: look at the "rest" from now and returns the groups
                //  or the whole match
                Pattern pat = Pattern.compile(pi.substring(2,pi.length()-1));
                String rest = s.nextLine().trim();
                Matcher mat = pat.matcher(rest);

                if(mat.matches())
                {
                   //System.out.println("Groups: "+mat.groupCount());
                   if(mat.groupCount()==0)
                   {
                      res = mat.group();
                   }
                   else
                   {
                      final List<String> all = new ArrayList<String>();
                      for(int i=0; i<mat.groupCount(); i++)
                      {
                        all.add(mat.group(i+1));
                      }
                      System.out.println("   "+mat.groupCount()+" groups: "+all);
                      res = all;
                   }
                }
                else
                {
                   System.out.println("Pattern not found in line "+lineNb+": "+line+", rest="+rest);

                }

                //res = s.next(pat);
                //res = s.findInLine(pat);  // May2009


             }
             else if(pi.equalsIgnoreCase("T"))
             {
                //todo: be clever !
                ParsePosition pos = new ParsePosition(0);
                String n = s.nextLine();
                res = parseDate(n, null, pos);

                s = new Scanner(n.substring(pos.getIndex()));
             }
             else if(pi.startsWith("T{"))
             {
                // limitation: only works here for fixed width date formats, fails for dd.MMM.yyyy ! where month is of variable length ! (April, Mai)

                String df = pi.substring(2,pi.length()-1);

               // int len = df.length() + StringUtils.count(df, "Z")*2;  // Z => CET  (TRICKY UGLY)

                String rest = s.nextLine().trim();

                ParsePosition pos = new ParsePosition(0);
                res = parseDate(rest, df, pos);

                if(pos.getIndex()>=0)
                {
                  s = new Scanner(rest.substring(pos.getIndex()));
                }

                //System.out.println("Parsing date '"+df+"' in '"+ne+"'");
                //System.out.println("pos = "+pos.getIndex());
             }

             //warn
             if(res==null) System.out.println("res null for "+pi+": line "+lineNb+": "+line);


             if(ignore)
             {
                //System.out.println("Ignored: "+res);
             }
             else
             {
                //System.out.println("scanned: "+res);

                if(res instanceof Collection)
                {
                  Collection cr = (Collection) res;
                  dataLine.addAll(cr);

                  if(firstLine && !this.takeFirstRowAsColumnName.isSelected())
                  {
                     for(int i=0; i<cr.size(); i++)
                     {
                       takenColNames.add(pi+"_"+(i+1));
                     }
                  }
                }
                else
                {
                  dataLine.add(res);
                  if(firstLine)
                  {
                     if(!this.takeFirstRowAsColumnName.isSelected())
                     {
                       takenColNames.add(pi);
                     }
                  }
                }


             }
          }

          firstLine = false;

          data.add(dataLine);

          s.close();
       }
       catch(Exception err)
       {
          if(!ignoreErrors.isSelected())
          {
            err.printStackTrace();
            throw new Exception("Can't scan line "+lineNb+" \""+line+"\"\nerror: "+err.getMessage(), err);

          }
          else
          {
             ignoredErrs++;
             //System.out.println("Ignored error: "+err.getMessage());
          }
       }
     }

     if(sortAfterParse.isSelected())  // [Oct2009]
     {
        // sort according to the first "user" column. (0 is line number)

        // ArrayList<ArrayList<Object>>
        Collections.sort( data, new Comparator< ArrayList<Object>>()
        {
           public final boolean equals( final Object obj ) {
              return true;
           }

           public final int compare( final ArrayList<Object> o1, final ArrayList<Object> o2 ) {
              Object ob1 = o1.get(1); // 0 is line number
              Object ob2 = o2.get(1); // 0 is line number

              if(ob1 instanceof Comparable)
              {
                return ((Comparable) ob1).compareTo(ob2);
              }
              else
              {
                return (""+ob1).compareTo(""+ob2);
              }
           }


        } );


        // subtle: reassign the line numbers
        for(int i=0; i<data.size(); i++)
        {
           data.get(i).set(0,i+1);
        }
     }

     /*
     if(ignoredErrs>0)
     {
        System.out.println("DataExplorerTool Ignored errs: "+ignoredErrs);
     }*/

     new TableLab(this, data, takenColNames);

  }


  private long parseDate(final String txt, /*@org.checkerframework.checker.nullness.qual.Nullable*/ String format, final ParsePosition pos) throws ParseException
  {
     if(format==null)
     {
        //try and try...
        //TODO: be more clever, and try current locale AND english
        Date d = DateFormat.getDateTimeInstance().parse(txt, pos);
        if(d!=null) return d.getTime();

        d = DateFormat.getTimeInstance().parse(txt, pos);
        if(d!=null) return d.getTime();

        d = DateFormat.getDateInstance().parse(txt, pos);
        if(d!=null) return d.getTime();

        throw new ParseException(txt, pos.getErrorIndex());
     }

     //current locale
     Date d = new SimpleDateFormat(format).parse(txt, pos);
     if(d!=null) return d.getTime();


     d = new SimpleDateFormat(format, Locale.ENGLISH).parse(txt, pos);
     if(d!=null) return d.getTime();

     throw new ParseException(txt, pos.getErrorIndex());

  }

   static void test(){
      System.out.println(""+ replaceCurlBraceWithCode("D3 T{dd.MM.yyyy HH:mm} end") );
      System.out.println(""+scanFormat("D3 T{dd.MM.yyyy HH:mm}"));
   }

   static void test2(){
      SimpleDateFormat sdf = (SimpleDateFormat )SimpleDateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT, Locale.ENGLISH);
      System.out.println(""+ sdf.toPattern());
      System.out.println(""+sdf.format(new Date()));
   }



   public static void main(String[] args) throws Exception
   {
      EventQueue.invokeLater(new Runnable() { public void run() {
          new DataLab(true);
      }});

   }

}