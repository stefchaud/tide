package snow.lab;

import snow.crypto.SimpleFileEncryptor;
import javax.crypto.SecretKey;
import tide.editor.MainEditorFrame;
import snow.crypto.PassphraseDialog;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.*;
import java.io.*;
import java.util.Arrays;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import snow.files.JFileChooser2;
import snow.html.HTMLUtils;
import snow.text.*;
import snow.texteditor.*;
import snow.utils.gui.*;
import snow.utils.storage.FileUtils;
import tide.utils.B64;
import tide.utils.SyntaxUtils;
import tide.utils.Uglyfier;

/** String laboratory.
*  Converts to various formats.
*/
public final class StringLab extends JFrame {

// ** ideas
//  1) sort
//  2) trim
//  3) replace regex
//  4)

   SimpleDocument inDoc = new SimpleDocument();
   JTextPane inPane = new JTextPane(inDoc);
   JLabel statusIn = new JLabel("");

   SimpleDocument outDoc = new SimpleDocument();
   JTextPane outPane = new JTextPane(outDoc);
   JLabel statusOut = new JLabel("");

   JLabel globalStatus = new JLabel("");

/*
   private StringLab()
   {
      this(true);
   }*/

   public StringLab(boolean standalone)
   {
      super("String Lab (transforms In to Out)");
      if(standalone) this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      this.setSize(800,600);
      this.setLocationRelativeTo(null);

      JPanel pIn = new JPanel(new BorderLayout());
      pIn.add(statusIn, BorderLayout.SOUTH);
      pIn.add(new JScrollPane(inPane), BorderLayout.CENTER);

      JPanel pOut = new JPanel(new BorderLayout());
      pOut.add(statusOut, BorderLayout.SOUTH);
      pOut.add(new JScrollPane(outPane), BorderLayout.CENTER);

      final JSplitPane sp = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, pIn, pOut);
      add(sp, BorderLayout.CENTER);
      sp.setDividerLocation(400);

      add(globalStatus, BorderLayout.SOUTH);

      Color alc = new Color(0,0,10,10);
      new AlternateLineHighlighter(inPane, alc);
      new AlternateLineHighlighter(outPane, alc);

      defineOperations();

      //not necessary:
      //   add(new CloseControlPanel(this, false, false, "Close"), BorderLayout.SOUTH);


      // so we can drag & drop between both panes without using Ctrl+C & Ctrl+V
      inPane.setDragEnabled(true);
      outPane.setDragEnabled(true);

// javax.swing.plaf.basic.BasicTextUI$TextTransferHandler
//System.out.println("intrh="+ inPane.getTransferHandler());



      this.setVisible(true);
   }


   void createJavaCodePopup(JPopupMenu pop)
   {
      JMenuItem toJava = new JMenuItem("To Java String");
      pop.add(toJava);
      toJava.addActionListener( new ActionListener(){
         public final void actionPerformed( final ActionEvent e ) {
            String in = inPane.getText().trim();

            in = in.replace("\r\n", "\n");
            in = in.replace("\\", "\\\\");  // order matters !
            in = in.replace("\"", "\\\"");
            in = in.replace("\n", "\\n\"\n");
            in = in.replace("\t", "\\t");
            in = in.trim();

            // prepend all lines with "+"
            in = in.replace("\n", "\n + \"");

            if(!in.endsWith("\"") || in.endsWith("\\\""))   // tricky: not 100%, may fail with \\\\" ... => should count ending "\"
            {
               in += "\"";   // clean end
            }

            outPane.setText("String s =\n \""+in+";");
         }
      });

      JMenuItem toJavaL = new JMenuItem("To Java List");
      pop.add(toJavaL);
      toJavaL.addActionListener( new ActionListener(){
         public final void actionPerformed( final ActionEvent e ) {
            String in = inPane.getText().trim();

            in = in.replace("\r\n", "\n");
            in = in.replace("\\", "\\\\");  // order matters !
            in = in.replace("\"", "\\\"");
            in = in.replace("\n", "\"\n");
            in = in.replace("\t", "\\t");
            in = in.trim();

            // prepend all lines with ","
            in = in.replace("\n", ",\n \"");

            if(!in.endsWith("\"") || in.endsWith("\\\""))   // tricky: not 100%, may fail with \\\\" ... => should count ending "\"
            {
               in += "\"";   // clean end
            }

            outPane.setText("String[] s = {\n \""+in+"};");
         }
      });

      JMenuItem rc = new JMenuItem("Remove all comments");
      pop.add(rc);
      rc.addActionListener( new ActionListener(){
         public final void actionPerformed( final ActionEvent e ) {
            String in = inPane.getText();
            outPane.setText(SyntaxUtils.removeAllComments(in));
         }
      });


      JMenuItem uu = new JMenuItem("Uglify Java Code");
      uu.setToolTipText("A Joke: makes code unreadable. NOT robust, only a joke. Compile and decompile => restores 100% of the code.");
      pop.addSeparator();
      pop.add(uu);
      uu.addActionListener( new ActionListener(){
         public final void actionPerformed( final ActionEvent e ) {
            String in = inPane.getText();
            outPane.setText(Uglyfier.uglyfy(in));
         }
      });
      JMenuItem du = new JMenuItem("De-uglify Java Code");
      pop.add(du);
      du.addActionListener( new ActionListener(){
         public final void actionPerformed( final ActionEvent e ) {
            String in = inPane.getText();
            in = Uglyfier.replaceUnicodesSequences(in);
            in = SyntaxUtils.removeAllComments(in);
            outPane.setText(in.trim());
         }
      });

      // todo: d&d would be also good
      JMenuItem rf = new JMenuItem("Read file");
      pop.addSeparator();
      pop.add(rf);
      rf.addActionListener( new ActionListener(){
         public final void actionPerformed( final ActionEvent e ) {

            File f = new JFileChooser2(StringLab.this).title("Choose a text file to open").remember("SLab_open", null).chooseToOpen();
            if(f==null) return;

            try{
               String in = FileUtils.getFileStringContent(f);
               outPane.setText(in);
            }
            catch(Exception ex) {
               globalStatus.setText("Cannot read file: "+ex.getMessage());
               ex.printStackTrace();
            }
         }
      });

      JMenuItem tb64 = new JMenuItem("To Base64 (UTF-8)");
      pop.addSeparator();
      pop.add(tb64);
      tb64.addActionListener( new ActionListener()
      {
         public final void actionPerformed( final ActionEvent e )
         {
            try{
               String in = B64.encodeBase64(inPane.getText().getBytes("UTF-8"));
               outPane.setText(in.trim());
            }
            catch(Exception ex) {
               globalStatus.setText("Cannot convert to base64: "+ex.getMessage());
               ex.printStackTrace();
            }
         }
      });

      JMenuItem ffb64 = new JMenuItem("From Base64 (UTF-8)");
      //pop.addSeparator();
      pop.add(ffb64);
      ffb64.addActionListener( new ActionListener(){
         public final void actionPerformed( final ActionEvent e )
         {
            try
            {
               String ttt = inPane.getText();
               // maybe better: keep only valid chars ?
               ttt = ttt.replace("\r\n", "");
               ttt = ttt.replace("\n", "");
               String in = new String(B64.decodeBase64(ttt),"UTF-8");
               outPane.setText(in.trim());
            }
            catch(Exception ex) {
               globalStatus.setText("Cannot convert from base64: "+ex.getMessage());
               ex.printStackTrace();
            }
         }
      });

      JMenuItem fb64 = new JMenuItem("File to Base64");
      pop.addSeparator();
      pop.add(fb64);
      fb64.addActionListener( new ActionListener(){
         public final void actionPerformed( final ActionEvent e )
         {
            try
            {
               File f = new JFileChooser2(StringLab.this).title("Choose a file to open").remember("SLab_open", null).chooseToOpen();
               //File f = FileChooserFilter.choose AFile(StringLab.this,false,"Choose a file to open", "SLab_open", null, JFileChooser.FILES_ONLY,null );
               if(f==null) return;

               if(f.length()>1e5)
               {
                  int rep = JOptionPane.showConfirmDialog(StringLab.this,
                             "This is a big file.\nDo you want to write the results in a file ?", "To File ?", JOptionPane.YES_NO_CANCEL_OPTION);
                  if(rep==JOptionPane.CANCEL_OPTION) { return; }
                  if(rep==JOptionPane.YES_OPTION)
                  {
                     File fout = new JFileChooser2(StringLab.this).title("Choose a file to save to").remember("SLab_save", new File(f, ".b64")).chooseToSave();
                     if(fout==null) return;

                     FileUtils.saveToFile(B64.encodeBase64(FileUtils.getFileByteContent(f)), fout);
                     //ok
                     return;
                  }
               }

               String in = B64.encodeBase64(FileUtils.getFileByteContent(f));
               outPane.setText(in.trim());
            }
            catch(Exception ex) {
               globalStatus.setText("Cannot convert to base64: "+ex.getMessage());
               ex.printStackTrace();
            }
         }
      });

      JMenuItem ffb642 = new JMenuItem("From Base64 to bin file");
      //pop.addSeparator();
      pop.add(ffb642);
      ffb642.addActionListener( new ActionListener(){
         public final void actionPerformed( final ActionEvent e )
         {
            try
            {
               File fout = new JFileChooser2(StringLab.this)
                  .title("Choose a file to save to")
                  .remember("SLab_save", new File( "out.b64"))
                  .chooseToSave();
               if(fout==null) return;

               String ttt = inPane.getText();
               // maybe better: keep only valid chars ?
               ttt = ttt.replace("\r\n", "");
               ttt = ttt.replace("\n", "");
               FileUtils.saveBytesToFile(
                      B64.decodeBase64(ttt),
                      fout);
            }
            catch(Exception ex) {
               globalStatus.setText("Cannot convert from base64: "+ex.getMessage());
               ex.printStackTrace();
            }
         }
      });

      JMenuItem enc = new JMenuItem("Encrypt");
      pop.addSeparator();
      pop.add(enc);
      enc.addActionListener( new ActionListener(){
         public final void actionPerformed( final ActionEvent e )
         {
            try{
               PassphraseDialog pd = new PassphraseDialog(MainEditorFrame.getTopFrame(), "PP", true, null, "Passphrase to encode");
               if(pd.wasCancelled())
               {
                  return;
               }
               final SecretKey secretKey = pd.getKey();
               byte[] enc = SimpleFileEncryptor.encrypt(inPane.getText().getBytes("UTF-8"), secretKey);
               String in = B64.encodeBase64( enc);
               outPane.setText(in.trim());
            }
            catch(Exception ex) {
               globalStatus.setText("Cannot convert to base64: "+ex.getMessage());
               ex.printStackTrace();
            }
         }
      });

      JMenuItem dec = new JMenuItem("Decrypt");

      pop.add(dec);
      pop.addSeparator();
      dec.addActionListener( new ActionListener(){
         public final void actionPerformed( final ActionEvent e )
         {
            try
            {
               String ttt = inPane.getText();
               // maybe better: keep only valid chars ?
               ttt = ttt.replace("\r\n", "");
               ttt = ttt.replace("\n", "");
               byte[] enc = B64.decodeBase64(ttt);

               PassphraseDialog pd = new PassphraseDialog(MainEditorFrame.getTopFrame(), "PP", true,
                    SimpleFileEncryptor.getKeyIDFromStream(new ByteArrayInputStream(enc)) ,
                    "Passphrase to decode");

               if(pd.wasCancelled())
               {
                  return;
               }
               final SecretKey secretKey = pd.getKey();
               final byte[] dec = SimpleFileEncryptor.decryptToMem(new ByteArrayInputStream(enc), secretKey, 128, null);

               outPane.setText( new String(dec, "UTF-8"));
            }
            catch(Exception ex) {
               globalStatus.setText("Cannot convert to base64: "+ex.getMessage());
               ex.printStackTrace();
            }

         }
      });

      /*todo
      JMenuItem cc = new JMenuItem("Count chars", Icons.sharedStat);
      pop.addSeparator();
      pop.add(cc);
      cc.addActionListener( new ActionListener(){
         public final void actionPerformed( final ActionEvent e ) {
            // todo
         }
      });
      JMenuItem cw = new JMenuItem("Count words", Icons.sharedStat);
      pop.add(cw);
      cw.addActionListener( new ActionListener(){
         public final void actionPerformed( final ActionEvent e ) {
            // todo
         }
      });
*/

      JMenuItem ss = new JMenuItem("Split");
      pop.add(ss);
      ss.addActionListener( new ActionListener(){
         public final void actionPerformed( final ActionEvent e )
         {
            String rep = JOptionPane.showInputDialog(StringLab.this, "Split pattern (Regex)", ",");
            if(rep==null) return;

            String ttt = inPane.getText();
            try
            {
               String[] sss = ttt.split(rep);
               globalStatus.setText("In splitted in "+sss.length+" parts");
               outPane.setText("");
               for(String li : sss)
               {
                 outDoc.appendLine(li);
               }
            }
            catch(final Exception ex) {
               ex.printStackTrace();
               globalStatus.setText("Cannot split: "+ex.getMessage());
            }
         }
      });


      JMenuItem so = new JMenuItem("Sort lines");
      pop.add(so);
      so.addActionListener( new ActionListener(){
         public final void actionPerformed( final ActionEvent e )
         {
              String ttt = inPane.getText();
              String[] sss = ttt.split("\n");
              globalStatus.setText(""+sss.length+" sorted lines");
              Arrays.sort(sss);
              outPane.setText("");
              for(String li : sss)
              {
                outDoc.appendLine(li);
              }
         }
      });


      JMenuItem tl = new JMenuItem("Trim lines");
      pop.add(tl);
      tl.addActionListener( new ActionListener(){
         public final void actionPerformed( final ActionEvent e )
         {
              String ttt = inPane.getText();
              String[] sss = ttt.split("\n");
              globalStatus.setText(""+sss.length+" trimmed lines");
              outPane.setText("");
              for(String li : sss)
              {
                outDoc.appendLine(li.trim());
              }
         }
      });

   }


   void defineOperations()
   {
      JPanel cp = new JPanel();
      JPanel np = new JPanel(new BorderLayout());
      np.add(cp, BorderLayout.NORTH);
      add(np, BorderLayout.NORTH);

      JPanel lrPan = new JPanel();
      lrPan.setBorder(new EmptyBorder(2,2,2,2));
      np.add(lrPan, BorderLayout.CENTER);
      lrPan.setLayout(new BoxLayout(lrPan, BoxLayout.X_AXIS));
      lrPan.add(Box.createHorizontalGlue());
      lrPan.add(new JLabel("In"));
      lrPan.add(Box.createHorizontalGlue());
      JButton reverse = new JButton("< Replace In with Out <");
      GUIUtils.makeSmall(reverse);
      lrPan.add(reverse);

      JButton diff = new JButton(" diffs ", Icons.sharedDiffTool);
      GUIUtils.makeSmall(diff);
      diff.setToolTipText("Press Shift to see diffs at char level");
      lrPan.add(Box.createHorizontalStrut(10));
      lrPan.add(diff);
      diff.addActionListener( new ActionListener(){
         public final void actionPerformed( final ActionEvent e ) {


            String in = inPane.getText();
            String out = outPane.getText();


            if(GUIUtils.isShiftDown(e))
            {
               // char diff

               LcsString seq = new LcsString(in, out);

               System.out.println("LCS: "+seq.getLcsLength());
               System.out.println("Edit Dist: "+seq.getMinEditDistance());
               System.out.println("Backtrack: "+seq.backtrack());
               //System.out.println("HTML Diff: "+seq.getHtmlDiff());

               GUIUtils.displayInFrame("diffs, dist="+seq.getMinEditDistance(), new JScrollPane(GUIUtils.createReadOnlyDescriptionArea(
               "<html>"
               //+"<head><style type=\"text/css\">\n.remove {color: red;}\n.add {color: green; font-weight: bold;}\n</style></head>"
               +"<head><style type=\"text/css\">\n.remove {background: #ffdcff; color: red;}\n.add {background: #ccffcc; color: green;}\n</style></head>"
               +"<body>"+seq.getHtmlDiff())), false);
            }
            else
            {
               // ignoring indentations
               LcsTextPerLine seq = new LcsTextPerLine(in, out, true);

               System.out.println("LCS: "+seq.getLcsLength());
               System.out.println("Edit Dist: "+seq.getMinEditDistance());
               System.out.println("Backtrack: "+seq.backtrack());
               //System.out.println("HTML Diff: "+seq.getHtmlDiff());

               GUIUtils.displayInFrame("diffs (LCS without indents), dist="+seq.getMinEditDistance(), new JScrollPane(GUIUtils.createReadOnlyDescriptionArea(
               "<html>"
               +"<head><style type=\"text/css\">\n.remove {background: #ffdcff; color: red;}\n.add {background: #ccffcc; color: green;}\n</style></head>"
               //+"<head><style type=\"text/css\">\n.remove {color: red;}\n.add {color: green; font-weight: bold;}\n</style></head>"
               +"<body>"+seq.getHtmlDiff())), false);
            }
         }
      });


      lrPan.add(Box.createHorizontalGlue());
      lrPan.add(new JLabel("Out"));
      lrPan.add(Box.createHorizontalGlue());

      reverse.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
         inDoc.setText(outDoc.getText());
      } });



      final JButton javaCodeOps = new JButton("Code Ops...");
      GUIUtils.makeSmall(javaCodeOps);
      cp.add(javaCodeOps);
      javaCodeOps.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
          JPopupMenu pop = new JPopupMenu();
          createJavaCodePopup(pop);
          pop.show(javaCodeOps, 0, javaCodeOps.getHeight());
      } });

      cp.add(Box.createHorizontalStrut(10));

      JButton toHtml = new JButton(" To HTML ");
      toHtml.setToolTipText("Press shift to see it");
      GUIUtils.makeSmall(toHtml);
      cp.add(toHtml);
      toHtml.addActionListener( new ActionListener(){
         public final void actionPerformed( final ActionEvent e ) {
            String in = inPane.getText();
            in = HTMLUtils.convertCharsToHTML(in);

            in = in.replace("<br><br>", " <p> \n");
            in = in.replace("\t", " &nbsp; &nbsp; ");    // ?? wrap "<pre>" or "<code>" on the line ??
            in = in.replace("<br>", " <br> \n");
            outPane.setText("<html><body>\n"+in+"\n</body></html>");

            if((e.getModifiers() & ActionEvent.SHIFT_MASK) == ActionEvent.SHIFT_MASK)
            {
               // tricky: html renderer don't like "\n" it fails !!!
              JOptionPane.showMessageDialog(StringLab.this, "<html>"+in.replace("\n", ""));
            }
         }
      });

      JButton ru = new JButton(" Evaluate unicode ");
      ru.setToolTipText("replace \\uXXXX with the character");
      GUIUtils.makeSmall(ru);
      cp.add(ru);
      ru.addActionListener( new ActionListener(){
         public final void actionPerformed( final ActionEvent e ) {
            String in = inPane.getText();
            outPane.setText(Uglyfier.replaceUnicodesSequences(in));
         }
      });


      JButton tr = new JButton(" Transpose ");
      GUIUtils.makeSmall(tr);
      cp.add(tr);
      tr.addActionListener( new ActionListener(){
         public final void actionPerformed( final ActionEvent e ) {
            String in = inPane.getText();
            try
            {
              outPane.setText(DataLab.transpose(in));
            }catch(Exception ex) {
               globalStatus.setText("Cannot transpose: "+ex.getMessage());
               ex.printStackTrace();
            }
         }
      });

      //useful for example to remove line numbers at each line start on code from some html presentation view
      JButton rc = new JButton(" Remove Column ");
      GUIUtils.makeSmall(rc);
      cp.add(rc);
      rc.addActionListener( new ActionListener(){
         public final void actionPerformed( final ActionEvent e ) {
            String in = inPane.getText();
            StringBuilder out = new StringBuilder();

            int n = 1; //todo: ask !
            try
            {
              BufferedReader br = new BufferedReader(new StringReader(in));
              String li = null;
              while((li=br.readLine())!=null)
              {
                 if(li.length()<n)
                 {
                    out.append(li+"\n");
                 }
                 else
                 {
                    out.append(li.substring(n)+"\n");
                 }
              }
              // remove last LF
              if(!in.endsWith("\n") && out.length()>0)
              {
                 out.setLength(out.length()-1);
              }

              outPane.setText(""+out);
            }catch(Exception ex) {
               globalStatus.setText("Cannot remove column: "+ex.getMessage());
               ex.printStackTrace();
            }
         }
      });
   }

   public void setText(String t)
   {
      inPane.setText(t);
   }

   public static void main(String[] args) throws Exception {
      //JOptionPane.showMessageDialog(null, "<html>Hallo&nbsp;<br>line<p>and pa.");
      //if(true) return;

      EventQueue.invokeLater(new Runnable() { public void run() {
               StringLab sl = new StringLab(true);
               sl.setText("test \"1\" und {2}\noder x=32\t33\t34.\nand another line !");
      }});





   }

}