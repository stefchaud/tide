package snow.datatransfer;

import java.awt.image.BufferedImage;
import snow.utils.gui.ImageUtils;
import java.awt.EventQueue;
import tide.editor.MainEditorFrame;
import snow.texteditor.SimpleEditor;
import java.util.*;
import java.awt.datatransfer.*;
import java.awt.Toolkit;

/** Also offers a simple clipboard history.
*/
public final class ClipboardUtils implements FlavorListener
{
  //String a = null;
  private final ArrayList<String> history = new ArrayList<String>();   // used: setSize()

  // singleton
  private static /*@org.checkerframework.checker.nullness.qual.Nullable*/ ClipboardUtils clipboardUtils;


  private ClipboardUtils()
  {

     EventQueue.invokeLater(new Runnable() { public void run() {

       if(!MainEditorFrame.hasInstance()) return;

       if(!MainEditorFrame.getInstance().listenToClipboard.isSelected()) return;

       Toolkit.getDefaultToolkit().getSystemClipboard().addFlavorListener(ClipboardUtils.this);
     }});

     //System.out.println("ClipboardUtils initialized");
/*
     if(Toolkit.getDefaultToolkit().getSystemSelection()!=null)
     {
        Toolkit.getDefaultToolkit().getSystemSelection().addFlavorListener(new FlavorListener()
        {
           public final void flavorsChanged( final FlavorEvent fe ) {
              System.out.println("SystemSelection: "+fe);
           }
        });
        System.out.println("ClipboardUtils also listen to system selection");
     }*/
  }

  public synchronized static ClipboardUtils getInstance()
  {
     if(clipboardUtils==null) clipboardUtils = new ClipboardUtils();
     return clipboardUtils;
  }

  public synchronized static void stop()
  {
     clipboardUtils = null;
  }

  public List<String> getHistory() { return this.history; }

  public void clearHistory() { history.clear(); }
  private void addToHistory(String txt)
  {
     //System.out.println("Clip Add to hist: "+txt);

     synchronized(history)
     {
        if(history.contains(txt))
        {
           // move at first place
           history.remove(txt);
        }

        history.add(0, txt);

        if(history.size()>20)
        {
           history.remove(history.size()-1);
           //history.setSize(20);
        }
     }
  }

  /** From system clipboard, occurs when CTRL+C is pressed somewhere in the whole system !
  *  excel, word, OR tIDE (not CTRL+C, but right-click + copy) !
  *    java.awt.datatransfer.FlavorEvent[source=sun.awt.windows.WClipboard@1959352]
  */
  public void flavorsChanged(FlavorEvent _fe)
  {
     if(!MainEditorFrame.getInstance().listenToClipboard.isSelected()) return;

     //System.out.println("Clip flavorsChanged: "+_fe);
     Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
     Transferable content = null;

     for(int ti=0; ti<2; ti++) // [Jan2007] try again...
     {
        try
        {
           content = clipboard.getContents(this);  // Note: requestor is not used
        }
        catch(IllegalStateException e)
        {
          // The method throws IllegalStateException if the clipboard is currently unavailable.
          //  For example, on some platforms, the system clipboard is unavailable while it is accessed by another application.
          //e.printStackTrace();
          //  retry later...
          try{ Thread.sleep(700); } catch(Exception exi) {}
        }
     }

     if(content!=null && content.isDataFlavorSupported(DataFlavor.stringFlavor))
     {
       try
       {
         String cont = (String) content.getTransferData(DataFlavor.stringFlavor);
         addToHistory(cont);
         // success
         return;
       }
       catch(Exception e)
       {
         e.printStackTrace();
       }
       catch(Error e)
       {
          // MAYBE OUT OF MEMORY
          e.printStackTrace();
       }
     }
  }

  // general utils

  @SuppressWarnings("nullness")
  public static void copyToClipboard(String txt)
  {
     if(txt==null) return;
     //getInstance().add(txt);
     //Toolkit.getDefaultToolkit().getSystemClipboard().setContents( new TransferableText(txt), null);
     Toolkit.getDefaultToolkit().getSystemClipboard().setContents( new StringSelection(txt), null);

     //Remark: comes in the history through the listener above !!
     // but one may "help"
     getInstance().addToHistory(txt);
  }

  public static void copyToClipboard(BufferedImage bim)
  {
      ImageUtils.copyToClipboard(bim);
  }

  public static String getClipboardStringContent()
  {
     Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
     Transferable content = clipboard.getContents(clipboard);  // note: requestor is not used.
     if(content.isDataFlavorSupported(DataFlavor.stringFlavor))
     {
       try
       {
         return ""+ content.getTransferData(DataFlavor.stringFlavor);
       }
       catch(Exception e)
       {
         return "error: "+e.getMessage();
       }
     }
     else
     {
       System.out.println("nothing to paste !");
       return "";
     }
  }


  //test
  private void standaloneTRunTest() throws Exception
  {
     getInstance().addToHistory("Hallo");
     new SimpleEditor(null, "Simple Editor", true, true);
  }



}