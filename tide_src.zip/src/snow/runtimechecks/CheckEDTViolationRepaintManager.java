package snow.runtimechecks;

/** class .
*/

import java.util.*;
import javax.swing.*;

// Adapted from the Troubleshooting Guide for JavaTM SE 6 DesktopTechnologies.
//  December 2006

/** Checks that the calls to the swing methods are in the EDT.
*
*  Usage: call
*    CheckEDTViolationRepaintManager.installRuntimeChecker();
*  a summary print will appear at the end
*
* [Sep2011]: renamed
*   CheckEDTViolationRepaintManager
*/
public class CheckEDTViolationRepaintManager extends RepaintManager
{

    // it is recommended to pass the complete check
    private boolean completeCheck = true;

    final Map<String, Integer> alreadyShown = new HashMap<String, Integer>();
    private int badCallsOutsideProject = 0;
    private int repaintsFromSwing = 0;

    // put here the names of the root packages of your project, with the ending dot.
    final public HashSet<String> projectPackagesStartWith = new HashSet<String>(Arrays.asList("tide.", "snow."));

    // exact match is used...
    final public HashSet<String> allowedMethodNamesCallingRepaint = new HashSet<String>(Arrays.asList(
      "imageUpdate", "insertString",
      "setCharacterAttributes", "setText"));


    public static void installRuntimeChecker()
    {
       RepaintManager.setCurrentManager(new CheckEDTViolationRepaintManager());
    }


    public CheckEDTViolationRepaintManager() {

        Runtime.getRuntime().addShutdownHook(new Thread()
        {
           public void run()
           {
              System.out.println("\n=====RepaintManager EDT Check:\n  badCallsOutsideProject="+badCallsOutsideProject);
              System.out.println("  repaintsFromSwing: "+repaintsFromSwing);

              System.out.println("  "+alreadyShown.size()+" distinct bad calls from project:");
              for(String bc : alreadyShown.keySet())
              {
                System.out.println("\tat "+bc+": "+alreadyShown.get(bc));
              }
           }
        });
    }

@Override
    public synchronized void addInvalidComponent(JComponent component) {
        checkThreadViolations(component);
        // use delegatee instead of super for *all* methods
        super.addInvalidComponent(component);
    }

    public boolean isCompleteCheck() {
        return completeCheck;
    }

    public void setCompleteCheck(boolean completeCheck) {
        this.completeCheck = completeCheck;
    }

@Override
    public void addDirtyRegion(JComponent component, int x, int y, int w, int h) {
        checkThreadViolations(component);
        super.addDirtyRegion(component, x, y, w, h);
    }

    /** this one causes exceptions when replacing textpane content in (SSafe checkout)
    */
@Override
    public void validateInvalidComponents() {
       super.validateInvalidComponents();
    }

@SuppressWarnings("unboxing")
    private void checkThreadViolations(JComponent c)
    {
        if (!SwingUtilities.isEventDispatchThread() && (completeCheck || c.isShowing())) {
            Throwable exception = new Throwable();
            boolean repaint = false;
            boolean fromSwing = false;
            StackTraceElement[] stackTrace = exception.getStackTrace();
            StackTraceElement firstInProject = null;
            for (StackTraceElement st : stackTrace)
            {
                if (repaint && st.getClassName().startsWith("javax.swing.")) {
                    fromSwing = true;
                }
                if ("repaint".equals(st.getMethodName())) {
                    repaint = true;
                }

                if(repaint && allowedMethodNamesCallingRepaint.contains(st.getMethodName())) return;

                if(firstInProject==null)
                {
                  for(String sw : projectPackagesStartWith)
                  {
                    if( st.getClassName().startsWith(sw))
                    {
                       firstInProject = st;
                       break;
                    }
                  }
                }
            }
            if (repaint && !fromSwing)
            {
                //no problems here, since repaint() is thread safe
                repaintsFromSwing++;
                return;
            }


            if(firstInProject==null)
            {
               badCallsOutsideProject++;
               // don't print them !
               return;
            }
            else if( alreadyShown.containsKey(""+firstInProject))
            {
               // show only once but count
               Integer val = alreadyShown.get(""+firstInProject);
               alreadyShown.put(""+firstInProject, val+1);
               return;
            }
            else
            {
               alreadyShown.put(""+firstInProject, 1);
               // show the first immediately:
               exception.printStackTrace();
            }

        }
    }
}