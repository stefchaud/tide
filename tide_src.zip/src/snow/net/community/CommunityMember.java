package snow.net.community;

import snow.sortabletable.TableRow;


/** Represents a detected member of this small test community
*    along with some optional informations as speed test results.
*/
public final class CommunityMember implements TableRow
{
   // @Implements("TableRow")
   public final Object getValueForColumn( final int col ) {
      if(col==0) return pName;
      if(col==1) return ip;

      if(col==2)
      {
         if(replyMicroSec==-1) return "";
         if(replyMicroSec==-2) return "wait...";
         if(replyMicroSec==-3) return "error";
         return (int)Math.round(replyMicroSec*1e-3);
      }

      if(col==3)
      {
        if(speedMbitPerSec==-1) return "";
        if(speedMbitPerSec==-2) return "wait...";
        if(speedMbitPerSec==-3) return "error";
        return (int)Math.round(speedMbitPerSec);
      }

      return "?col"+col;
   }

   String pName;
   String ip;
   long since;
   //boolean alive;

   long replyMicroSec = -1;
   double speedMbitPerSec = -1;

   @Override public final boolean equals( Object obj ) {
      CommunityMember m2 = (CommunityMember) obj;
      CommunityMember m1 = this;

      if (!m1.pName.equals(m2.pName)) return false;
      if (!m1.ip.equals(m2.ip)) return false;

      return true;
   }

   @Override public final int hashCode( ) {
      return pName.hashCode();
   }

}