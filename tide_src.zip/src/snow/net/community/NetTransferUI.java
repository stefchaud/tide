package snow.net.community;

import java.awt.EventQueue;
import snow.texteditor.SimpleDocument;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.awt.BorderLayout;
import java.awt.event.*;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CancellationException;
import javax.swing.*;
import snow.io.StreamUtils;
import snow.sortabletable.*;
import snow.utils.NetUtils;
import snow.utils.SysUtils;
import snow.utils.gui.GUIUtils;
import snow.utils.gui.Icons;
import snow.utils.gui.JGridPanel;
import snow.utils.gui.ProgressModalDialog;
import snow.utils.storage.FileUtils;
import tide.editor.MainEditorFrame;
import tide.editor.TideUtils;

/** Peer to peer mechanism to transfer files
*  UI added in the tCom frame
*/
public final class NetTransferUI
{

   final static File transferroot = new File(System.getProperty("user.home"), ".tide_global/tcom/");

   final public static File offeredFolder = new File(transferroot, "offered");
   final static File downloadedFolder = new File(transferroot, "downloaded");



   // offered files
   final private JPanel localFilesPanel = new JPanel(new BorderLayout());

   // downloaded files
   final private JPanel downloadedFilesPanel = new JPanel(new BorderLayout());

   final FineGrainTableModelBuilder<OFile> offeredFiles = new FineGrainTableModelBuilder<OFile>(3);

   private ServerSocket ss = null;


   static class OFile implements TableRow
   {
      final File f;
      OFile(File f)
      {
         this.f = f;
      }

      // @Implements("TableRow")
      public final Object getValueForColumn( final int col ) {
         if(col==0) return f.getName();
         if(col==1) return new Date(f.lastModified());
         if(col==2) return FileUtils.formatSize(f.length());

         return null;  //TODO
      }

      @Override public int hashCode()
      {
         return f.hashCode();
      }

      @Override public final String toString() {
         return f.getName();
      }

      @Override public boolean equals(Object o2)
      {
         return ((OFile) o2).f.equals(f);
      }
   }


   static class RFile implements TableRow
   {
      final String name;
      final Date lastMod;
      final long size;

      RFile(final String name, final long lastMod, final long size)
      {
         this.name = name;
         this.lastMod = new Date(lastMod);
         this.size = size;
      }

      public final Object getValueForColumn( final int col ) {
         if(col==0) return name;
         if(col==1) return lastMod;
         if(col==2) return FileUtils.formatSize(size);

         return null;
      }

      @Override public final String toString() {
         StringBuilder sb = new StringBuilder();
         sb.append("File "+name+", length="+size+", lastmod="+lastMod);
         return sb.toString();
      }
   }

   final SimpleDocument log;

   /** Constructor. */
   public NetTransferUI(SimpleDocument log)
   {
      this.log = log;
      createLocalFilesPanel();
      createDownloadedFilesPanel();
   }


   /**
   */
   private void createLocalFilesPanel()
   {
      offeredFiles.setColumnNames("File name", "Last-mod", "Size");

      localFilesPanel.add(offeredFiles.createView().getJPanel(), BorderLayout.CENTER);

      localFilesPanel.add(new JLabel("Local files in "+offeredFolder), BorderLayout.NORTH);

      final JTextField portField = new JTextField("8080", 4);
      portField.setMaximumSize(portField.getPreferredSize());
      final JButton startOffering = new JButton("Start offering files", Icons.rssIcon(18));
      final JButton stop = new JButton("Stop", Icons.sharedStop);
      stop.setEnabled(false);

      final JButton opts = new JButton("Opts", Icons.sharedTriDownIcon);
      opts.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         JPopupMenu pop = new JPopupMenu();
         JMenuItem omi = new JMenuItem("Open offered folder", Icons.sharedSystemFolder);
         pop.add(omi);
         omi.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
            if(!offeredFolder.exists())
            {
               offeredFolder.mkdirs();
            }
            SysUtils.openFileExplorer( offeredFolder );
         } });

         JMenuItem odi = new JMenuItem("Open download folder", Icons.sharedSystemFolder);
         pop.add(odi);
         odi.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
            if(! downloadedFolder.exists())
            {
               downloadedFolder.mkdirs();
            }
            SysUtils.openFileExplorer( downloadedFolder );
         } });

         JMenuItem ref = new JMenuItem("Refresh offered files", Icons.sharedWiz);
         pop.add(ref);
         ref.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
            refreshOfferedFiles();
         }});

         JMenuItem dd = new JMenuItem("Download...", Icons.sharedDownload);
         pop.add(dd);
         dd.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
            downloadDialog(null);
         }});

         JMenuItem oft = new JMenuItem("Offer actual tide.jar");
         pop.add(oft);
         oft.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
            File tj = TideUtils.getTideJarMaybeFromPreviousRun();
            if(tj!=null && tj.exists())
            {
               // copy !
               if(!offeredFolder.exists()) offeredFolder.mkdirs();
               File dest = new File(offeredFolder, "tide.jar");
               if(dest.exists())
               {
                  if(dest.lastModified() > tj.lastModified())
                  {
                     JOptionPane.showMessageDialog(null, "The offered version is newer, you should actualize", "Newer version", JOptionPane.WARNING_MESSAGE);
                     return;
                  }
                  dest.delete();
               }

               try
               {
                  FileUtils.copy( tj, dest);
               }
               catch(final Exception e) {
                  e.printStackTrace();
               }
            }

            refreshOfferedFiles();
         }});

         pop.show(opts, 0, opts.getHeight());
      } });


//no effect portField.setAlignmentY(0.28f);
      localFilesPanel.add(GUIUtils.addSmallComponentsToLine(10,0, startOffering, " on port ", portField, 2, stop, 4, opts,0,10), BorderLayout.SOUTH);


      startOffering.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae)
      {
         try
         {
            log.appendBoldLine("starting server on port "+portField.getText());
            offerFiles( Integer.parseInt(portField.getText()) );
            stop.setEnabled(true);
         }
         catch(final Exception e)
         {
             log.appendErrorLine("failed to start server: "+e.getMessage());
             JOptionPane.showMessageDialog(null, "Can't offer files on port "+portField.getText()+"\nerr="+e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
             e.printStackTrace();
         }
      } });

      stop.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         stop.setEnabled(false);
         stopIfRunning();
      }});

      refreshOfferedFiles();
   }

   void downloadDialog(String from)
   {
      if(!this.downloadedFolder.exists())
      {
         this.downloadedFolder.mkdirs();
      }

      JGridPanel gp = new JGridPanel(2);
      final JTextField host = new JTextField( from!=null ? from : "localhost");
      final JTextField port = new JTextField("8080");
      gp.getGridLayout().addExplanationArea("Connect to another tIDE instance on the local network");
      gp.addG("host");
      gp.addG(host);
      gp.addG("port");
      gp.addG(port);

      int rep = JOptionPane.showOptionDialog(null, gp, "tConnect",
         JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null,
         new Object[]{"Connect", "Cancel"}, "Connect");

      if(rep!=0) return;

      try
      {

         final Socket s = new Socket();
         s.connect(new InetSocketAddress(
            host.getText().trim(), Integer.parseInt(port.getText().trim())
         ), 2000); // 2 seconds

         final DataInputStream dis = new DataInputStream(s.getInputStream());
         final DataOutputStream dos = new DataOutputStream(s.getOutputStream());
         dos.writeUTF("dir");
         dos.flush();

         int nFiles = dis.readInt();
         //System.out.println(""+nFiles+" files");
         log.appendLine(""+nFiles+" files offered");

         final FineGrainTableModelBuilder<RFile> tmb = new FineGrainTableModelBuilder<RFile>(3);
         tmb.setColumnNames("File", "Last-mod", "Size");

         for(int i=0; i<nFiles; i++)
         {
            tmb.addRows(new RFile(dis.readUTF(), dis.readLong(), dis.readLong()));
         }

         //FineGrainTableModelBuilder<RFile>.
         STView<RFile> view = tmb.createView();

         rep = JOptionPane.showOptionDialog(null, view.getJPanel(), "tConnect",
            JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null,
            new Object[]{"Download selected", "Cancel"}, "Download selected");

         if(rep!=0) return;

         // selected
         @SuppressWarnings("unchecked")
         final List<RFile> list = view.getSelected();
         for(RFile ri : list)
         {
            final Socket ns = new Socket();
            ns.connect(
               new InetSocketAddress( host.getText().trim(), Integer.parseInt(port.getText().trim()) ),
               1000);

            download(ri, ns);
         }
      }
      catch(Exception e)
      {
         JOptionPane.showMessageDialog(null, ""+e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
         e.printStackTrace();
      }
   }

   void stopIfRunning()
   {
         if(ss!=null && !ss.isClosed())
         {
            System.out.println("tCom: stopping...");
            log.appendBoldLine("stopping server");
            try{
              ss.close();
            }
            catch(final Exception e) {
               e.printStackTrace();
            }
         }
         else
         {
              log.appendWarningLine("nothing to stop");

         }


   }


   /** downloads the given file
   *
   */
   void download(final RFile f, final Socket s)
   {
      // (the server side runs the handleIncomingConnection with "get")
      log.appendLine("Download "+f+" from "+s);

      final ProgressModalDialog pmd = new ProgressModalDialog(MainEditorFrame.getTopFrame(), "Download "+f.name, false);
      pmd.setShowPause(true);
      pmd.start();
      Thread t = new Thread()
      {
         public void run()
         {
               try
               {
                  //System.out.println("download "+f.name+" from "+s.getInetAddress());

                  final DataInputStream dis = new DataInputStream(s.getInputStream());
                  final DataOutputStream dos = new DataOutputStream(s.getOutputStream());
                  dos.writeUTF("get");
                  dos.writeUTF(f.name);
                  dos.flush();

                  String reply = dis.readUTF();
                  if(!"ok".equalsIgnoreCase(reply))
                  {
                     System.out.println("tCom: FAILURE!"+reply);
                     throw new RuntimeException("can't download: "+reply);
                  }

                  //System.out.println("reading "+ f.size+" bytes");

                  File file = new File(downloadedFolder, f.name);

                  BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file));

                  long start = System.currentTimeMillis();

                  try{

                     byte[] buf = new byte[1024];
                     long totRead=0;
                     int read = -1;

                     while((read=dis.read(buf))!=-1)
                     {
                       if(pmd.getWasCancelled()) throw new CancellationException("Download cancelled");
                       pmd.pauseIfNeeded();

                       bos.write( buf,0,read);
                       totRead+=read;

                       pmd.setProgressValue( (int)(100*(totRead*1.0/f.size)), NetUtils.formatNetSpeed(totRead, System.currentTimeMillis()-start));

                     }
                     bos.flush();
                     // out log
                     System.out.println("tCom: download done, read "+totRead+" bytes for "+f);
                  }
                  finally
                  {
                     bos.close();
                     s.close();
                  }

                  long dt = System.currentTimeMillis() -start;

                  log.println("   downoad done for "+f);
                  log.println("   duration "+dt+" ms");
                  log.println("   speed="+  NetUtils.formatNetSpeed(f.size, dt));
                  file.setLastModified( f.lastMod.getTime());


               }
               catch(Exception e) {
                  System.out.println("tCom: download failed: "+e.getMessage());
                  System.out.println("   file: "+f);
                  e.printStackTrace();
               }
               finally
               {
                  pmd.closeDialog();
               }
         }
      };
      t.start();
   }





   void refreshOfferedFiles()
   {
       if(!offeredFolder.exists()) return;

       List<OFile> actual = new ArrayList<OFile>();
       for(File fi : offeredFolder.listFiles())
       {
          if(fi.isFile())
          {
             if(fi.getName().equalsIgnoreCase(".ds_store")) continue;
             actual.add(new OFile(fi));
          }
       }
       //System.out.println("tCom: "+actual.size()+" files to offer");
       offeredFiles.setAll_RAW( actual );
       offeredFiles.fireTableModelHasChanged();

   }



   private void offerFiles(final int port) throws Exception
   {
      ss = new ServerSocket(port);

      Thread t = new Thread()
      {
         public void run()
         {
            while(!ss.isClosed())
            {
               try
               {
                 final Socket so = ss.accept();
                 System.out.println("tCom: incoming connection: "+so);
                 EventQueue.invokeLater(new Runnable() { public void run() {
                    log.appendLine("incoming connection: "+so);

                 }});
                 handleIncomingConnection(so);

               }
               catch(final SocketException e) {
                  if(ss.isClosed()) return;
                  e.printStackTrace();
               }
               catch(final IOException e) {
                  if(ss.isClosed()) return;
                  e.printStackTrace();
               }
            }
         }
      };
      t.start();

   }


   void handleIncomingConnection(final Socket so)
   {
      Thread t = new Thread()
      {
         public void run()
         {
            try{
               // only one at a time
                DataInputStream dis = new DataInputStream(so.getInputStream());
                DataOutputStream dos = new DataOutputStream(so.getOutputStream());

                String cmd = dis.readUTF();
                log.appendLine("incoming cmd: "+cmd);
                if("dir".equals(cmd))
                {
                   List<OFile> of = offeredFiles.getRowsCopy();
                   log.appendLine(""+of.size()+" offered files");
                   dos.writeInt(of.size());

                   for(OFile o : of)
                   {
                      dos.writeUTF(o.f.getName());
                      dos.writeLong(o.f.lastModified());
                      dos.writeLong(o.f.length());
                   }

                   dos.flush();

                }
                else if("get".equals(cmd))
                {
                   List<OFile> of = offeredFiles.getRowsCopy();
                   String name = dis.readUTF();
                   for(OFile o : of)
                   {
                      if(o.f.getName().equalsIgnoreCase(name))
                      {
                         dos.writeUTF("ok");
                         // dos.writeLong(o.f.length());

                         BufferedInputStream bis = new BufferedInputStream(new FileInputStream(o.f));
                         try
                         {
                            long wrote = StreamUtils.copy(bis, dos);
                            log.appendLine("send done, wrote "+wrote+" bytes");
                         }
                         finally
                         {
                            dos.flush();
                            bis.close();

                            //[2014-04] needed !
                            dos.close();
                         }
                         log.appendLine("send done.");

                         return;
                      }
                   }
                   log.appendLine("requested file not found");
                   dos.writeUTF("not found");
                   dos.flush();

                }
            }
            catch(Exception e) {
               e.printStackTrace();
            }
         }
      };
      t.start();
   }

   public JPanel getLocalFilesPanel()
   {
      return localFilesPanel;
   }

   private void createDownloadedFilesPanel()
   {
      downloadedFilesPanel.add(new JLabel("Downloaded files in "+downloadedFolder), BorderLayout.NORTH);
   }


   static JComponent test()
   {
      SimpleDocument log = new SimpleDocument();
      NetTransferUI nt = new NetTransferUI(log);
      JTabbedPane t = new JTabbedPane();
      t.addTab("offered", Icons.rssIcon(18), nt.getLocalFilesPanel());
      t.addTab("log", Icons.consoleIcon(18,18,true, ">"), log.createView(false).getView());
      return t;
   }


   public static void main(String[] args) throws Exception
   {

      CommunityUI.main(args);
   }


}