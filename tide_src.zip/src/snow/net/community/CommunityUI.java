package snow.net.community;

import tide.Version;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Window;
import java.awt.event.*;
import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.util.*;
import javax.swing.*;
import snow.net.ConTest;
import snow.sortabletable.*;
import snow.texteditor.SimpleDocument;
import snow.texteditor.SimpleDocumentView;
import snow.utils.gui.GUIUtils;
import snow.utils.gui.Icons;
import tide.editor.MainEditorFrame;

/** Network test (multicast).
*   Announciates and listen to responses...
*/
public final class CommunityUI extends JDialog implements CommunityListener
{
   final FineGrainTableModelBuilder<CommunityMember> ftmb = new FineGrainTableModelBuilder<CommunityMember>(Annunciator.getInstance().members, 4);
   {
      ftmb.setColumnNames("Hostname", "IP", "hello send/answer [ms]", "speed [Mbit/s]");
   }
   final SortableTableModel stm = new SortableTableModel(ftmb);
   final JTable table = new JTable(stm);

   SimpleDocument doc = new SimpleDocument();

   JTabbedPane tabs = new JTabbedPane();

   final SimpleDocument logDoc = new SimpleDocument();

   final NetTransferUI netTransfer = new NetTransferUI(logDoc);

   SimpleDocument notesDoc = new SimpleDocument();

   // not so important
   static CommunityUI lastRef = null;

   public static String getLastNotes()
   {
      if(lastRef==null) return "not available.";
      return lastRef.notesDoc.getText();
   }



   // @Implements("CommunityListener")
   public final void memberAnnounce( final CommunityMember m )
   {
      refreshListUI();
   }


   void refreshListUI()
   {
      ftmb.addRows();
   }


   public CommunityUI( Window p)
   {
      super( p==null ? MainEditorFrame.getTopFrame() : p, "tCom", JDialog.ModalityType.MODELESS);

      lastRef = this;
      Annunciator.getInstance().setLogDoc(logDoc);

      Annunciator.getInstance().addCommunityListener(this);

      stm.installGUI(table);

      JTextPane explanationPane = new JTextPane();
      explanationPane.setEditable(false);

      final JPanel mcastPanel = new JPanel(new BorderLayout());
      mcastPanel.add(new JScrollPane(table), BorderLayout.CENTER);

      tabs.addTab("Info", new JScrollPane(explanationPane));
      tabs.addTab("Connections", Icons.sharedNetworkIcon, mcastPanel);
      tabs.addTab("Sharing", Icons.rssIcon(18), netTransfer.getLocalFilesPanel());
      final SimpleDocumentView ldv = logDoc.createView(false);
      tabs.addTab("Log", Icons.consoleIcon(18,18,true, ">"), ldv.getView());

      tabs.addTab("Notes", Icons.textFile(16), createNotesPanel());


      add(tabs, BorderLayout.CENTER);

      new UniversalTableCellRenderer(stm, table);

      JPanel cpan = new JPanel();
      mcastPanel.add(cpan, BorderLayout.SOUTH);

      JButton clear = GUIUtils.makeSmall( new JButton("clear list", Icons.sharedBlueCross) );
      cpan.add(clear);
      clear.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         Annunciator.getInstance().members.clear();
         refreshListUI();
      } });

      JButton check = GUIUtils.makeSmall( new JButton("discover") );
      check.setToolTipText("Emits a multicast and listen to responses ("+Annunciator.multicast_IP+" : "+Annunciator.port+")");
      cpan.add(check);
      check.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         discover();
      } });

      JButton add1 = GUIUtils.makeSmall( new JButton("add host manually") );
      add1.setToolTipText("Add a new host manually (use only if the multicast didn't worked)");
      cpan.add(add1);
      add1.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         addOneCustom();
      } });

      // some infos

      explanationPane.setDocument(doc);
      try
      {
        doc.appendLine("Computer name: "+System.getenv("COMPUTERNAME")); // null on linux !
        InetAddress local = InetAddress.getLocalHost();
        doc.appendLine("InetAddress.getLocalHost(): "+local); // "localhost" on linux,  computername/ip on windows

        final Enumeration<NetworkInterface> nilist = NetworkInterface.getNetworkInterfaces();

        doc.appendLine("\nNetwork Interfaces (without loopback and empty):");

        while (nilist.hasMoreElements())
        {
          final NetworkInterface ni = nilist.nextElement();
          //if(ni.isLoopback()) continue;

          List<InterfaceAddress> iad = ni.getInterfaceAddresses();
          if(iad==null) continue;
          if(iad.isEmpty())
          {
             continue;
          }

          doc.appendBoldLine("\nNI "+ni.getDisplayName()+" ("+iad.size()+" adds)");
          for(InterfaceAddress ai : iad)
          {
             doc.append("   Ad: "+ai.getAddress());
             if(ai.getBroadcast()!=null)
             {
               doc.append( "\t\tbroadcast: "+ai.getBroadcast());
             }
             doc.appendLine("");
          }
        }
      }
      catch(final Exception e) {
        e.printStackTrace();
                  logDoc.appendErrorLine("Cannot enumerate network interfaces: "+e.getMessage());

      }
      explanationPane.setCaretPosition(0);

      //pack();
      setSize(600, 600);
      setLocationRelativeTo(null);
      setVisible(true);

      // UI

      table.addMouseListener(new MouseAdapter() {
        @Override public void mousePressed(MouseEvent me)
        {
           if(me.isPopupTrigger())
           {
              showPopup(me);
           }
        }
        @Override public void mouseReleased(MouseEvent me)
        {
           if(me.isPopupTrigger())
           {
              showPopup(me);
           }
        }
      });

      this.addWindowListener(new WindowAdapter()
      {
         @Override public final void windowClosing( final WindowEvent e ) {
            stop();
         }

         @Override public final void windowClosed( final WindowEvent e ) {
            stop();
         }

         void stop()
         {
            netTransfer.stopIfRunning();
         }
      });

      discover();

      if(!ConTest.serverStarted.get())
      {
         new Thread() { public void run()
         {
          try
          {
             new ConTest().startServer();
          }
          catch(final Exception e)
          {
             EventQueue.invokeLater(new Runnable() { public void run() {
                 String mess = "Cannot start connection test server (ServerSocket, not fatal)\n"+e.getMessage();
                 doc.appendErrorLine(mess);
                 JOptionPane.showMessageDialog(CommunityUI.this, mess, "Warning",
                       JOptionPane.WARNING_MESSAGE);
             }});

             logDoc.appendErrorLine("Cannot start server: "+e.getMessage());
             e.printStackTrace();
          }
         }}.start();
      }
   }


   void addOneCustom()
   {
      final String rep = JOptionPane.showInputDialog(this, "Please enter the custom tide IP location...", "remote tIDE", JOptionPane.QUESTION_MESSAGE);

      if(rep==null) return;

      try
      {
         Annunciator.getInstance().sendCustomDiscovererTo(InetAddress.getByName(rep));
      }
      catch(final Exception e) {
                   logDoc.appendErrorLine("Cannot announce: "+e.getMessage());

         e.printStackTrace();
      }
   }

   JPanel createNotesPanel()
   {
      JPanel cp = new JPanel(new BorderLayout());
      notesDoc.appendLine("This content is shared, the remote tCom can fetch the content");
      cp.add(notesDoc.createView(true).getView(), BorderLayout.CENTER);
      return cp;
   }


   void showPopup(MouseEvent me)
   {
      final List<CommunityMember> sel = ftmb.getSelectedItems(table, stm);
      if(sel.isEmpty()) return;
      if(sel.size()!=1) return;

      final CommunityMember cm = sel.get(0);

      final JPopupMenu pop = new JPopupMenu();


      JMenuItem spt = new JMenuItem("Test Speed to "+cm.pName, Icons.sharedWiz);
      pop.add(spt);
      spt.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {

         cm.replyMicroSec = -2;  // wait...
         cm.speedMbitPerSec = -2;
         refreshListUI();

         new Thread(){ public void run() {
            testSpeed(cm);
         }}.start();

      } });

      JMenuItem dwn = new JMenuItem("Download offered files from "+cm.pName, Icons.sharedDownload);
      pop.add(dwn);
      dwn.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         netTransfer.downloadDialog(cm.pName);
      }});


      JMenuItem viewtv = new JMenuItem("View tIDE version "+cm.pName, Icons.sharedSmallStart);
      pop.add(viewtv);
      viewtv.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae)
      {
         try
         {
            InetAddress ad = InetAddress.getByName(cm.ip);
            String ver = ConTest.getTideVersion(ad);
            JOptionPane.showMessageDialog(table,
               "Remote version: "+ver
               +"\nLocal version: "+Version._VERSION
               , "tide version of "+ad, JOptionPane.INFORMATION_MESSAGE);
         }
         catch(final Exception e) {
          logDoc.appendErrorLine("Cannot see version: "+e.getMessage());

            JOptionPane.showMessageDialog(table, ""+e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
         }
      }});

      JMenuItem gn = new JMenuItem("Get notes "+cm.pName, Icons.sharedSmallStart);
      pop.add(gn);
      gn.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae)
      {
         try
         {
            InetAddress ad = InetAddress.getByName(cm.ip);
            String nnn = ConTest.getNotes(ad);
            notesDoc.setText(nnn);
         }
         catch(final Exception e) {
          logDoc.appendErrorLine("Cannot see notes: "+e.getMessage());

            JOptionPane.showMessageDialog(table, ""+e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
         }
      }});

      pop.show(table, me.getX(), me.getY());
   }


   void testSpeed(final CommunityMember cm)
   {
       try{
          long t = ConTest.testQuickReplyNanos(InetAddress.getByName(cm.ip));
          cm.replyMicroSec = t/1000;
       }
       catch(final Exception e) {
          e.printStackTrace();
          cm.replyMicroSec = -3;
          logDoc.appendErrorLine("Cannot test speed quick: "+e.getMessage());
       }
       refreshListUI();

       try{
          double t = ConTest.testSpeedMbitPersec(InetAddress.getByName(cm.ip));
          cm.speedMbitPerSec = t;
       }
       catch(final Exception e) {
          e.printStackTrace();
          cm.speedMbitPerSec = -3;

          logDoc.appendErrorLine("Cannot test speed: "+e.getMessage());
       }

       refreshListUI();
   }


   void discover()
   {
       new Thread(){
          public void run()
          {
            Annunciator.discoverer(logDoc);
          }
       }.start();
   }



   public static void main(String[] args) throws Exception
   {
      // creates and annunciate
      Annunciator.getInstance();

      EventQueue.invokeLater(new Runnable() { public void run() {
             new CommunityUI(null);
      }});

   }

}