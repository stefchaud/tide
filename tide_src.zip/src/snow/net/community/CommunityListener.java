package snow.net.community;

/**
*/
public interface CommunityListener
{
   void memberAnnounce(CommunityMember m);

}