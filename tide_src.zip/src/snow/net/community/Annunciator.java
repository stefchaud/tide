package snow.net.community;

import snow.utils.NetUtils;
import snow.utils.storage.FileUtils;
import snow.texteditor.SimpleDocument;
import javax.swing.JOptionPane;
import java.io.IOException;
import java.net.*;
import java.util.*;

/** Multicast annunciator and discover mechanism.
*/
public final class Annunciator
{
   private static class SingletonHolder {
      private static final Annunciator instance = new Annunciator();
   }

   public final List<CommunityMember> members = new ArrayList<CommunityMember>();

   private Annunciator()
   {
      try{
        startAnnunciatorOnAllInterfaces();
      }
      catch(final Exception e) {
         logDoc.appendErrorLine("Cannot announce: "+e.getMessage());
        e.printStackTrace();
      }
   }

   public static Annunciator getInstance() {
      return SingletonHolder.instance;
   }

   // Params::
   public static int port = 4449;

   // Multicast
   public static String discover_id = "tide_discovery";
   public static String reply_id = "tide_reply";

   public static String multicast_IP = "230.0.0.3";
   public static InetAddress address = null;

   public SimpleDocument logDoc = new SimpleDocument();

   public void setLogDoc(SimpleDocument newLogDoc)
   {
      if(logDoc.getLength()>0)
      {
         // don't loose diagnostics
         newLogDoc.appendLine( logDoc.getText( )) ;
      }
      logDoc = newLogDoc;
   }


//not used now
//   List<InetAddress> myAddresses = new ArrayList<InetAddress>();

   List<CommunityListener> listeners = new ArrayList<CommunityListener>();
   void addCommunityListener(CommunityListener cl)
   {
      listeners.add(cl);
   }


   void startAnnunciatorOnAllInterfaces() throws Exception
   {
        address = InetAddress.getByName(multicast_IP);

        Enumeration<NetworkInterface> nilist = NetworkInterface.getNetworkInterfaces();
        while (nilist.hasMoreElements())
        {
          final NetworkInterface ni = nilist.nextElement();

          if (ni.isLoopback())
            continue;

          if (ni.isPointToPoint())
            continue;

          if (ni.isVirtual())
            continue;
/*
          Enumeration<InetAddress> ads = ni.getInetAddresses();
          while(ads.hasMoreElements()) {
              myAddresses.add(  ads.nextElement() );
          }; */

// typicall: my wireless network
if(!ni.isUp()) continue;


          new Thread() { public void run()  {
             try
             {
                startAnnunciator(ni);
             }
             catch (Exception e)
             {
                e.printStackTrace();
             }
          }}.start();

          // just for outputs
          try{ Thread.sleep(100); } catch(InterruptedException ex) { break; }

        }

        //System.out.println("myAddresses: "+myAddresses);
   }


   void startAnnunciator(final NetworkInterface ni) throws Exception
   {
      System.out.println("tCom: Starting Annunciator on "+ni);

      MulticastSocket socket = null;

      try
      {
      socket = new MulticastSocket(port);
      InetSocketAddress addr = new InetSocketAddress(multicast_IP, port);
      socket.joinGroup(addr, ni);

      logDoc.println("joined "+addr);

      DatagramPacket packet;

      logDoc.println("listening for UDP multicasts");

      while (true)
      {
        byte[] buf = new byte[1024];
        packet = new DatagramPacket(buf, buf.length);
        socket.receive(packet);          // blocks
        final InetAddress clientAddress = packet.getAddress();
        final String received = new String(packet.getData(), 0, packet.getLength(), "UTF-8");

        logDoc.println("message from "+clientAddress+": '"+received+"'");

        if (discover_id.equals(received))
        {
           addToList(clientAddress);
           sendReplyTo(clientAddress);
        }
        else if (reply_id.equals(received))
        {
           addToList(clientAddress);
        }
        else
        {
           logDoc.println("OTHER RECEIVED: "+received);
        }
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    finally
    {
      if (socket != null)
      {
        try
        {
          socket.leaveGroup(address);
        }
        catch (Exception e2)
        {
          // ignore
        }
        socket.close();
      }
    }
   }


  private void addToList(final InetAddress clientAddress)
  {
           CommunityMember m = new CommunityMember();

           m.ip = clientAddress.getHostAddress();
           m.pName = clientAddress.getCanonicalHostName();

           if(!members.contains(m))
           {
             members.add(m);
             for(CommunityListener cl : listeners)
             {
                cl.memberAnnounce(m);
             }
           }
  }

  private void sendReplyTo(final InetAddress clientAddress)
  {
    if(clientAddress.isLinkLocalAddress())
    {
      System.out.println("is local.");
      return;
    }

    DatagramSocket socket = null;
    try
    {
      socket = new DatagramSocket();

      byte[] buf = reply_id.toString().getBytes("UTF-8");
      DatagramPacket packet = new DatagramPacket(buf, 0, buf.length, clientAddress, port);

      logDoc.println("sending unicast udp reply to "+clientAddress); //+": "+this.reply);

      socket.send(packet);
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
    finally
    {
      if (socket != null)
        socket.close();
    }
  }


  /** for manual multicasts
  */
  public void sendCustomDiscovererTo(final InetAddress clientAddress)
  {
    if(clientAddress.isLinkLocalAddress())
    {
      System.out.println("is local.");
      return;
    }

    DatagramSocket socket = null;
    try
    {
      socket = new DatagramSocket();

      byte[] buf = discover_id.toString().getBytes("UTF-8");
      DatagramPacket packet = new DatagramPacket(buf, 0, buf.length, clientAddress, port);

      logDoc.println("sending unicast udp discover to "+clientAddress); //+": "+this.reply);

      socket.send(packet);
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
    finally
    {
      if (socket != null)
        socket.close();
    }
  }



  /** For manual trigerred discoveries.
  */
  public static void discoverer(SimpleDocument logDoc)
   {
     System.out.println("tCom: Discovering instances");
     logDoc.appendLine("Discovering instances");

     try
     {

       final Enumeration<NetworkInterface> nilist = NetworkInterface.getNetworkInterfaces();
       while (nilist.hasMoreElements())
       {
         NetworkInterface ni = nilist.nextElement();

         if (ni.isLoopback())
           continue;

         if (ni.isPointToPoint())
           continue;

         if (ni.isVirtual())
           continue;

         if(!ni.isUp()) continue;

         MulticastSocket socket = null;
         final InetAddress group = InetAddress.getByName(Annunciator.multicast_IP);
         try
         {
           logDoc.appendLine("Announcing ");
           socket = new MulticastSocket();
           socket.setTimeToLive(50);  // NOT A TIME :-)
           InetSocketAddress addr = new InetSocketAddress(group, 0);
           socket.setNetworkInterface(ni);

           logDoc.println(" Issuing multicast discovery request on "+ni.getDisplayName());

           try{ Thread.sleep(100); } catch(InterruptedException ex) { ; }

           // construct request
           final byte[] buf = Annunciator.discover_id.getBytes("UTF-8");

           // send it
           final DatagramPacket packet = new DatagramPacket(buf, buf.length, group, Annunciator.port);
           socket.send(packet);

           // wait some seconds for the replies
           try
           {
             Thread.sleep(300);
           }
           catch (InterruptedException e)
           {
             // continue
           }
         }
         catch (IOException e)
         {
            logDoc.appendErrorLine("Cannot announce: "+e.getMessage());
            e.printStackTrace();
         }
         finally
         {
            NetUtils.closeIgnoringExceptions(socket);
         }
       }
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
   }



   public static void main(String[] args) throws Exception
   {
       getInstance();

       JOptionPane.showMessageDialog(null, "Running...", "Annunciator", JOptionPane.INFORMATION_MESSAGE);
       System.exit(0);
   }

}