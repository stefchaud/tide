/** Multicast service announce/discovery basic system.
*   *EXPERIMENTAL*
*   Named here "community" as it serves to build up a system of collaborating instances in a network.
 *  It can also be used localhost, but then fails to work if the network adapter is unplugged / not present.
 *  Mechanisms as jUnique with message passing is better if the goal is to limit to one instance per machine.
 *
 *  Furthermore, i didn't manage to limit the mechanism to localhost, therefore all instances are discovered in the network !
 *
 * Discoveries:
 *
 *   Localhost has 1GBitPerSec /only/ and is generally slower to answer to hello !!  (why?)
 *   Localhost in linux seems 4 times faster (?)
 *   Multicast doesn't work in greater companies intranet... (switch configuration)
 *
 */
package snow.net.community;
