package snow.net;

import tide.Version;
import snow.net.community.CommunityUI;
import tide.editor.MainEditorFrame;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.*;
import java.util.Arrays;
import java.io.*;
import java.net.*;
import java.net.ServerSocket;

/** Test Network connections (latency, speed, ...)
*
*  Linux:    configure iptables to let TCP on port 1236
*               let UDP on 4449
*               use "system-config-securitylevel"
*/
public final class ConTest
{
   public final static int testServerPort = 1236;

   public static AtomicBoolean serverStarted = new AtomicBoolean(false);


   public ConTest()
   {
   }



   /** Strange: also localhost has 1 second !!
   *   It's not a good indication of connection speed / latency.
   *  -1: not available under 2 seconds or any other problem.
   */
   static int getSmallestIsReachableTime(InetAddress to)
   {
      try
      {
         List<Integer> ts = Arrays.asList(10,50,100,200,500,900,1000,1100,2000);
         for(int ti : ts)
         {
            if(to.isReachable(ti)) return ti;
         }
      }
      catch(final Exception e) {
         e.printStackTrace();
      }

      return -1;
   }

/** details:
Subtle: InetAddress.get(localhost) gives localhost
  InetAddress.getLocalhost NOT
*/

   /** Receiving 5 seconds of stream.
   *   Local speed = 1344 Mbps  ( workstat quadcore and laptop core2)
   *   Local speed eee: 377 Mbps
   *   home net with powerlan: 1Mbps
   *   LAN Network:  94 Mbps
   */
   public static double testSpeedMbitPersec(InetAddress to) throws Exception
   {
      System.out.println("test connection to "+to);

      long t00 = System.currentTimeMillis();

      final Socket s = new Socket(); //to, 1236);
      s.connect(new InetSocketAddress(to, 1236), 1000);


      BufferedInputStream bis = new BufferedInputStream(s.getInputStream());

      System.out.println("SSS");
      s.getOutputStream().write("speed\n".getBytes("utf-8"));
      s.getOutputStream().flush();

      long conTime = System.currentTimeMillis()-t00;
      System.out.println("conTime="+conTime+" ms");


      long t0 = System.currentTimeMillis();

      byte[] b = new byte[128];
      long len = 0;
      while(true)
      {
         int r = bis.read(b);
         if(r==-1) break;

         len+=r;
      }

      long dt = System.currentTimeMillis()-t0;

      System.out.println("read "+len+" bytes in "+dt+" ms");
      double sp = len/(dt*1e-3);
      System.out.println("Speed = "+(int) (sp*1e-3)+" kB per sec");
      System.out.println("Speed = "+(int) (8.0*sp*1e-6)+" Mbps");

      s.shutdownInput();
      s.close();

      return 8.0*sp*1e-6;

   }

   /**
   *   A custom ping (connecting and exchanging the "ping\n" string)
   */
   public static long testQuickReplyNanos(InetAddress to) throws Exception
   {
      System.out.println("test custom ping to "+to);

    //  int st = getSmallestIsReachableTime(to);
    //  System.out.println("Smallest reachable delay: "+st);

      long t0 = System.nanoTime();

      final Socket s = new Socket(); //to, 1236);
      s.connect(new InetSocketAddress(to, 1236), 1000);
      final BufferedReader bis = new BufferedReader(new InputStreamReader( s.getInputStream(), "utf-8" ));
      s.getOutputStream().write("ping\n".getBytes("utf-8"));
      s.getOutputStream().flush();

      String reply = bis.readLine();

      long dt = System.nanoTime()-t0;

      System.out.println("Reply: "+reply+" in "+(int) (dt*1e-6)+" ms");

      s.shutdownInput();
      s.close();

      return dt;

   }


   /**
   *
   */
   public static String getTideVersion(InetAddress to) throws Exception
   {
      final Socket s = new Socket(); //to, 1236);
      s.connect(new InetSocketAddress(to, 1236), 1000);
      final BufferedReader bis = new BufferedReader(new InputStreamReader( s.getInputStream(), "utf-8" ));
      s.getOutputStream().write("tideversion\n".getBytes("utf-8"));
      s.getOutputStream().flush();
      String reply = bis.readLine();
      s.shutdownInput();
      s.close();

      return reply;
   }


   public static String getNotes(InetAddress to) throws Exception
   {
      final Socket s = new Socket(); //to, 1236);
      s.connect(new InetSocketAddress(to, 1236), 1000);
      final BufferedReader bis = new BufferedReader(new InputStreamReader( s.getInputStream(), "utf-8" ));
      s.getOutputStream().write("notes\n".getBytes("utf-8"));
      s.getOutputStream().flush();

      DataInputStream dis = new DataInputStream(s.getInputStream());
      int len = dis.readInt();
      System.out.println("reading test");

      byte[] ret = new byte[len];
      dis.readFully(ret);
      //String reply = bis.read.readLine();

      s.shutdownInput();
      s.close();

      return new String(ret, "utf-8");
   }


   /** Installs a server socket to serve incoming test connection requests
   */
   public void startServer() throws Exception
   {
      ServerSocket ss = new ServerSocket(testServerPort, 0, null);  // auto: + all local

      System.out.println("tCom: ServerSocket inet:"+ ss.getInetAddress());

      serverStarted.set(true);
      System.out.println("tCom: Waiting for connections on port "+testServerPort);

      while(true)
      {
         try
         {
            final Socket s = ss.accept();
            new Thread()
            {
               public void run() {
                 treatConnectionRequests(s);
               }
            }.start();
         }
         catch(final Exception e) {
            e.printStackTrace();
         }
      }
   }

   /** SPEED:  Sends approximatively 5 seconds data in blocks of 10kB amd close
   *    PING:  reply "ping" in utf-8
   *    tideversion: sends the string version in utf-8 and close
   *    quit: close socket.
   */
   void treatConnectionRequests(final Socket s)
   {
      System.out.println("Serving "+s);

      try
      {

         final BufferedReader bis = new BufferedReader(new InputStreamReader( s.getInputStream(), "utf-8" ));
         System.out.println("waiting...");

         while(true)
         {
             String line = bis.readLine();
             System.out.println("Command: "+line);

             if(line==null) break;
             else if(line.equalsIgnoreCase("quit"))
             {
                break;
             }
             else if(line.equalsIgnoreCase("tideversion"))
             {
                s.getOutputStream().write((Version._VERSION+"\n").getBytes("utf-8"));
                s.getOutputStream().flush();
                break;
             }
             else if(line.equalsIgnoreCase("notes"))
             {

                String notes = CommunityUI.getLastNotes(); //"This\nhas to be implemented";


                System.out.println(notes);
                DataOutputStream dos = new DataOutputStream(s.getOutputStream());
                byte[] cont = notes.getBytes("utf-8");
                dos.writeInt( cont.length );
                dos.write( cont );
                dos.flush();

                break;
             }

             else if(line.equalsIgnoreCase("speed"))
             {
                System.out.println("performing speed test");
                BufferedOutputStream  bos = new BufferedOutputStream( s.getOutputStream() );

                long t0 = System.currentTimeMillis();

                byte[] buf = new byte[10000];  // 10kB
                while(true)
                {
                    if(System.currentTimeMillis()-t0>3000L) break;  // 3 sec
                    bos.write(buf);
                }

                bos.flush();
                break;
             }
             else if(line.equalsIgnoreCase("ping"))
             {
                s.getOutputStream().write("ping\n".getBytes("utf-8"));
                s.getOutputStream().flush();
             }
         }
      }
      catch(final Exception e) {
         e.printStackTrace();
      }
      finally
      {
         try{
            s.shutdownOutput();
            s.close();
         }
         catch(final Exception e2) {
            e2.printStackTrace();
         }
      }
   }



   // server.
   public static void main(String[] args) throws Exception
   {
      new ConTest().startServer();
   }

}