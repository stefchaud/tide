package snow.progressbutton;

/** class TProc.
*/
public final class TProc
{
   /** Constructor. */
   public TProc()
   {
   }

   public static void main(String[] args) throws Exception
   {
      new TProc();
   }

}