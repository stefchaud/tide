package snow.progressbutton;

import snow.utils.gui.GUIUtils;
import snow.utils.gui.Icons;
import java.awt.RenderingHints;
import java.awt.Graphics2D;
import java.awt.Graphics;
import java.awt.Color;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Dimension;
import java.awt.geom.*;

/**  Animates the progress, and let some interations as pause and stop
*/
public final class ProgressIndicatorPanel extends JComponent
{
   ProgressButton.PState state = ProgressButton.PState.None;
   double progressPercent = -1;
   Process proc = null;

   boolean animate = false;
   Timer timer = null;

   ProgressIndicatorPanel()
   {
      setPreferredSize(new Dimension(22, 22));
      setMaximumSize(new Dimension(22, 22));

      this.setFocusable(true);
      this.addMouseListener(new MouseAdapter()
      {
        @Override public void mouseClicked(MouseEvent me)
        {
           if(state==ProgressButton.PState.Running)
           {
              JPopupMenu pop = new JPopupMenu();
              //todo: <if can pause>
              //pop.add("pause");
              //pop.add("stop");

              if(proc!=null)
              {
                 JMenuItem kill = new JMenuItem("kill", Icons.sharedStop);
                 pop.add(kill);
                 kill.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
                   proc.destroy();
                 } });

              }
              else
              {
                 pop.add("no process");
              }

              pop.show(ProgressIndicatorPanel.this, me.getX(), me.getY());
           }
        }
      });
   }


   void _animate()
   {
      if(timer==null)
      {
        timer = new Timer(100, new ActionListener() { public void actionPerformed(final ActionEvent ae) {
           repaint();
        } });
        timer.start();
      }
      else
      {
        timer.restart();
      }
   }

   void _stopAnimate()
   {
      if(timer!=null)
      {
        timer.stop();
      }

      repaint();
   }


   void setState(ProgressButton.PState s)
   {
      state = s;

      if(state==ProgressButton.PState.Running)
      {
         _animate();
      }
      else
      {
         _stopAnimate();
      }

      repaint();
   }





   //Overrides method of JComponent
   @Override protected final void paintComponent( final Graphics g )
   {
      Graphics2D g2 = (Graphics2D) g;
      g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
      g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
      g2.setColor(getBackground());
      g2.fill(g.getClipBounds());

      g2.setColor(Color.lightGray);

      g2.drawRect(0,0,getWidth()-1, getHeight()-1);

      if(state==ProgressButton.PState.Running)
      {
         g2.setColor(Color.blue);
         g2.fill(new Rectangle2D.Double(
             (getWidth()*0.5-3),
             (getHeight()*0.5-3),  6, 6));

         if(progressPercent>0)
         {
            Arc2D a  = new Arc2D.Double(0,0,getWidth(), getHeight(), 0, 0.01*progressPercent*360, Arc2D.PIE);
            Arc2D a2 = new Arc2D.Double(4,4,getWidth()-8, getHeight()-8, 0, 0.01*progressPercent*360, Arc2D.PIE);

            Area ar = new Area(a);
            ar.subtract(new Area(a2));
            g2.fill(ar);
         }
         else
         {
            // 3 seconds per turn

            double sangle =  (System.currentTimeMillis() % 3000 ) *1e-3*360/3;

            Arc2D a  = new Arc2D.Double(0,0,getWidth(), getHeight(), sangle, 60, Arc2D.PIE);
            Arc2D a2 = new Arc2D.Double(4,4,getWidth()-8, getHeight()-8, sangle, 60, Arc2D.PIE);

            Area ar = new Area(a);
            ar.subtract(new Area(a2));
            g2.fill(ar);

            /*no
            g2.fillRect(
               (int) (Math.random()*(getWidth()-3)),
               (int) (Math.random()*(getHeight()-3)),  3, 3);
               */
         }
      }
      else if(state==ProgressButton.PState.Done)
      {
         g2.setColor(Color.green);
         g2.fill(new Rectangle2D.Double(
             (getWidth()*0.5-3),
             (getHeight()*0.5-3),  6, 6));
      }
      else if(state==ProgressButton.PState.Error)
      {
         g2.setColor(Color.red);
         g2.fill(new Rectangle2D.Double(
             (5+getWidth()*0.5-3),
             (5+getHeight()*0.5-3),  6, 6));
      }
   }

   public static void main(final String[] arguments) throws Exception
   {
      ProgressIndicatorPanel pip = new ProgressIndicatorPanel();
      pip._animate();
      pip.state = ProgressButton.PState.Running;
      JPanel p = GUIUtils.boxLayout(2, new JButton("go..."), "   ", pip);
      GUIUtils.displayInFrame("test", p, true);
   }
}