/** a framework to display and control some progress.
* designed to be less blocking than ProgressModalDialog.
*/
package snow.progressbutton;
