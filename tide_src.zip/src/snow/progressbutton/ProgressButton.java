package snow.progressbutton;

/** class ProgressButton.
*/
public final class ProgressButton
{
   static enum PState { Running, Done, None, Error, Cancelled, Paused };

   /** Constructor. */
   public ProgressButton()
   {
   }

   public static void main(String[] args) throws Exception
   {
      new ProgressButton();
   }

}