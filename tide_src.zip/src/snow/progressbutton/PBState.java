package snow.progressbutton;

public enum PBState
{
   ONE, TWO, THREE
}