package snow.progressbutton;

/** The result value of an action, decided be the programmer.
*/
public enum PBActionResult
{
   Success,
   Failed,
   Interrupted

}