package snow.numerical;

/** class NumUtils.
*/
public final class NumUtils
{
   /** Constructor. */
   private NumUtils()
   {
   }


   public static boolean isNumber(double x)
   {
      if(Double.isNaN(x)) return false;
      if(Double.isInfinite(x)) return false;
      return true;
   }


   public static double round(double x, double dx)
   {
      double n = Math.round(x/dx);
      return n*dx;
   }

  public static double[][] transpose(final double[][] mat)
  {
    if(mat.length==0)
    {
      return new double[0][0];
    }

    double[][] t = new double[mat[0].length][mat.length];
    for(int i=0; i<mat.length; i++)
    {
      for(int j=0; j<mat[0].length; j++)
      {
        t[j][i] = mat[i][j];
      }
    }
    return t;
  }

   public static void main(final String[] arguments) throws Exception
   {
      System.out.println(""+isNumber(Double.POSITIVE_INFINITY));
      System.out.println(""+isNumber(Double.NEGATIVE_INFINITY));
   }


}