package snow.numerical.clustering;

import snow.utils.gui.GUIUtils;
import snow.tplot.TPlotPanel;
import snow.tplot.TPlot;
import java.awt.Color;
import snow.tplot.model.ListPlotElement;
import java.awt.EventQueue;
import java.util.*;
import snow.utils.ArrayUtils;
import snow.utils.gui.Colors;

/** A simple KMeans clustering.
*/
public final class KMeans
{
   /** Constructor. */
   public KMeans()
   {
   }

   /** @return the indices
   */
   public static List<List<Integer>> cluster(List<double[]> data, int n)
   {
      if(n>data.size()) n=data.size();

      // initialize n clusters (we can improve like kMeans++)
      List<double[]> clusterCenter = new ArrayList<double[]>();

      // trivial approach: take the first n data points  (for random indexing, its equivalent to take random points)
      for(int i=0; i<n; i++)
      {
         //clusterCenter.add( data.get(i) );
         clusterCenter.add( data.get( rnd.nextInt(data.size())) );
      }

      int[] previousClusterPosForData = null;

      final int maxSteps = 32;
      boolean converged = false;
      int step=0;

      stepLoop: for(step=0; step<maxSteps; step++)
      {

         // put each point in the nearest cluster
         int[] clusterPosForData = new int[data.size()];
         int i=0;
         for(double[] di : data)
         {
            double minDist = Double.MAX_VALUE;

            int minPos = -1;

            int p=0;
            for( double[] ci : clusterCenter)
            {
               double d = dist(ci, di);
               if(d<minDist)
               {
                  minDist=d;
                  minPos = p;
               }
               p++;
            }
            clusterPosForData[i++] = minPos;
         }

         // termination test
         if(previousClusterPosForData!=null)
         {
            if(Arrays.equals( previousClusterPosForData, clusterPosForData))
            {
               converged=true;
               break stepLoop;
            }
         }
         previousClusterPosForData = clusterPosForData;

         //System.out.println("cps="+Arrays.toString(clusterPosForData));

         // recompute the new centers
         double[][] newCenters = new double[n][data.get(0).length];
         int[] clusterSize = new int[n];
         for(i=0; i<data.size(); i++)
         {
             int pi = clusterPosForData[i];
             clusterSize[pi]++;
             ArrayUtils.addTo(newCenters[pi], data.get(i));
         }

         // set the new centers, considering eventually loss (if no elt in cluster)
         clusterCenter.clear();
         for(i=0; i<n; i++)
         {
             if(clusterSize[i]==0)
             {
                continue;
             }

             ArrayUtils.divideBy( newCenters[i], clusterSize[i] );
             clusterCenter.add(  newCenters[i] );
         }

         //System.out.println("clusterSize: "+Arrays.toString(clusterSize));
         //System.out.println();
      }

      if(!converged)
      {
         System.out.println("KMeans not converged after "+maxSteps+" steps");
      }
      else
      {
         System.out.println(n+" K-Means on "+data.size()+" vals, dim="+data.get(0).length+" done in step "+step);
      }


      // result

      List<List<Integer>> clusters = new ArrayList<List<Integer>>();
      // create empty lists
      for(int i=0; i<n; i++)
      {
         clusters.add( new ArrayList<Integer>() );
      }


      for(int i=0; i<previousClusterPosForData.length; i++)
      {
         int cl = previousClusterPosForData[i];
         // i is to put in "cl"
         clusters.get(cl).add(i);
      }


      return clusters;
   }


   /** L2 distance
   */
   static double dist(double[] a, double[] b)
   {
      double s = 0;
      for(int i=0; i<a.length; i++)
      {
         s += Math.pow(a[i]-b[i],2);
      }
      return Math.sqrt(s);

   }

   static Random rnd = new Random(1);

   static double[] randomVect(int size)
   {
      double[] r = new double[size];
      for(int i=0; i<size; i++)
      {
         r[i] = rnd.nextDouble();
      }
      return r;
   }

   public static TPlotPanel demo()
   {
      final TPlot tp2 = new TPlot("KMeans clusters");

      // 50 K-Means on 1000 vals, dim=200 done in step 8

      final List<double[]> data = new ArrayList<double[]>();
      final int dim = 2;

      // just random
      /*
      for(int i=0; i<500; i++)
      {
         data.add(randomVect(14));
      }*/

      // random points with random data around
      int groups = 15;
      for(int i=0; i<groups; i++)
      {

         double[] m = randomVect(dim);

         for(int j=0; j<50; j++)
         {
            double[] rr = randomVect(dim);
            ArrayUtils.divideBy(rr, 7.0);
            double[] pi = m.clone();
            ArrayUtils.addTo(pi, rr);
            data.add(pi);
         }
      }


      final List<List<Integer>> clusters = cluster(data, 12);

      final List<Double> dims =new ArrayList<Double>();
      for(List<Integer> ci : clusters)
      {
         dims.add((double) ci.size());
      }
      Collections.sort(dims);
      System.out.println(""+dims);

      // nice 2D plot

      EventQueue.invokeLater(new Runnable() { public void run()
      {
            //tp.listPlotJoined("test", dims);
            //tp.listPlotPoints("test2", 0.1, Arrays.asList(new double[]{1,2}, new double[]{3,4}));

            int cn=0;
            for(List<Integer> ci : clusters)
            {
               if(ci.isEmpty()) continue;

               cn++;
               List<double[]> cli = new ArrayList<double[]>();
               double[] mean = null;
               for(int pi : ci)
               {
                  cli.add(data.get(pi));
                  if(mean==null)
                  {
                     mean = data.get(pi).clone();
                  }
                  else
                  {
                     ArrayUtils.addTo(mean,data.get(pi));
                  }
               }

               ArrayUtils.divideBy(mean, ci.size());

               double rmax = 0;
               List<Double> rvals=new ArrayList<Double>();
               for(int pi : ci)
               {
                  double ri = dist(data.get(pi), mean);
                  rvals.add(ri);
                  if(ri>rmax) rmax=ri;
               }

               Collections.sort(rvals);
               // 80% of points are into r80
               double r80 = rvals.get((int)(0.5*rvals.size()));


               int ptsDensity = (int)(ci.size()/(r80*r80));

               String name="cluster"+cn+", n="+ci.size()+", dens="+ptsDensity;
               Color col = Colors.getRandomColorReproductible(true);

               ListPlotElement lpe = new ListPlotElement(name);
               lpe.pointsOnly();
               lpe.setPointStyle(col, 1, false);
               lpe.setPoints(cli);
               tp2.add(lpe);

               lpe = new ListPlotElement("KM80_"+name);
               lpe.circle(mean[0], mean[1], r80, 30);
               lpe.setLineStyle( col, 1);
               tp2.add(lpe);

               lpe = new ListPlotElement("KMC_"+name);
               lpe.circle(mean[0], mean[1], 0.012, 30);
               lpe.setLineStyle( col, 1);
               tp2.add(lpe);
            }

            tp2.autoscale();
            //tp2.viewInDialog( null );

      }});


      if(true) return tp2.getPlotPanel();

      System.out.println("clusters: "+clusters);
      //Shape ps = PlotUtils.multiline(dims);



      /* visualize MM
      System.out.println("{");
      for(int i=0; i<clusters.size(); i++)
      {
         List<Integer> ci = clusters.get(i);
         System.out.println("{");
         for(int j=0; j<ci.size(); j++)
         {
            double[] di = data.get(ci.get(j));
            System.out.print("  {"+di[0]+", "+di[1]+"}");
            if(j<ci.size()-1) System.out.print(", ");
         }

         System.out.print("}");
         if(i<clusters.size()-1) System.out.println(", ");
      }
      System.out.println("}");
      */

       return tp2.getPlotPanel();

   }


   // idea: use convex hull for better density estimate
   // resplit the most undense clusters?



   public static void main(String[] args) throws Exception
   {
      GUIUtils.displayInFrame("demo", demo(), true);
   }

}