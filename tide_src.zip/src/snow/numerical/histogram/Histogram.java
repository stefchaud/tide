package snow.numerical.histogram;

import java.util.*;

/** Histogram.
*/
public final class Histogram
{
   final List<Double> data = new ArrayList<Double>();

   private double min = Double.NaN;
   private double max = Double.NaN;
   private long nBins = -1;

   public List<Bin> bins = new ArrayList<Bin>();

   private long belowMin = 0;
   private long aboveMax = 0;


   @Override public final String toString() {
      if(bins.isEmpty()) return "no data";
      StringBuilder sb = new StringBuilder();
      sb.append(nBins+" bins between "+min+" and "+max);

      if(data.isEmpty())
      {
         sb.append(" (no data)");
      }
      else
      {
         sb.append(" from "+data.size()+" data points");
      }

      if(belowMin>0)
      {
         sb.append("\n"+belowMin+" below min");
      }
      if(aboveMax>0)
      {
         sb.append("\n"+aboveMax+" above max");
      }
      for(Bin b : bins)
      {
         sb.append("\n  "+b.count+" in "+b.from+" .. "+b.to);
      }
      return sb.toString();
   }


   /** Constructor. */
   public Histogram()
   {
   }

   public double[] getMinMaxRangeUsedToClassify()
   {
      return new double[]{min, max};
   }
   public final long getBelowMin() { return belowMin; }
   public final long getAboveMax() { return aboveMax; }

   public Histogram addData(double... vals)
   {
      for(double d : vals)
      {
         data.add(d);
      }
      return this;
   }

   public Histogram addData(Collection<? extends Number> vals)
   {
      for(Number d : vals)
      {
         data.add(d.doubleValue());
      }
      return this;
   }


   public Histogram setMinMax(double min, double max)
   {
      this.min = min;
      this.max = max;

      return this;
   }

   public final Histogram setNBins(long a)
   {
      this.nBins = a;
      return this;
   }

   public final Histogram setGoodNBinsFrom80Percentile()
   {
      if(data.size()<8)
      {
         nBins = 4;
         return this;  // no sense
      }
      Collections.sort(data);

      min = data.get(0);
      max = data.get(data.size()-1);

      if(min==max)
      {
         max = min+1;
      }

      nBins = (int) (Math.log(data.size())*2.2-1);

      // weight it so that this density is kept for the "mass"
      double w80 = data.get((data.size()*9)/10)-data.get(data.size()/10);

      if(w80>0)
      {
         double w100 = data.get(data.size()-1)-data.get(0);
         double rat = w100/w80 ;
         System.out.println("rat80="+rat+" for nBins="+nBins) ;
         nBins = (long) (rat* nBins);
      }

      return this;
   }


   public Histogram classify()
   {
      Collections.sort(data);

      if(Double.isNaN(min))
      {
         //searchMinMax();
         min = data.get(0);
         max = data.get(data.size()-1);

         if(min==max)
         {
            max = min+1;
         }
      }

      if(nBins<0)
      {
         nBins = (int) Math.log(data.size())*4;
         if(nBins<5) nBins = 5;
      }
/*
      System.out.println("classing "+nBins+" bins");
      System.out.println("xmin="+min);
      System.out.println("xmax="+max+"\n");
      */

      Map<Long, Bin> bm = new HashMap<Long,Bin>();

      for(double x : data)
      {
         if(x<min)
         {
            belowMin++;
         }
         else if(x>max)
         {
            aboveMax++;
         }
         else
         {
            // in [0.. nBins-1 ]
            long  b =  (long) Math.floor((x-min) / (max-min)*(nBins));

            //special
            if(b==nBins) b = nBins-1;

            if(bm.containsKey(b))
            {
               bm.get(b).count++;
            }
            else
            {
               Bin bi = new Bin();

               bi.count = 1;
               bi.from = min + b * (max-min)/(nBins) ;
               bi.to = bi.from + (max-min)/(nBins);

               bm.put(b, bi);
            }
         }
      }

      // sorteds bins
      for(long n : new TreeSet<Long>(bm.keySet()))
      {
         bins.add(bm.get(n));
      }

      return this;
   }


   public Histogram setHistogramFromCounts(
      double[] xStart, double[] xEnd, int[] count, String /*@org.checkerframework.checker.nullness.qual.Nullable*/ [] labels)
   {
      for(int i=0; i<xStart.length; i++)
      {
         Bin b = new Bin();
         b.from = xStart[i];
         b.to = xEnd[i];
         b.count = count[i];
         if(labels!=null)
         {
            b.label = labels[i];
         }
         bins.add(b);
      }

      return this;
   }


   public class Bin
   {
      public double from;
      public double to;
      public long count;
      public String label = "";
   }


   public static void main(String[] args) throws Exception
   {
      snow.tplot.model.HistogramElement.main(null);
   }

}