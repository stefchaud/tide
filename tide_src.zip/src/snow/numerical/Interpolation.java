package snow.numerical;

import java.util.ArrayList;
import java.util.List;

/** Interpolation, without any extrapolations
*/
public final class Interpolation
{
   final private double[] x;
   final private double[] y;
   final private String name;

   /** needs sorted x values
   */
   public Interpolation(double[] x, double[] y, String name)
   {
      this.x = x;
      this.y = y;
      this.name = name;

      //check sorted
      double xa = x[0];
      for(int i=1; i<x.length; i++)
      {
         double xb = x[i];
         if(xb<=xa)
         {
            throw new RuntimeException("x not absolutely monotic growing");
         }
         xa = xb;
      }
   }


   public List<double[]> sampleDerivative(int from, int to, int dx)
   {
       List<double[]> sde = new ArrayList<double[]>();
       for(int i=from; i<to; i+=dx)
       {
          sde.add(new double[]{i, getFunctionDerivativeValue(i)});
       }
       return sde;
   }



   public double getFunctionValue(double xv)
   {
      double xa = x[0];

      if(xv==xa) return y[0];
      if(xv<xa)
      {
         throw new RuntimeException("extrapolation <");
      }

      for(int i=1; i<x.length; i++)  //binary search would be quicker
      {
         double xb = x[i];
         if(xv==xb) return y[i];

         if(xv<xb)
         {
            // we are in xa..xb
            double ya = y[i-1];
            double yb = y[i];
            return (xv-xa)/(xb-xa)*(yb-ya)+ya;
         }
         xa=xb;
      }
      throw new RuntimeException("extrapolation >");
   }


   /** without any smoothing, just the slope between the closest points
   */
   public double getFunctionDerivativeValue(double xv)
   {
      double xa = x[0];
      if(xv<xa)
      {
         throw new RuntimeException("extrapolation <");
      }

      for(int i=1; i<x.length; i++)
      {
         double xb = x[i];

         if(xv <=xb)
         {
            // we are in xa..xb
            double ya = y[i-1];
            double yb = y[i];

            return (yb-ya)/(xb-xa);
         }
         xa=xb;
      }
      throw new RuntimeException("extrapolation >");
   }


   static Interpolation create(List<double[]> xy, String descr)
   {
      int n = xy.size();
      double[] x = new double[n];
      double[] y = new double[n];
      for(int i=0; i<n; i++)
      {
         double[] pi = xy.get(i);
         x[i] = pi[0];
         y[i] = pi[1];
      }
      return new Interpolation(x, y, descr);
   }


   public static void main(String[] args) throws Exception
   {
      Interpolation ip = new Interpolation(new double[]{1,2,3}, new double[]{2,4,7}, "xxx");
      System.out.println("ip1 "+ip.getFunctionDerivativeValue(1));
      System.out.println("ip2 "+ip.getFunctionDerivativeValue(2));
      System.out.println("ip3 "+ip.getFunctionDerivativeValue(2.6));
      System.out.println("ip4 "+ip.getFunctionDerivativeValue(2.9));
   }


}