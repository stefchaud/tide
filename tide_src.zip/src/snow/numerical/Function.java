package snow.numerical;

/** y = f(x)
*/
public interface Function
{
   double getValue(double x);

}