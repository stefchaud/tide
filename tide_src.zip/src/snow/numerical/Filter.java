package snow.numerical;

import java.util.*;

/** Some filtering operations
*/
public final class Filter
{
   /** Constructor. */
   public Filter()
   {
   }

   /** caution, if the data points in x are not equidistant, the result is not well defined...
   */
   public static List<double[]> movingAverage( List<double[]> data, int left, int right)
   {
      if(left<0) throw new IllegalArgumentException("left="+left+" should be >= 0");
      if(right<0) throw new IllegalArgumentException("right="+right+" should be >= 0");

      List<double[]> ret = new ArrayList<double[]>();
      final int n = data.size();
      final int w = left+right+1;
      for(int i=left; i<n-right; i++)
      {
         double x = data.get(i)[0];

         double y = 0;
         for(int j=0; j<w; j++)
         {
            y += data.get( i-left + j)[1];
         }

         ret.add(new double[]{x, y/w});
      }

      return ret;
   }



   public static void main(String[] args) throws Exception
   {
      new Filter();
   }

}