package snow.exec;

import snow.utils.DateUtils;
import java.io.PrintWriter;
import java.io.Writer;
import snow.utils.StreamGobbler;
import java.io.IOException;

/** Convenience class to wrap an external executed process
*   Wraps the process AND its execution.
*  Usage:
*  1) build
*  2) startProcess()
*  3) opt: query
*/
public final class ExtProcess
{
   static enum State {Raw, Started, Running, Done}

   private State state = State.Raw;

   private Process p;

   long startTime = -1;

   private String descr = "ExProc";
   private Writer out = null; //System.out;
   private Writer errOut = null; //System.err;

   private StreamGobbler sgOut, sgErr;

   final private ProcessBuilder pb = new ProcessBuilder();




   // Builder

   /** Constructor.
   */
   public ExtProcess()
   {

   }

   public ExtProcess execute(String... cmd) throws IOException
   {
      pb.command(cmd);
      return this;
   }


   public ExtProcess descr(String d) throws IOException
   {
      if(state != State.Raw)
      {
         throw new IllegalStateException(""+state);
      }
      descr = d;

      return this;
   }

   public ExtProcess redirectToSysOut() throws IOException
   {
      return redirect(new PrintWriter(System.out), new PrintWriter(System.err));
   }

   public ExtProcess redirect(final Writer out, final Writer err) throws IOException
   {
      if(state != State.Raw)
      {
         throw new IllegalStateException(""+state);
      }

      //
      this.out = out;
      this.errOut = err;


      return this;
   }


   // must be called after the build has been made
   public ExtProcess startProcess() throws IOException
   {
      if(state != State.Raw)
      {
         throw new IllegalStateException(""+state);
      }

      p = pb.start();

      state = State.Running;
      startTime = System.currentTimeMillis();

      redirectAndGobble();

      return this;
   }


   /** ALWAYS Called just after the process launch, redirects the outputs to the out and errOut streams
   */
   private void redirectAndGobble()
   {
      try
      {
         sgOut = new StreamGobbler(p.getInputStream(), out, descr);
         sgOut.setName("Gobbler "+descr+" (in)");
         sgOut.start();

         sgErr = new StreamGobbler(p.getErrorStream(), errOut, descr);
         sgErr.setName("Gobbler "+descr+" (err)");
         sgErr.start();

         Thread t = new Thread()
         {
            public void run()
            {
               try
               {
                  sgOut.join();
                  sgErr.join();

                  ExtProcess.this.state = ExtProcess.State.Done;
                  System.out.println("pdone");
               }
               catch(final Exception e) {
                  System.out.println("failure: "+e.getMessage());
                  e.printStackTrace();
               }
            }
         };
         t.start();

      }
      catch(final Exception e) {
         state = State.Done;
      }
   }

   // queries


   public synchronized ExtProcess waitForTermination(long timeout)
   {
       try
       {
         sgOut.join(timeout);
         sgErr.join(timeout);

         state = State.Done;
       }
       catch(InterruptedException ie) { ie.printStackTrace(); }

       return this;
   }

   public void printStatus()
   {
       System.out.println("status of ExtProcess "+descr);
       System.out.println("state: "+state);
       System.out.println("started "+DateUtils.formatDateDifferenceFromNow(startTime)+" ago");
   }




   public static void main(String[] args) throws Exception
   {
      //fails
      //new ExtProcess().execute("dir").startProcess();

      //new ExtProcess().execute("cmd", "/c", "dir").descr("hello").startProcess().printStatus();

      //new ExtProcess().execute("cmd", "/c", "dir").descr("hello").redirectToSysOut().startProcess().waitForTermination(1000).printStatus();

      new ExtProcess().execute("cmd", "/c", "ping google.ch").descr("hello").redirectToSysOut().startProcess().waitForTermination(10000).printStatus();

//
//      new ExtProcess().execute("cmd", "/c", "ping localhost").descr("hello").redirectToSysOut().startProcess().waitForTermination(1000).printStatus();

   }

}