package snow.sys;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Insets;
import java.awt.event.*;
import java.io.*;
import java.net.InetAddress;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import javax.swing.*;
import snow.sortabletable.*;
import snow.utils.gui.GUIUtils;

/** Analyses Windows XP firewall log and give access to some system utilities.
*  admin: "netsh firewall set logging maxfilesize = 1024"
*/
public final class NetExplorer
{
   final static SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH); // approx iso

   String localhost = "localhost";


   // DNS Resolving...
   //

   // Must be cached for efficiency across multiple calls => static cache.
   //   subtle: dhcp ips from yesterday may have today other names !
   final static Map<String, String> hostForIP = new HashMap<String, String>();

   public static String getHostNameForIP(String ip)
   {
      // no sense...
      if(ip.length()==0 || !Character.isDigit(ip.charAt(0))) return ip;

      if(hostForIP.containsKey(ip)) return hostForIP.get(ip);

      try
      {
         InetAddress inet = InetAddress.getByName(ip);

         if(inet.isMulticastAddress())
         {
           System.out.println("Is multicast: "+ip);
           return ip;  // don't resolve !  (??)
         }

         String hn = inet.getHostName();
         if(hn==null) return ip;

         hostForIP.put(ip, hn);
         return hn;
      }
      catch(Exception e)
      {
         e.printStackTrace();
         return null;
      }
   }


   public NetExplorer()
   {

   }




   /** An analysis focuses on the various IPs found in the firewall log.
   *  TODO: add a stat function in the sortable table header context menu. (count, categorize, ...)
   */
   JPanel createFWindowsFirewallTab(final File lf)
   {
     // final boolean group = false;

      final JPanel f = new JPanel(new BorderLayout());

      final STableMod sm = new STableMod();
      SortableTableModel stm =new SortableTableModel(sm);
      JTable t = new JTable(stm);
      stm.installGUI(t);

      f.add(GUIUtils.makeSmall(new JScrollPane(t)), BorderLayout.CENTER);

      MultiSearchPanel asp = new MultiSearchPanel("", null, stm);
      f.add(asp, BorderLayout.NORTH);

      JPanel cp = new JPanel(new FlowLayout(FlowLayout.LEFT,3,2));
      f.add(cp, BorderLayout.SOUTH);

      final JButton upd = new JButton("update");
      upd.setMargin(new Insets(0,0,0,0));
      cp.add( upd);

      final JButton resolveIPs = new JButton("resolve names");
      resolveIPs.setMargin(new Insets(0,0,0,0));
      cp.add( resolveIPs);
      resolveIPs.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
         resolveIPs.setEnabled(false);
         resolveNamesTr(sm);
      } });

      final JComboBox cbTime = new JComboBox(new String[]{"last 5 min","last hour", "all"});
      final JCheckBox groupSames = new JCheckBox(" group same", false);
      cp.add( groupSames);

      //final JCheckBox cb5m = new JCheckBox("Last 5 minutes only", true);
      cp.add( cbTime);

      final JLabel status = new JLabel("");
      cp.add(status);

      final ActionListener updater = new ActionListener() {
         public void actionPerformed(ActionEvent ae)
         {
           upd.setEnabled(false);
           cbTime.setEnabled(false);
           resolveIPs.setEnabled(false);

           final int selTime = cbTime.getSelectedIndex();

           final Thread th = new Thread() { public void run()
           {
            final List<Entry> entries = new ArrayList<Entry>();
            Map<String, Entry> quickID1 = new HashMap<String, Entry>();
            try
            {
               final BufferedReader fr = new BufferedReader(new FileReader(lf));

               try
               {
                  localhost = InetAddress.getLocalHost().getHostAddress();
               }
               catch(Exception e) {e.printStackTrace();}

               String line = null;
               String lastLine = null;

               long count = 0;
               long firstTime = -1;
               long lastTime = -1;

               Set<String> ips1 = new TreeSet<String>();
               Set<String> ips2 = new TreeSet<String>();
               Set<String> ports1 = new TreeSet<String>();
               Set<String> ports2 = new TreeSet<String>();

               Map<String, TreeSet<String>> portsForIp = new HashMap<String, TreeSet<String>>();
               Map<String, TreeSet<String>> ipsForPort = new HashMap<String, TreeSet<String>>();



               while((line=fr.readLine())!=null)
               {
                  //System.out.println(""+line);
                  if(line.startsWith("#"))
                  {
                    System.out.println(""+line);
                    continue;
                  }

                  line = line.trim();
                  if(line.length()==0) continue;


                  count++;
                  if(count%1000==0)
                  {
                     status.setText("     "+count+" lines read...");
                  }

                  if(firstTime<0)
                  {
                    firstTime = df.parse(line.substring(0,19)).getTime();
                  }


                  // always add the new entry, but keep the old data
                  Entry ei = new Entry(line);

                  long age = System.currentTimeMillis()-ei.time;
                  if(age<1000*3600*24*365 && age>0)
                  {
                    if(selTime==0 && age > 1000*60*5) continue;  // because the entries are sorted
                    if(selTime==1 && age > 1000*3600) continue;
                  }

                  if(groupSames.isSelected())
                  {

                    Entry old = quickID1.get(ei.uniqueID1());
                    if(old!=null)
                    {
                       entries.remove(old);
                       ei.count += old.count;
                       ei.size += old.size;
                    }
                     quickID1.put(ei.uniqueID1(), ei);
                  }

                  entries.add(ei);

                  //System.out.println(""+line.substring(20));
                  Scanner sc   = new Scanner(line.substring(20));
                  String type  = sc.next();   // DROP | OPEN |
                  String prot  = sc.next();   // UDP
                  String ip1   = sc.next();   // IP (local)
                  String ip2   = sc.next();   // IP (remote)
                  String port1 = sc.next();   // Port1   (local port?)
                  String port2 = sc.next();   // Port2

                  if(!type.equalsIgnoreCase("OPEN")) continue;

                  ips1.add(ip1);
                  ips2.add(ip2);
                  ports1.add(port1);  //LOCAL
                  ports2.add(port2);

                  if(!ipsForPort.containsKey(port2)) ipsForPort.put(port2, new TreeSet<String>());
                  ipsForPort.get(port2).add(ip2);

                  if(!portsForIp.containsKey(ip2)) portsForIp.put(ip2, new TreeSet<String>());
                  portsForIp.get(ip2).add(port2);

                  lastLine = line;
               }

               if(lastLine!=null)
               {
                 lastTime = df.parse(lastLine.substring(0,19)).getTime();
               }

               System.out.println("\nDone. Time from "+df.format(firstTime)+"  to  "+df.format(lastTime));

               //System.out.println("IPS1: "+ips1);
               //System.out.println("IPS2: "+ips2);
               //Local ports:
               //System.out.println("Ports1: "+ports1.size()+" differents");

               System.out.println("\nPorts2: "+ports2);

               System.out.println("\nIPs for port: "+ipsForPort);
               System.out.println("\nports for ip: "+portsForIp);

               fr.close();

               System.out.println(""+count+" log lines");

               EventQueue.invokeLater(new Runnable() { public void run() {
                  sm.setEntries(entries);

                 /* if(cbTime.isSelected())
                  {
                     keepOnlyLast5Minutes(sm);
                  }*/

               }});

               f.updateUI();
            }
            catch(Exception e)
            {
               f.add(new JLabel("ERROR: "+e.getMessage()), BorderLayout.CENTER);
               e.printStackTrace();
            }
            finally
            {
               quickID1.clear();
               status.setText("   "+entries.size()+" entries");
               entries.clear();
               upd.setEnabled(true);
               cbTime.setEnabled(true);
               resolveIPs.setEnabled(true);
            }
         }};
         th.start();
      }};

      cbTime.addItemListener(new ItemListener() {

         public final void itemStateChanged( final ItemEvent e ) {

           switch(cbTime.getSelectedIndex())
           {
              case 0: keepOnlyLastXXMinutes(sm, 5); break;
              case 1: keepOnlyLastXXMinutes(sm, 60); break;
           }
           updater.actionPerformed(null);
      } });


      upd.addActionListener(updater);
      groupSames.addActionListener(updater);

      // initial call
      updater.actionPerformed(null);


      return f;
   }

   private void keepOnlyLastXXMinutes(final STableMod sm, final int m)
   {
      sm.keepOnlyLastXXMinutes(m);
   }

   private void resolveNamesTr( final STableMod sm)
   {
      Thread tr = new Thread()
      {
         public void run()
         {
            sm.resolveIPs();
         }
      };
      tr.start();

   }


   class STableMod extends FineGrainTableModel
   {
      final private List<Entry> entries = new ArrayList<Entry>();

      public final Object getValueAt( final int row, final int col ) {

         Entry ei = null;
         synchronized(entries)
         {
           if(row<0 || row>entries.size()) return "bad row "+row;
           ei = entries.get(row);
         }

         if(col==0) return df.format(ei.time);
         if(col==1) return ei.type;
         if(col==2) return ei.count;
         if(col==3) return ei.size;
         if(col==4) return ei.ip1+" : "+ei.port1;
         if(col==5) return ei.ip2+" : "+ei.port2;
         if(col==6) return ei.prot;
         if(col==7) return ei.rest;

         return "?";
      }

      public void setEntries(final List<Entry> ne)
      {
         this.fireTableModelWillChange();
         synchronized(entries)
         {
           entries.clear();
           entries.addAll(ne);
         }
         this.fireTableDataChanged();
         this.fireTableModelHasChanged();
      }

      public void keepOnlyLastXXMinutes(int m)
      {
         this.fireTableModelWillChange();
         int rem =0;
         synchronized(entries)
         {
           for(int i=entries.size()-1; i>=0; i--)
           {
              if(System.currentTimeMillis()-entries.get(i).time > m*1000*60)
              {
                 entries.remove(i);
                 rem++;
              }
           }
         }
         System.out.println("removed "+rem +" entries");
         this.fireTableDataChanged();
         this.fireTableModelHasChanged();

      }

      /** Retrieved in parallel. Must be called in a userthread. may take minutes !
      *   90 % have response within millisecs !
      *   10% remains unresolved after several seconds timeout !!
      */
      public void resolveIPs()
      {
         final ExecutorService executorService = Executors.newFixedThreadPool(64);
         System.out.println("Resolving "+entries.size()+" ips");

         List<Entry> allEntriesCopy = new ArrayList<Entry>(entries);
         for(final Entry ei : allEntriesCopy)
         {
            // SOME VERY SLOW => must be threaded...
            executorService.submit(new Runnable(){
               public void run() {
                 //
                 if(ei.ip1!=null && ei.ip1.length()>0)
                 {
                    if(Character.isDigit(ei.ip1.charAt(0)))
                    {
                       ei.ip1 = getHostNameForIP(ei.ip1);
                       //System.out.println(""+ei.ip1);
                    }
                 }

                 if(ei.ip2!=null && ei.ip2.length()>0)
                 {
                    if(Character.isDigit(ei.ip2.charAt(0)))
                    {
                       ei.ip2 = getHostNameForIP(ei.ip2);
                       //System.out.println(""+ei.ip2);
                    }
                 }
            }});
         }


         System.out.println("Waiting for IP resolve completion");
         try
         {
           executorService.awaitTermination(10, TimeUnit.MINUTES);
         }catch(Exception e) {
           e.printStackTrace();
         }
         System.out.println("Done.");
      }

      public final int getRowCount(  )
      {
         synchronized(entries)
         {
           return entries.size();
         }

      }

      public final int getColumnCount(  ) {
         return 8;
      }


     final private String[] COLUMN_NAMES = new String[]{"time", "type", "calls", "bytes", "src", "dest", "prot", "last entry details" };

     int[] COLUMN_PREFERRED_SIZES = new int[]{15, 8, 5, 8, 20, 20, 5, 25};
     @Override
    public int getPreferredColumnWidth(int column)
     {
       if(column>=0 && column<COLUMN_PREFERRED_SIZES.length) return COLUMN_PREFERRED_SIZES[column];
       return -1;
     }

     @Override
    public String getColumnName(int col) { return COLUMN_NAMES[col]; }

   }


/* "c:/windows/pfirewall.log" File format:

 #Version: 1.5
 #Software: Microsoft Windows Firewall
 #Time Format: Local
 #Fields: date time action protocol src-ip dst-ip src-port dst-port size tcpflags tcpsyn tcpack tcpwin icmptype icmpcode info path

*/
   /** = a line in the firewall log. */
   class Entry
   {
      long count = 1;
      String type, prot, ip1, ip2, port1, port2, rest;
      long time;

      long size = 0;

      public Entry(final String line) throws Exception
      {
         SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH);
         try
         {
            time = df.parse(line.substring(0,19).trim()).getTime();
         }catch(Exception e)
         {
            System.out.println("Can't parse time "+line.substring(0,19));
            time = System.currentTimeMillis();
         }

         Scanner sc = new Scanner(line.substring(20));
         type = sc.next();  // DROP | OPEN |
         prot = sc.next();  // UDP

         ip1 = sc.next();   // IP (local)

         if(ip1.equals(localhost))
         {
            ip1 = "localhost";
         }
         else
         {
           //if(resolveNames) ip1 = getHostNameForIP(ip1);
         }

         ip2 = sc.next();   // IP (remote)

         if(ip2.equals(localhost))
         {
            ip2 = "localhost";
         }
         else
         {
            //if(resolveNames) ip2 = getHostNameForIP(ip2);
         }


         port1 = sc.next();   // Port1   (local port?)
         port2 = sc.next();   // Port2
         String ss = sc.next();
         if(!ss.equals("-"))
         {
           size = Long.parseLong(ss);
         }

         // NEXT: tcpflags tcpsyn tcpack tcpwin icmptype icmpcode info path

         rest = sc.nextLine();
      }

      public String uniqueID1()
      {
         return type+ip2+":"+port2+" ("+prot+")";
      }
   }


}