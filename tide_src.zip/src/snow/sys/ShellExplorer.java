package snow.sys;

import tide.editor.MainEditorFrame;
import snow.utils.gui.Icons;
import java.io.File;
import java.awt.event.*;
import snow.utils.SysUtils;
import java.awt.BorderLayout;
import snow.utils.gui.ClosableJTabbedPane;
import javax.swing.*;

/** Useful shell commands for win and lin
*/
public final class ShellExplorer extends JFrame
{
   private final  ClosableJTabbedPane tabs = new ClosableJTabbedPane();

   /** Constructor. */
   public ShellExplorer(boolean standalone)
   {
      super("Shell Explorer");
      if(standalone)
      {
         this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      }

      add(tabs, BorderLayout.CENTER);


      createMenu();

      setSize(800,600);

      setVisible(true);
   }

   void createMenu()
   {
      JMenuBar menu = new JMenuBar();
      this.setJMenuBar(menu);

      JMenu files = new JMenu("Files");
      menu.add(files);

      JMenu net = new JMenu("network");
      menu.add(net);

      JMenu java = new JMenu("java");
      menu.add(java);

      JMenu reg = new JMenu("registry");
      if(SysUtils.is_Windows_OS())
      {
         menu.add(reg);
      }

/*todo
      JMenu settings = new JMenu("Global settings");
      menu.add(settings);
      //charset, timeout, ...

      JMenu utils = new JMenu("Utils");
      menu.add(utils);
*/

      addMenu(files, "", "new command tab").setIcon(Icons.sharedPlus);;
      files.addSeparator();

      files.add(createOpenShellMenu(new File(System.getProperty("user.dir")).getAbsoluteFile(), "user.dir"));
      files.add(createOpenShellMenu(new File(System.getProperty("user.home")).getAbsoluteFile(), "user.home"));

      files.addSeparator();

      if(SysUtils.is_Windows_OS())
      {
         addMenu(files, "cacls c:/temp", "CACLS");

         files.addSeparator();

         addMenu(files, "type c:\\windows\\system32\\CCM\\Logs\\mtrmgr.log", "mtrmgr");

         addMenu(net, "netstat -ao", "netstat -ao");
         addMenu(net, "netstat -n", "netstat -n");
         addMenu(net, "netstat -bov", "netstat -bov");
         addMenu(net, "netstat -res", "netstat -res");
         addMenu(net, "netstat -help", "netstat -help");

         net.addSeparator();

         addMenu(net, "ipconfig /all", "ipconfig /all");
         addMenu(net, "route print", "route print");

         addMenu(net, "type C:/WINDOWS/system32/drivers/etc/hosts".replace("/", "\\"), "etc/hosts");

         net.addSeparator();

         addMenu(net, "net help", "net help");

         net.addSeparator();

         addMenu(net, "netsh firewall show config", "Win Firewall Settings");

         /*special*/
         final File fw = new File("c:/windows/pfirewall.log"); // search ! (from "net" command)
         if(fw.exists())
         {
            JMenuItem miFW = new JMenuItem("explore windows firefall");
            miFW.setToolTipText(""+fw);
            net.add(miFW);
            miFW.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
                tabs.addClosableTab("Win Firewall",  new NetExplorer().createFWindowsFirewallTab(fw));
            }});
         }


         addMenu(reg, "reg query hkcu\\software\\javasoft /s", "Javasoft Registry (HKCU)");
         addMenu(reg, "reg query hklm\\software\\javasoft /s", "Javasoft Registry (HKLM)");
         addMenu(reg, "reg query hklm\\software\\Wow6432Node\\javasoft /s", "Javasoft Registry HKLM (64bit)");
         reg.addSeparator();
         addMenu(reg, "reg query hklm\\software", "hklm\\software");

      }

      else
      {
         //Mac OSX and linux
         //TODO: all all commands from chapter 13 suse admin book...

         addMenu(net, "ifconfig", "ifconfig");
         addMenu(net, "route print", "route print");

         addMenu(net, "whois google.ch", "whois google.ch");

         addMenu(net, "cat /etc/hosts", "cat /etc/hosts");
         addMenu(net, "cat /etc/networks", "cat /etc/networks");
         addMenu(net, "cat /etc/host.conf", "cat /etc/host.conf");
         addMenu(net, "cat /etc/resolv.conf", "cat /etc/resolv.conf");
         addMenu(net, "cat /etc/sysconfig/network/ifcfg-*", "cat /etc/sysconfig/network/ifcfg-*");
         addMenu(net, "cat /etc/sysconfig/network/config", "cat /etc/sysconfig/network/config");
         addMenu(net, "cat /etc/sysconfig/network/dhcp", "cat /etc/sysconfig/network/dhcp");
         addMenu(net, "cat /etc/sysconfig/network/wireless", "cat /etc/sysconfig/network/wireless");
         // TODO: add the XML system prop file cat

         //todo:
         // "lxterminal" for debian squeeze of RPi
         //  and other...

         addMenu(net, "lsof -n  | grep LISTEN", "netstat equivalent on osx");

      }

      {
         addMenu(java, "java -version", "java -version in the shell");
         addMenu(java, "javaws -version", "javaws -version in the shell");
         addMenu(java, "javac -version", "javac -version in the shell");
         addMenu(java, "jps", "jps");

         if(MainEditorFrame.hasInstance())
         {
            // jdk bin
            // project root
               java.addSeparator();

               java.add(createOpenShellMenu(MainEditorFrame.getActualProject().getJava_Home(), "project's jdk"));
               java.add(createOpenShellMenu(MainEditorFrame.getActualProject().getSources_Home(), "project src"));
         }
      }
   }

   JMenuItem addMenu( final JMenu m, final String command,final String descr )
   {
      JMenuItem mi = new JMenuItem(descr);
      m.add(mi);
      mi.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
          addTab(command, descr);
      } });
      return mi;
   }

   void addTab(String command, String descr )
   {
      tabs.addClosableTab(descr, createCommandPanel(command));
   }


   public static JPanel createCommandPanel(final String cmd)
   {
      return new SystemCommandPanel(cmd);
   }



   public  JMenuItem createOpenShellMenu(final File d, String descr)
   {
       JMenuItem openInShell = new JMenuItem("Shell in "+descr, Icons.sharedShellIcon);
       openInShell.setToolTipText(""+d);
       openInShell.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
          try
          {
            SysUtils.openShellAt( d ) ;
          }catch(Exception e) {
            JOptionPane.showMessageDialog(null, "Can't open shell at\n   "+d+"\n\nError: "+e.getMessage(),
               "Error", JOptionPane.ERROR_MESSAGE);
          }
       } });
       return openInShell;
   }

   public static void main(String[] args) throws Exception
   {
      new ShellExplorer(true);
   }

}