package snow.sys;

import snow.texteditor.AlternateLineHighlighter;
import java.io.File;
import snow.Basics;
import snow.utils.gui.JGridPanel;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.*;
import java.nio.charset.Charset;
import java.util.List;
import javax.swing.*;
import snow.texteditor.SimpleDocument;
import snow.utils.CollectionUtils;
import snow.utils.StreamGobbler;
import snow.utils.SysUtils;
import snow.utils.gui.GUIUtils;
import snow.utils.gui.Icons;

/** Interactive panel to execute a shell command
*/
public final class SystemCommandPanel extends JPanel
{
   //Stop doesn't work well
   //todo: pass a Ctrl+C to the process ?

    final SimpleDocument doc = new SimpleDocument();
    final JTextPane ta = new JTextPane(doc);
    final JTextField tf = new JTextField();
    final JButton refresh = new JButton("refresh");
    final JButton stop = new JButton(Icons.sharedStop);

    Process proc = null;
    long started = -1;
    long duration = -1;

    final private File workingDir;

   /** Constructor. */
   public SystemCommandPanel(String cmd)
   {
      this(cmd, null);
   }

   /** Constructor. */
   public SystemCommandPanel(String cmd, File workingDir)
   {
      super(new BorderLayout());

      this.workingDir = workingDir;

      tf.setText(cmd);
      if(workingDir!=null)
      {
         tf.setToolTipText("Working dir: "+workingDir);
      }

      //JPanel cp = new JPanel(new FlowLayout(FlowLayout.LEFT,3,2));
      JGridPanel cp = new JGridPanel(5);
      cp.getGridLayout().setColumnWeights(new double[]{1,100,1,1,1});
      add(cp, BorderLayout.NORTH);
      cp.addG(new JLabel("Command: "));
      cp.addG(tf);
      refresh.setMargin(new Insets(0,0,0,0));
      cp.addG(refresh);
      cp.addG(stop);

      final snow.texteditor.SearchPanel cop = new snow.texteditor.SearchPanel(ta, doc);
      ta.setFont( new Font("Lucida Sans Typewriter", Font.PLAIN, 10));
      ta.setEditable(false);
      doc.append("Please wait...");
      add(GUIUtils.makeSmall(new JScrollPane(ta)), BorderLayout.CENTER);

      new AlternateLineHighlighter(ta);

      add(cop, BorderLayout.SOUTH);

      JButton search = new JButton(Icons.sharedSearch);
      search.setMargin(new Insets(0,0,0,0));
      search.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
         cop.CTRL_F_pressed();
      }});
      cp.addG(search);

      final ActionListener act = new ActionListener() { public void actionPerformed(ActionEvent ae)
      {
        launchCommand();
      } };

      stop.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         System.out.println("stopping "+tf.getText());
         if(proc!=null)
         {
            doc.appendErrorLine("Stopping (process destroyed)");
            System.out.println("kkk");
            try
            {
               proc.destroy();
               proc.getOutputStream().write(new byte[]{3});  //Ctrl+C
               proc.getOutputStream().flush();
               //proc.getOutputStream().close();
               //proc.getInputStream().close();

            }
            catch(final Exception e) {
               e.printStackTrace();
            }
         }
      } });

      refresh.addActionListener(act);
      tf.addActionListener(act);

      // initial action
      act.actionPerformed(null);
   }

   // threadsafe
   void setRunningCmd(final boolean is)
   {
      if(!EventQueue.isDispatchThread())
      {
         EventQueue.invokeLater(new Runnable() { public void run() {
               setRunningCmd(is);
         }});
         return;
      }

      refresh.setEnabled(!is);
      tf.setEditable(!is);
      stop.setEnabled(is);
   }

   void launchCommand()
   {
       doc.clearDocument();
       setRunningCmd(true);

       Thread t = new Thread()
       {
        public void run()
        {

         List<String> cmd = SysUtils.is_Windows_OS() ?
            CollectionUtils.asArrayList("cmd", "/c") :    // "/u"  NOT working, seems to affect only file redirection
            CollectionUtils.asArrayList( "/bin/sh", "-c") ;

         // no need to split the command itself...
         // even more, it fails on linux => no split !
         cmd.add( tf.getText().trim() );

         try
         {
            started = System.currentTimeMillis();

            ProcessBuilder pb = new ProcessBuilder(cmd);
            if(workingDir!=null)
            {
               pb.directory(workingDir);
            }

            proc = pb.start();

            //TODO: Charset !!!
            // http://stackoverflow.com/questions/1259084/what-encoding-code-page-is-cmd-exe-using
            // "cmd / u"
            // todo: to test on XP !!

            StreamGobbler sg2 = new StreamGobbler(proc.getInputStream(),
              doc.createWriterForThisDocument(false) , "");

            if(SysUtils.is_Windows_OS()) // [may2012]
            {
               sg2.charset = Charset.forName("IBM850");   // obtained in console, asking for "chcp"
               //sg2.charset = Charset.forName("UTF-16LE");
            }
            //System.out.println(""+Charset.defaultCharset());  // windows-1252
            //System.out.println(""+ Charset.availableCharsets().keySet());

            sg2.start();

            StreamGobbler sg4 = new StreamGobbler(proc.getErrorStream(),
              doc.createWriterForThisDocument(true) , "");

            if(SysUtils.is_Windows_OS())
            {
              sg4.charset = Charset.forName("IBM850");   // obtained in a console, with "chcp"
            }

            sg4.start();

            sg2.join();
            sg4.join();

            EventQueue.invokeLater(new Runnable() { public void run() {
               ta.setCaretPosition(0);
            }});

         }
         catch(Exception e)
         {
            ta.setText("ERROR: "+e.getMessage()+"\n\n"+Basics.exceptionToString(e));
            e.printStackTrace();
         }
         finally
         {
            //System.out.println("scp:done");
            setRunningCmd(false);
            duration = System.currentTimeMillis()-started;
         }
       }};
       t.setPriority(Thread.MIN_PRIORITY);
       t.start();
   }



   static JPanel test() throws Exception
   {
      System.out.println("\n".getBytes()[0]);
//      return new SystemCommandPanel("netstat -ab"); //long on windows
      return new SystemCommandPanel("echo héllo"); //long on windows

   }

}