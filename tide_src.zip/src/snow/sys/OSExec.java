package snow.sys;

//import java.io.File;
import snow.utils.ProcessUtils;
import snow.utils.CollectionUtils;
import java.util.List;
import snow.utils.SysUtils;

/** class OSExec.
*/
public final class OSExec
{
   /** Constructor. */
   public OSExec()
   {
   }


   /** calls cmd /c XXX on windows and /bin/sh on mac
   *    NOTE: pass "java -version"  , NOT "java", "-version"
   */
   public static String execute(String... cmd) throws Exception
   {
         List<String> cmdl = SysUtils.is_Windows_OS() ?
            CollectionUtils.asArrayList("cmd", "/c") :    // "/u"  NOT working, seems to affect only file redirection
            CollectionUtils.asArrayList( "/bin/sh", "-c") ;

         for(String ci : cmd)
         {
            cmdl.add(ci);
         }

         System.out.println("cmdl:"+cmdl);
         Process p = Runtime.getRuntime().exec(cmdl.toArray(new String[cmdl.size()]));
         String ret = ProcessUtils.readWholeProcessStack(p, 20000);
         return ret;
   }




   public static void main(String[] args) throws Exception
   {
      String tt = execute("java -version");
      System.out.println(""+tt);

 //     SysUtils.openShellInFolder(new File("/System"));

   }

}