package snow.sys;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.event.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import snow.html.HTMLUtils;
import snow.sortabletable.*;
import snow.utils.ProcessUtils;
import snow.utils.StringUtils;
import snow.utils.SysUtils;
import snow.utils.gui.GUIUtils;
import snow.utils.gui.Icons;

/** TODO: Rename this to JavaInWinRegExplorer
*    Offers an easy way to uninstall Java stuff, (javaws, jdks, ...)
*    Only works on Windows, currently...
*    Looks in the Windows registry
*/
public final class JavaUninstaller {

   public JavaUninstaller(boolean standalone) {
      try{
         searchUninstallers(standalone);
      }
      catch(Exception e) {
         e.printStackTrace();
      }
   }

   @SuppressWarnings("unchecked")
   static void searchUninstallers(boolean standalone) throws Exception
   {
      ProcessBuilder pb = new ProcessBuilder("cmd",  "/c",  "REG QUERY HKLM\\SOFTWARE\\microsoft\\windows\\currentversion\\uninstall /s");
      Process proc = pb.start();

      InputStreamReader isr = new InputStreamReader(proc.getInputStream());
      BufferedReader br = new BufferedReader(isr);
      String line = null;
      List<RegEntry> entries = new ArrayList<RegEntry>();
      RegEntry entry = new RegEntry();
      entries.add(entry);
      while((line = br.readLine()) !=null)
      {
         String ltl = line.trim();
         if(ltl.startsWith("!")) continue;

         if(ltl.isEmpty())
         {
            if(entry.cont.length()>0)
            {
               if(entry.cont.indexOf("Java")<0 && entry.cont.indexOf("javaws")<0)
               {
                  entries.remove(entry);
               }

               entry = new RegEntry();
               entries.add(entry);
            }
         }
         else
         {
            entry.cont.append("\n"+ltl);
         }
      }

      if(entry.cont.indexOf("Java")<0 && entry.cont.indexOf("javaws")<0)
      {
         entries.remove(entry);
      }

      System.out.println(""+entries.size()+" reg entries:");
      for(RegEntry ei : entries)
      {
         System.out.println("   "+ei.getDisplayName());
      }

      final FineGrainTableModelBuilder<RegEntry> model = new FineGrainTableModelBuilder<RegEntry>(entries, 4);
      model.setColumnNames("Name", "Type", "Date", "Install location");

      model.setPreferredColumnWidth(18,5,6, 35);
      final SortableTableModel stm = new SortableTableModel(model, 1, true);
      final JTable table = new JTable(stm);
      stm.installGUI(table);
      table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
      JPanel tp = SortableTableUtils.createTableWithSearchBar(stm, table);
      UniversalTableCellRenderer utr = new UniversalTableCellRenderer(stm, table);
      utr.setFormatForColumn(2, new SimpleDateFormat("yyyy-MM-dd"));
      table.setDefaultRenderer(Date.class, utr );
      table.setComponentPopupMenu(new JPopupMenu()
      {

         //Overrides method of JPopupMenu
         @Override public final void show( final Component invoker, final int x, final int y ) {
            removeAll();
            final List<RegEntry> sel = model.getSelectedItems(table, stm);
            if(sel.size()!=1)
            {
               add(""+sel.size()+" selected entries");
            }
            else
            {
               JMenuItem openloc = new JMenuItem("Open Folder", Icons.sharedSystemFolder);
               add(openloc);
               openloc.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
                   SysUtils.openFileExplorer(sel.get(0).getPath());
               } });
            }

            super.show(invoker, x, y);
         }


      });


      final JTextArea ta = new JTextArea(9, 70);
      ta.setEditable(false);
      JPanel cp = new JPanel(new BorderLayout());

      JPanel bp = new JPanel();
      bp.setBorder(new EmptyBorder(2,2,2,2));
      bp.setLayout(new BoxLayout(bp, BoxLayout.X_AXIS));

      cp.add(bp, BorderLayout.SOUTH);


      JSplitPane sp = new JSplitPane(JSplitPane.VERTICAL_SPLIT, tp, new JScrollPane(ta));
      sp.setDividerLocation(300);
      cp.add(sp, BorderLayout.CENTER);


      final JButton uninstall = new JButton("Run Uninstaller", Icons.sharedWiz);
      GUIUtils.makeSmall(uninstall);
      bp.add(uninstall);
      bp.add(Box.createHorizontalStrut(5));
      uninstall.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
         List<RegEntry> sels = model.getSelectedItems(table, stm);
         if(sels.size()==1)
         {
            uninstall(sels.get(0));
         }
      } });

      final JButton uninstallAllCmd = new JButton("Uninstall CMD for selected", Icons.sharedWiz);
      GUIUtils.makeSmall(uninstallAllCmd);
      bp.add(uninstallAllCmd);
      bp.add(Box.createHorizontalStrut(5));
      uninstallAllCmd.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
         StringBuilder sb = new StringBuilder("@echo off\r\n");
         for(RegEntry ri :  model.getSelectedItems(table, stm))
         {
            sb.append("rem "+ri.getDisplayName()+"\r\n");
            sb.append(""+ri.getUninstallCommand()+"\r\n\r\n");
         }
         GUIUtils.displayInDialog(null, "Uninstall cmd", GUIUtils.createReadOnlyDescriptionArea(""+sb));

      } });



      if(SysUtils.hasCustomBrowser())
      {
         final JButton plugin = new JButton("Verify Custom Browser Plugin", Icons.sharedInternet);
         GUIUtils.makeSmall(plugin);
         bp.add(plugin);
         plugin.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
            try
            {
               // custom browser
               SysUtils.openBrowser("http://java.com/en/download/installed.jsp?detect=jre&try=1");
            }
            catch(Exception e) {
               e.printStackTrace();
            }
         } });
      }

      final JButton plugino = new JButton("Verify Browser Plugin", Icons.sharedInternet);
      GUIUtils.makeSmall(plugino);
      bp.add(plugino);
      plugino.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
         try
         {
            //NOT the custom browser
            SysUtils.openBrowser("http://java.com/en/download/installed.jsp?detect=jre&try=1", false);
         }
         catch(Exception e) {
            e.printStackTrace();
         }
      } });



      table.getSelectionModel().addListSelectionListener(new ListSelectionListener()
      {
         public final void valueChanged( final ListSelectionEvent e ) {
            List<RegEntry> sels = model.getSelectedItems(table, stm);
            if(sels.size()==1)
            {
               ta.setText(""+sels.get(0));
               ta.setCaretPosition(0);
               uninstall.setEnabled(true);
            }
            else
            {
               ta.setText("");
               uninstall.setEnabled(false);
            }
         }
      });

      GUIUtils.displayInFrame("Installed Java Applications     (JAVA_HOME="+System.getenv("JAVA_HOME")+")", cp, standalone);

   }

   /** Calls the uninstaller
   */
   static void uninstall(RegEntry re)
   {
      try
      {
         String adm = SysUtils.selectAdminAccount("An admin account is needed to perform the operation");
         if(adm==null) return;

         String rep = ProcessUtils.readWholeProcessStack(
           //"cmd.exe", "/C", "MsiExec.exe", "/x"+re.getNameForUninstaller());
           "cmd.exe", "/C", "start", "/WAIT", "runas", "/user:"+adm, "cmd /C " +re.getUninstallCommand()
          );
          //MsiExec.exe /x"+re.getNameForUninstaller());

         System.out.println(""+rep);

      }
      catch(Exception e) {
         e.printStackTrace();
      }
   }

   static class RegEntry implements TableRow
   {

      // @Implements("TableRow")
      public final Object getValueForColumn( final int col ) {
         if(col==0) return getDisplayName();
         if(col==1) return getType();
         if(col==2) return getDate();
         if(col==3) return getPathWithColor();
         if(col==4) return getUninstallCommand(); // hidden
         return "?";
      }

      public String getType()
      {
         String co = (""+cont).toLowerCase();
         if(co.contains("development kit")) return "JDK";
         if(co.contains("java 2 sdk")) return "JDK";  // 1.2, 1.3, 1.4
         if(co.contains("runtime environment")) return "JRE";
         if(co.contains("wireless toolkit")) return "Wireless Toolkit";
         if(co.contains("java db")) return "Java DB";
         if(co.contains("java(tm)")) return "JRE";  // jre6 ... also contains "javaws"
         if(co.contains("msjavavm")) return "Microsoft VM";
         if(co.contains("javaws")) return "Web Start App";

         if(co.contains("fx"))
         {
            if(!co.contains("runtime")) return "JFX SDK";
            return "JFX";
         }

         return "?";
      }


      StringBuilder cont = new StringBuilder();
      @Override public final String toString() {
         return (""+cont).trim();
      }

      Date getDate()
      {
         String dn = StringUtils.extractFromFirstToNext_Excluded(""+cont+"\n", "InstallDate", "\n");
         if(dn==null || dn.trim().isEmpty() || dn.trim().equalsIgnoreCase("REG_SZ"))
         {
            return null;
         }
         dn = dn.replace("REG_SZ", "").trim();

         if(dn.length()==8)
         {
            try{
               return new SimpleDateFormat("yyyyMMdd").parse(dn);
            }
            catch(final Exception e) {
               e.printStackTrace();
            }
         }

         return null;
      }

      /*@org.checkerframework.checker.nullness.qual.Nullable*/ File getPath()
      {
         String dn = StringUtils.extractFromFirstToNext_Excluded(""+cont+"\n", "InstallLocation", "\n");

         if(dn==null || dn.trim().isEmpty() || dn.trim().equalsIgnoreCase("REG_SZ"))
         {
            // second chance, as for javaDB
            dn = StringUtils.extractFromFirstToNext_Excluded(""+cont+"\n", "InstallSource", "\n");
         }

         if(dn==null || dn.isEmpty())
         {
           return null;
         }

         dn = dn.replace("REG_SZ", "").trim();
         File fi = new File(dn);
         return fi;
      }


      // with "diagnostics"
      String getPathWithColor()
      {
         String dn = StringUtils.extractFromFirstToNext_Excluded(""+cont+"\n", "InstallLocation", "\n");

         if(dn==null || dn.trim().isEmpty() || dn.trim().equalsIgnoreCase("REG_SZ"))
         {
            // second chance, as for javaDB
            dn = StringUtils.extractFromFirstToNext_Excluded(""+cont+"\n", "InstallSource", "\n");
         }

         if(dn==null || dn.isEmpty())
         {
           return "";
         }

         dn = dn.replace("REG_SZ", "").trim();
         File fi = new File(dn);
         if(fi.exists())
         {
             return ""+dn;
         }
         else
         {
            // UGLY ! the line is cropped in the renderer without the "..." if not place => nbsp is the solution
            // UGLY with Nimbus !
             return "<html><body><span color=#ff0000>Not&nbsp;found:&nbsp;"+HTMLUtils.convertCharsToHTML(dn);
         }
      }

      public String getDisplayName()
      {
         String dn = StringUtils.extractFromFirstToNext_Excluded(""+cont+"\n", "DisplayName", "\n");
         if(dn!=null) return dn.replace("REG_SZ", "").trim();
         return StringUtils.keepAfterLastExcl(StringUtils.firstLine((""+cont).trim()), "\\");
      }

      public String getUninstallCommand()
      {
         String us = StringUtils.extractFromFirstToNext_Excluded(""+cont+"\n", "UninstallString", "\n");
         if(us!=null && us.length()>5)
         {
            us = us.trim();
            return StringUtils.removeBeforeIncluded(us, "\t").trim();
         }
         return "MsiExec.exe /x"+getNameForUninstaller();
      }

      public String getNameForUninstaller()
      {
         return StringUtils.keepAfterLastExcl(StringUtils.firstLine((""+cont).trim()), "\\");
      }
   }


   public static void main(String[] args) throws Exception
   {
/*
int choosed = JOptionPane.showOptionDialog(null,
   "1) Just displays versions and detects JDK / JRE on harddrive.\n"
+"2) Displays / Uninstall found in registry.\n"
+"3) Display javasoft registry and system properties.\n\n",
   "Java Soft Utilities",
   JOptionPane.YES_NO_CANCEL_OPTION,
   JOptionPane.QUESTION_MESSAGE, null,
   new String[]{ "1) Detect JREs", "2) View Uninstallers", "3) Properties", "Cancel"}, "Cancel");
   if(choosed==3) return;
   if(choosed==0)
   {
      JavasDetector.main(null);
      return;
   }
   if(choosed==2)
   {
      SystemPropertiesViewer.main(null);
      //JavasDetector.main(null);
      return;
   }
*/

GUIUtils.setNimbusLookAndFeel_IfPossible();
      //System.out.println(""+StringUtils.removeBeforeIncluded("REG_SZ	C:/WINDOWS/System32", "\t"));
      new JavaUninstaller(true);

   }

}