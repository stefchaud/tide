package snow.plot;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Paint;
import java.awt.Stroke;

public final class PlotStyle {  // == PlotGroup

   static int styleCount = 0;

   final String name;
   Stroke stroke;
   Paint paint;
   // used if nonnegative
   double absoluteThickness = -1;
   boolean enabled = true;
   boolean filled = false; //todo

   public PlotStyle()
   {
      this(null);
   }

   public PlotStyle(/*@org.checkerframework.checker.nullness.qual.Nullable*/ String name) {
      styleCount++;

      if(name==null)
      {
        this.name = "Style_"+styleCount;
      }
      else
      {
         this.name = name;
      }
   }

   public PlotStyle(String name, Color c) {
     this(name);
     paint = c;
   }

   public PlotStyle(String name, Color c, double absoluteThickness) {
     this(name);
     paint = c;
     this.absoluteThickness = absoluteThickness;
   }

   public static PlotStyle createDefaultStyle()
   {
      return new PlotStyle();
   }

   // suitable for chained call
   //

   public PlotStyle fill() {
      filled = true;
      return this;
   }

   public PlotStyle disable() {
      enabled = false;
      return this;
   }

   public PlotStyle thickness(double t) {
      stroke = new BasicStroke((float) t);
      return this;
   }



}