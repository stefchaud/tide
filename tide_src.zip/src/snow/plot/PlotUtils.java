package snow.plot;

import java.awt.Color;
import java.awt.Font;
import java.awt.Point;
import java.awt.Shape;
import java.awt.geom.*;
import java.util.*;

public final class PlotUtils {

   private PlotUtils() {
   }

   public static Shape multiline(double[] x, double[] y)
   {
      final GeneralPath gp = new GeneralPath();
      gp.moveTo(x[0], y[0]);
      for(int i=1; i<x.length; i++)
      {
         gp.lineTo(x[i], y[i]);
      }
      return gp;
   }

   /** line made of multpile connected segments
   */
   public static Shape multiline(List<? extends Number> x, List<? extends Number> y)
   {
      final GeneralPath gp = new GeneralPath();

      gp.moveTo(x.get(0).doubleValue(), y.get(0).doubleValue());

      for(int i=1; i<x.size(); i++)
      {
         gp.lineTo(x.get(i).doubleValue(), y.get(i).doubleValue());
      }
      return gp;
   }

   /** line made of multpile connected segments
   */
   public static Shape multilineXY(List<double[]> xyvals)
   {
      final GeneralPath gp = new GeneralPath();

      gp.moveTo(xyvals.get(0)[0], xyvals.get(0)[1]);

      for(int i=1; i<xyvals.size(); i++)
      {
         gp.lineTo(xyvals.get(i)[0], xyvals.get(i)[1]);
      }
      return gp;
   }

   /** line made of multpile connected segments.
   * X axis takes natural numbers [1, ... N]
   */
   public static Shape multiline(List<? extends Number> y)
   {
      final GeneralPath gp = new GeneralPath();

      gp.moveTo(1, y.get(0).doubleValue());

      for(int i=1; i<y.size(); i++)
      {
         gp.lineTo(i+1, y.get(i).doubleValue());
      }
      return gp;
   }

   /** line made of multpile connected segments.
   * X axis takes natural numbers [1, ... N]
   */
   public static Shape multiline(double... y)
   {
      final GeneralPath gp = new GeneralPath();

      gp.moveTo(1, y[0]);

      for(int i=1; i<y.length; i++)
      {
         gp.lineTo(i+1, y[i]);
      }
      return gp;
   }



   public static List<Object> histogramFromCounts(
      double[] xStart, double[] xEnd, int[] count, String /*@org.checkerframework.checker.nullness.qual.Nullable*/ [] labels, boolean withCountLabels)
   {
      List<Object> shapes = new ArrayList<Object>();

      double maxCnt = 0;
      for(int i=0; i<count.length; i++)
      {
         if(count[i]==0) continue;
         maxCnt = Math.max(maxCnt, count[i]);

         double x1 = xStart[i];
         double x2 = xEnd[i];
         double binWidth = x2-x1;
         shapes.add(new Rectangle2D.Double(x1+binWidth*0.01, 0, binWidth-binWidth*0.02, count[i]));
      }

      if(labels!=null)
      {
         shapes.add(new PlotStyle("Category labels"));
         shapes.add(new Font("Dialog", Font.BOLD, 10));
         for(int i=0; i<count.length; i++)
         {
            double x1 = xStart[i];
            double x2 = xEnd[i];
            double binWidth = x2-x1;

            if(labels[i]!=null)
            {
              shapes.add(  new Point((int) (x1+binWidth*0.5), (int)(-maxCnt/10)) );
              shapes.add(  " "+labels[i] );
            }
         }
      }

      if(withCountLabels)
      {
        shapes.add(new PlotStyle("Count labels", Color.lightGray));
        //shapes.add(new Font("Dialog", Font.BOLD, 10));
        for(int i=0; i<count.length; i++)
        {
           if(count[i]<1) continue;

           double x1 = xStart[i];
           double x2 = xEnd[i];
           double binWidth = x2-x1;

           shapes.add(  new Point((int) (x1+binWidth*0.5), (int)(count[i] + maxCnt/30)) );
           shapes.add(  "  "+count[i] );
        }
      }


      return shapes;
   }



}