package snow.plot;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Paint;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.Window;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.*;
import javax.swing.*;
import snow.utils.gui.*;

/** A panel to plot to.
*  Simply uses the java.awt.geom shape model.   (=> ugly line thickness)
*  PlotStyle objects can be added to customize and allow editing styles it defines "sections" or "layers" for subsequents elements.
*
* Wheel: zoom in & out (shift: only zooms y) + zooms around mouse position !
* Click and drag: zoom
* Right click and drag: pan
* Simple right click: edit
*
* [Oct2009]: simple date& time representation.
* [july2013]: replaced by TPlotPanel for numerical data, removed the scale
*/

public final class PlotPanel extends JPanel
{

   // allow paste images from clip (as a screenshot)

   // PlotStyle, Shape and Paint (Color) elements
   // order is kept
   // non null styles applies on next elements per default.
   private final List<Object> plotItemsAndStyles = new ArrayList<Object>();

   // NEVER reset, only ever retransformed at pan/zoom...
   final private AffineTransform plotTransform = new AffineTransform(1,0,0,-1,0,0);  // inverted y coord

   int clickedStart_x_SC = -1;
   int clickedStart_y_SC = -1;
   String startStr = "";

   int dx = -1, dy = -1;
   boolean zoomOrPan = false;  // true: zoom, false: pan


   public final JTextField statusBar = new JTextField("status");


   final List<EditableElement> selectedElements = new ArrayList<EditableElement>();

   public void setSelectedElementsFromModel()
   {
      selectedElements.clear();
      for(Object oi : plotItemsAndStyles)
      {
         if(oi instanceof EditableElement)
         {
            EditableElement ei = (EditableElement) oi;
            if(ei.isSelected())
            {
               selectedElements.add(ei);
            }
         }
      }

   }


   public PlotPanel()
   {
      super();

      setLayout(null);
      this.setPreferredSize(new Dimension(400, 300));
      statusBar.setEditable(false);

      setBackground(Color.white);
      setForeground(Color.black);

      // mouse listener and wheel listener
      MouseAdapter mad = new MouseAdapter(){

         //renoved: moved => draw coord lines

         @Override public final void mousePressed( final MouseEvent e ) {
            //left click: create a zoom window
            //right click: pan
            // for both, we need an anchor, defined at click

            clickedStart_x_SC = e.getX();
            clickedStart_y_SC = e.getY();
            dx=-1;
            dy=-1;
            zoomOrPan = e.getButton() == MouseEvent.BUTTON1;

            try{
                 double[] xy = new double[2];
                 plotTransform.inverseTransform(new double[]{e.getX(), e.getY()}, 0, xy, 0, 1);
                 startStr = "pt1: {"+xy[0]+", "+xy[1]+"}";
                 statusBar.setText(startStr);
            }
            catch(final Exception ec) {
               ec.printStackTrace();
            }

         }

         @Override public final void mouseDragged( final MouseEvent e ) {
            dx = e.getX()-clickedStart_x_SC;
            dy = e.getY()-clickedStart_y_SC;
            try{

                 double[] xy0 = new double[2];
                 plotTransform.inverseTransform(new double[]{clickedStart_x_SC, clickedStart_y_SC}, 0, xy0, 0, 1);

                 double[] xy = new double[2];
                 plotTransform.inverseTransform(new double[]{e.getX(), e.getY()}, 0, xy, 0, 1);

                 double dx = xy[0]-xy0[0];
                 double dy = xy[1]-xy0[1];

                 statusBar.setText("dx="+dx+", dy="+dy+", dy/dx="+(dy/dx));



            }
            catch(final Exception ec) {
               ec.printStackTrace();
            }

            repaint();
         }



         @Override public final void mouseReleased( final MouseEvent e ) {
            dx = e.getX()-clickedStart_x_SC;
            dy = e.getY()-clickedStart_y_SC;
            //System.out.println("delta: ("+dx+", "+dy+") on "+e.getButton());

            if(dx==0 && dy==0)
            {
               // clicked without drag !

               //System.out.println("Coords: ("+e.getX()+", "+e.getY()+")");
               //

               // [Nov2010]: selection

               if(!e.isControlDown())
               {
                  for(EditableElement ei : selectedElements)
                  {
                     ei.setSelected(false);
                  }
                  selectedElements.clear();
                  repaint();
               }

               for(Object oi : plotItemsAndStyles)
               {
                  if(oi instanceof EditableElement)
                  {
                     EditableElement ei = (EditableElement) oi;

                     if(selectedElements.contains(ei)) continue;  // already selected

                     if(ei.isPresentAt(screenToUser(e)))
                     {
                        selectedElements.add(ei);
                        ei.setSelected(true);
                        break;  // only one.
                     }
                  }
               }

               if(!selectedElements.isEmpty())
               {
                  //System.out.println("Action on selected...");
                  repaint();
                  return;
               }


               // [nov2010]: only show popup on right button press
               if(e.getButton()!=MouseEvent.BUTTON3)  return;


               final JPopupMenu pop = new JPopupMenu();

               double[] xy = new double[2];
               try
               {

                  // todo: show in a tooltip or in a floatable toolbar

                 plotTransform.inverseTransform(new double[]{e.getX(), e.getY()}, 0, xy, 0, 1);
                 pop.add("{"+xy[0]+", "+xy[1]+"}");  // lets format by the frame&axis obj ?
                 pop.addSeparator();
               }
               catch(Exception e2) {
                 e2.printStackTrace();
               }

               final String helpStr = "<html>Usage: <ul><li>left+click and drag to zoom<li>right+click and drag to pan"
                 +"<li>wheel to zoom (shift: only y).</ul>";
               JMenuItem help = new JMenuItem("Help", Icons.createHelpIcon(14,true));
               pop.add(help);
               help.setToolTipText(helpStr);
               help.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
                   GUIUtils.displayInDialog(PlotPanel.this, "Plot Help", new JLabel(helpStr));
               } });

               JMenuItem reset = new JMenuItem("Autoscale", Icons.sharedMeasure);
               reset.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_HOME, 0, false));
               pop.add(reset);
               reset.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
                  autoscale();
                  repaint();
               } });


               JMenuItem edit = new JMenuItem("Edit Styles");
               pop.addSeparator();
               pop.add(edit);
               edit.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
                  edit(e.getX(), e.getY());
               } });


               for(Object oi : plotItemsAndStyles)
               {
                  if(oi instanceof AutoUpdateElement)
                  {
                     ((AutoUpdateElement) oi).addToPopup(pop, xy[0], xy[1], PlotPanel.this);
                  }
               }

               pop.show(PlotPanel.this, e.getX(), e.getY());
               clickedStart_x_SC = -1;
               repaint();
            }
            else
            {

               if(!selectedElements.isEmpty())
               {
                  //move all selected elements. System.out.println("Drag end for "+selectedElements.size()+" elts");
                  for(EditableElement ei : selectedElements)
                  {
                     double[] duc = screenToUser(clickedStart_x_SC,clickedStart_y_SC);
                     double[] duc2 = screenToUser(clickedStart_x_SC+dx,clickedStart_y_SC+dy);

                     ei.move(duc2[0]-duc[0], duc2[1]-duc[1]);
                  }

                  dx=0; dy=0;

                  repaint();
                  return;
               }

               // perform pan or zoom !
               if(zoomOrPan)
               {

                  {
                      // select all in given range
                      int x1 = Math.min(clickedStart_x_SC, clickedStart_x_SC+dx);
                      int y1 = Math.min(clickedStart_y_SC, clickedStart_y_SC+dy);
                      dx = Math.abs(dx);  // [May2010]: was missing
                      dy = Math.abs(dy);

                      double[] p1 = screenToUser(x1, y1);
                      double[] p2 = screenToUser(x1+dx, y1+dy);

                      double x0 = Math.min(p1[0],p2[0]);
                      double y0 = Math.min(p1[1],p2[1]);

                      double ddx = Math.abs(p2[0]-p1[0]);
                      double ddy = Math.abs(p2[1]-p1[1]);


                      Rectangle2D selw = new Rectangle2D.Double(x0,y0, ddx,ddy);
                      for(Object oi : plotItemsAndStyles)
                      {
                         if(oi instanceof EditableElement)
                         {
                            EditableElement ei = (EditableElement) oi;
                            if(selectedElements.contains(ei)) continue;

                            if(ei.isPresentIn(selw))
                            {
                               //System.out.println("Intersects:: "+ei);

                               selectedElements.add(ei);
                               ei.setSelected(true);
                            }
                            else
                            {
                               //System.out.println("not present: "+ei);
                            }
                         }
                      }
                      repaint();
                  }
               }
               else
               {
                  pan(dx, dy);
               }

               //done.
               clickedStart_x_SC = -1;

            }
         }

         @Override public final void mouseWheelMoved( final MouseWheelEvent mwe ) {
            //zoom in & out around mouse position

            double[] dest = screenToUser(mwe.getX(), mwe.getY());  // inverse
            plotTransform.translate(dest[0], dest[1]);

            int mw = mwe.getWheelRotation();
            if(mw<0 || mwe.getPreciseWheelRotation()<0)
            {
               if(mwe.isShiftDown())
               {
                  plotTransform.scale(1, 1.2);  // only y
               }
               else
               {
                  plotTransform.scale(1.2, 1.2);
               }
            }
            else
            {
               if(mwe.isShiftDown())
               {
                  plotTransform.scale(1.0, 1.0/1.2);
               }
               else
               {
                  plotTransform.scale(1.0/1.2, 1.0/1.2);
               }
            }

            plotTransform.translate(-dest[0], -dest[1]);

            repaint();
         }
      };


      this.addMouseListener(mad);        //zoom and pan
      this.addMouseWheelListener(mad);   //zoom and pan
      this.addMouseMotionListener(mad);  //drag
/*hide not working
      this.addComponentListener(new ComponentAdapter()
      {
         // @Implements("ComponentListener")
         public final void componentShown( final ComponentEvent e ) {
            System.out.println("initial autoscale !");
            autoscale();
         }
      }); */


// not working well !

      // works only with true
      this.registerKeyboardAction(new ActionListener() { public void actionPerformed(ActionEvent ae) {
         pan(-getWidth()/8, 0);
      } }, KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, 0, true), JComponent.WHEN_IN_FOCUSED_WINDOW);

      this.registerKeyboardAction(new ActionListener() { public void actionPerformed(ActionEvent ae) {
         pan( getWidth()/8, 0);
      } }, KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, 0, true), JComponent.WHEN_IN_FOCUSED_WINDOW);

      // works also with false !
      this.registerKeyboardAction(new ActionListener() { public void actionPerformed(ActionEvent ae) {
         pan(0, -getHeight()/8);
      } }, KeyStroke.getKeyStroke(KeyEvent.VK_UP, 0, false), JComponent.WHEN_IN_FOCUSED_WINDOW);

      this.registerKeyboardAction(new ActionListener() { public void actionPerformed(ActionEvent ae) {
         pan(0,  getHeight()/8);
      } }, KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, 0, false), JComponent.WHEN_IN_FOCUSED_WINDOW);

      // works only with true
      this.registerKeyboardAction(new ActionListener() { public void actionPerformed(ActionEvent ae) {
         //System.out.println("Auto");
         autoscale();
      } }, KeyStroke.getKeyStroke(KeyEvent.VK_HOME, 0, true), JComponent.WHEN_IN_FOCUSED_WINDOW);

      this.registerKeyboardAction(new ActionListener() { public void actionPerformed(ActionEvent ae) {
         System.out.println("Esc"); // ok
      } }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), JComponent.WHEN_IN_FOCUSED_WINDOW);

   }


   void pan(int pdx, int pdy)
   {
       // pan !  inverse delta transform
       double[] src = new double[]{0,0, pdx,pdy};
       double[] dest = new double[4];
       try
       {
         plotTransform.inverseTransform(src, 0, dest,0, 2);
       } catch(Exception e2) {
         e2.printStackTrace();
       }
       //System.out.println("pan: "+dest);
       plotTransform.translate(dest[2]-dest[0], dest[3]-dest[1]);
       repaint();
   }


   /** Adds the shapes to the plot with the optional style (may be null).
   *  Styles can be (later) edited.
   *  Styles may also be shared between several disjoint elements !
   * Array and Collections are flattened (recursively).
   * Text can be added as sequence of 3 objects {Font, Point, String}
   */
   public void addElements(/*@org.checkerframework.checker.nullness.qual.Nullable*/ PlotStyle style, Object... shapesOrStyles)
   {
      if(style!=null)
      {
         plotItemsAndStyles.add(style);
      }

      for(Object si : shapesOrStyles)
      {
         // flattens the objects
         if(si instanceof Object[])
         {
            // recurse
            addElements(null, (Object[]) si);
         }
         else if(si instanceof Collection)
         {
            // recurse
            addElements(null, ((Collection) si).toArray());
         }
         else
         {
            plotItemsAndStyles.add(si);
         }
      }
   }

   public void clearModel()
   {
      plotItemsAndStyles.clear();
   }

   public void removeElement(final Object o)
   {
      System.out.println("Removing "+o);
      while( plotItemsAndStyles.remove(o) ) {
         // remove all occurences !
      }
   }

   public void removeElements(final List<?> os)
   {
      for(final Object oi : os)
      {
         removeElement(oi);
      }
   }


   public void viewPlotLegend()
   {
      edit(-1, -1);   // -1 => show at the right
   }

   /** Edit action */
   void edit(int px, int py)
   {
      final JDialog d = new JDialog(GUIUtils.getWindowForComponent(this), "Edit Plot Styles", JDialog.ModalityType.MODELESS);
      GUIUtils.setWindowTransparency(d, 0.85f);


      JPanel p = new JPanel();
      GridLayout3 gl3 = new GridLayout3(3, p);
      d.add(p, BorderLayout.CENTER);

      final JButton back = new JButton("  ");
      GUIUtils.makeSmall(back);
      back.setBackground(getBackground());
      gl3.add("");
      gl3.add("Background");
      gl3.add(back);
      back.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
         Color cc = ExtColorChooser.choose(getBackground(), d.getContentPane(), "Background");
         if(cc!=null)
         {
            setBackground(cc);
            back.setBackground(cc);
            repaint();
         }
      } });

      final List<PlotStyle> actualStyles = collectActualStyles();
      final List<JCheckBox> groupVisibilities = new ArrayList<JCheckBox>();
      if(actualStyles.size()>3)
      {
         gl3.insertLineBreakAfterNextComponent();
         JPanel pa = new JPanel(new FlowLayout(FlowLayout.LEFT,2,0));
         gl3.add(pa);
         JButton viewall = GUIUtils.makeSmall(new JButton("View all"));
         pa.add(viewall);
         JButton hideall = GUIUtils.makeSmall(new JButton("Hide all"));
         pa.add(hideall);
         JButton autoscaleBt = GUIUtils.makeSmall(new JButton(Icons.sharedMeasure));
         pa.add(autoscaleBt);

         autoscaleBt.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
             autoscale();
         } });

         viewall.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
            for(JCheckBox ci : groupVisibilities)
            {
               if(!ci.isSelected())
               {
                 ci.doClick();
               }
            }
         } });

         hideall.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
            for(JCheckBox ci : groupVisibilities)
            {
               if(ci.getName().equalsIgnoreCase("frame")) continue;

               if(ci.isSelected())
               {
                 ci.doClick();
               }
            }
         } });

      }

      // styles
      for(final PlotStyle si : actualStyles)
      {
         final JCheckBox activate = new JCheckBox("", si.enabled);
         activate.setName(si.name);
         groupVisibilities.add(activate);
         gl3.add(activate);
         activate.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
            si.enabled = activate.isSelected();
            repaint();
         }});
         gl3.add(""+si.name);
         JPanel pa = new JPanel(new FlowLayout(FlowLayout.LEFT,3,2));
         gl3.add(pa);

         final JButton col = new JButton("  ");  //todo: allow a gradient paint ?
         GUIUtils.makeSmall(col);
         if(si.paint instanceof Color)
         {
           col.setBackground((Color) si.paint);
         }
         pa.add(col);
         col.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
            Color cc = ExtColorChooser.choose(getBackground(), d.getContentPane(), "Background");
            if(cc!=null)
            {
               si.paint = cc;
               col.setBackground(cc);
               repaint();
            }
         } });

         //todo: fill, thick, ...
      }

      d.pack();

      Point scr = this.getLocationOnScreen();

      if(px>0)
      {
        d.setLocation(px+scr.x, py+scr.y);
      }
      else
      {
         Window w = GUIUtils.getWindowForComponent(this);
         if(w!=null)
         {
            d.setLocation( w.getLocation().x+w.getWidth()+3, w.getLocation().y);
            LayoutUtils.ensureWithinScreen(d);
         }
      }

      d.setVisible(true);
   }

   // used for edition.
   private List<PlotStyle> collectActualStyles()
   {
      List<PlotStyle> styles = new ArrayList<PlotStyle>();

      for(Object si : plotItemsAndStyles)
      {
         if(si instanceof PlotStyle)
         {
            PlotStyle ps = (PlotStyle) si;
            styles.add(ps);
         } // could "collect" the elements belonging to the style...

         // could recurse into lists ?
      }
      return styles;
   }

   /** inverse transform (ex: mouse to user) */
   double[] screenToUser(MouseEvent me)
   {
      return  screenToUser(me.getX(), me.getY());
   }

   /** inverse transform (ex: mouse to user) */
   double[] screenToUser(double x, double y)
   {
       double[] dest = new double[6];
       double[] ret = new double[2];
       try
       {
         plotTransform.inverseTransform(new double[]{x,y}, 0, ret,0, 1);

       } catch(Exception e2) {
         e2.printStackTrace();
       }
       return ret;
   }

   /** normal transform */
   public double[] userToScreen(double x, double y)
   {
       double[] dest = new double[6];
       double[] ret = new double[2];
       try
       {
         plotTransform.transform(new double[]{x,y}, 0, ret,0, 1);

       } catch(Exception e2) {
         e2.printStackTrace();
       }
       return ret;
   }

   public double[] userToScreen(double[] xy)
   {
      return userToScreen(xy[0], xy[1]);
   }


   public Rectangle2D autoscale()
   {
      Rectangle2D union = null; // new Rectangle2D.Double();  // init on first element

      boolean ignored = false;

      for(Object si : plotItemsAndStyles)
      {
         if(si instanceof PlotStyle)
         {
            ignored = !((PlotStyle) si).enabled;
            continue;
         }

         if(ignored) continue;

         if(si instanceof Shape)
         {
            Shape ssi = (Shape) si;
            if(union==null)
            {
               union = ssi.getBounds2D();
            }
            else
            {
               Rectangle2D.union(ssi.getBounds2D(), union, union);
            }
         }
         else if(si instanceof Point)  // for text !
         {
            Point pt = (Point) si;
            if(union==null)
            {
               union = new Rectangle2D.Double(pt.x, pt.y, 0, 0);
            }
            else
            {
               Rectangle2D.union(new Rectangle2D.Double(pt.x, pt.y, 0, 0), union, union);
            }
         }
         else if(si instanceof EditableElement)
         {
            EditableElement ei = (EditableElement) si;
            if(union==null)
            {
               union = ei.getBounds();
            }
            else
            {
               Rectangle2D.union(ei.getBounds(), union, union);
            }
         }

      }

      //System.out.println("Center at "+union.getCenterX()+" "+union.getCenterY());
      // center => {w/2, h/2}
      double sw = getWidth()>0 ? getWidth() : 300;
      double sh = getHeight()>0 ? getHeight() : 100;

      if(union==null)
      {
         union = new Rectangle2D.Double(0,0,1,1);
      }

      double uw = union.getWidth();
      double uh = union.getHeight();
      if(uw==0) uw=1;
      if(uh==0) uh=1;
      double wantsx = sw/uw;  // wanted global value
      double wantsy = sh/uh;

      // zoom (combine)
      double sx = plotTransform.getScaleX();
      double sy = Math.abs(plotTransform.getScaleY());  // to keep sign !
      plotTransform.scale(0.85*wantsx/sx, 0.85*wantsy/sy);

      // bring middle of the screen to the objects center
      double[] dest = screenToUser(sw/2, sh/2);  // inverse

      dest =new double[]{ union.getCenterX()-dest[0], union.getCenterY()-dest[1]};
      plotTransform.translate(-dest[0], -dest[1]);

      repaint();

      return union;
   }

   // also works for negative coords
   private static void drawRect(Graphics g, int x, int y, int w, int h)
   {
      int x1 = Math.min(x, x+w);
      int y1 = Math.min(y, y+h);
      g.drawRect(x1, y1, Math.abs(w), Math.abs(h));
   }


   /** Paints all plot elements with styles
   */
   @Override public final void paintComponent( Graphics g )
   {
      super.paintComponent(g);
      Graphics2D g2 = (Graphics2D) g;

      // limits to render
      double[] l1 = screenToUser(g2.getClipBounds().getX(), g2.getClipBounds().getY());
      double[] l2 = screenToUser(g2.getClipBounds().getX()+g2.getClipBounds().getWidth(), g2.getClipBounds().getY()+g2.getClipBounds().getHeight());

      double minXToRender = Math.min(l1[0], l2[0]);
      double maxXToRender = Math.max(l1[0], l2[0]);

      double minYToRender = Math.min(l1[1], l2[1]);
      double maxYToRender = Math.max(l1[1], l2[1]);

      Rectangle2D r = new Rectangle2D.Double();
      r.setFrameFromDiagonal(minXToRender, minYToRender, maxXToRender, maxYToRender);


      if(clickedStart_x_SC>0)
      {
         Color oc = g.getColor();
         g.setColor(Colors.createContrastedColor(getBackground(), 33f));
         if(zoomOrPan && selectedElements.isEmpty())
         {
            drawRect(g, clickedStart_x_SC, clickedStart_y_SC, dx, dy);
         }
         else
         {
            g.drawLine(clickedStart_x_SC, clickedStart_y_SC, clickedStart_x_SC+dx, clickedStart_y_SC+dy);
         }
         g.setColor(oc);
      }


      //backup
      Paint oldPaint = g2.getPaint();
      final AffineTransform oldTransform = g2.getTransform();
      //origTransform = oldTransform;
      final Stroke oldStroke = g2.getStroke();

      // tricky... only use y as thickness computation, since we're focused on f(x) curves...
      // but this is not nice.
      //todo  later only good solution is to transform shapes to screen coordinates system...
      double sy = Math.abs(plotTransform.getScaleY()) + Math.abs(plotTransform.getScaleX());
      //System.out.println("sy="+sy);
      double wh = 0.002*Math.max(getHeight(), 100);

      // the default absolute stroke
      g2.setStroke(new BasicStroke((float)(wh/sy)));
      g2.transform(plotTransform);
      g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);



      boolean ignore = false;
      boolean fill = false;
      Point nowPos = new Point(0,0);
      for(Object si : plotItemsAndStyles)
      {
         // recurse ?
         if(si instanceof PlotStyle)
         {
            PlotStyle ps = (PlotStyle) si;

            ignore = !ps.enabled;

            if(ignore) continue;

            fill = ps.filled;

            if(ps.paint!=null) {
               g2.setPaint(ps.paint);
            }

            if(ps.stroke!=null) {
               g2.setStroke(ps.stroke);
            }

            if(ps.absoluteThickness>0)
            {
               g2.setStroke(new BasicStroke((float)(wh/sy*ps.absoluteThickness)));
            }
            continue;  // fully treated...
         }

         if(ignore) continue;


         if(si instanceof Shape)
         {


            Shape ssi = (Shape) si;

            Rectangle2D sbds = ssi.getBounds2D();
            if(!r.intersects(sbds))
            {
              //don't draw if outside actual limits !
              // System.out.println("ignore");
              continue;
            }

            if(fill)
            {
               g2.fill(ssi);
            }
            else
            {
               // here we may encounter singular transforms even if the affine transform is OK !
               // for example when zooming out extemely around (0,0) when there are points arount 10^9 present...
               //  this is "not" really nice
               try
               {
                 g2.draw(ssi);
               }catch(Exception e) {
                 e.printStackTrace();
               }
            }
         }
         else if(si instanceof Point) // used as "actual" render position for next coming text elements
         {
            nowPos =(Point) si;
         }
         else if(si instanceof Font)
         {
            g.setFont((Font) si);
         }

         else if(si instanceof String)
         {
            // uses last declared position !
            // but without any transform !!
            AffineTransform cplotTransform = g2.getTransform();
            g2.setTransform(oldTransform);

            double[] tp = userToScreen(nowPos.getX(), nowPos.getY());
            String text = ""+si;
            String[] lines = text.split("\n");
            for(String li : lines)
            {
              g.drawString(li, (int) tp[0], (int) tp[1]);
              tp[1] += g2.getFont().getSize()*1.4;
            }
            g2.setTransform(cplotTransform);
         }
         else if(si instanceof Paint)
         {
            g2.setPaint((Paint) si);
         }
         else if(si instanceof Image)   //buggy
         {
            double[] tp = userToScreen(nowPos.getX(), nowPos.getY());
            g2.drawImage((Image) si, (int)tp[0], (int)tp[1], null);
         }
         else if(si instanceof Icon) //buggy (upside down)
         {
            double[] tp = userToScreen(nowPos.getX(), nowPos.getY());
            Icon ic = (Icon) si;
            //ic.paintIcon(this, g2, (int)tp[0], (int)tp[1]);
            ic.paintIcon(this, g2, nowPos.x, nowPos.y);
            //g2.drawImage((Image) si, (int)tp[0], (int)tp[1], null);
         }

         else if(si instanceof AffineTransform)
         {
            g2.transform((AffineTransform) si);
         }
         else if(si instanceof AutoUpdateElement)
         {
            AutoUpdateElement pa = (AutoUpdateElement) si;
            pa.paint(g2, this, oldTransform);
         }
         else if(si instanceof CustomPaintableElement)
         {
            CustomPaintableElement cp = (CustomPaintableElement) si;
            //g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            cp.paint(g2, this, oldTransform);
         }

         else
         {
            if(ignore) continue;

            System.out.println("Unknown PlotElement: "+si.getClass());
         }
      }

      g2.setTransform(oldTransform);
      g2.setPaint(oldPaint);
      g2.setStroke(oldStroke);
   }


   /** Used by the frame, that "follows"
   */
   public interface AutoUpdateElement
   {
      void paint(Graphics2D g, PlotPanel ref, final AffineTransform oldTransform);

      /** Let add custom elements to the popup. Only adds if concerned !
      */
      void addToPopup(JPopupMenu pop, double px, double py, PlotPanel ref);
   }

   public interface CustomPaintableElement
   {
      void paint(Graphics2D g, PlotPanel ref, final AffineTransform oldTransform);
   }


   /** Used by graphic elements that are moveable by the user
   */
   public interface EditableElement
   {
      boolean isSelectable();
      boolean isSelected();
      boolean isMoveable();
      boolean isPresentAt(double[] xy);
      boolean isPresentIn(Rectangle2D rect);
      void move(double dx, double dy);
      void setSelected(boolean is);
      public Rectangle2D getBounds();
   }
}