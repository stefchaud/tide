/** A simple framework to plot 2D data and explore them interactively.
*   Supports also timed datas (date ranges), zoom, pan, ...
*   Primitive but powerful.
*/
package snow.plot;