package snow.text;

import java.util.List;
import snow.utils.gui.GUIUtils;

/** Analyse differences if strings, char per char.
*/
public class LcsString extends LongestCommonSubsequence<Character> {
	private String x;
	private String y;

	public LcsString(String from, String to) {
		this.x = from;
		this.y = to;
	}

	@Override protected int lengthOfY() {
		return y.length();
	}
	@Override protected int lengthOfX() {
		return x.length();
	}
	@Override protected Character valueOfX(int index) {
		return x.charAt(index);
	}
	@Override protected Character valueOfY(int index) {
		return y.charAt(index);
	}




	public String getHtmlDiff() {
		DiffType type = null;
		List<DiffEntry<Character>> diffs = diff();
		StringBuffer buf = new StringBuffer();

		for(DiffEntry<Character> entry : diffs) {
			if(type != entry.getType()) {
				if(type != null) {
					buf.append("</span>");
				}
				buf.append("<span class=\""+entry.getType().getName()+"\">");
				type = entry.getType();
			}
			buf.append(escapeHtml(entry.getValue()));
		}
		buf.append("</span>");
		String bs = buf.toString();
		bs = bs.replace("\n", "<br>");
		bs = bs.replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;");
		return bs;
	}

   private String escapeHtml(Character ch) {
     // if(true) return ch.toString();

      switch(ch) {
         case '<' : return "&lt;";
         case '>' : return "&gt;";
         case '"' : return "\\&quot;";
         default : return ch.toString();
      }
   }

   /* EXAMPLE.  Here's how you use it. */
   public static void main(String[] args) {
		LcsString seq = new LcsString("the quick brown fox",
		  "the Fast brown dog");
		System.out.println("LCS: "+seq.getLcsLength());
		System.out.println("Edit Dist: "+seq.getMinEditDistance());
		System.out.println("Backtrack: "+seq.backtrack());
		System.out.println("HTML Diff: "+seq.getHtmlDiff());

		GUIUtils.displayInFrame("diffs", GUIUtils.createReadOnlyDescriptionArea(
		    "<html>"
		    //+"<head><style type=\"text/css\">\n.remove {color: red;}\n.add {color: green;}\n</style></head>"
		    +"<head><style type=\"text/css\">\n.remove {background: #ffdcff; color: red;}\n.add {background: #ccffcc; color: green;}\n</style></head>"
		    +"<body>"+seq.getHtmlDiff()), true);
	}

}
