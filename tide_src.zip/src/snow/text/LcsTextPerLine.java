package snow.text;

import java.io.*;
import java.util.*;

/** Analyse differences of texts, line per line
*/
public final class LcsTextPerLine extends LongestCommonSubsequence<String>
{
	private List<String> fileX;
	private List<String> fileY;
	private final boolean ignoreIndents;


      public LcsTextPerLine(String fX, String fY, boolean ignoreIndents) {
         this(toLines(fX), toLines(fY), ignoreIndents);
      }

	public LcsTextPerLine(List<String> fileX, List<String> fileY, boolean ignoreIndents) {
		this.fileX = fileX;
		this.fileY = fileY;
		this.ignoreIndents = ignoreIndents;
	}

	static List<String> toLines(String txt)
	{
	   BufferedReader br = new BufferedReader(new StringReader(txt));
	   List<String> ret = new ArrayList<String>();
	   String line = null;
	   try
	   {
         while((line = br.readLine())!=null)
         {
            ret.add( line );
         }
	   }catch(Exception ex) {}  // string don't fail
	   return ret;
	}

	@Override protected int lengthOfY() {
		return fileY.size();
	}
	@Override
	protected int lengthOfX() {
		return fileX.size();
	}
	@Override protected String valueOfX(int index) {
		return fileX.get(index);
	}
	@Override protected String valueOfY(int index) {
		return fileY.get(index);
	}

	@Override
	protected boolean equals(String x1, String y1) {
	   if(ignoreIndents)
	   {
         return (null == x1 && null == y1) || x1.trim().equals(y1.trim());
	   }
	   else
	   {
         return (null == x1 && null == y1) || x1.equals(y1);
	   }
   }

   public String getHtmlDiff() {
     DiffType type = null;
     List<DiffEntry<String>> diffs = diff();
     StringBuffer buf = new StringBuffer();

     for(DiffEntry<String> entry : diffs) {
   	if(type != entry.getType()) {
   		if(type != null) {
   			buf.append("</span>");
   		}
   		buf.append("<span class=\""+entry.getType().getName()+"\">");
   		type = entry.getType();
   	}
   	buf.append("<br>"+escapeHtml(entry.getValue()));
     }
     buf.append("</span>");
     return buf.toString();
   }

   private String escapeHtml(String src) {
      String ret = src;
      ret = ret.replace("<", "&lt;");
      ret = ret.replace(">", "&gt;");
      ret = ret.replace("\"", "\\&quot;");
      return ret;
   }

   /* EXAMPLE.  Here's how you use it.
   public static void main(String[] args)
   {
       System.out.println(""+toLines("aaa\nthe quick brown fox\nbbb"));

		LcsTextPerLine seq = new LcsTextPerLine(
		  "aaa\nthe quick brown fox\nbbb\nccc",
		  "aaa\nthe Fast brown dog\nbbb\n ccc", false);

		System.out.println("LCS: "+seq.getLcsLength());
		System.out.println("Edit Dist: "+seq.getMinEditDistance());
		System.out.println("Backtrack: "+seq.backtrack());
		System.out.println("HTML Diff: "+seq.getHtmlDiff());

		GUIUtils.displayInFrame("diffs", GUIUtils.createReadOnlyDescriptionArea(
		    "<html>"
		    +"<head><style type=\"text/css\">\n.remove {color: red;}\n.add {color: green;}\n</style></head>"
		    +"<body><pre>"+seq.getHtmlDiff()+"</pre>"), true);
	}
   */

}
