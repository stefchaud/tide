package snow.chars;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CharsetEncoder;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import snow.Basics;
import snow.sortabletable.*;
import snow.texteditor.SimpleDocument;
import snow.utils.gui.GUIUtils;
import snow.utils.gui.JGridPanel;

/** A debug tool to explore character encodings
*/
public final class CharsetsExplorer extends JFrame
{
   final JTextPane tpIn = new JTextPane();


   public CharsetsExplorer()
   {
      super("Charset encoders explorer");

      JGridPanel gp = new JGridPanel(2);
      add(gp, BorderLayout.CENTER);
      gp.getGridLayout().addExplanationArea("Explore/debug/hack the character representations");

      gp.addG("Default Locale");
      gp.addG(""+Locale.getDefault());

      gp.addG("Default Charset");
      gp.addG(""+Charset.defaultCharset());

      gp.getGridLayout().addSeparator();

      gp.addG("input");
      gp.addG(new JScrollPane(tpIn), true);
      tpIn.setText("\u00b5 = 4 ?");
      tpIn.setPreferredSize(new Dimension(300,200));
      tpIn.setMinimumSize(new Dimension(300,200));
      tpIn.setPreferredSize(tpIn.getPreferredSize());

      final JButton qj = new JButton(" add chars ...");
      GUIUtils.makeSmall(qj);
      qj.setToolTipText("add some exotic characters");
      gp.addG("");
      gp.addG(qj, false);
      qj.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         final JPopupMenu pop = CharUtils.charExplorerPopup(tpIn.getFont(),
             new ActionListener() { public void actionPerformed(final ActionEvent ae) {
                String bt = ((JButton)ae.getSource()).getText();
                tpIn.setText( tpIn.getText() +bt );
             }}
         );
         pop.show(qj,0,0);
      } });

      //todo
//      FontsExplorer.chooseFont()

 //     gp.addG("input format");
 //     gp.addG(new JComboBox(new Object[]{"string", "bytes (int)", "bytes (hex)", "auto"}), false);

      gp.getGridLayout().insertLineBreakAfterNextComponent();
      gp.addG("");

      final JButton gb = new JButton("View encoders for given input");
      final JButton sall = new JButton("View all encoders");
      gp.addG("Output");
      gp.addG(GUIUtils.addComponentsToLine(gb, sall));

      gb.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         exploreAllCharsets(tpIn.getText(), true);
      } });

      sall.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         exploreAllCharsets(tpIn.getText(), false);
      } });

//not done: auto popupating popup
      /*
      gb.addMouseListener(new MouseAdapter()
      {
        @Override public void mousePressed(MouseEvent me)
        {
        }
        @Override public void mouseReleased(MouseEvent me)
        {
           final JPopupMenu pop = new JPopupMenu();
           final SortedMap<String, Charset> sortedMap = Charset.availableCharsets();

           final JProgressBar prog = new JProgressBar();
           prog.setMaximum(sortedMap.size());
          // prog.setIndeterminate(true);
           pop.add(prog);

           Thread t = new Thread()
           {
             public void run()
             {

              for(final String ki : sortedMap.keySet())
              {
                 EventQueue.invokeLater(new Runnable() { public void run() {
                   prog.setValue( prog.getValue()+1);
                 }});

                 Charset cs = sortedMap.get(ki);
                 if(cs.canEncode())
                 {
                    if(cs.newEncoder().canEncode(tpIn.getText()))
                    {
                       EventQueue.invokeLater(new Runnable() { public void run() {
                            pop.setVisible(false);
                            pop.add(ki);

                 //           pop.setVisible(true);
                            pop.pack();
                            pop.show(gb, 0, gb.getHeight());
                       }});
                    }
                    else
                    {
                       System.out.println("cannot encode with "+cs);
                    }
                 }
                 else
                 {
                    System.out.println("Charset without encoding: "+cs);
                 }
              }

              EventQueue.invokeLater(new Runnable() { public void run() {
                prog.setString("done.");
              } });
           }};
           t.start();
           pop.show(gb, 0, gb.getHeight());
        }
      });
      */
      // get bytes (charset)

      setSize(600,400);
      setLocationRelativeTo(null);
      setVisible(true);
   }


   private void exploreAllCharsets(final String testToEncode, boolean onlyEncodingTest)
   {

       final FineGrainTableModelBuilder<CTE> tmb = new FineGrainTableModelBuilder<CTE>(3);
       tmb.setColumnNames("name", "average byte per char", "max byte per char");
       final SortedMap<String, Charset> sortedMap = Charset.availableCharsets();
       for(final String ki : sortedMap.keySet())
       {
          Charset cs = sortedMap.get(ki);
          if(onlyEncodingTest && testToEncode!=null)
          {
             if(!cs.canEncode()) continue;
             try
             {
                // openJDK throws some Exception !!
                if(!cs.newEncoder().canEncode(testToEncode)) continue;
             }
             catch(final Exception e) {
                //e.printStackTrace();
                continue;
             }

          }
          tmb.addRows(new CTE(cs));
       }

       JPanel p = new JPanel(new BorderLayout());
       final SortableTableModel stm = new SortableTableModel(tmb);
       final JTable t = new JTable(stm);
       stm.installGUI(t);

       final SimpleDocument doc = new SimpleDocument();
       final JTextPane preview = new JTextPane(doc);
       JSplitPane sp = new JSplitPane(JSplitPane.VERTICAL_SPLIT, new JScrollPane(t), new JScrollPane(preview));
       p.add(sp, BorderLayout.CENTER);
       sp.setDividerLocation(320);

       p.add(new MultiSearchPanel(stm), BorderLayout.NORTH);

       final JCheckBox markControlChars = new JCheckBox("control chars in red (CR LF except)", true);
       p.add(markControlChars, BorderLayout.SOUTH);

       //JButton toFile = new JButton("to file...");

       GUIUtils.displayInDialog(this, "All charset encoders", p)  ;

       t.getSelectionModel().addListSelectionListener(new ListSelectionListener()
       {
          public final void valueChanged( final ListSelectionEvent lse) {
              final List<CTE> sel = tmb.getSelectedItems(t, stm);
              if(sel.size()==1)
              {
                 preview.setText("");

                 if(testToEncode!=null)
                 if(sel.get(0).cse !=null)
                 {
                    try
                    {
                       ByteBuffer bb = sel.get(0).cse.encode(CharBuffer.wrap(testToEncode));
                       byte[] bytes = bb.array();

                       doc.setText("");
                       doc.append(
                          bytes.length+" bytes: \t"+Arrays.toString( bytes )
                           +"\r\nHex:\t");

                       int n=-1;
                       for(byte b : bytes)
                       {
                          if(n%20==19)
                          {
                             doc.append("\n\t");
                          }

                          if(n%5==4)
                          {
                             doc.append("\t");
                          }

                          n++;
                          int bi = getByteAsInt(b);

                          String c = getByteIntAsHex(bi);

                          if( markControlChars.isSelected() && isCtrlOtherThanCRLF(bi) )
                          {
                             doc.appendError(c);
                          }
                          else
                          {
                             doc.append(c);
                          }

                          doc.append(" ");
                       }

                       preview.setCaretPosition(0 );
                    }
                    catch(final Exception e) {
                       doc.appendErrorLine("Cannot encode, message="+e.getMessage());
                       doc.appendErrorLine(Basics.exceptionToString(e));
                       preview.setCaretPosition(0 );

                       //e.printStackTrace();
                    }
                 }
              }
              else
              {
                 preview.setText(""+sel.size()+" selected charsets");
              }
          }
       });
   }

   // all charsets can decode. some few can only encode
   class CTE implements TableRow
   {

      public final Object getValueForColumn( final int col ) {
         if(col==0)
         {
            if(cse==null) return cs.name()+" (DECODE ONLY)";
            if(!cs.name().equals(cs.displayName())) return cs.name()+" ["+cs.displayName()+"]";
            else return cs.name();
         }
         if(col==1)
         {
            if(cse==null) return 1f/csd.averageCharsPerByte();
            return cse.averageBytesPerChar();
         }
         if(col==2)
         {
            if(cse==null) return 1f/csd.maxCharsPerByte();
           return cse.maxBytesPerChar();
         }

         return null;
      }

      final private Charset cs;
      final private /*@org.checkerframework.checker.nullness.qual.Nullable*/ CharsetEncoder cse;
      final private CharsetDecoder csd;

      public CTE(Charset cs)
      {
         this.cs = cs;
         csd = cs.newDecoder();
         if(cs.canEncode())
         {
           cse = cs.newEncoder();
         }
         else
         {
            cse = null;
         }
      }
   }


   // helpers

   public static int getByteAsInt(byte b)
   {
        //if(bi<0) bi = 256+bi;
        return (int)b & 0xff;
   }

   public static String getByteIntAsHex(int b)
   {
        String c = "";
        if(b<16) c += "0";
        c += Integer.toHexString(b);
        return c;
   }

   // and tab
   public static boolean isCtrlOtherThanCRLF(int bi)
   {
      if(bi>=32) return false;
      if(bi==9) return false;
      if(bi==10) return false;
      if(bi==13) return false;
      return true;
   }


// standalone app
   public static void main(String[] args) throws Exception
   {
      GUIUtils.setNimbusLookAndFeel_IfPossible();
      EventQueue.invokeLater(new Runnable() { public void run() {
         new CharsetsExplorer();
      }});
   }

}