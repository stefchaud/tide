package snow.chars;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.event.*;
import java.io.File;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CodingErrorAction;
import java.util.*;
import java.util.concurrent.TimeUnit;
import javax.swing.*;
import javax.swing.event.*;
import snow.sortabletable.*;
import snow.texteditor.SimpleDocument;
import snow.utils.CollectionUtils;
import snow.utils.ProcessUtils;
import snow.utils.SysUtils;
import snow.utils.gui.GUIUtils;
import snow.utils.gui.JGridPanel;
import snow.utils.storage.FileUtils;

/** Decodes bytes with some charset...
*
*/
public final class CharsetDecoderExplorer  extends JFrame
{
   final JTextPane tpIn = new JTextPane();
   final JComboBox inputFormat = new JComboBox(new Object[]{
     "string (unicode)",
     "string (bad decoded with default charset)",
     "bytes (signed int)",
     "bytes (hex)",
     "first 512 bytes of file",
     "shell command",   // interessant:  "echo éäñ" and look  echo "éäñ§$ç"  // echo € fails on my Win7 !!
     "file path (whole content will be read)"

   });


   /** accept 9, 10 and 13
   */
   static boolean hasControls(String s)
   {
      for(char ci : s.toCharArray())
      {
         if(Character.isISOControl(ci))
         {
             if(ci==9) continue;
             if(ci==10) continue;
             if(ci==13) continue;
           return true;
         }
      }
      return false;
   }

   // all charsets can decode. some few can only encode
   class CTD implements TableRow
   {

      public final Object getValueForColumn( final int col )
      {
         if(col==0)
         {
            if(!cs.name().equals(cs.displayName())) return cs.name()+" ["+cs.displayName()+"]";
            else return cs.name();
         }
         if(col==1)
         {
            return csd.averageCharsPerByte();
         }
         if(col==2)
         {
           return csd.maxCharsPerByte();
         }
         if(col==3)
         {
            //return result.length()+" chars: "+result;
            return result;
         }
         if(col==4)
         {
            return hasControls;
         }
         if(col==5)
         {
            return maxCP;
         }


         return null;
      }

      final private Charset cs;
      final private CharsetDecoder csd;
      private String result = "";
      int maxCP = 0;
      boolean hasControls = false;

      public CTD(final Charset cs, final byte[] todo, boolean trim)
      {
         this.cs = cs;
         csd = cs.newDecoder();
         if(todo!=null)
         {
           try
           {
              CharBuffer bb  = cs.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode( ByteBuffer.wrap(todo) );
              char[] bba = bb.array();
              result = new String(bba, bb.arrayOffset(), bb.length());

              if(trim)
              {
                 result = result.trim();
              }

              for(char ci : bba)
              {
                 maxCP = Math.max(maxCP, (int) ci);
              }

              hasControls = hasControls(result);
           }
           catch(final Exception e) {
              //e.printStackTrace();
              result = "<failure> "+e.getMessage();
           }
         }
      }
   }

   /** Constructor. */
   public CharsetDecoderExplorer()
   {
      super("Charset decoders explorer");

      JGridPanel gp = new JGridPanel(2);
      add(gp, BorderLayout.CENTER);
      gp.getGridLayout().addExplanationArea("Explore/debug/hack the character decoding");

      gp.addG("Default Locale");
      gp.addG(""+Locale.getDefault());

      gp.addG("Default Charset");
      gp.addG(""+Charset.defaultCharset());


      gp.addG("file.encoding");
      gp.addG(""+System.getProperty("file.encoding"));  // windows: buggy, NOT the output format of all utilities, as CACLS on a german system !!


      //chcp in console
      if(SysUtils.is_Windows_OS())
      {
         // HORRIBLE !
         //  if we parse the output of some system processes as CHCP, the chars are coded in cp850 !!!

         // Win7 german: 850, WinXP GB: 437

         gp.addG("sys cmd chcp");
         final JLabel response = new JLabel("... executing ...");
         gp.addG(response);

         SwingWorker<String, Object> sw = new SwingWorker<String, Object>()
         {
            @Override protected final String doInBackground(  ) {
               try{
                  String rep = ProcessUtils.readWholeProcessStack("cmd", "/C", "chcp");
                  return rep;
               }
               catch(final Exception e) {
                  return "Failed: "+e.getMessage();
               }
            }

            @Override
            protected void done() {
                try {
                    response.setText(get());
                } catch (Exception ignore) {
                }
            }
         };

         sw.execute();
      }


      gp.getGridLayout().addSeparator();

      gp.addG("input");
      gp.addG(new JScrollPane(tpIn), true);
      tpIn.setText("c2 b5 20 3d 20 	34 20 3f 00 00 	00 00 00 00 00");
      //tpIn.setText("-62, -75, 32, 61, 32, 52, 32, 63, 0, 0, 0, 0, 0, 0, 0");

      tpIn.setPreferredSize(new Dimension(300,200));
      tpIn.setMinimumSize(new Dimension(300,200));
      tpIn.setPreferredSize(tpIn.getPreferredSize());

      final JButton qj = new JButton(" add chars ...");
      GUIUtils.makeSmall(qj);
      qj.setToolTipText("add some exotic characters");
      gp.addG("");
      gp.addG(qj, false);
      qj.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae)
      {
         final JPopupMenu pop = CharUtils.charExplorerPopup(tpIn.getFont(),
             new ActionListener() { public void actionPerformed(final ActionEvent ae) {
                String bt = ((JButton)ae.getSource()).getText();
                tpIn.setText( tpIn.getText() +bt );
             }}
         );
         pop.show(qj,0,0);
      } });

      gp.addG("input format");
      gp.addG(inputFormat, false);
      inputFormat.setSelectedIndex(3);

      gp.getGridLayout().insertLineBreakAfterNextComponent();
      gp.addG("");

      gp.getGridLayout().addTitleSeparator("decoding options");

      final JCheckBox trim = new JCheckBox("trim decoded string (ignore 0s at end)", true);
      gp.addG("");
      gp.addG(trim);

      final JCheckBox acceptOnlyWithoutControls = new JCheckBox("accept only results without control codes", true);
      gp.addG("");
      gp.addG(acceptOnlyWithoutControls);


      final JTextField maxCodePoint = new JTextField("1024", 6);
      gp.addG("max codepoint");
      gp.addG(maxCodePoint, false            );


      final JButton gb = new JButton("View decoders for the given input");
      final JButton sall = new JButton("View all decoders");
      gp.addG("Output");
      gp.addG(GUIUtils.addComponentsToLine(gb, " ", sall));

      gb.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae)
      {
         try
         {
            exploreCharsets(getInputBytes(), true, trim.isSelected(), acceptOnlyWithoutControls.isSelected(), Integer.parseInt(maxCodePoint.getText()));
         }
         catch(final Exception e)
         {
            JOptionPane.showMessageDialog(null, "Bad format: "+e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
         }

      } });

      sall.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         try{
            exploreCharsets(getInputBytes(), false, trim.isSelected(), acceptOnlyWithoutControls.isSelected(), Integer.parseInt(maxCodePoint.getText()));
         }
         catch(final Exception e) {
            JOptionPane.showMessageDialog(null, "Bad format: "+e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
         }
      } });


      setSize(660, 560);
      setLocationRelativeTo(null);
      setVisible(true);
   }

   private byte[] getInputBytes() throws Exception
   {
      if(inputFormat.getSelectedIndex()==0)
      {
         return tpIn.getText().getBytes(Charset.forName("UTF-8"));
      }
      if(inputFormat.getSelectedIndex()==1)
      {
         return tpIn.getText().getBytes(Charset.defaultCharset());
      }
      if(inputFormat.getSelectedIndex()==2)
      {
         // byte as int
         List<Integer> bytes = new ArrayList<Integer>();
         for(String si : tpIn.getText().split("[\\s,;]"))
         {
            si = si.trim();
            if(si.isEmpty()) continue;
            bytes.add( Integer.parseInt(si) );
         }
         byte[] b = new byte[bytes.size()];
         for(int i=0; i<b.length; i++)
         {
            b[i] = bytes.get(i).byteValue();
         }
         return b;
      }

      if(inputFormat.getSelectedIndex()==3)
      {
         List<Byte> bytes = new ArrayList<Byte>();
         for(String si : tpIn.getText().split("[\\s,;]"))
         {
            si = si.trim();
            if(si.isEmpty()) continue;
            //bytes.add( Byte.parseByte(si, 16) ); // FF is out of range !
            bytes.add( Integer.valueOf(Integer.parseInt(si, 16)).byteValue() );
         }
         byte[] b = new byte[bytes.size()];
         for(int i=0; i<b.length; i++)
         {
            b[i] = bytes.get(i);
         }
         return b;

      }
      if(inputFormat.getSelectedIndex()==4)
      {
         //file
         String fin = tpIn.getText().trim();
         if(fin.length()>0)
         {
            File f = new File(fin);
            if(f.exists())
            {
               long len = f.length();
               try
               {
                  if(len<1000)
                  {
                     return FileUtils.getFileByteContent(f);
                  }
                  else
                  {
                     // first 512 ?
                     //todo
                     return FileUtils.getFileByteContent(f);
                  }
               }
               catch(final Exception e) {
                  e.printStackTrace();
               }
            }
         }
      }

      if(inputFormat.getSelectedIndex()==5)
      {
          final List<String> cmd;
          if(SysUtils.is_Windows_OS())
          {
             cmd = CollectionUtils.asArrayList("cmd", "/C");
          }
          else
          {
             cmd = CollectionUtils.asArrayList( "/bin/sh", "-c");
          }
          cmd.add( tpIn.getText().trim() );  // NO split here.
          System.out.println("executing shell command: "+cmd);

          return ProcessUtils.readWholeProcessStackRAW(cmd, TimeUnit.MINUTES.toMillis(1));
      }

      if(inputFormat.getSelectedIndex()==6)
      {
         File f = new File(""+tpIn.getText().trim());
         byte[] bc = FileUtils.getFileByteContent(f);
         System.out.println("CharsetDecoderExplorer: read "+bc.length+" bytes from "+f);
         return bc;
      }

      return null;
   }


   // http://unicode.org/faq/utf_bom.html#BOM

   public static void main2() throws Exception {
      System.out.println(""+ Integer.parseInt("FF", 16));
   }


   static boolean canDecode(Charset cs, byte[] todo)
   {

      try
      {
         CharBuffer bb  = cs.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode( ByteBuffer.wrap(todo) );
         String result = new String(bb.array());
         return true;
      }
      catch(final Exception e) {
         return false;
      }
   }


   private void exploreCharsets(final byte[] testTodecode, final boolean onlyDecodingTest, final boolean trim, final boolean onlyWithoutCtrl, final int maxCodePoint)
   {

         final FineGrainTableModelBuilder<CTD> tmb = new FineGrainTableModelBuilder<CTD>(6);
         tmb.setColumnNames("name", "average char per byte", "max char per byte", "decoded text", "has controls", "max char");
         tmb.setPreferredColumnWidth(8,4,4,20,4, 4);
         final SortedMap<String, Charset> sortedMap = Charset.availableCharsets();
         for(final String ki : sortedMap.keySet())
         {
            Charset cs = sortedMap.get(ki);
            if( onlyDecodingTest && !canDecode(cs, testTodecode)) continue;


            CTD dec = new CTD(cs, testTodecode, trim);

            if(onlyWithoutCtrl && dec.hasControls) continue;

            if(maxCodePoint>0 && dec.maxCP>maxCodePoint) continue;

            tmb.addRows(dec);
         }

         System.out.println(""+tmb.getRowCount()+" charsets found");

         JPanel p = new JPanel(new BorderLayout());
         final SortableTableModel stm = new SortableTableModel(tmb);
         final JTable t = new JTable(stm);
         stm.installGUI(t);

         final SimpleDocument doc = new SimpleDocument();
         final JTextPane preview = new JTextPane(doc);
         JSplitPane sp = new JSplitPane(JSplitPane.VERTICAL_SPLIT, new JScrollPane(t), new JScrollPane(preview));
         p.add(sp, BorderLayout.CENTER);
         sp.setDividerLocation(320);

         p.add(new MultiSearchPanel(stm), BorderLayout.NORTH);

         //final JCheckBox markControlChars = new JCheckBox("control chars in red (CR LF except)", true);
         //p.add(markControlChars, BorderLayout.SOUTH);

         //JButton toFile = new JButton("to file...");

         GUIUtils.displayInDialog(this, "All charset encoders", p).setSize(600,600);  ;

         t.getSelectionModel().addListSelectionListener(new ListSelectionListener()
         {
            public final void valueChanged( final ListSelectionEvent lse) {
                final List<CTD> sel = tmb.getSelectedItems(t, stm);
                if(sel.size()==1)
                {
                   doc.setText(""+sel.get(0).result+"\n\nchars: ");
                   //
                   for(char ci : sel.get(0).result.toCharArray())
                   {
                      if(Character.isISOControl(ci))
                      {
                         doc.appendError((int) ci+" ");
                      }
                      else
                      {
                         doc.append((int) ci+" ");
                      }

                   }
                }
                else
                {
                   doc.setText(""+sel.size()+" selected entries");
                }
                preview.setCaretPosition(0);
            }
         });
   }


//c:\temp\test_utf8.txt

   public static void main(String[] args) throws Exception
   {EventQueue.invokeLater(new Runnable() { public void run() {
      new CharsetDecoderExplorer();
   }});

   }

}