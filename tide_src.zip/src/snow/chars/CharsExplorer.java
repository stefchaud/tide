package snow.chars;

import snow.sortabletable.*;

import snow.chars.CharUtils;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import java.awt.font.GlyphVector;
import snow.veg.ShapeEd;
import snow.utils.gui.*;
import java.net.URL;
import snow.utils.NetUtils;
import snow.utils.gui.GUIUtils;
import java.util.prefs.Preferences;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.nio.charset.*;
import java.nio.*;
import java.util.*;
import java.io.*;

/**
  ftp://ftp.unicode.org/Public/UNIDATA/unicodeData.txt
  http://unicode.org/Public/UNIDATA/UnicodeData.txt
*/
@SuppressWarnings("nullness")
public class CharsExplorer extends JFrame
{
  final private UnicodeTableModel basicTableModel = new UnicodeTableModel();
  final private SortableTableModel stm = new SortableTableModel(basicTableModel, 1, true);
  final private JTable table = new JTable(stm);

  private final JComboBox charsetCB;
  private final JComboBox displayLimitCB = new JComboBox(new String[]{"32768", "256", "1024", "2048", "4096", "8192", "16384", "32768", "65536"});
  private int charDisplayLimit = 8192;
  final StringBuilder allChars = new StringBuilder();
  final private JDialog previewDialog;
  final private JTextArea previewLabel = new JTextArea(  );
  public final static String downloadURL = "http://unicode.org/Public/UNIDATA/UnicodeData.txt";

  private FontRenderContext frc = new FontRenderContext(new AffineTransform(1,0,0,1,0,0), true, true);

  private CharsExplorer(boolean standalone)
  {
     super("Characters viewer (Unicode16)");
     if(standalone) { this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); }

     table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
     stm.installGUI(table);
     add(GUIUtils.makeSmall(new JScrollPane(table)), BorderLayout.CENTER);

     new UniversalTableCellRenderer(stm, table);

     table.setFont(new Font("Dialog", Font.PLAIN, 16));
     table.setRowHeight(21);

     JPanel northPan = new JPanel();
     northPan.setLayout(new BoxLayout(northPan, BoxLayout.Y_AXIS));
     add(northPan, BorderLayout.NORTH);

     JPanel optsPan = new JPanel(new FlowLayout(FlowLayout.LEFT,3,2));
     northPan.add(optsPan);

     MultiSearchPanel sp = new MultiSearchPanel(stm);
     northPan.add(sp);

     // initialize combobox for charsets
     charsetCB = new JComboBox(collect_limited_Charsets());
     optsPan.add(charsetCB);
     charsetCB.setMaximumRowCount(30);
     charsetCB.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent ae)
       {
         Charset cs = (Charset) charsetCB.getSelectedItem();
         basicTableModel.setCharset(cs);
       }
     });

     optsPan.add(new JLabel(" up to: "));
     optsPan.add(displayLimitCB);
     displayLimitCB.setMaximumRowCount(20);
     displayLimitCB.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent ae)
       {
         String limS = (String) displayLimitCB.getSelectedItem();
         basicTableModel.setDisplayLimit( Integer.parseInt(limS) );
       }
     });

     // only few !
     //final JComboBox fontCB = new JComboBox(Toolkit.getDefaultToolkit().getFontList());
     final String[] allFonts = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
     final JComboBox fontCB = new JComboBox(allFonts);
     fontCB.setMaximumRowCount(30);

     optsPan.add(fontCB);
     fontCB.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent ae)
       {
         String fn = (String) fontCB.getSelectedItem();

         table.setFont(new Font(fn, Font.PLAIN, 16));
         previewLabel.setFont(new Font(fn, Font.PLAIN, 50));

         Preferences.userRoot().put("CharsExplorer_font", fn);
       }
     });

     // [feb2011]
     fontCB.setSelectedItem(Preferences.userRoot().get("CharsExplorer_font", "Lucida Sans Unicode"));
     //"Arial Unicode MS" is better

     File udata = new File(Preferences.userRoot().get("unicodedata_path", "c:/data/unicodedata.txt"));
     if(!udata.exists())
     {
      //  if(!udata.exists()) throw new RuntimeException("No unicode data: "+udata);
     }

     JButton ed = new JButton("E");
     optsPan.add(ed);
     ed.setToolTipText("Edits the selected shapes");
     ed.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
            String str = previewLabel.getText().trim();
            if(str.isEmpty()) str+="@";

            GlyphVector glv = table.getFont().createGlyphVector(frc, str);
            Shape fs = glv.getOutline(5,20);
            ShapeEd.edit(fs, false);
     } });


     final JButton qj = new JButton("J");
     qj.setToolTipText("Selected characters");
     optsPan.add(qj);  // quick jump
     qj.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
        final JPopupMenu pop = CharUtils.charExplorerPopup(table.getFont(),
            new ActionListener() { public void actionPerformed(final ActionEvent ae) {
               String bt = ((JButton)ae.getSource()).getText();
               previewLabel.setText( previewLabel.getText()+bt );

               if(!bt.isEmpty())
               {
                  try{
                     int pos = (int) bt.charAt(0);
                     System.out.println("pos="+pos);
                     Rectangle rp = table.getCellRect(pos,0,true);
                     table.scrollRectToVisible(rp);
                     table.getSelectionModel().setSelectionInterval(pos,pos);
                  }
                  catch(final Exception e) {
                     e.printStackTrace();
                  }
               }
            }}
        );
        pop.show(qj,0,0);
     } });

     if(udata.exists()) {
        parseUnicodeData(udata);
     }

     this.basicTableModel.setDisplayLimit(32768);
     charsetCB.setSelectedIndex(0);

     setSize(950,480);
     setLocation(100,150);
     setVisible(true);

     previewDialog = new JDialog(this, "Chars Preview", false);
     previewDialog.setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
     previewDialog.setLayout(new BorderLayout());
     previewDialog.add(new JScrollPane(previewLabel), BorderLayout.CENTER);
     previewLabel.setLineWrap(true);
     previewDialog.setSize(300,350);
     previewDialog.setLocation(getX()+getWidth()+5, getY());
     previewDialog.setVisible(true);

     table.scrollRectToVisible( table.getCellRect(50,0,true));

     table.getSelectionModel().addListSelectionListener(new ListSelectionListener()
     {
        public void valueChanged(ListSelectionEvent lse)
        {
           if(lse.getValueIsAdjusting()) return;

           int sel = table.getSelectedRow();
           if(sel==-1)
           { previewLabel.setText(""); return; }

           int pos = stm.getIndexInUnsortedFromTablePos(sel);
           if(pos==-1)
           { previewLabel.setText(""); return; }

           String nt = previewLabel.getText() + basicTableModel.getValueAt(pos,3);
           if(nt.length()>20) nt = nt.substring(nt.length()-20, nt.length());
           previewLabel.setText(nt);
        }
     });

     //System.out.println((int) Character.MAX_VALUE+" ");
  } // Constructor


  private Vector<Charset> collect_limited_Charsets()
  {
     SortedMap<String, Charset> sm = Charset.availableCharsets();
     Vector<Charset> items = new Vector<Charset>(sm.values());
     for(int i=items.size()-1; i>=0; i--)
     {
/*ACCEPT ALL
       Charset cs = (Charset) items.elementAt(i);
       if(cs.newEncoder().averageBytesPerChar()!=1.0f)
       {
         items.remove(cs);
       }*/
     }
     return items;
  }

  final private Hashtable<Integer, String> names = new Hashtable<Integer, String>();

  public void parseUnicodeData(File file)
  {
   FileReader fr = null;

   try
   {
     fr = new FileReader(file);
     BufferedReader br = new BufferedReader(fr);
     String line = null;
     while( (line=br.readLine())!=null)
     {
       try
       {
        // 0041 ; LATIN CAPITAL LETTER A ; Lu;0;L;;;;;N;;;;0061;
        StringTokenizer tokenizer = new StringTokenizer(line, ";");
        String n = tokenizer.nextToken(); //  0041
        String name = tokenizer.nextToken(); //  name

        int code = Integer.parseInt(n, 16);
        names.put(code, name);
       }
       catch(Exception e)
       {
         System.out.println("Cannot parse "+line);
       }
     }
   }
   catch(Exception e)
   {
    e.printStackTrace();
   }
   finally
   {
     try{fr.close();} catch(Exception e) {}
   }
  }

  /* Offer download.
  *
  private File askUnicodeDataPath()
  {
     final String[] rep = new String[]{"unicodedata.txt"};
     final JDialog d = new JDialog(this, "Missing unicodedata file", true); // modal
     d.add(GUIUtils.createReadOnlyDescriptionArea("The unicodedata.txt file (1MB) is missing."
     +"\nThis is not mandatory but very useful to search for characters by name,"
     +"\nfor example the cyrillic capital letter ksi (046e): \u046e."
     +"\nThe file can be downloaded from the unicode organization homepage."), BorderLayout.CENTER);
     JPanel cp = new JPanel(new FlowLayout(FlowLayout.CENTER,5,5));
     d.add(cp, BorderLayout.SOUTH);
     JButton cancel = new JButton("cancel", Icons.sharedCross);
     cp.add(cancel);
     cancel.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
        d.setVisible(false);
     } });

     JButton spec = new JButton("specify location");
     cp.add(spec);
     spec.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
        JFileChooser fs = new JFileChooser();

        fs.setFileSelectionMode(fs.FILES_ONLY);
        fs.setDialogTitle("Give the location of unicodedata.txt");
        int resp =fs.showOpenDialog(d) ;
        if(resp==JFileChooser.APPROVE_OPTION)
        {
           rep[0] = fs.getSelectedFile().getAbsolutePath();
        }
        d.setVisible(false);
     } });

     JButton down = new JButton("download", Icons.sharedDownArrow);
     cp.add(down);
     down.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {

        JFileChooser fs = new JFileChooser();
        fs.setFileSelectionMode(fs.FILES_ONLY);
        fs.setDialogTitle("Give the location to store unicodedata.txt");
        int resp =fs.showSaveDialog(d) ;
        if(resp==JFileChooser.APPROVE_OPTION)
        {
           rep[0] = fs.getSelectedFile().getAbsolutePath();
           try
           {
              URL url = new URL(downloadURL);
              NetUtils.download(url, fs.getSelectedFile());
           }
           catch(Exception e) {
              JOptionPane.showMessageDialog(d, "Cannot download:\n  "+e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
              e.printStackTrace();
           }
        }

        d.setVisible(false);
     } });

     d.pack();
     d.setLocationRelativeTo(null);
     d.setVisible(true);


     // dummy
     return new File(rep[0]);
  }*/



   public static boolean isInstalled()
   {
      File cand = new File(Preferences.userRoot().get("unicodedata_path","c:/data/unicodedata.txt"));
      if(cand.exists()) return true;
      return false;
   }

   public static /*@org.checkerframework.checker.nullness.qual.Nullable*/ File install() throws Exception
   {
      String[] opts = new String[]{"Download it for you", "Take a specified nam_dict.txt location"};
      Object rep = JOptionPane.showInputDialog(null,
         "Names Explorer needs the unicodedata.txt file from\n\n   "+downloadURL+"  [1MB]"
         +"\n\nWhat should I do ?\n\n",
         "Confirmation", JOptionPane.QUESTION_MESSAGE,
         null, opts, opts[0]);
      if(rep==null) return null;

      if(rep.equals(opts[1]))
      {
         JFileChooser fs = new JFileChooser();
         fs.setDialogTitle("Specify the location of unicodedata.txt");
         fs.setFileSelectionMode(JFileChooser.FILES_ONLY);
         int acc = fs.showOpenDialog(null);
         if(acc!=JFileChooser.APPROVE_OPTION) return null;
         final File f = fs.getSelectedFile();
         if(!f.getName().equalsIgnoreCase("unicodedata.txt"))
         {
            JOptionPane.showMessageDialog(null, "The file MUST be unicodedata.txt\n\n   "+f+"\n\nis invalid.",
               "Error", JOptionPane.ERROR_MESSAGE);
            return null;
         }
         Preferences.userRoot().put("unicodedata_path", f.getAbsolutePath());
         return f;
      }
      else
      {
         // download
         JFileChooser fs = new JFileChooser();
         fs.setDialogTitle("Specify a folder to install unicodedata.txt in");
         fs.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
         int acc = fs.showSaveDialog(null);
         if(acc!=JFileChooser.APPROVE_OPTION) return null;
         final File destFold = fs.getSelectedFile();
         final File destFile = new File(destFold, "unicodedata.txt");
         ProgressModalDialog pmd = ProgressModalDialog.createStandaloneProgress("Installing");
         try
         {
            NetUtils.downloadFileFromServer(new URL(downloadURL), destFile, "unicodedata.txt", pmd);
            Preferences.userRoot().put("unicodedata_path", destFile.getAbsolutePath());
            return destFile;
         }
         finally
         {
            pmd.closeDialog();
         }
      }

     // return null;
   }



/** Standalone launcher.
*/
  public static void main(String[] a) throws Exception
  {
     launch(true);
  }


  public static void launch(final boolean standalone) throws Exception
  {
     if(!isInstalled())
     {
        if(install()==null)
        {
          // return;
        }
     }

     EventQueue.invokeLater(new Runnable()
     { public void run()
       {
         new CharsExplorer(standalone);
       }
     });
  }





  class UnicodeTableModel extends FineGrainTableModel
  {
     private char[] representableCharsetChars = null;

     String[] COLUMN_NAMES = new String[]{"representable", "hexcode", "intcode", "char", "name", "unicode block", "type"}; //, "lowercase", "uppercase", "titlecase" };

     int[] COLUMN_PREFERRED_SIZES = new int[]{4, 8,8,8, 28,16, 4,4,4,4};
     @Override
     public int getPreferredColumnWidth(int column)
     {
       if(column>=0 && column<COLUMN_PREFERRED_SIZES.length) return COLUMN_PREFERRED_SIZES[column];
       return -1;
     }
     @Override
     public String getColumnName(int col) { return COLUMN_NAMES[col]; }

     @Override
     public int getColumnAlignment(int column)
     {
       if( column==3 || column==4) return JLabel.LEFT;
       return JLabel.CENTER;
     }

     public int getColumnCount() { return COLUMN_NAMES.length; }
     public int getRowCount()    { return charDisplayLimit; }

     public void setDisplayLimit(int lim)
     {
       //System.out.println("set limit to "+lim);
       fireTableModelWillChange();
       charDisplayLimit = lim;
       fireTableDataChanged();
       fireTableModelHasChanged();
     }

     public void setCharset(Charset cs)
     {
      fireTableModelWillChange();
      byte[] bb = new byte[256];
      for(int i=0; i<256; i++)
      {
        bb[i] =  (byte) i;
      }

      representableCharsetChars = cs.decode(ByteBuffer.wrap(bb)).toString().toCharArray();
      Arrays.sort(representableCharsetChars);
      fireTableDataChanged();
      fireTableModelHasChanged();
     }


     public Object getValueAt(int row, int col)
     {
       char c = (char) row;

       if(col==0)
       {
        if(representableCharsetChars==null) return Boolean.TRUE;
        int pos = Arrays.binarySearch(representableCharsetChars, c);
        return Boolean.valueOf( pos>=0 );
       }

       if(col==1)
       {
         String hexCode = "000"+Integer.toHexString(row);
         return hexCode.substring(hexCode.length()-4,hexCode.length());
       }

       if(col==2) return row;


       if(col==3) return ""+c ;
       if(col==4)
       {
         Object n = names.get(row); //Character.toString(c);
         if(n==null) return "";
         return ""+n;
       }
       if(col==5)
       {
         Character.UnicodeBlock ub = Character.UnicodeBlock.of(c);  // in 1.5, can be applied to INT
         if(ub==null) return "";
         return ""+ub;
       }

       if(col==6) return Integer.valueOf(Character.getType(c));
       if(col==7) return Boolean.valueOf(Character.isLowerCase(c));
       if(col==8) return Boolean.valueOf(Character.isUpperCase(c));
       if(col==9) return Boolean.valueOf(Character.isTitleCase(c));

       return "?";
     }

/*
     public Class getColumnClass(int col)
     {
       if(col==0) return Integer.TYPE;
       return String.class;
     }  */
  }


}