package snow.chars;

import java.nio.charset.Charset;
import java.util.Vector;
import javax.swing.JComboBox;

/** class CharsetUtils.
*/
public final class CharsetUtils
{
   /** Constructor. */
   public CharsetUtils()
   {
   }


   /** selected item is either a string for the default encoder
   *    or a charset to use.
   *    Tipp: use  CharsetUtils.getSelected(cb) to get the selected.
   */
   public static JComboBox getCharsetEncodersCombobox()
   {
      Vector<Object> encoders = new Vector<Object>();
      encoders.add("Default ("+Charset.defaultCharset()+")");
      for(Charset cs : Charset.availableCharsets().values())
      {
         if(cs.canEncode())
         {
            encoders.add(cs);
         }
      }
      return new JComboBox(encoders);
   }

   public static Charset getSelected(JComboBox cb)
   {
      if( cb.getSelectedItem() instanceof Charset )
      {
         return (Charset) cb.getSelectedItem();
      }
      String n = ""+cb.getSelectedItem();
      if(n.startsWith("Default "))
      {
         return Charset.defaultCharset();
      }

      return Charset.forName(n);
   }


   public static /*@org.checkerframework.checker.nullness.qual.Nullable*/ Charset getSelected_NullIfDefault(JComboBox cb)
   {
      if( cb.getSelectedItem() instanceof Charset )
      {
         return (Charset) cb.getSelectedItem();
      }

      String n = ""+cb.getSelectedItem();
      if(n.startsWith("Default "))
      {
         //return Charset.defaultCharset();
         return null;
      }

      return Charset.forName(n);
   }



   /** selected item is either a string for the default encoder
   *    or a charset to use.
   *
   *    Tipp: use  CharsetUtils.getSelected(cb) to get the selected.
   */
   public static JComboBox getCharsetDecodersCombobox()
   {
      Vector<Object> encoders = new Vector<Object>();
      encoders.add("Default ("+Charset.defaultCharset()+")");
      for(Charset cs : Charset.availableCharsets().values())
      {
         encoders.add(cs);
      }
      return new JComboBox(encoders);
   }
}