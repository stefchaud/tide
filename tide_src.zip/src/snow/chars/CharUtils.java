package snow.chars;

import java.util.*;
import snow.utils.gui.GUIUtils;
import snow.utils.gui.JGridPanel;
import javax.swing.event.*;
import java.awt.Font;
import java.awt.event.*;
import javax.swing.*;

/** CharUtils.
*/
public final class CharUtils
{
   /** Constructor. */
   private CharUtils()
   {
   }

/*
  http://www.stewi.ch/de/LadyPlus_Zubehoer.php
  http://www.stewi.ch/de/Lady_Zubehoer.php
*/


//12288 ideograph, jap
//13184 units
//19968 ideogr

static List<Object[]> niceCharRanges = new ArrayList<Object[]>();
static
{
   niceCharRanges.add(new Object[]{"nice", 8490, 15});
   niceCharRanges.add(new Object[]{"arrows", 8592, 91});
   niceCharRanges.add(new Object[]{"math1", 8704, 100});
   niceCharRanges.add(new Object[]{"math2", 8804, 142});
   niceCharRanges.add(new Object[]{"ocr", 9280, 11});
   niceCharRanges.add(new Object[]{"(a)", 9312, 140});
   niceCharRanges.add(new Object[]{"box", 9472, 150});
   niceCharRanges.add(new Object[]{"polygons", 9632, 80});
   niceCharRanges.add(new Object[]{"meteo/symb", 9728, 84});
   niceCharRanges.add(new Object[]{"chess/music", 9812, 29});
   niceCharRanges.add(new Object[]{"scissors", 9985, 150});

   niceCharRanges.add(new Object[]{"greek", 913, 100});
   niceCharRanges.add(new Object[]{"hebrew", 1488, 40});
   niceCharRanges.add(new Object[]{"cyril1", 1025, 135});
   niceCharRanges.add(new Object[]{"cyril2", 1025+143, 140});
   niceCharRanges.add(new Object[]{"arab", 1632, 156});

   //a lot more... only see start...
   niceCharRanges.add(new Object[]{"ideogr1", 12288, 100});
   niceCharRanges.add(new Object[]{"units", 13184, 100});
   niceCharRanges.add(new Object[]{"ideogr2", 19968, 100});
}

  public static JPopupMenu charExplorerPopup( final ActionListener selectionListener)
  {
     //final Font font = new Font("Lucida Sans Unicode", Font.PLAIN, 15);
     final Font font = new Font("Arial Unicode MS", Font.PLAIN, 15);
     return charExplorerPopup(font, selectionListener);
  }

  /** tipp: pop.getClientProperty("typed");
  */
  public static JPopupMenu charExplorerPopup(final Font font, final ActionListener selectionListener)
  {
     final JPopupMenu pop = new JPopupMenu();

     final JCheckBoxMenuItem keepOpen = new JCheckBoxMenuItem("keep open", false);

     //don't work!! closes when clicked ! :  pop.add(keepOpen);

     final ActionListener ali = new ActionListener() { public void actionPerformed(ActionEvent ae) {
        JButton bt = (JButton) ae.getSource();
        System.out.println(""+bt.getText()+" "+bt.getToolTipText());

        String tt = "";
        if(pop.getClientProperty("typed")!=null)
        {
           tt+=pop.getClientProperty("typed");
        }
        tt+=bt.getText();
        pop.putClientProperty("typed", tt);

        if(selectionListener!=null) {
          selectionListener.actionPerformed(ae);
        }

        if(!keepOpen.isSelected())
        {
          pop.setVisible(false);
        }
     } };


     for(final Object[] rangei : niceCharRanges)
     {
        final int st = (Integer) rangei[1];
        final int len = (Integer) rangei[2];

        final JMenu mi=new JMenu(""+rangei[0]);
        pop.add(mi);

        createAtMenuSelection(mi, new ActionListener() { public void actionPerformed(final ActionEvent ae) {
               JGridPanel bp = new JGridPanel(10);
               mi.add(bp);
               for(int i=0; i<len; i++)
               {
                  int pi = st+i;
                  JButton bi = GUIUtils.makeSmall(new JButton( ""+(char) (pi)));
                  bi.setFont(font);
                  bi.setToolTipText("<html><h1>"+pi+"  "+(char) pi);
                  bp.addG(bi);
                  bi.addActionListener(ali);
               }
       }});
     }

     pop.addSeparator();

     for(int pg=0; pg<20; pg++)
     {
       final int st = 161+pg*100;
       final JMenu mi=new JMenu(""+st+" - "+(st+99));
       pop.add(mi);

       createAtMenuSelection(mi, new ActionListener() { public void actionPerformed(final ActionEvent ae) {
                  JGridPanel bp = new JGridPanel(10);
                  mi.add(bp);
                  for(int i=0; i<100; i++)
                  {
                     int pi = st+i;
                     JButton bi = GUIUtils.makeSmall(new JButton( ""+(char) (pi)));
                     bi.setFont(font);
                     bi.setToolTipText("<html><h1>"+pi+"  "+(char) pi);
                     bp.addG(bi);
                     bi.addActionListener(ali);
                  }
       }});

     }

     return pop;
  }

  /** Useful to create popup content (in mi) at selection time instead as in advance
  */
  public static void createAtMenuSelection(final JMenu mi, final ActionListener creationCode)
  {
       mi.addMenuListener(new MenuListener()
       {
          public final void menuCanceled( final MenuEvent e ) {
          }

          public final void menuDeselected( final MenuEvent e ) {
          }

          public final void menuSelected( final MenuEvent e )
          {
             //BUG: comp ct = 0 always !!   System.out.println("mc = "+mi.getComponentCount()+ "  "+mi.getItemCount());
             if(mi.getItemCount()==0)
             {
                creationCode.actionPerformed(null);
             }
          }
       });
  }

}