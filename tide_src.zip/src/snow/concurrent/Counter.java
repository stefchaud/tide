package snow.concurrent;

import java.util.Vector;

// not thread safe...
public class Counter
{
  private int counterValue = 0;
  public Counter()
  {
  }

  public void increment(int count)
  {
    counterValue += count;
    notifyValueChanged();
  }

  public int getCount() { return counterValue; }

  final private Vector<CounterListener> listeners = new Vector<CounterListener>();
  public void addCounterListener(CounterListener cl)
  {
    listeners.add(cl);
  }
  public void removeCounterListener(CounterListener cl)
  {
    listeners.remove(cl);
  }

@SuppressWarnings("nullness")
  private void notifyValueChanged()
  {
    for(CounterListener cl: listeners.toArray(new CounterListener[listeners.size()]))
    {
      cl.counterUpdated(counterValue);
    }
  }

  private void terminateCounter()
  {
    listeners.clear();
  }

}