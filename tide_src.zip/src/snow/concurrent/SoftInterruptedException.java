package snow.concurrent;

/** Useful to propagate InterruptedException as unchecked RuntimeExceptions.
*   Used in the ProgressModalDialog on cancellation and multithreaded routines.
*/
public final class SoftInterruptedException extends RuntimeException {

   public SoftInterruptedException() {
   }

   public SoftInterruptedException(final String mess) {
      super(mess);
   }

   public SoftInterruptedException(final String mess, final Throwable cause) {
      super(mess, cause);
   }

   public SoftInterruptedException(final Throwable cause) {
      super(cause);
   }
}