package snow.concurrent;

import java.awt.EventQueue;
import java.awt.event.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.event.*;
import javax.swing.text.Document;
import snow.utils.gui.JGridPanel;

public final class DelayedMergedUpdater2 implements ActionListener, DocumentListener, ChangeListener, CaretListener
{
  //todo: maybe better realized with javax.swing.Timer  and coalesce !


  private final ActionListener action; // action to be executed
  private final long minSilenceMS; // min duration between two update calls

  // if true, ensure the action is executed in the EDT thread.
  private final boolean edt;

  private volatile long lastAction = 0; // timestamp of last change event
  private final AtomicBoolean isWaiting = new AtomicBoolean(false);

  private final ThreadFactory threadFactory = new ThreadFactory()
  {
    public Thread newThread(final Runnable r)
    {
      final Thread t = new Thread(r);
      t.setName("DelayedMergedUpdater2");
      return t;
    }
  };
  // dies after 1 minute unused
  private final ExecutorService executor = Executors.newCachedThreadPool(this.threadFactory);



  /**
   *
   * @param minSilenceMS minimum period of "silence" to wait before updating the given action.
   * @paralm edt if true, the update is placed in the EventQueue queue.
   * @param action  the action to update.
   */
  public DelayedMergedUpdater2(final long minSilenceMS, final boolean edt, final ActionListener action)
  {
    super();

    this.action = action;
    this.minSilenceMS = minSilenceMS;
    this.edt = edt;
  }



  /**
   * the loop (the engine) that triggers the update when necessary after the correct amound of silence.
   */
  private void updaterLoop()
  {
    try
    {
      // once notified try update, sleeping if necessary
      long dt = 0;
      while ((dt = System.currentTimeMillis()-this.lastAction) < this.minSilenceMS)
      {
        // try to wait exactely
        try
        {
          Thread.sleep(this.minSilenceMS - dt);
        }
        catch (InterruptedException ire)
        {
        }
      }

      update();
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
    finally
    {
      this.isWaiting.set(false);
    }
  }

  private void update() throws Exception
  {
    try
    {
      if(this.edt)
      {
        EventQueue.invokeLater(new Runnable()
        {
          public void run()
          {
            action.actionPerformed(null);
          }
        });
        return;
      }

      this.action.actionPerformed(null);
    }
    catch(Exception e)
    {
      throw e;
    }
  }


  /**
  * Call this to perform an update of the action.
  * The update will be performed after a silence period greater than the minimal given "silence" delay.
  * Subsequent calls are merged, i.e. only the "last" one will be "executed".
  */
  public void changeOccured()
  {
    this.lastAction = System.currentTimeMillis();

    if( ! this.isWaiting.getAndSet(true))
    {
      this.executor.submit(new Runnable()
      {
        public void run()
        {
          updaterLoop();
        }
      });
    }
  }

  // the listeners

  // @Implements("ChangeListneer")
  public final void stateChanged( final ChangeEvent e ) {
     changeOccured();
  }

  // @Implements("ActionListener")
  public final void actionPerformed( final ActionEvent e ) {
     changeOccured();
  }

  // @Implements("DocumentListener")
  public final void changedUpdate( final DocumentEvent e ) {
    changeOccured();
  }

  // @Implements("DocumentListener")
  public final void insertUpdate( final DocumentEvent e ) {
     changeOccured();
  }

  // @Implements("DocumentListener")
  public final void removeUpdate( final DocumentEvent e ) {
     changeOccured();
  }

  // @Implements("CaretListener")
  public void caretUpdate(javax.swing.event.CaretEvent ce)
  {
     changeOccured();
  }

  // Helpers

  public DelayedMergedUpdater2 onChange(JButton b)
  {
     b.addActionListener(this);
     return this;
  }

  public DelayedMergedUpdater2 onChange(Document d)
  {
     d.addDocumentListener(this);
     return this;
  }


  static void test()
  {
     JGridPanel gl = new JGridPanel(2);

     gl.addG("name");
     JTextField tf = new JTextField();
     gl.addG(tf);

     JButton bt = new JButton("change");
     gl.addG("");
     gl.addG(bt);

     DelayedMergedUpdater2 dmu = new DelayedMergedUpdater2(300, true, new ActionListener() { public void actionPerformed(final ActionEvent ae) {
        System.out.println(" Hello");
     } });
     dmu.onChange( tf.getDocument() );
     dmu.onChange( bt );

     gl.showInDialog(null, "test", true);
  }

}