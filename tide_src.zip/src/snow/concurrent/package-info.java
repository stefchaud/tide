/** Some concurrency utilities.
*/
package snow.concurrent;