package snow.concurrent;

import java.util.concurrent.*;

/** wraps a runnable into an interruptable task.
  I.e. creates a thread that can be interrupted.
     should only be interrupted when not stopping itself correctely with the Interrupter

 Usage example

     InterruptableTask actualTask = new InterruptableTask()
     {
        public void run()
        {
           ...
           if(interrupter.getShouldStopEvaluation()) return;
        }
     };
     Thread t = new Thread(actualTask);
     t.setPriority(Thread. MIN_PRIORITY);
     t.start();
*/
public abstract class InterruptableTask <T> implements Callable<T>, Runnable  // T is NOT used now.
{
  Thread thread;
  final public Interrupter interrupter = new Interrupter();  // clean and correct way to stop the thread
  Future<?> future;  // set at submit
  private boolean isExecuting = false;

  public InterruptableTask()
  {
  }

  public boolean isExecuting() { return isExecuting; }

  /** Creates a thread to evaluate this task and Waits until completion, returning null
  */
  @SuppressWarnings("nullness")
  public final T call() throws Exception
  {
     if(this.interrupter.getShouldStopEvaluation())
     {
       // never evaluates !
       return null;
     }

     isExecuting = true;
     thread = new Thread(this);  // calls this runnable
     // wait until completion
     try
     {
       thread.start();
       thread.join();
     }
     catch(Exception e)
     {
       kill();
       throw e;
     }
     finally
     {
       isExecuting = false;
     }
     return null;
  }

  /** Use only if request stop has not succeded.
     This kills the thread.
     BE CAREFUL: if the therad calls EventQueue.invokeAndWait, and catch Exception without throwing them
      the thread continues !!
  */
  public void kill()
  {
     if(thread!=null && thread.isAlive())
     {
       thread.interrupt();  // throws an exception that may be catched => not 100% stops
     }

     // thread.stop()  // stops 100% but not safe ! deprecated !!
  }

  public void requestStop()
  {
     if(interrupter.getShouldStopEvaluation())
     {
       // already cool stopped but still called => kill
       kill();
     }
     else
     {
       // first attempt : cool stop
       interrupter.stopEvaluation();
     }
  }


}