package snow.concurrent;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.*;
import java.util.concurrent.*;

/** Counts items. (code base found at JavaOne)
*/
public final class ItemCounter <T> {

   private final ConcurrentMap<T, AtomicInteger> map = new ConcurrentHashMap<T, AtomicInteger>();

   public void increment(T key)
   {
      AtomicInteger value = new AtomicInteger(0);
      AtomicInteger old = map.putIfAbsent(key, value);
      if(old!=null) { value=old; }
      value.incrementAndGet();
   }

   public void increment(T key, int n)
   {
      AtomicInteger value = new AtomicInteger(0);
      AtomicInteger old = map.putIfAbsent(key, value);
      if(old!=null) { value=old; }

      value.addAndGet(n);
   }

   public int getCount(T key)
   {
      AtomicInteger value = map.get(key);
      return value==null ? 0 : value.get();
   }

   public Set<T> getKeys() { return map.keySet(); }

   public int getNumberOfKeys() { return map.size(); }


   @Override public final String toString() {
      final StringBuilder sb = new StringBuilder();
      for(T ki : new TreeSet<T>(getKeys()))
      {
         sb.append("\n"+getCount(ki)+" \toccurence"+(getCount(ki)==1?"":"s")+" of \t'"+ki+"'");
      }
      return sb.toString().trim();
   }



   public final String toStringList() {
      if(map.isEmpty()) return "{}";
      StringBuilder sb = new StringBuilder("{");
      for(T ki : new TreeSet<T>(getKeys()))
      {
         sb.append("{"+getCount(ki)+", "+ki+"}, ");
      }
      sb.setLength(sb.length()-2);
      sb.append("}");
      return sb.toString().trim();
   }

   public final String toStringShort() {
      if(map.isEmpty()) return "";
      final StringBuilder sb = new StringBuilder();
      for(T ki : new TreeSet<T>(getKeys()))
      {
         sb.append(""+getCount(ki)+" "+ki+", ");
      }
      sb.setLength(sb.length()-2);
      return sb.toString().trim();
   }

}