
package snow.concurrent;

public interface CounterListener
{
  public void counterUpdated(int counterValue);
}