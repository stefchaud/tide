package snow.concurrent;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.Collection;

public final class ConcurrentUtils {

   public ConcurrentUtils() {
   }

   /** For thread pools: take 2* number of procs. Works quite fine.
   */
   @SuppressWarnings("nullness")
   public static int getNumberOfProcessors()
   {
      try
      {
        // not present on mac osX
        return Integer.parseInt(System.getenv("NUMBER_OF_PROCESSORS"));
      }
      catch(Exception e)
      {
        return Runtime.getRuntime().availableProcessors();
      }
   }


   public static void terminateAndWait(final ExecutorService exec, final long seconds, final /*@org.checkerframework.checker.nullness.qual.Nullable*/ Interrupter interrupter, final /*@org.checkerframework.checker.nullness.qual.Nullable*/ Collection<Future<?>> futs)
   {
      try
      {
         exec.shutdown();
         exec.awaitTermination(seconds, TimeUnit.SECONDS);
      }
      catch(InterruptedException e) {

         // cancel waiting computations (avoids starting them)
         exec.shutdownNow();

         // preserve this thread's interrupted state
         Thread.currentThread().interrupt();

         // stops the other tasks (softly)
         if(interrupter!=null)
         {
            interrupter.stopEvaluation();
         }

         throw new SoftInterruptedException("", e);   // make it a RuntimeException !
      }
      catch(SoftInterruptedException e) {

         // cancel waiting computations (avoids starting them)
         exec.shutdownNow();

         // preserve this thread's interrupted state
         Thread.currentThread().interrupt();

         // stops the other tasks (softly)
         if(interrupter!=null)
         {
            interrupter.stopEvaluation();
         }

         // propagate the stop
         throw e;
      }

      // [jan2011]: IMPORTANT !
      if(futs!=null)
      {
        checkForSuccessfulCompletion(futs);
      }
   }

   /** To be called after execution completion.
   *   Rethrows execution errors as runtime exception.
   */
   public static void checkForSuccessfulCompletion(final Collection<Future<?>> futs)
   {
      for(final Future fi : futs)
      {
         // called "laundryException" in Goetz's book

         try{
            fi.get();
         }
         catch(final ExecutionException e) {
            if(e.getCause() instanceof RuntimeException)
            {
               throw (RuntimeException) e.getCause();
            }
            throw new RuntimeException(e.getCause());
         }
         catch(final RuntimeException e)
         {
            throw e;
         }
         catch(final Exception e) {
            throw new RuntimeException(e);
         }
      }
   }


   public static void main(String[] args) throws Exception
   {
      System.out.println(""+
      Runtime.getRuntime().availableProcessors());
      System.out.println(""+getNumberOfProcessors());
   }

}