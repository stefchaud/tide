package snow.html;


public final class HTMLUtils
{
   private HTMLUtils()
   {
   }

   /** Replaces the line return with <br> and some subtelties, like "<" and ">".
   */
   public static String convertCharsToHTML(String str)
   {
      //CAUTION don't use someHTMLCodes below !
      //
      // and keep that order !!
      str = str.replace("<", "&lt;");
      str = str.replace(">", "&gt;");
      str = str.replace("\r\n", "<br>");
      str = str.replace("\n", "<br>");
      return str;
   }


   /** With html and body tags at beginning.
   */
   public static String createCODEHTMLFromText(String str)
   {
      return createCODEHTMLFromText(str, false);
   }

   public static String createCODEHTMLFromText(String str, boolean small)
   {
      // keep that order !!
      return "<html><body><pre>"+(small?"<small>":"")+convertCharsToHTML(str)+(small?"</small>":"")+"</pre>";
   }

   public static final String[][] someHTMLCodes = new String[][]
   {
     {"<","&lt;"},   {">","&gt;"},  {"\"","&quot;"},  {"'","&apos;"},  {"&","&amp;"},   //XML
     {"ä","&auml;"},   {"ö","&ouml;"},  {"ü","&uuml;"},
     {"Ä","&Auml;"},   {"Ö","&Ouml;"},  {"Ü","&Uuml;"},
     {"ß","&szlig;"},  {"é","&eacute;"},{"è","&egrave;"},
     {"ê","&ecirc;"},  {"à","&aacute;"},{"ç","&ccedil;"},
     {"ø","&oslash;"}, {"œ","&oelig;"},{"æ","&aelig;"},
     {"ñ","&ntilde;"}, {"+","&euro;"},
     {"£","&pound;"},  {"¥","&yen;"},  {"¡","&iexcl;"},
     {"¿","&iquest;"}, {"©","&copy;"}, {"®","&reg;"},
     {"§","&sect;"},   {"«","&laquo;"}, {"»","&raquo;"},
     {"@","&trad;"}  // ?
     };

   public static String removeHTML(String rep)
   {
      for(final String[] ci : someHTMLCodes)
      {
         if(rep.contains(ci[1]))  // with case !
         {
            rep = rep.replace(ci[1], ci[0]);  // replaces all occurences
         }
      }

      return rep;
   }

}