package snow.html;

import snow.utils.gui.GUIUtils;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;

/** Just a primitive viewer with a statusbar
*/
public class HTMLViewer extends JPanel implements HyperlinkListener
{

  final private JTextPane textPane = new JTextPane();
  final private JTextField statusBar = new JTextField();   // Better than JLabel : can be copy pasted

  public HTMLViewer()
  {
     super(new BorderLayout(0,0));
     add(GUIUtils.makeSmall(new JScrollPane(textPane)), BorderLayout.CENTER);
     textPane.setEditable(false);
     textPane.setContentType("text/html");
     add(statusBar, BorderLayout.SOUTH);
     statusBar.setEditable(false);

     textPane.addHyperlinkListener(this);
  }

  public void hyperlinkUpdate(javax.swing.event.HyperlinkEvent hle)
  {
    if(hle.getURL()!=null)
    {
      statusBar.setText( "URL: "+hle.getURL() );
    }
    else
    {
      statusBar.setText( hle.getDescription() );
    }
  }

  public void setHTMLContent(String cont)
  {
    textPane.setText(cont);
    textPane.setCaretPosition(0);
    statusBar.setText("");
  }


}