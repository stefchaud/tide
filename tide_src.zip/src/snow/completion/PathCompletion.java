package snow.completion;

import snow.utils.storage.FileUtils;
import snow.utils.SysUtils;
import java.io.*;
import java.util.*;

/** To complete file paths.
*/
public final class PathCompletion {

  public PathCompletion() {
  }

  public static class Item
  {
     final private String presentatioName;
     final private String completePath;
     final private String completion;
     //if true should be highlighted in the UI
     public boolean isFilterHit = false;

     public Item(String presentatioName, String completePath, String completion)
     {
        this.presentatioName = presentatioName;
        this.completePath = completePath;
        this.completion = completion;
     }

     public final String getPresentatioName() { return presentatioName; }
     public final String getCompletePath() { return completePath; }
     public final String getCompletion() { return completion; }

     @Override public final String toString() {
        return completion;
     }

  }

  // Sublte ops assuming folders names ends with "/"
  //

  private static boolean isDirectory(String pa)
  {
     return pa.endsWith("/");
  }

  private static String normalize(String pa)
  {
     pa = pa.replace("\\", "/");
     return pa;

  }

  private static String normalize(File fi)
  {
     String pa = normalize(fi.getAbsolutePath());
     if(fi.isDirectory() && !pa.endsWith("/")) pa+="/";
     return pa;
  }

  private static boolean exists(String pa)
  {
     File pf = new File(pa);
     if(!pf.exists()) return false;  // easy
     // subtle:
     if(pf.isDirectory() && !pa.endsWith("/")) return false;
     return true;
  }


  public static List<Item> getCompletions(String pathPart)
  {
     return getCompletions(pathPart, null);  // accepts all files
  }


  /** returns the strings that can be appened to the pathPart in order to get valid paths (1 depth).
  *   To be used in path completions.
  *   ex: "c:/pro" => {"gram files/", jects/"}, ...
  *
  *  IMPORTANT: folders names must end with "/", so we know that c:/windows/system may be completed with "/", or ".ini"
  */
  public static List<Item> getCompletions(String pathPart, /*@org.checkerframework.checker.nullness.qual.Nullable*/ FileFilter fileFilter)   //rem: can't pass a file object here, because inconsistent "/" at end for dirs  new File("c:/temp/").getAbsolutePath() removes the "/" !!
  {
     boolean caseInsensitive = SysUtils.is_Windows_OS();

     final List<Item> comps = new ArrayList<Item>();

     String npa = normalize(pathPart);
     //System.out.println("npa="+npa);

     File paf = new File(pathPart);

     if(!exists(npa))  // as in "c:/pro" => search parent !
     {
        File pP = paf.getParentFile();  // "c:/"
        if(pP==null)
        {

           if(pathPart.endsWith(":"))
           {
              // [dec2011]
              comps.add(new Item("/ (mandatory)", pathPart+"/", "/"));
           }
           else if(pathPart.isEmpty())
           {
              // [dec2011]
              for(File fi : SysUtils.listAllReadableRootsIncludingMedia())
              {
                 String zz = ""+fi;
                 String descr = ""+zz;

                 if(fi.getTotalSpace()==0)
                 {

                    descr += "   no media";  //false: exists: "+fi.exists();
                 }
                 else
                 {
                    if(!fi.canWrite())
                    {
                       descr += "  *ReadOnly*";
                    }
                    else
                    {
                       descr += "  Free: "+FileUtils.formatSize(fi.getUsableSpace());
                    }
                    descr+= ",  Total: "+FileUtils.formatSize(fi.getTotalSpace());
                 }

                 comps.add(new Item(descr, zz, zz));
              }
           }

           return comps;
        }

        String pN = paf.getName();      // "pro"
        if(caseInsensitive) pN = pN.toLowerCase();
        int pnl = pN.length();

        //System.out.println("look in "+pP+" for files named "+pN+"*");



        File[] fis = pP.listFiles(fileFilter);
        if(fis!=null)
        {
           for(File fi : fis)
           {
              String fn = fi.getName();
              if(caseInsensitive) fn = fn.toLowerCase();

              if(fn.startsWith(pN))
              {
                 String cmp = fi.getName();
                 if(fi.isDirectory())
                 {
                    cmp+="/";
                 }

                 Item it = new Item(cmp, normalize(fi), cmp.substring(pnl));
                 if(fileFilter!=null && fi.isFile() && fileFilter.accept(fi))
                 {
                    comps.add(0, it);
                    it.isFilterHit = true;
                 }
                 else
                 {
                    comps.add(it);
                 }
              }
           }
        }
     }
     else
     {
        boolean isDir = isDirectory(npa);

        // the path exists... "c:/windows" or "c:/temp/abc.jpg"
        if(!isDir)
        {

           // nothing to complete (TODO: complete within jars !!)
           return comps;
        }
        else
        {
           File[] fis = paf.listFiles(fileFilter);
           //System.out.println("list files in "+paf );
           if(fis!=null)
           {
              for(File fi : fis)
              {
                 String da = fi.isDirectory() ? "/" :"";
                 Item it =  new Item(fi.getName()+da, normalize(fi), fi.getName()+da);

                 if(fileFilter!=null && fi.isFile() && fileFilter.accept(fi))
                 {
                    comps.add(0, it);
                    it.isFilterHit = true;
                 }
                 else
                 {
                    comps.add(it);
                 }

              }
           }
        }

     }

     return comps;
  }

  /** Useful to "autocomplete" the greatest common path without prompting the user !
  *  @return empty string if none.
  *  [system/, system.ini, system32/]  => "sys"
  */
  public static String getCommonStart(List<Item> comps)
  {
     if(comps.isEmpty()) return "";
     if(comps.size()==1) return comps.get(0).getCompletion();

     boolean caseInsensitive = SysUtils.is_Windows_OS();

     // find the shortest
     String shortest = comps.get(0).getCompletion();
     for(Item it : comps)
     {
        if(it.getCompletion().length()<shortest.length()) {
           shortest = it.getCompletion();
        }
     }

     // look the longest part that matches
  ll:for(int len = shortest.length(); len>=1; len--)
     {
        String ci = shortest.substring(0, len);
        // look if ok
        for(Item it : comps)
        {
           if(caseInsensitive)
           {
             if(!it.getCompletion().toLowerCase().startsWith(ci.toLowerCase())) {
                continue ll;  // failure
             }
           }
           else
           {
             if(!it.getCompletion().startsWith(ci)) {
                continue ll;  // failure
             }
           }
        }

        // yeaah.
        return ci;
     }

     return "";
  }


  private static void test(String pa)
  {
     System.out.println("\n===== TEST FOR : "+pa);
     System.out.println("comps: "+getCompletions(pa));
     System.out.println("common start: "+getCommonStart(getCompletions(pa)));
  }

  public static void main(String[] arguments) throws Exception
  {
      /*test("c:/progra");
      test("c:/program files");
      test("c:/program files/");
      test("c:/temp/test");
      */
      test("");
//     System.out.println("c) "+getCompletions(new File("")));
//     System.out.println("d) "+getCompletions(new File("c:/windows/sys")));
//     System.out.println("d2) "+getCompletions(new File("c:/windows/system")));
//     System.out.println("e) "+getCommonStart(getCompletions(new File("c:/windows/sys"))));
  }
}