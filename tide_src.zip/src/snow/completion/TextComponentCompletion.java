package snow.completion;

import java.awt.Rectangle;
import java.awt.EventQueue;
import javax.swing.text.*;
import java.util.*;
import java.awt.event.*;
import javax.swing.*;


/** Controls the completion for a JTextComponent.
*/
public final class TextComponentCompletion<T>
{
   final private JTextComponent textComponent;
   private /*@org.checkerframework.checker.nullness.qual.Nullable*/ CompletionListener<T> completionListener;
   private final List<T> completions = new ArrayList<T>();
   private final boolean fullMode;
   private final int minCharsToPop;
   private int maxPopupItems = 25;

   private /*@org.checkerframework.checker.nullness.qual.Nullable*/ JPopupMenu previousPop = null;

   final KeyListener listener;


   /** Allows to be notified of completion events.
   */
   public static interface CompletionListener<T> extends EventListener
   {
      public void itemSelected(T item);
   }

   /** May help gc !
   */
   public void deinstallCompletion()
   {
      textComponent.removeKeyListener(listener);
      completionListener = null;
      synchronized(completions)
      {
        completions.clear();
      }
   }


   public TextComponentCompletion(final JTextComponent textComponent, final T... comps_)
   {
      this(textComponent, false, false, 3, comps_);
   }

   /** Adds completion popup for typed text in the textComponent.
   *   The popup shows the possible completions in a popup. the clicking of a given popup item or pressing enter pastes the
   *    selected item in the textComponent.
   */
   public TextComponentCompletion(final JTextComponent textComponent,
           boolean showPopupAtStartup, final boolean fullMode, final int minCharsToPop, final T... comps_)
   {
      this.textComponent = textComponent;
      for(T ci : comps_)
      {
         if(!(""+ci).isEmpty())
         {
            this.completions.add(ci);
         }
      }
      //this.completions.addAll(Arrays.asList(comps_));
      this.fullMode = fullMode;
      this.minCharsToPop = minCharsToPop;

      class Keylistener extends KeyAdapter // call order: P T R
      {
         private /*@org.checkerframework.checker.nullness.qual.Nullable*/ JMenuItem getSelected()
         {
             if(previousPop==null) return null;
             for(MenuElement mi : previousPop.getSubElements())
             {
                JMenuItem mei = (JMenuItem) mi;

                if(mei.isSelected() || mei.isArmed())  // isArmed is true !
                {
                   //System.out.println("Selected: "+mei.getText());
                   return mei;
                }
             }
             //System.out.println("No menu selected !");
             return null;
         }

         @Override public void keyPressed(KeyEvent ke)
         {
            //System.out.println("P");
         }
         @Override public void keyTyped(KeyEvent ke)
         {
            //System.out.println("T");
         }
         @Override public void keyReleased(KeyEvent ke)
         {
            //System.out.println("R");
            if(previousPop!=null)
            {
              int sel = previousPop.getSelectionModel().getSelectedIndex();
              //System.out.println("sel = "+sel);

              if(ke.getKeyCode()==KeyEvent.VK_UP)
              {
                 sel++;
                 if(sel>=previousPop.getComponentCount())
                 {
                    sel = previousPop.getComponentCount()-1;
                 }
                 previousPop.getSelectionModel().setSelectedIndex(sel);
                 return;
              }
              else if(ke.getKeyCode()==KeyEvent.VK_DOWN)
              {
                 sel--;
                 if(sel<0) sel=0;
                 previousPop.getSelectionModel().setSelectedIndex(sel);
                 return;
              }
              else if(ke.getKeyCode()==KeyEvent.VK_ENTER)
              {
                 //System.out.println("ENTER pressed");
                 // DON'T WORK !!
                 JMenuItem mei = getSelected();
                 if(mei!=null)
                 {
                    mei.doClick();
                    return;
                 }
                 return;

              }
              else if(ke.getKeyCode()==KeyEvent.VK_ESCAPE)
              {
                 return;
              }
            }

            updatePopup();
         }


      } // class Keylistener

      listener = new Keylistener();
      textComponent.addKeyListener(listener);

      // initial show alternatives
      if(showPopupAtStartup)
      {
        //todo: show only when component showed, otherwise the popup can't determine its position
        EventQueue.invokeLater(new Runnable() { public void run() {
           updatePopup();
        }});
      }


   }

   public final /*@org.checkerframework.checker.nullness.qual.Nullable*/ CompletionListener<T> getCompletionListener() { return completionListener; }

   public final void setCompletionListener(CompletionListener<T> a) { this.completionListener = a; }

   public final void setCompletions(final T... comps_)
   {
      synchronized(completions)
      {
        this.completions.clear();
        this.completions.addAll(Arrays.asList(comps_));
      }

      if(previousPop!=null && previousPop.isVisible())
      {
         updatePopup();
      }
   }

   public final void setCompletions(final Collection<T> comps_)
   {
      synchronized(completions)
      {
        this.completions.clear();
        this.completions.addAll(comps_);
      }

      if(previousPop!=null && previousPop.isVisible())
      {
         updatePopup();
      }
   }

   public final void addCompletions(final Collection<T> comps_)
   {
      synchronized(completions)
      {
         for(T ci : comps_)
         {
            if( !this.completions.contains(ci) )
            {
               this.completions.add(ci);
            }
         }
      }

      if(previousPop!=null && previousPop.isVisible())
      {
         updatePopup();
      }
   }

   /** REFERENCE !
   */
   public final List<T> getCompletions() { return completions; }

   public final int getMaxPopupItems() { return maxPopupItems; }
   public final void setMaxPopupItems(int a) { this.maxPopupItems = a; }

   /** From start or previous space up to the caret position.
   */
   private String getTextBeforeCaret()
   {
      if(fullMode) return textComponent.getText();

      if(textComponent.getCaretPosition()<=0) return "";

      String sel = "";
      try{
        sel = textComponent.getText(0, textComponent.getCaretPosition());

        // from last space before
        final int ls = Math.max(sel.lastIndexOf(' '), sel.lastIndexOf('\n'));
        if(ls>-1)
        {
           sel = sel.substring(ls+1);
        }

        //System.out.println("TT="+sel);
      }
      catch(Exception e) {
         sel = textComponent.getText();
         e.printStackTrace();
      }
      return sel;
   }


   /** Updates the available completions. Called on keypresses.
   */
   private void updatePopup()
   {
       String exactBefore = getTextBeforeCaret();
       String s = exactBefore.toLowerCase();
       List<T> cand = new ArrayList<T>();
       if(s.length() >= minCharsToPop)
       {
         synchronized(completions)
         {
           for(T ci : completions)
           {
              if((""+ci).toLowerCase().contains(s))
              {
                 // but do not add if the text exactely equals, not necessary then !
                 if(!exactBefore.equals(ci))
                 {
                   cand.add(ci);
                 }
              }
           }
         }
       }

       if(previousPop!=null && previousPop.isVisible())
       {
          //System.out.println("disable");
          previousPop.setVisible(false);
       }

       //todo: if more than 30, show submenues or only the 20 first and allow for browsing.
       int n = -1;
       if(cand.size()>0)
       {
          final JPopupMenu pop = new JPopupMenu();
          previousPop = pop;
          for(final T ci : cand)
          {
             n++;

             if(n>=maxPopupItems)
             {
                pop.add("  ... "+(cand.size()-n)+" more ...");
                break;
             }

             JMenuItem mi = new JMenuItem(""+ci);
             pop.add(mi);
             mi.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {

                // Called when selected => replaces the last element with the selection

                String selBefore = getTextBeforeCaret();

                //System.out.println("Replace "+selBefore+" with "+ci);


                if(fullMode)
                {
                  textComponent.setText(""+ci);
                }
                else
                {
                   if(selBefore.length()==0)
                   {
                      // append
                      textComponent.setText(textComponent.getText()+ci);
                   }
                   else
                   {
                      // replace the last occurence of "selBefore" before caret position with the selection
                      String txt = textComponent.getText();
                      int end = txt.length();
                      try{
                         end = textComponent.getCaretPosition();
                      }
                      catch(Exception e) {

                      }

                      int pos = txt.lastIndexOf(selBefore, end);

                      if(pos<0)
                      {
                        // append
                        textComponent.setText(textComponent.getText()+ci);
                      }
                      else
                      {
                         txt = txt.substring(0, pos) + ci + txt.substring(pos + selBefore.length());
                         textComponent.setText(txt);
                      }
                   }
                }

                pop.setVisible(false);

                // notify listener
                if(completionListener!=null) { completionListener.itemSelected(ci); }
             } });
          }

          EventQueue.invokeLater(new Runnable() { public void run() {
             textComponent.requestFocus();
          }});

          int x=0;
          int y = textComponent.getHeight();

          try{
             Rectangle re = textComponent.modelToView(Math.max(0, textComponent.getCaretPosition()-s.length()));
             x = re.x;
             y = re.y + textComponent.getFont().getSize()+2;
          }
          catch(Exception e) {
             //e.printStackTrace();
          }

          pop.show(textComponent, x, y);
       }
   }


/*test
   public static void main(String[] args) throws Exception
   {

      EventQueue.invokeLater(new Runnable() { public void run() {

         JFrame test = new JFrame("test");
         test.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

         //OKJTextField tt = new JTextField();
         JTextArea tt = new JTextArea(4, 20);

         TextComponentCompletion<String> tcc = new TextComponentCompletion<String>(tt,
           false, false, 2,
           "azerty", "azrael", "azerbaidjan", "azimo", "aaa", "aaaa", "aaaaa", "bb", "bbb", "aaabb", "bbbaa");

         tcc.setCompletionListener(new CompletionListener<String>()
           {
              public void itemSelected(String s)
              {
                 System.out.println("Selectedd: "+s);
              }
           } );

         test.add(tt, BorderLayout.CENTER);
         test.add(new JLabel(" Please enter the name of the component:   "), BorderLayout.NORTH);

         test.pack();
         test.setLocationRelativeTo(null);
         test.setVisible(true);
      }});

   }*/

}