package snow.fun.aggregate;

import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.event.*;
import javax.swing.*;
import java.awt.BasicStroke;
import java.awt.geom.GeneralPath;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.*;
import java.util.*;

/** Simulates a simple aggregate grow from germs.
*   New pts are added to the nearest neighbours of the existing set.
*   Create nice figures.
*
*/
public final class AggregateGrow
{

   class Pt
   {
      final private int x;
      final private int y;


      private  Pt closest = null;

      Pt(final int x, final int y)
      {
         this.x = x;
         this.y = y;
      }

      double dist2(Pt p)
      {
         return (p.x-x)*(p.x-x) + (p.y-y)*(p.y-y);
      }

      @Override public final boolean equals( /*@org.checkerframework.checker.nullness.qual.Nullable*/ Object obj ) {
         if(obj instanceof Pt)
         {
            Pt op = (Pt) obj;
            return op.x==x && op.y==y;
         }
         else
         {
            return false;
         }
      }
   }

   final private int w;
   final private int h;
   final List<Pt> pts = new ArrayList<Pt>();
   Random rnd = new Random();

   /*@org.checkerframework.checker.nullness.qual.Nullable*/ Pt hit = null;


   double gridSize = 5;

   /** Constructor. */
   public AggregateGrow(int w, int h)
   {
      this.w = w;
      this.h = h;
   }


   void addGerm(int x, int y)
   {
      pts.add( new Pt(x,y) );
   }


   void addFromTop(int nap)
   {
      for(int i=0; i<nap; i++)
      {
         Pt p = new Pt(rnd.nextInt(w),0);
         Pt npt = addToClosest(p);
      }
   }

   /*@org.checkerframework.checker.nullness.qual.Nullable*/ Pt addFromTopUntilTopReached()
   {
      return addFromTopUntilTopReached(100000);
   }

   /*@org.checkerframework.checker.nullness.qual.Nullable*/ Pt addFromTopUntilTopReached(int max)
   {
      for(int i=0; i<max; i++)
      {
         Pt p = new Pt(rnd.nextInt(w),0);
         Pt npt = addToClosest(p);
         if(npt!=null && npt.y<=0)
         {
           // System.out.println("top reached after "+i+" points");
            return npt; // reached
         }
      }

      return null;
   }

   void addFromBorders(int nap)
   {
      for(int i=0; i<nap; i++)
      {
         Pt p = null;
         switch(rnd.nextInt(4))
         {
            case 0: //top
              p = new Pt(rnd.nextInt(w),0);
              break;
            case 1: //left
              p = new Pt(0, rnd.nextInt(h));
              break;
            case 2: //bottom
              p = new Pt(rnd.nextInt(w), h);
              break;
            case 3: //right
              p = new Pt(w, rnd.nextInt(h));
              break;
         }

         Pt npt = addToClosest(p);

      }
   }


   void addFromRect(int nap, int x0, int y0, int rw, int rh)
   {
      for(int i=0; i<nap; i++)
      {
         Pt p = null;
         switch(rnd.nextInt(4))
         {
            case 0: //top
              p = new Pt(rnd.nextInt(rw)+x0, y0);
              break;
            case 1: //left
              p = new Pt(x0, y0+rnd.nextInt(rh));
              break;
            case 2: //bottom
              p = new Pt(x0+rnd.nextInt(rw), rh+y0);
              break;
            case 3: //right
              p = new Pt(x0+rw, rnd.nextInt(rh)+y0);
              break;
         }

         Pt npt = addToClosest(p);

      }
   }

   void addFromCircle(int max)
   {
      double r = w/2.0;
      for(int i=0; i<max; i++)
      {
         double a = rnd.nextDouble()*2.0*Math.PI;
         Pt p = new Pt((int)(w/2.0+r*Math.cos(a)), (int)(h/2.0+r*Math.sin(a)));
         addToClosest(p);
      }
   }

   void addFromFullRect(int max, int x0, int y0, int rw, int rh)
   {
      for(int i=0; i<max; i++)
      {
         Pt p = new Pt((int)(x0+rnd.nextInt(rw)),(int)(y0+rnd.nextInt(rh) ));
         addToClosest(p);
      }
   }


   /*@org.checkerframework.checker.nullness.qual.Nullable*/ Pt addFromBordersUntilReached()
   {
      for(int i=0; i<100000; i++)
      {
         Pt p = null;
         switch(rnd.nextInt(4))
         {
            case 0: //top
              p = new Pt(rnd.nextInt(w),0);
              break;
            case 1: //left
              p = new Pt(0, rnd.nextInt(h));
              break;
            case 2: //bottom
              p = new Pt(rnd.nextInt(w), h);
              break;
            case 3: //right
              p = new Pt(w, rnd.nextInt(h));
              break;
         }

         Pt npt = addToClosest(p);
         if(npt!=null)
         {
           if( npt.y<=0 || npt.y>=h || npt.x>=w || npt.x<=0)
           {
             //System.out.println("border reached after "+i+" points");
             return npt; // reached
           }
         }
      }
      return null;
   }


   /** null if hit outside bounds
   */
   /*@org.checkerframework.checker.nullness.qual.Nullable*/ Pt addToClosest(Pt p)
   {
      if(pts.isEmpty())
      {
         System.out.println("No germ: adding "+p);
         pts.add(p);
         return p;
      }

      double dm = Double.MAX_VALUE;
      Pt closest = null;
      for(Pt pi : pts)
      {
         double di = pi.dist2(p);
         if(di<dm)
         {
            dm = di;
            closest = pi;
         }
      }

      assert closest!=null:"nullness";  // because pts not empty

      // determine dest coords
      double dx =  p.x - closest.x;
      double dy =  p.y - closest.y;

      if(dx==0 && dy==0) return null;  // overwrite

      //distance
      double n = Math.sqrt(dx*dx+dy*dy);

      dx/=n;
      dy/=n;

      double step = Math.min(gridSize, n);

      int nx = (int) Math.round(closest.x+dx*step);
      int ny = (int) Math.round(closest.y+dy*step);

      if(nx>=w || ny>=h) return null;  // outside
      if(nx<0 || ny<0) return null;

      Pt npt = new Pt(nx,ny);
      npt.closest = closest;
      pts.add(npt);

      return npt;

   }

   public BufferedImage createIm()
   {
      BufferedImage bim = new BufferedImage(w,h, BufferedImage.TYPE_INT_RGB);

      Graphics2D g = bim.createGraphics();
      g.setColor(Color.white);
      g.fillRect(0,0,w,h);

      drawOn(g);

      g.dispose();
      return bim;

   }

   public void drawOn(Graphics2D g)
   {

      g.setColor(Color.lightGray);

      for(Pt pi : pts)
      {
        // dots
        if(pi.closest==null)
        {
           g.drawLine(pi.x, pi.y, pi.x, pi.y);
        }
        else
        {
           g.drawLine(pi.x, pi.y, pi.closest.x, pi.closest.y);
        }
      }

      if(hit!=null)
      {
         GeneralPath gp = new GeneralPath();
         gp.moveTo(hit.x, hit.y);

         if(hit!=null)
         {
            Pt p = hit;
            while(true)
            {
               if(p==null) break;

               gp.lineTo(p.x, p.y);

               p = p.closest;
            }
         }

         g.setColor(Color.red);
         g.setStroke(new BasicStroke(hitwidth));
         g.draw(gp);

      }
   }



   public static void main(String[] args) throws Exception
   {
      test4();
   }

   static BufferedImage test1()
   {
      AggregateGrow ct = new AggregateGrow(1280, 1000);
      ct.addGerm(128,1000);
      //ct.addFromTop(80);
      Pt h = ct.addFromTopUntilTopReached();
      ct.hit = h;
      return ct.createIm();
   }

   static BufferedImage test2()
   {
      AggregateGrow ct = new AggregateGrow(1280, 1000);
      ct.addGerm(600,500);
      //ct.addFromTop(80);
      //Pt h = ct.addFromTopUntilTopReached();
      //ct.hit = h;
      ct.addFromBorders(2000);
      return ct.createIm();
   }


   static void test3()
   {
      final JFrame f = new JFrame();
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      f.setSize(800,600);
      f.setVisible(true);

      final int[] germ = new int[2];
      final AggregateGrow[] ct = new AggregateGrow[1];
      final JPanel crpan = new JPanel()
      {
         @Override protected final void paintComponent( final Graphics g ) {
             super.paintComponent(g);
             if(ct[0]!=null)
             {
                ct[0].drawOn((Graphics2D) g);
             }
         }
      } ;


      f.getLayeredPane().add(crpan);
      crpan.setBounds(0,0,f.getWidth(), f.getHeight());  // oups, buggy when resizing => should listen to the frame (or parent size)...
      crpan.setVisible(true);

      crpan.addMouseListener(new MouseAdapter()
      {
         @Override public final void mouseClicked( final MouseEvent e ) {
            //System.out.println("click: "+e);
            crpan.setBounds(0,0,f.getWidth(), f.getHeight());
            germ[0] = e.getX();
            germ[1] = e.getY();

            ct[0] = new AggregateGrow(f.getWidth(), f.getHeight());
            ct[0].addGerm(germ[0], germ[1]);

            //Pt hit = ct[0].addFromBordersUntilReached(); //1000);
            //ct[0].hit = hit;

            //ct[0].addFromCircle(600);
            //ct[0].addFromRect(600,20,20,50,50);
            //ct[0].addFromFullRect(600,200,200,150,150);

            //ct[0].addFromFullRect(600,100,100,150,150);

            ct[0].addFromFullRect(500,0,0,f.getWidth(), f.getHeight());
            ct[0].addFromFullRect(600,100,100,150,150);

            f.repaint();
         }
      });

   }



   static void test4()
   {
      final JFrame f = new JFrame();
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      f.add(new JTextArea("Hello"));
      f.setSize(800,600);
      f.setLocationRelativeTo(null);
      f.setVisible(true);




      addCristalGrowthMouseMotionToFrame(f);
   }


   public static void addCristalGrowthMouseMotionToFrame(final JFrame f)
   {

      final int[] germ = new int[2];
      final AggregateGrow[] ct = new AggregateGrow[1];
      final JPanel crpan = new JPanel()
      {
         @Override protected final void paintComponent( final Graphics g ) {
             super.paintComponent(g);
             if(ct[0]!=null)
             {
                ct[0].drawOn((Graphics2D) g);
             }
         }
      } ;

      crpan.setOpaque(false);

      f.getLayeredPane().add(crpan);
      //f.getGlassPane().setVisible(true);
      crpan.setBounds(0,0,f.getWidth(), f.getHeight());  // oups, buggy when resizing => should listen to the frame (or parent size)...
      crpan.setVisible(true);


      final MouseAdapter mad = new MouseAdapter()
      {

         @Override public final void mouseClicked( final MouseEvent e ) {
            crpan.removeMouseListener(this);
            crpan.removeMouseMotionListener(this);
            crpan.setVisible(false);
         }

         long lastUpdate = -1;
         @Override public final void mouseMoved( final MouseEvent e ) {

            if(System.currentTimeMillis()-lastUpdate < 100L)
            {
               return;
            }

            lastUpdate = System.currentTimeMillis();

            // on move, kill the old and start a new anim
            if(ct[0]!=null)
            {
              ct[0].animDone=true;
            }

                 germ[0] = e.getX();
                 germ[1] = e.getY();

                 ct[0] = new AggregateGrow(f.getWidth(), f.getHeight());
                 ct[0].addGerm(germ[0], germ[1]);
                 crpan.setBounds(0,0,f.getWidth(), f.getHeight());
                 ct[0].startFlashAnimation(f);

         }
      };
      crpan.addMouseMotionListener(mad);
      crpan.addMouseListener(mad);

      //mad.mouseMoved(new MouseEvent(crpan,0,0,0,200,500,0,false,0));


   }

   //
   // animation
   //


   int animStep = 0;
   float hitwidth = 0.5f;
   double restIntensity = 1;
   boolean animDone = false;


   /** Funny flash through the aggregate.
   */
   void startFlashAnimation(final Component c)
   {
      animStep = 0;
      animDone = false;

      final Thread t = new Thread() { public void run() {
         flashAnimRecurse(c);
         // caution: not done here !
      }};
      t.start();
   }



   void flashAnimRecurse(final Component c)
   {
      if(animDone) return;

      animStep++;

      if(animStep>80)
      {
        animDone = true;
        return;
      }

      if(hit == null)
      {
         this.addFromRect(15,0,0,w,h);
         final Pt p = addFromTopUntilTopReached(10);
         if(p!=null)
         {
            hit = p;
         }
      }
      else
      {
         hitwidth += 0.06f;
         restIntensity *= 0.9;
      }

      try{ Thread.sleep(15); } catch(InterruptedException ex) { return; }

      // continue recursion, but only after completion (using the EDT queuing)
      EventQueue.invokeLater(new Runnable() { public void run() {
            c.repaint();
            flashAnimRecurse(c);
      }});
   }


}