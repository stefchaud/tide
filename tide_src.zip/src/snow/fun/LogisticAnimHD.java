package snow.fun;

import java.awt.event.*;
import java.awt.Graphics2D;
import java.awt.image.*;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.util.concurrent.*;
import java.util.*;
import java.awt.Color;
import javax.swing.*;

/** class LogisticAnimHD.
*/
public final class LogisticAnimHD  extends JPanel
{



   private Map<Double, Double> convXForR = new HashMap<Double,Double>();

   Color convCol = new Color(1f,0.0f,0f,0.3f);

   /** Constructor. */
   public LogisticAnimHD()
   {
      setBackground(Color.white);
      setForeground(new Color(0f,0.0f,0f,0.01f));
      resetSize();

      this.addComponentListener(new ComponentAdapter()
      {
         @Override public final void componentResized( final ComponentEvent e ) {
            //edt
            resetSize();
         }
      });

   }

   private double convForR(double r, double x0)
   {
      if(convXForR.containsKey(r)) return convXForR.get(r);

      double x = x0;
      for(int i=0; i<180; i++)
      {
         x = x*r*(1-x);
      }

      convXForR.put(r, x);

      return x;
   }

   BufferedImage buf = null;
   Graphics2D bufGr = null;
   int animStep = 0;
   double dr = 0.1;
   long validId = -1;
   int w =1;
   int h =1;

   BufferedImage old = null;
   ExecutorService executor = null;

   //edt
   void resetSize()
   {
      // idea: store the old one (if animStep>15) and use it scaled to the new dims unless the new buf itself is at stage >15
      if(animStep>25)
      {
         old = buf;
      }
      if(executor!=null)
      {
         executor.shutdownNow();
      }

      buf = new BufferedImage(Math.max(1,getWidth()), Math.max(1,getHeight()), BufferedImage.TYPE_INT_ARGB);
      bufGr = buf.createGraphics();
      bufGr.setColor(getForeground());
      animStep=0;
      validId = System.currentTimeMillis();
      w = buf.getWidth();
      h = buf.getHeight();
      //System.out.println("reset to "+w+" x "+h);

      dr = (rmax-rmin)*0.1/buf.getHeight();  // 10 * oversampled, but nice.


         Thread t = new Thread() { public void run() {
            animLoop(validId);
         }};
         t.start();
      //animLoop(validId);
   }

   void plotPoint(final double r, final double x)
   {
      int sx = (int)Math.round(x*w);
      int sy = h-(int)Math.round((r-rmin)/(rmax-rmin)*h);

      //buf.getRaster().setPixel();


      // sync slow but needed if also setting color ?
      synchronized(bufGr) {
        bufGr.drawLine(sx,sy, sx,sy);
      }
   }

   void setColor(final Color c)
   {
      bufGr.setColor(c);
   }

   void plotPoint(final double r, final double x, final Color c)
   {
      int sx = (int)Math.round(x*w);
      int sy = h-(int)Math.round((r-rmin)/(rmax-rmin)*h);

      // no alpha...
      buf.setRGB(sx,sy,c.getRGB());

      /*synchronized(this)
      {
        bufGr.setColor(c);
        bufGr.drawLine(sx,sy, sx,sy);
      }*/
   }

   double rmin  = 3.52;
   double rmax = 4;

   Random rand = new Random();

   void animLoop(final long id)
   {
      if(id!=this.validId) return;

      animStep++;
      //System.out.println("step "+animStep);
      if(animStep>100)
      {
         System.out.println("done after "+(System.currentTimeMillis()-validId));
         return;
      }

      int nps = Runtime.getRuntime().availableProcessors();
      executor = Executors.newFixedThreadPool(nps*2);

      //for(double r=rmin; r<rmax; r+=dr)  //  be parallelized with ease

      int slices = nps*2;
      double sls = (rmax-rmin)/slices;

      for(int ml = 0; ml<slices; ml++)
      {

         final double rs = rmin + sls*ml;
         final double re = rs+sls;

         if(executor.isShutdown()) return;  // stopped
         if(id!=this.validId) return;
         try
         {
          executor.submit(new Runnable(){ public void run() {

            double x0 = 0.5;
            double x = 0;
            int ii=0;
            for(double r=rs; r<re; r+=dr)
            {
               ii++;
               if(animStep<30)
               {
                  // quick first steps
                  if((ii % animStep) != animStep) continue;
               }

               if(id!=validId) return;

               x0 = convForR(r, x0);
               x=x0;

               int imax = 11+rand.nextInt(1+w/20);
               if(animStep>60)
               {
                  imax *= 3;
               }

           pl:for(int i=0; i<imax; i++)
               {
                  double dx = x;
                  x = x*r*(1-x);

                  dx=Math.abs(dx-x);

                  // experiment: colorize according to *speed*
                  //setColor(new Color((float)dx,(float)(1f-dx),0f,0.01f));

                  //plotPoint(r,x,new Color((float)dx,0.1f,0.1f,0.01f)); //,0.01f));
                  plotPoint(r,x);

                  if(i>5 && Math.abs(x-x0)<1e-14)
                  {
                     //System.out.println("conv after "+i+" steps");


                     //plotPoint(r,x,convCol);
                     //bufGr.setColor(getForeground());

                     break pl;
                  }
               }

               convXForR.put(r,x);
            }
          }});
         }catch(final Exception e) {
            // immediately stop
            return;
         }
      }

      try{
         executor.shutdown();
         executor.awaitTermination(100, TimeUnit.SECONDS);
      }
      catch(final Exception e) {
         e.printStackTrace();
      }


      if(id!=this.validId) return;

      repaint();

      EventQueue.invokeLater(new Runnable() { public void run() {
         Thread t = new Thread() { public void run() {
            animLoop(id);
         }};
         t.start();
      }});
   }

   @Override protected final void paintComponent( final Graphics g ) {

      super.paintComponent(g);

      //g.drawLine(0,0,getWidth(), getHeight());
      if(animStep<35 && old!=null && old.getWidth()>20 && System.currentTimeMillis()-validId < 10000L)
      {

         g.drawImage(old,0,0,w,h,null);
         //return;
      }

      if(buf!=null)
      {
         //long t0 = System.currentTimeMillis();
         g.drawImage(buf,0,0,null);
         //System.out.println(""+(System.currentTimeMillis()-t0));
      }
   }

   // subtle subtle tRun test.
   JComponent testTRun( final Graphics g ) {

      paintComponent(g);
      return new JLabel("Hello");
   }



   public static JPanel test()
   {
      return new LogisticAnimHD();
   }



}