package snow.fun;

import java.text.DecimalFormat;
import java.util.concurrent.TimeUnit;
import snow.utils.DateUtils;
import java.util.*;

/** Find reasons to make a Party today.
*    Useful for uninspired people and generally for IT people that lacks social contacts :-).
*
*    todo:
*    Subtle:   you're 333 days old
*    Or  in 33 days, you're 333 days
*    Or in 33 and 3 days you're...
*/
public final class PartyReason
{


   public PartyReason(final Date birthdate)
   {
      long normDate = DateUtils.getStartOfDayForTime(birthdate.getTime());
      System.out.println("\nParty reason finder 0.1 for "+new Date(normDate));

      long now = DateUtils.getMidnightTodayMorning();

      long diff = now - normDate;
      //System.out.println("Age in millis:\t"+diff);
      System.out.println("Age in seconds:\t"+(diff/TimeUnit.SECONDS.toMillis(1)));
      System.out.println("Age in hours:  \t"+(diff/TimeUnit.HOURS.toMillis(1)));
      System.out.println("Age in days:  \t"+(diff/TimeUnit.DAYS.toMillis(1)));

      // subtle: todo better (discrete maths and exact date comps !!)
      System.out.println("Age in months (30d):\t"+df3.format(1.0*diff/TimeUnit.DAYS.toMillis(30)));
      System.out.println("Age in seasons (365/4d):\t"+df3.format(diff*4.0/TimeUnit.DAYS.toMillis(365)));
      System.out.println("Age in years (365d):\t"+df3.format(1.0*diff/TimeUnit.DAYS.toMillis(365)));
      //subcategory of age... System.out.println("Age in 12 years (365d):\t"+(1.0*diff/TimeUnit.DAYS.toMillis(365*12)));

      Calendar c = Calendar.getInstance();
      //c.setTime(normDate);
      //c.get(c.day)

   }

   DecimalFormat df3 =new DecimalFormat("0.000");

   public static void main(String[] args) throws Exception
   {
      new PartyReason(DateUtils.getDate(8, 1, 2008));
      new PartyReason(DateUtils.getDate(8, 2, 2006));

      new PartyReason(DateUtils.getDate(18, 2, 1973));
      new PartyReason(DateUtils.getDate(16, 10, 1974));
      new PartyReason(DateUtils.getDate(9, 10, 1934));
      new PartyReason(DateUtils.getDate(8, 5, 1944));
      new PartyReason(DateUtils.getDate(22, 8, 1973));

   }

}