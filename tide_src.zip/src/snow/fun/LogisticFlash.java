package snow.fun;


import java.awt.Graphics2D;
import java.awt.Color;
import javax.swing.*;
import java.awt.Graphics;

/** A funny flash *percolated* through the logisitc plot.
*/
public final class LogisticFlash extends JPanel
{
   final Color hcol = new Color(0.95f,0.f,0.f,0.8f);


   public LogisticFlash()
   {
      this.setBackground(new Color(1f,1f,1f));

      // really nice graphics when using alpha of black, so we see patterns
      this.setForeground(new Color(0f,0f,0f, 0.1f));  // alpha
   }



      // quick
      void line(Graphics2D g, double x1, double y1, double x2, double y2)
      {
         g.drawLine((int)x1, (int)y1, (int)x2, (int) y2);
      }

      // quickest way to draw a dot ?
      void dot(Graphics2D g, double x, double y)
      {
         //g.fill(new Rectangle2D.Double(x,y,1,1));
         line(g, x,y, x,y);

      }

      @Override protected final void paintComponent( final Graphics g ) {

         super.paintComponent(g);
         Graphics2D g2 = (Graphics2D) g;
         //no influence g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
         //no influence g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_SPEED);
         //not better, but 4 times slower!  g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

         long t0 = System.currentTimeMillis();

         int w = getWidth();
         int h = getHeight();

         if(w+h<10) return;

         double x = 0.5;
         double x0 = x;
         double dr = 0.5/h;    // oversampled in x makes sense because of color's alpha
         double prevX = -1;

         for(double r=3.5; r<4; r+=dr)
         {

            // convergence
            x0=x;
            cl:for(int i=0; i<450; i++)
            {
               x=x*r*(1-x);
               if(Math.abs(x-x0)<1e-12) break cl;
            }

            // drawing
            // as much points as pixels
            x0=x;
            double nearest = -1;
        pl:for(int i=0; i<w/10; i++)
            {

               dot(g2, x*w, h-h*(r-3.5)*2);
               x = x*r * (1.0-x);

               if(prevX>0)
               {
                  double dd = Math.abs(x-prevX);
                  if(dd< Math.abs(nearest-prevX))
                  {
                     nearest = x;
                  }
               }

               if(Math.abs(x-x0)<1e-12) break pl;

            }

            // connection to previous nearest
            // quad: no time lost with that

            if(prevX>0)
            {
               g.setColor(hcol);
               line(g2, prevX*w, h-h*(r-dr-3.5)*2, nearest*w, h-h*(r-3.5)*2);
               g.setColor(getForeground());

               prevX = nearest;
            }
            else
            {
               prevX = Math.random();
            }
         }


         // quad: 1sec for 1920*1200   (AA: 3 sec, not better)
         //
         System.out.println(""+(System.currentTimeMillis()-t0));

      }


      static JPanel test()
      {
         return new LogisticFlash();
      }


}