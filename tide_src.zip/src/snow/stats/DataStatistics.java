package snow.stats;

/** Some DataStatistics.
*/
public final class DataStatistics {

   /** Constructor. */
   private DataStatistics() {
   }


  /** Here, mean is not known "a priori", but estimated from data, the factor is therefore 1/(n-1).
      @return the variance (square of standard deviation). 1/(n-1) sum{ (xi-mean)^2 }
  */
  public static double variance(double[] x)
  {
     double mean = mean(x);
     double sum = 0;
     for(int i=0; i<x.length; i++)
     {
       sum += (x[i]-mean)*(x[i]-mean);
     }
     return sum/(x.length-1);
  }


  public static double mean(double[] x)
  {
     if(x.length<1) throw new RuntimeException("unable to compute the mean of a list of "+x.length+" elements");
     double sum = 0;
     for(int i=0; i<x.length; i++)
     {
       sum += x[i];
     }
     return sum/x.length;
  }


  /** Here, mean is known "a priori", the factor is 1/n.
      @return the variance (square of standard deviation). 1/(n) sum{ (xi-mean)^2 }
   */
  public static double variance(double[] x, double meanAPriori)
  {
     double sum = 0;
     for(int i=0; i<x.length; i++)
     {
       sum += (x[i]-meanAPriori)*(x[i]-meanAPriori);
     }
     return sum/(x.length);
  }


  /** @return the square root of the variance
   */
  public static double standardDeviation(double[] x)
  {
     return Math.sqrt( variance(x) );
  }



}