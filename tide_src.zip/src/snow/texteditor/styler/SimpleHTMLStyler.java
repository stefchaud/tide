package snow.texteditor.styler;

import java.awt.EventQueue;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import snow.concurrent.DelayedMergedUpdater2;
import snow.lookandfeel.ThemesManager;
import snow.texteditor.*;
import snow.utils.gui.*;

public final class SimpleHTMLStyler {

   public SimpleHTMLStyler(StyledDocument doc)
   {
      setOrUpdateStyles(doc);

      doc.setCharacterAttributes(0, doc.getLength(), getDefaultStyle(doc), true);

      String cont = "<ERROR>";
      try
      {
        cont = doc.getText(0, doc.getLength());
      }catch(Exception e) {
        e.printStackTrace();
        cont = "<error>: "+e.getMessage();
      }
      SimpleHTMLParser dwt = new SimpleHTMLParser(cont);

      if(dwt.xmlMode)
      {
         System.out.println("XML !");
      }

      SimpleHTMLParser.Item it;
      while((it=dwt.getNextItem())!=null)
      {
         switch(it.type)
         {
            case  Content:

                Style s = getDefaultStyle(doc);

                StyleConstants.setItalic(s, it.tags.contains(SimpleHTMLParser.Italic));
                StyleConstants.setBold(s, dwt.xmlMode || it.tags.contains(SimpleHTMLParser.Bold));

                int fs = 12;
                if(it.tags.contains(SimpleHTMLParser.Title) || it.tags.contains(SimpleHTMLParser.H1)) fs = 18;
                else if(it.tags.contains(SimpleHTMLParser.H2) || it.tags.contains(SimpleHTMLParser.H3)) fs = 16;
                else if(it.tags.contains(SimpleHTMLParser.H4) || it.tags.contains(SimpleHTMLParser.H5)) fs = 14;

                if(fs>12) StyleConstants.setBold(s, true);

                StyleConstants.setFontSize(s, fs);
                StyleConstants.setSuperscript(s, it.tags.contains(SimpleHTMLParser.Superscript));
                StyleConstants.setSubscript(s, it.tags.contains(SimpleHTMLParser.Subscript));
                //StyleConstants.setUnderline(s,  it.tags.contains(SimpleHTMLParser.AREF));

                doc.setCharacterAttributes(it.positionInDocument, it.word.length(), s, false);

                break;
            case  Comment:
                 doc.setCharacterAttributes(it.positionInDocument, it.word.length(), getCommentStyle(doc), false);
              break;
            case  SingleTag:  //
                 if(it.word.startsWith("<img"))
                 {
                   doc.setCharacterAttributes(it.positionInDocument, it.word.length(), getTodoStyle(doc), false);
                 }
                 else if(it.word.startsWith("<a") && it.word.contains("href="))
                 {
                   doc.setCharacterAttributes(it.positionInDocument, it.word.length(), getRefStyle(doc), false);
                 }
                 else if(it.word.startsWith("<a") && it.word.contains("name="))
                 {
                   doc.setCharacterAttributes(it.positionInDocument, it.word.length(), getKeywordStyle(doc), false);
                 }


              break;

         }
      }
   }

   /** Should be called on UI manager changes
   */
   public void setOrUpdateStyles(StyledDocument doc)
   {
     // TODO: read from CSS, made editable from user !
     Style s = doc.getStyle("default");

     StyleConstants.setFontFamily(s, ThemesManager.getInstance().get_tideEditor_codeEditorFont().getFamily());
     StyleConstants.setBold(s, ThemesManager.getInstance().get_tideEditor_codeEditorFont().isBold());

     StyleConstants.setForeground(s, ThemesManager.getInstance().get_tideEditor_textColor());  // black

     Style defaultStyle = doc.getStyle("regular");

     Style keywordStyle = doc.addStyle("keyword", defaultStyle);
     StyleConstants.setForeground(keywordStyle, ThemesManager.getInstance().get_tideEditor_keywordColor());   // new Color(160,30,30));

     Style commentStyle = doc.addStyle("comment", defaultStyle);
     StyleConstants.setForeground(commentStyle, ThemesManager.getInstance().get_tideEditor_commentColor());   // blue  (30,30,160)

     Style litteralStyle = doc.addStyle("litteral", defaultStyle);
     StyleConstants.setForeground(litteralStyle, ThemesManager.getInstance().get_tideEditor_litteralsColor()); // new Color(30,160,30));

     Style todoStyle = doc.addStyle("todo", defaultStyle);
     StyleConstants.setForeground(todoStyle, ThemesManager.getInstance().get_tideEditor_todoColor());

     Style refStyle = doc.addStyle("ref", defaultStyle);
     StyleConstants.setForeground(refStyle, ThemesManager.getInstance().get_tideEditor_litteralsColor());

     Style nbStyle = doc.addStyle("number", defaultStyle);
     StyleConstants.setForeground(nbStyle, ThemesManager.getInstance().get_tideEditor_numbersColor());

     Style annotStyle = doc.addStyle("annotations", defaultStyle);
     StyleConstants.setForeground(annotStyle, ThemesManager.getInstance().get_tideEditor_annotationColor());
   }

   public static Style getAnnotationStyle(StyledDocument doc)  { return doc.getStyle("annotations"); }
   public static Style getTodoStyle(StyledDocument doc)        { return doc.getStyle("todo");     }
   public static Style getRefStyle(StyledDocument doc)     { return doc.getStyle("ref");  }
   public static Style getCommentStyle(StyledDocument doc)     { return doc.getStyle("comment");  }
   public static Style getKeywordStyle(StyledDocument doc)     { return doc.getStyle("keyword");  }
   public static Style getLitteralStyle(StyledDocument doc)    { return doc.getStyle("litteral"); }
   public static Style getDefaultStyle(StyledDocument doc)     { return doc.getStyle("default");  }



   /** Installs a document listener to track the changes and rescan the syntax.
   *   the listener should be removed when the document is closed.
   *   an initial parsing, can be triggered with callinf insertUpdate(null).
    */
   public static DocumentListener install_parseAtChanges(final SimpleDocument doc, final JTextPane pane)
   {

      final DelayedMergedUpdater2 dmu = new DelayedMergedUpdater2(300, true, new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         new SimpleHTMLStyler(doc);
      } });


       DocumentListener dl = new DocumentListener()
       {
          public final void insertUpdate( final DocumentEvent e ) { dmu.changeOccured();  }
          public final void removeUpdate( final DocumentEvent e ) { dmu.changeOccured();  }
          public final void changedUpdate( final DocumentEvent e ) { } //update();  }  // NO because the styling itself is causing changes
       };
       pane.getDocument().addDocumentListener(dl);


/*old
       DocumentListener dl = new DocumentListener()
       {
          public final void insertUpdate( final DocumentEvent e ) { update();  }
          public final void removeUpdate( final DocumentEvent e ) { update();  }
          public final void changedUpdate( final DocumentEvent e ) { } //update();  }  // NO because the styling itself is causing changes

          void update()
          {
             //todo: only after XX ms silence !
            EventQueue.invokeLater(new Runnable() { public void run() {
               new SimpleHTMLStyler(doc);
            }});
          }

       };
       pane.getDocument().addDocumentListener(dl);
       */

       return dl;
   }

  @SuppressWarnings("nullness")
   public static void main(String[] args) throws Exception {
/*
      SimpleEditor.main(null);
      if(true) return;
*/
      String test = "<html><h1><b>Hello</b></h1>"
         +"<!-- no -->?<img src=\"Hallo\"><i><b>bold and italic</b>italic</i><a href=\"xyz\">Ref !!</a></html>";

      SimpleDocument doc = new SimpleDocument();
      doc.setText(test);
      //doc.setText(FileUtils.getFileStringContent(new File("C:/temp/test/b1.cmd")));

      JTextPane pane = new JTextPane(doc);
      JFrame f = GUIUtils.displayInFrame("Style test", new JScrollPane(pane), true);
      //install_parseAtChanges(doc, pane).insertUpdate(new AbstractDocument.DefaultDocumentEvent(0,0,DocumentEvent.EventType.INSERT));  // not ok.
      install_parseAtChanges(doc, pane).insertUpdate(null);
   }

}