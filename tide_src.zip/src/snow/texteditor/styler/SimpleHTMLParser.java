package snow.texteditor.styler;

import java.util.*;

/** ultra simple, suitable also for xml styles.
*/
public final class SimpleHTMLParser {

   public final static Tag Italic = new Tag("i");
   public final static Tag Bold = new Tag("b");
   public final static Tag Title = new Tag("title");
   public final static Tag H1 = new Tag("h1");
   public final static Tag H2 = new Tag("h2");
   public final static Tag H3 = new Tag("h3");
   public final static Tag H4 = new Tag("h4");
   public final static Tag H5 = new Tag("h5");
   public final static Tag AREF = new Tag("a");
   public final static Tag Subscript = new Tag("sub");
   public final static Tag Superscript = new Tag("sup");

   // nothing to do with existence of closing tags
   // only has to do how format and show them.
   public final Set<String> singleTags = new HashSet<String>(Arrays.asList(
      "frame", "p", "br", "img", "p", "br", "a"));

// parsed items
   public final List<Item> items = new ArrayList<Item>();

   // tells which tags apply to the current part
   //  this is an ordered list !
   private List<Tag> actualInheritedTags = new ArrayList<Tag>();

   boolean xmlMode = false;

   // tag with optional parameter(s).
   // equals looks ONLY at the name "a", ...
   static class Tag
   {
      final String name;
      /*@org.checkerframework.checker.nullness.qual.Nullable*/ String params = null;  // opt

      public Tag(String name)
      {
         this.name = name;
      }

      public Tag(String name, String p)
      {
         this.name = name;
         this.params = p;
      }

      public boolean containsInParams(String x)
      {
         if(params==null) return false;
         return params.toLowerCase().contains(x);
      }

      @Override public boolean equals(/*@org.checkerframework.checker.nullness.qual.Nullable*/ Object o)
      {
         if(o instanceof Tag)
         {
           return ((Tag) o).name.equalsIgnoreCase(name);
         }
         else
         {
            return false;
         }
      }

      @Override public int hashCode()
      {
         return name.hashCode();
      }

      @Override public final String toString() {
         return name + (params!=null ? " ("+params+")" : "");
      }
   }

   public SimpleHTMLParser(final String doc)
   {

      int endPosition = doc.length();
      String docLow = doc.toLowerCase();

      xmlMode = docLow.startsWith("<?xml");

      StringBuilder actual = new StringBuilder();
      int actualStartPosition = 0;

      for(int i=0; i<endPosition; i++)  // char by char
      {
         char ci = doc.charAt(i);
         actual.append(ci);


         // detection of comments (forwards up to the comment end)
         if(ci=='-')
         {
            if(actual.length()>2 && actual.toString().endsWith("<!--"))
            {
               // we've recognize the comment start
               // => add the actual token before comment start "<!--"
               actual.setLength(actual.length()-4);
               addToken(actual.toString(), actualStartPosition);

               actual.setLength(0);
               actualStartPosition = i-3;

               int end = doc.indexOf("-->", i+1);
               if(end<0)
               {
                  // everything up to the end !
                  end = doc.length();
               }
               else
               {
                  end+=3;
               }
               actual.append(doc.substring(actualStartPosition, end));

               addToken(""+actual, actualStartPosition, ItemType.Comment);

               actualStartPosition = end;
               actual.setLength(0);

               i=end;  //SKIP
            }
         }
         else if(ci=='<')  // treat up to ">" but not comments
         {
            if(nextChars(doc, i+1, 1).equals("!")) continue;

            // look up to next ">" or "space"
            String cont = nextCharsUpToOneOfChars(doc, i, "> ", true);
            if(cont!=null)
            {
               if(cont.endsWith(">"))
               {
                  // simple case, tag without param

                  //System.out.println("simple tag: "+cont);
                  String tagName = cont.substring(1, cont.length()-1).trim();
                  boolean isEndingTag = tagName.startsWith("/");

                  // last one without ci
                  actual.setLength(actual.length()-1);
                  addToken(actual.toString(), actualStartPosition);

                  actual.setLength(0);
                  actualStartPosition = i+cont.length();

                  i += cont.length()-1;

                  // tag hierarchy store
                  if(isEndingTag)
                  {
                     //
                     removeLastTag(new Tag(tagName.substring(1)));
                  }
                  else
                  {
                     actualInheritedTags.add(new Tag(tagName));
                  }
               }
               else if(cont.endsWith(" "))
               {
                  String tagName = cont.substring(1, cont.length()-1).toLowerCase();
                  //System.out.println("ext tag: " + tagName);

                  // we need more to distinguish "<a href="  and "<a name", ...
                  String nc = nextCharsUpToOneOfChars(doc, i+cont.length(), ">=", true);
                  //System.out.println("   "+nc);
                  if(nc!=null)
                  {
                     nc = nc.toLowerCase();

                     if(singleTags.contains(tagName))   // "img", ...
                     {
                        // add actual without "<"
                        actual.setLength(actual.length()-1);
                        addToken(actual.toString(), actualStartPosition);
                        actual.setLength(0);

                        int endDef = doc.indexOf(">", i+tagName.length());
                        if(endDef<0) endDef = doc.length();

                        addToken(doc.substring(i, endDef+1), i, ItemType.SingleTag);

                        actualStartPosition = endDef+1;
                        i = actualStartPosition;
                     }
                     else   // all other tags have closing items, as in <a href="xyz"> ...</a>
                     {
                        // add actual without "<"
                        actual.setLength(actual.length()-1);
                        addToken(actual.toString(), actualStartPosition);
                        actual.setLength(0);

                        int endDef = doc.indexOf(">", i+tagName.length());
                        if(endDef<0) endDef = doc.length();

                        actualInheritedTags.add(new Tag(tagName, doc.substring(i+cont.length(), endDef)));
                        actualStartPosition = endDef;
                        i = actualStartPosition;
                     }
                  }
                  else
                  {
                     System.out.println("WARN: nothig after "+tagName);
                  }
               }
            }
         }  // not either "<" or "-"
      }  // chars loop

      // last
      addToken(actual.toString(), actualStartPosition);
   }

   private void removeLastTag(Tag t)
   {
      for(int i=actualInheritedTags.size()-1; i>=0; i--)
      {
         if(actualInheritedTags.get(i).name.equalsIgnoreCase(t.name))
         {
            actualInheritedTags.remove(i);
            return;
         }
      }

      if(!singleTags.contains(t.name))
      {
        System.out.println("WARN: No opening Tag found for "+t);
        System.out.println("  actual: "+actualInheritedTags);
      }//else just ignore
   }

   private String nextChars(String doc, int pos, int n)
   {
      StringBuilder sb = new StringBuilder();
      int end = Math.min(pos+n, doc.length());
      for(int i=pos; i<end; i++)
      {
         sb.append(doc.charAt(i));
      }
      return sb.toString();
   }

   /** null if end not found
   */
   private /*@org.checkerframework.checker.nullness.qual.Nullable*/ String nextCharsUpTo(String doc, int pos, String end, boolean nullIfEndNotFoundOrWholeRest)
   {
      StringBuilder sb = new StringBuilder();
      for(int i=pos; i<doc.length(); i++)
      {
         sb.append(doc.charAt(i));
         if(endsWith(sb, end)) return sb.toString();
      }
      return nullIfEndNotFoundOrWholeRest ? null : sb.toString();
   }

   private /*@org.checkerframework.checker.nullness.qual.Nullable*/ String nextCharsUpToOneOfChars(String doc, int pos, String endChars, boolean nullIfEndNotFoundOrWholeRest)
   {
      StringBuilder sb = new StringBuilder();
      for(int i=pos; i<doc.length(); i++)
      {
         char ci = doc.charAt(i);
         sb.append(ci);
         if(endChars.indexOf(ci)!=-1) return sb.toString();
      }
      return nullIfEndNotFoundOrWholeRest ? null : sb.toString();
   }

   private boolean endsWith(StringBuilder sb, String end)
   {
      if(sb.length()<end.length()) return false;
      for(int i=0; i<end.length(); i++)
      {
         if(sb.charAt(sb.length()-end.length()+i) != end.charAt(i)) return false;
      }
      return true;
   }

   void addToken(String w, int start)
   {
      addToken(w, start, ItemType.Content);
   }

   void addToken(String w, int start, ItemType t)
   {
      if(w.trim().isEmpty()) return;  // don't add empty things.

      items.add(new Item(w, start, t, actualInheritedTags));
   }

   // iterate over tokens
   private int at = 0;
   public /*@org.checkerframework.checker.nullness.qual.Nullable*/ Item getNextItem()
   {
      if(at>=items.size()) return null;
      return items.get(at++);
   }

   public static enum ItemType {
      //TagO, TagE, // separate opening and ending tag
      //TagS,       // autoclosed tag  <XXX/>
      //TagPair,    // only for selected tags as <h1>...</h1>
      Comment,
      Content,
      //Image,
      SingleTag  // image, ...
   }

   public static class Item
   {
     final public int positionInDocument;
     final public String word;
     final public ItemType type;
     final public List<Tag> tags = new ArrayList<Tag>();

     public Item(String w, int pos, ItemType type, List<Tag> tags)
     {
       this.word = w;
       this.positionInDocument = pos;
       this.type = type;
       this.tags.addAll(tags);
     }

     @Override public final String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\n "+type+": \""+word+"\" with "+tags );
        return sb.toString();
     }
   }

   /*test*/
   public static void main(String[] args) throws Exception {

      String test = "<html><h1><b>Hello</b></h1>"
         +"<!-- no -->?<img src=\"Hallo\"><i><b>bold and italic</b>italic</i><a href=\"xyz\">Ref !!</a></html>";
      System.out.println("test="+test+"\n\n");
      System.out.println(""+ new SimpleHTMLParser(test).items);

      //SimpleHTMLStyler.main(new String[0]);
   }

}