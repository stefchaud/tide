package snow.texteditor.styler;

import java.util.*;

/** Simple hand-made parser to be used to parse the windows batch file syntax.
*   the syntax is "so easy" that it is here parsed line per line.
*   Also used for linux scripts (tempor)...
*
*/
public final class SimpleWindowsBatParser {

  // shifts all items positions. Used when the text is taken from other positions than the start
  // of the document
  final String documentContent;
  private int actualStartPosition =0;

  public final List<Item> items = new ArrayList<Item>();

  private String separators = "\n@(){}[]-+*/=.;,%";   // not ":" wind start sect and "::" comments !

  // "rem ", "echo ", "::", "#" ini files: comments = line start with ";", refs start with "["
  private boolean nowInComment = false;

  // if not zero, contains the actual litteral separator we're in
  private char nowInLitteral = 0;


  //todo: recognize params
  // 1)  %1, %2, ... %9  and  %*
  // 2) %path%
  // 3) %~dp0   %xxx:~0,-1%

  /** parses the whole document.
  */
  public SimpleWindowsBatParser(final String doc)
  {
      this.documentContent = doc;
      int endPosition = doc.length();

      StringBuilder actual = new StringBuilder();
      int actualStartPosition = 0;

      for(int i=0; i<endPosition; i++)  // char by char
      {
         char ci = doc.charAt(i);

         if(!nowInComment)
         {
            if(nowInLitteral==0)
            {
               // detect litteral begin
               if(ci=='\"') nowInLitteral = ci;
               if(ci=='\'') nowInLitteral = ci;
               if(ci=='`')  nowInLitteral = ci;

               if(nowInLitteral!=0)
               {
                  // add before
                  nowInLitteral = 0;
                  if(actual.length()>0)
                  {
                     addToken(actual, actualStartPosition);
                     actualStartPosition = i;
                  }

                  // always keep it
                  actual.append(ci);

                  nowInLitteral = ci;
                  continue;
               }
            }
            else  // we are in a litteral
            {
               actual.append(ci);
               if(ci==nowInLitteral)
               {
                  addToken(actual, actualStartPosition);
                  actualStartPosition = i+1;
               }
               continue;
            }
         }

         if(!nowInComment)
         {

           if(Character.isWhitespace(ci))
           {
             if(actual.length()>1)
             {
                if(actual.toString().toLowerCase().endsWith("rem"))
                {
                   nowInComment = true;
                }
                if(actual.toString().toLowerCase().endsWith("echo"))
                {
                   nowInComment = true;
                }
                else if(actual.toString().trim().startsWith("::"))
                {
                   nowInComment = true;
                }
             }
           }
           else if(ci=='#' && actual.toString().trim().isEmpty())
           {
              nowInComment = true;
           }
         }

         if(nowInComment)
         {
            // only stop at line end
            if(ci!='\n')
            {
               // just add and continue
               actual.append(ci);
               continue;
            }
         }



         if(separators.contains(""+ci)) //=='\n')
         {
            if(actual.length()>0)
            {
               addToken(actual, actualStartPosition);
               actualStartPosition = i;
            }
            // don't add the CR
            actualStartPosition++;
         }
         else if(ci=='$')
         {
            // comments of type 2, break the line
            if(actual.length()>0)
            {
               addToken(actual, actualStartPosition);
               actualStartPosition = i;
            }

            // always keep $
            actual.append(ci);
         }
         else
         {
            // just add
            actual.append(ci);
         }
      }

      // last word
      if(actualStartPosition<doc.length())
      {
         addToken(actual, actualStartPosition);
      }
   }

   /** may split in several tokens !
   */
   void addToken(StringBuilder actual, int pos)
   {
      nowInComment = false;

      String w = ""+actual;
      String wt = w.trim();
      String wtl = wt.toLowerCase();
      ItemType t = ItemType.Word;
      if(nowInLitteral!=0)
      {
         t=ItemType.Litteral;
      }
      else if(wt.startsWith(":") && wt.length()>1 && Character.isLetter(wt.charAt(1)))
      {
         t=ItemType.Ref;
      }
      else if(wtl.startsWith("rem ")
        || wtl.startsWith("::")
        || wtl.equals("rem")
        || wt.startsWith("#") // (linux)
        || wtl.equals("#")
        )
      {
         t=ItemType.Comment;
      }
      else if(wtl.startsWith("echo"))
      {
         t=ItemType.Echo;
      }
      else
      {
         // split !
         addSplitTokens(w, pos);
         actual.setLength(0);
         return;
      }


      items.add( new Item(""+actual, pos, t) );
      actual.setLength(0);
      nowInLitteral = 0;

   }

   void addSplitTokens(String line, int posStart)
   {
      //System.out.println("Split line "+line.trim());
      StringBuilder aw = new StringBuilder();
      int aws = 0;
      for(int i=0; i<line.length(); i++)
      {
         char ci = line.charAt(i);
         if(Character.isWhitespace(ci) || ci==';' ||ci=='=' || ci=='\'')
         {
            if(aw.length()>0)
            {
               String wi = ""+aw;
               items.add( new Item(""+aw, aws + posStart, ItemType.Word) );
               aws = i+1;
               aw.setLength(0);
               continue;
            }
            else
            {
               aws = i+1;
            }
         }
         else
         {
            aw.append(ci);
         }
      }

      // don't forget the last one
      if(aw.length()>0)
      {
         String wi = ""+aw;
         items.add( new Item(""+aw, aws+posStart, ItemType.Word) );
      }
   }

   private int at = 0;
   public /*@org.checkerframework.checker.nullness.qual.Nullable*/ Item getNextItem()
   {
      if(at>=items.size()) return null;
      return items.get(at++);
   }


  public static enum ItemType {
     Word,
     Comment,
     Litteral,
     Ref,
     Echo
  }

  public static class Item
  {
    final public int positionInDocument;
    final public String word;
    final public ItemType type;

    public Item(String w, int pos, ItemType type)
    {
      this.word = w;
      this.positionInDocument = pos;
      this.type = type;
    }

    public int getPositionEnd() { return positionInDocument+word.length(); }
@Override
    public String toString() { return word+" ("+ positionInDocument+", "+type+")"; }
  }


  /*test
  public static void main(String[] arguments) throws Exception {
     WindowsBatStyler.main(null);
  }*/



}