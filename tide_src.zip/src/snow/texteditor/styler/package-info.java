/**
 * Provides some stylers for common syntaxes.
 * extremely simplified processing, hand written and very tolerant,
 * to be used as syntax highlighters in editor / renderers.
 *
 * TODO: make a small framework
 *  interface TextParser {}
 *  abstract class TextSyntaxStyler {}
 *
 * Remark: we don't want some high fidelity renderers but either clever help for editing / debugging.
 *
 * TODO: xml parser / renderer with eventually syntax debugger (eventually with xsl ?)
 */
//@SuppressWarnings("nullness")
package snow.texteditor.styler;
