package snow.texteditor.styler;

import java.awt.event.*;
import java.io.File;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import snow.concurrent.DelayedMergedUpdater2;
import snow.lookandfeel.ThemesManager;
import snow.texteditor.*;
import snow.utils.gui.GUIUtils;
import snow.utils.storage.FileUtils;

/** A simple standalone variant to style batch script document (windows or linux !).
*
*/
public final class WindowsBatStyler
{
   public static Set<String> keywords = new HashSet<String>(Arrays.asList(
      "goto", "def", "if", "else", "shift", "exist", "errorlevel",
      "for", "in", "set", "do", "call", "echo", "pause", "exit",
      "dir", "setlocal", "endlocal", "not", "enableextensions", "path",
      "cd",

      "case", "while", "then", "done",    // linux !
      "esac", "fi", "exec", "true", "false", "expr"
      ));

   public WindowsBatStyler(StyledDocument doc)
   {
      setOrUpdateStyles(doc);

      doc.setCharacterAttributes(0, doc.getLength(), getDefaultStyle(doc), true);

      String cont = "<ERROR>";
      try
      {
        cont = doc.getText(0, doc.getLength());
      }catch(Exception e) {
        e.printStackTrace();
        cont = "<error>: "+e.getMessage();
      }
      SimpleWindowsBatParser dwt = new SimpleWindowsBatParser(cont);
      SimpleWindowsBatParser.Item it;
      while((it=dwt.getNextItem())!=null)
      {
         switch(it.type)
         {
            case  Word:
              if(keywords.contains(it.word))
              {
                 doc.setCharacterAttributes(it.positionInDocument, it.word.length(), getKeywordStyle(doc), false);
              }
              else if(it.word.startsWith("@"))
              {
                 doc.setCharacterAttributes(it.positionInDocument, it.word.length(), getAnnotationStyle(doc), false);
              }
              else if(it.word.startsWith(":"))
              {
                 if(it.word.length()>1 && Character.isLetter(it.word.charAt(1)))   // don't take :0.0 as a ref !
                 {
                   doc.setCharacterAttributes(it.positionInDocument, it.word.length(), getRefStyle(doc), false);
                 }
              } // else let it !
              break;
            case  Litteral:
                  doc.setCharacterAttributes(it.positionInDocument, it.word.length(), getLitteralStyle(doc), false);
              break;
            case  Ref:
                  doc.setCharacterAttributes(it.positionInDocument, it.word.length(), getRefStyle(doc), false);
              break;
            case  Comment:
                 doc.setCharacterAttributes(it.positionInDocument, it.word.length(), getCommentStyle(doc), false);
              break;
            case  Echo:
                 doc.setCharacterAttributes(it.positionInDocument, it.word.length(), getAnnotationStyle(doc), false);
              break;

         }
      }
   }

   /** Should be called on UI manager changes
   */
   public void setOrUpdateStyles(StyledDocument doc)
   {
     Style s = doc.getStyle("default");

     StyleConstants.setFontFamily(s, ThemesManager.getInstance().get_tideEditor_codeEditorFont().getFamily());
     StyleConstants.setBold(s, ThemesManager.getInstance().get_tideEditor_codeEditorFont().isBold());

     StyleConstants.setForeground(s, ThemesManager.getInstance().get_tideEditor_textColor());  // black

     Style defaultStyle = doc.getStyle("regular");

     Style keywordStyle = doc.addStyle("keyword", defaultStyle);
     StyleConstants.setForeground(keywordStyle, ThemesManager.getInstance().get_tideEditor_keywordColor());   // new Color(160,30,30));

     Style commentStyle = doc.addStyle("comment", defaultStyle);
     StyleConstants.setForeground(commentStyle, ThemesManager.getInstance().get_tideEditor_commentColor());   // blue  (30,30,160)

     Style litteralStyle = doc.addStyle("litteral", defaultStyle);
     StyleConstants.setForeground(litteralStyle, ThemesManager.getInstance().get_tideEditor_litteralsColor()); // new Color(30,160,30));

     Style numberStyle = doc.addStyle("number", defaultStyle);
     StyleConstants.setForeground(numberStyle, ThemesManager.getInstance().get_tideEditor_numbersColor()); // new Color(30,160,30));

     Style todoStyle = doc.addStyle("todo", defaultStyle);
     StyleConstants.setForeground(todoStyle, ThemesManager.getInstance().get_tideEditor_todoColor());

     Style warnStyle = doc.addStyle("ref", defaultStyle);
     StyleConstants.setForeground(warnStyle, ThemesManager.getInstance().get_tideEditor_todoColor());

     Style annotStyle = doc.addStyle("annotations", defaultStyle);
     StyleConstants.setForeground(annotStyle, ThemesManager.getInstance().get_tideEditor_annotationColor());
   }

   public static Style getAnnotationStyle(StyledDocument doc) { return doc.getStyle("annotations"); }
   public static Style getTodoStyle(StyledDocument doc) { return doc.getStyle("todo"); }
   public static Style getRefStyle(StyledDocument doc) { return doc.getStyle("ref"); }
   public static Style getCommentStyle(StyledDocument doc) { return doc.getStyle("comment"); }
   public static Style getKeywordStyle(StyledDocument doc) { return doc.getStyle("keyword"); }
   public static Style getLitteralStyle(StyledDocument doc) { return doc.getStyle("litteral"); }
   public static Style getDefaultStyle(StyledDocument doc) { return doc.getStyle("default"); }


   /** Installs a document listener to track the changes and rescan the syntax.
   *   The listener should be removed when the document is closed.
   *   An initial parsing, can be triggered with callinf insertUpdate(null).
    */
   public static DocumentListener install_parseAtChanges(final SimpleDocument doc, final JTextPane pane)
   {

      final DelayedMergedUpdater2 dmu = new DelayedMergedUpdater2(300, true, new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         new WindowsBatStyler(doc);
      } });


      DocumentListener dl = new DocumentListener()
      {
         public final void insertUpdate( final DocumentEvent e ) { dmu.changeOccured();  }
         public final void removeUpdate( final DocumentEvent e ) { dmu.changeOccured();  }
         public final void changedUpdate( final DocumentEvent e ) { } //update();  }  // NO because the styling itself is causing changes
      };
      pane.getDocument().addDocumentListener(dl);

      return dl;
   }

/*test
   public static void main(String[] args) throws Exception
   {
      SimpleDocument doc = new SimpleDocument();

      doc.setText(FileUtils.getFileStringContent(new File("C:/temp/a.bat")));
      JTextPane pane = new JTextPane(doc);
      JFrame f = GUIUtils.displayInFrame("Style test", new JScrollPane(pane), true);
      install_parseAtChanges(doc, pane).insertUpdate(null);
   } */

}