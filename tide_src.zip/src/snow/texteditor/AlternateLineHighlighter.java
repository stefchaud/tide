package snow.texteditor;

import snow.utils.gui.GUIUtils;
import java.awt.*;
import javax.swing.*;
import javax.swing.text.*;

/** Highlights each second line.
*   Very useful for tabulated data.
*IDEA: highlight depending on some header like "AAA> "
*/
public final class AlternateLineHighlighter
	implements Highlighter.HighlightPainter
	//, CaretListener, MouseListener, MouseMotionListener
{
	private JTextComponent component;

	private Color color;

	private Rectangle lastView;

	static JTextPane test()
	{
	   JTextPane tp = new JTextPane();
	   new AlternateLineHighlighter(tp, new Color(220,220,210,10));
	   new LinePainter(tp);
	   return tp;
	}

	/*
	 *  The line color will be calculated automatically by attempting
	 *  to make the current selection lighter by a factor of 1.2.
	 *
	 *  @param component  text component that requires background line painting
	 */
	public AlternateLineHighlighter(JTextComponent component)
	{
		this(component, null);

		// too much contrast for nimbus
		if(GUIUtils.isNimbusLF())
		{
		    //Colors.createContrastedColor(component.getSelectionColor(), 10f);
		   setLighter(new Color(200,200,233, 210));
		}
		else
		{
		   setLighter(component.getSelectionColor());
		}
	}

	/*
	 *  Manually control the line color
	 *
	 *  @param component  text component that requires background line painting
	 *  @param color      the color of the background line
	 */
	public AlternateLineHighlighter(JTextComponent component, Color color)
	{
		this.component = component;
		setColor( color );


		//  Turn highlighting on by adding a dummy highlight

		try
		{
			component.getHighlighter().addHighlight(0, 0, this);
		}
		catch(BadLocationException ble) {}
	}

	/*
	 *	You can reset the line color at any time
	 *
	 *  @param color  the color of the background line
	 */
	public void setColor(Color color)
	{
		this.color = color;
	}

	/*
	 *  Calculate the line color by making the selection color lighter
	 *
	 *  @return the color of the background line
	 */
	public void setLighter(Color color)
	{
		int red   = Math.min(255, (int)(color.getRed() * 1.2));
		int green = Math.min(255, (int)(color.getGreen() * 1.2));
		int blue  = Math.min(255, (int)(color.getBlue() * 1.2));

		setColor(new Color(red, green, blue));
	}

	//  Paint the background highlight

	public void paint(Graphics g, int p0, int p1, Shape bounds, JTextComponent c)
	{
		try
		{
		   Element re = c.getDocument().getDefaultRootElement();
		   for(int i=0; i<re.getElementCount(); i+=2)
		   {
			Rectangle r = c.modelToView(re.getElement(i).getStartOffset());
			g.setColor( color );
			g.fillRect(0, r.y, c.getWidth(), r.height);
		   }

		}
		catch(BadLocationException ble) {System.out.println(ble);}
	}

}