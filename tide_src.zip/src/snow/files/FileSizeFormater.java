package snow.files;

import java.io.File;
import java.text.FieldPosition;
import java.text.Format;
import java.text.ParsePosition;
import snow.utils.storage.FileUtils;

/** Helper to format file sizes.
*  Wikes with files and numbers
*/
public class FileSizeFormater extends Format
{
   public static FileSizeFormater sharedInstance = new FileSizeFormater();

   @Override public final StringBuffer format( final Object obj, final StringBuffer toAppendTo, final FieldPosition pos )
   {
      if(obj==null) return toAppendTo;
      long s = 0;
      if(obj instanceof Number)
      {
         s =((Number) obj).longValue();
      }
      else if(obj instanceof File)
      {
         s =((File) obj).length();
      }
      else
      {
         s = Long.parseLong(""+obj);
      }
      toAppendTo.append(FileUtils.formatSize(s));
      return toAppendTo;
   }

   //Overrides abstract method of Format
   @Override public final Object parseObject( final String source, final ParsePosition pos ) {
      return null;
   }
}