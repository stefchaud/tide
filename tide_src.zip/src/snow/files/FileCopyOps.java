package snow.files;

import java.awt.Component;
import java.awt.BorderLayout;
import snow.texteditor.SimpleDocument;
import javax.swing.JDialog;
import java.awt.Window;
import snow.utils.gui.GUIUtils;
import javax.swing.JComponent;
import java.util.*;
import java.io.File;

/** Utilities top copy files / folders recursively
*  Goal: unattended copy but with options and problems reporting (on demand)
*/
public final class FileCopyOps
{
   final private File source;
   final private File dest;

   List<String> problems = new ArrayList<String>();

   /** Constructor.
   */
   public FileCopyOps(File source, File dest)
   {
      this.source = source;
      this.dest = dest;
   }

   // please call viewEventualProblemsInModalDialog thereafter
   public void copy()
   {

      //todo
   }

   // please call viewEventualProblemsInModalDialog if true
   public boolean hasProblems()
   {
      return !problems.isEmpty();
   }

   public void viewEventualProblemsInModalDialog(Component parent)
   {
      if(problems.isEmpty()) return;

      Window w = GUIUtils.getWindowForComponent(parent);
      JDialog d = new JDialog(w, problems.size()+" copy problems", JDialog.ModalityType.APPLICATION_MODAL);

      SimpleDocument doc = new SimpleDocument();
      d.add(doc.createView(false).getView(), BorderLayout.CENTER);

      for(String p : problems)
      {
         doc.appendLine(p);
      }

      d.setSize(800,600);
      d.setLocationRelativeTo(parent);
      d.setVisible(true);


      //todo
   }


   public static void main(String[] args) throws Exception
   {
      FileCopyOps cop = new FileCopyOps(
        new File("c:/temp/benchs/"),
        new File("c:/temp/benchs2/")
      );

      cop.copy();
   }

}