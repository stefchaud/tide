package snow.files;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.*;
import snow.sortabletable.*;
import snow.utils.DateUtils;
import snow.utils.gui.*;
import snow.utils.storage.*;

/** With content last mod date statistics (min, max, median)
*/
public final class DirectoryStatExplorer
{
   final File baseFolder;
   final JFileChooser chooser;

   final int baseLength;
   final List<Folder> folders = new ArrayList<Folder>();
   long dateOverallMin=Long.MAX_VALUE, dateOverallMax=-1;
   long totFileCount = 0;
   long totSizeCount = 0;
   final String[] columns = new String[]{"package", "files", "size", "median date", "last modified dates [min, median, max]"};

   public DirectoryStatExplorer(final File baseFolder, final JFileChooser chooser)
   {
     this.baseFolder = baseFolder;
     this.chooser = chooser;
     baseLength = baseFolder.getAbsolutePath().length();

     if(baseFolder==null) return;
     if(!baseFolder.isDirectory()) return;

     ProgressModalDialog pmd = new ProgressModalDialog(new JFrame(), "Scanning "+baseFolder.getAbsolutePath(), true);
     pmd.start();

     List<File> allFolders = new ArrayList<File>();
     FileUtils.getFoldersRecurse(baseFolder, allFolders, false);

     pmd.setProgressBounds(allFolders.size());

     System.out.println(""+allFolders.size()+ " folders found in "+baseFolder);

     for(File fi : allFolders)
     {
        if(pmd.getWasCancelled())
        {
          pmd.closeDialog();
          return;
        }

        pmd.incrementProgress(1);
        Folder ffi = new Folder(fi);
        totFileCount += ffi.count;
        totSizeCount += ffi.size;
        folders.add( ffi );

        pmd.setProgressComment(""+folders.size()+" folders, "+totFileCount+" files.");
     }
     pmd.closeDialog();

     view();
  }


  void view()
  {
     String tit =   "Folders explorer for "+totFileCount+" files and "+folders.size()+" folders, "+ FileUtils.formatSize(totSizeCount)
         + "   [dates range: "+DateUtils.dateFormatMDY.format(dateOverallMin)+" - "+DateUtils.dateFormatMDY.format(dateOverallMax)+"]";

      JDialog d = new JDialog(new JFrame(), tit, true);  // if false, remains behind the chooser !
      CloseControlPanel ccp = new CloseControlPanel(d, false, true, "Close");
      d.add(ccp, BorderLayout.SOUTH);

      final FoldersTableModel ftm = new FoldersTableModel();
      final SortableTableModel stm = new SortableTableModel(ftm, 7, false);  // so we see first the last modified packs
      final JTable table = new JTable(stm);
      Renderer renderer = new Renderer();
      stm.installGUI(table);
      table.setDefaultRenderer(Folder.class, renderer);

      d.add(GUIUtils.makeSmall(new JScrollPane(table)), BorderLayout.CENTER);

      MultiSearchPanel msp = new MultiSearchPanel(stm);
      d.add(msp, BorderLayout.NORTH);

      table.addMouseListener(new MouseAdapter(){
          @Override public void mousePressed(MouseEvent me)
          {
             if(me.getClickCount()==2)
             {
                int pos = stm.getIndexInUnsortedFromTablePos(table.getSelectedRow());
                Folder fi = folders.get(pos);
                if(chooser!=null)
                {
                  chooser.setSelectedFile( fi.folder );
                }
             }
          }
      });

      d.setSize(850, 700);
      d.setLocation(150, 50);
      d.setVisible(true);

  }



  /** Creates stats of the folder's content
  */
  class Folder implements TableRow
  {

     public final Object getValueForColumn( final int col ) {
         if(col==0)
         {
            if(name.length()==0) return "<unnamed package>";
            return name;
         }
         if(col==1)
         {
            return count;
         }
         if(col==2)
         {
            return size;
            //if(size<=0) return "";
            //return FileUtils.formatSize(size);  // => sort has to be impl
         }
         if(col==3)
         {
            if(dateMedian<=0) return "";
            return DateUtils.dateFormatMDY.format( dateMedian );  // => sort has to be impl
         }
         if(col==4)
         {
            return this;
               /*DateUtils.dateFormatMDY.format( it.dateMin ) + " - "+ DateUtils.dateFormatMDY.format( it.dateMedian )
                +" - "+DateUtils.dateFormatMDY.format( it.dateMax );*/
         }

         return "?";

     }


     final File folder;
     final String name;

     int count=0;
     long size = 0;
     long dateMin = Long.MAX_VALUE;
     long dateMax = -1;
     long dateMedian;
     List<Long> dates = new ArrayList<Long>(); // used for median

     public Folder(File folder)
     {
        this.folder = folder;
        this.name = folder.getAbsolutePath().substring(baseLength);

        File[] fis = folder.listFiles();
        if(fis!=null)
        {
           for(File fi : fis)
           {
              if(fi.isFile())
              {
                 count++;
                 size += fi.length();
                 long lm = fi.lastModified();

                 if(lm>0)
                 {
                   dates.add(lm);

                   if(lm < dateMin) dateMin = lm;
                   if(lm > dateMax) dateMax = lm;

                   if(lm < dateOverallMin) dateOverallMin = lm;
                   if(lm > dateOverallMax) dateOverallMax = lm;
                 }

              }
           }
        }

        endStat();
     }

      /** Must be called at the end, after all sources have been added */
      public void endStat()
      {
         if(!dates.isEmpty())
         {
           dateMedian = dates.get(dates.size()/2);
         }
         dates.clear();  // no more used.
      }
  }


   class FoldersTableModel extends FineGrainTableModelBuilder<Folder>
   {
      public FoldersTableModel()
      {
         super(folders, columns.length);
         setColumnNames(columns);
         setPreferredColumnWidth(COLUMN_PREFERRED_SIZES);
      }

      @Override public int getColumnAlignment(int column)
      {
         if(column==0) return JLabel.LEFT;
         return JLabel.RIGHT;
      }

      int[] COLUMN_PREFERRED_SIZES = new int[]{26,4, 4, 8, 20};

      @Override
      public int compareForColumnSort(int row1, int row2, int col)
      {
         if(col==2)
         {
            return Long.valueOf(folders.get(row1).size).compareTo(folders.get(row2).size);
         }

         if(col==3)
         {
            return Long.valueOf(folders.get(row1).dateMedian).compareTo(folders.get(row2).dateMedian);
         }

         if(col==4)
         {
            // of interrest: look at last mod ! first not very useful
            return Long.valueOf(folders.get(row1).dateMax).compareTo(folders.get(row2).dateMax);
         }

         // use the getValueAt
         return super.compareForColumnSort(row1,row2,col);
      }
   }

   class Renderer extends DefaultTableCellRenderer
   {
     RendererIm rim = new RendererIm();

     @Override public Component getTableCellRendererComponent(JTable table, Object value,
                          boolean isSelected, boolean hasFocus, int row, int column)
     {
        if(column==4)
        {
           //rim.setPreferredSize( getPreferredSize() );
           if(isSelected)
           {
              rim.setBackground(UIManager.getColor("Table.selectionBackground"));
           }
           else
           {
              rim.setBackground(UIManager.getColor("Table.background"));
           }
           rim.set((Folder) value);
           return rim;
        }
        return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
     }
   }

   class RendererIm extends JPanel
   {
      Folder pi;
      public RendererIm()
      {
         super();
         //setBackground(table.getBackground()); //Color.white);
         //setSize(200,20);
      }

      public void set(Folder pi)
      {
         this.pi = pi;
      }

      @Override
      public void paintComponent(Graphics gr)
      {
         super.paintComponent(gr);  // border, background, ...
         if(pi==null) return;
         if(dateOverallMax<0) return;

         // gray bloc from min to max
         gr.setColor(Color.lightGray);
         int min = (int)( relPosDate(pi.dateMin)* getWidth() );
         int max = (int)( relPosDate(pi.dateMax)* getWidth() );
         gr.fillRect(min,2,max-min, getHeight()-4);
         int med = (int)( relPosDate(pi.dateMedian)* getWidth() );
         gr.setColor(Color.darkGray);
         gr.fillRect(med,0,1, getHeight());
      }
   }

   // in [0,1]
   private double relPosDate(final long d)
   {
      return (1.0*(d-dateOverallMin)) / (dateOverallMax-dateOverallMin);
   }

/*to test
   public static void main(String[] args) throws Exception
   {
      FileChooserFilter.main(args);
   }*/

}