package snow.files;

import java.awt.EventQueue;
import snow.utils.DateUtils;
import java.util.*;
import snow.utils.storage.*;
import java.io.File;

/** LastModNormalizer.  A kind of experiment.
*
*   IDEA: set consistent recursive lastmodified times on directories (= normalizer)
*     to directly *see* the last mod on a branch recursively.
*   Actually, windows only sets it for the directory containing a changed file (or folder).
*
*
*  BUGGY: don't work reliabily... very "unnice"
*    C:\Java\docs\api\java\text\spi\class-use    for example can call 10 times the routine, the date is NOT changed !!
*
*  UGLY !!  Fails if a folder is opened by the explorer !!

*/
public final class LastModNormalizer {

   List<Long> lastMods = new ArrayList<Long>();

   /** Constructor. */
   public LastModNormalizer(File f) {
      List<File> allDirs = new ArrayList<File>();
      FileUtils.getFoldersRecurse(f, allDirs, true);

      // important: depth first IF sorted(either using name or length), think about !
      // one could also collect depth-first...
      Collections.sort(allDirs);
      Collections.reverse(allDirs);

      System.out.println("Analysing "+f);
      System.out.println(""+allDirs.size()+" folders to normalize last-mod");
      int fail = 0;
      for(final File fi : allDirs)
      {
         long alm = fi.lastModified();
         final long lm2 = lastMod_OfLevel1(fi);

         if(lm2<0) continue;  // ignore empty dirs

         if(FileUtils.isSameTime_tricky(alm,lm2))
         {
            //System.out.println("Same time: "+DateUtils.formatDateAndTimeHuman(alm)+"   \t"+fi);
         }
         else
         {
            // set !
            fi.setLastModified(lm2);

            System.out.println("Set to "+DateUtils.formatDateAndTimeHuman(lm2)+" \t for "+fi);
            System.out.println("   Old: "+DateUtils.formatDateAndTimeHuman(alm) + " (diff "+DateUtils.formatTimeDifference(lm2-alm)+")");

            if(fi.lastModified() != lm2)
            {
               System.out.println("   FAILED ! "+DateUtils.formatDateAndTimeHuman(fi.lastModified()));
               fail++;

               //doesn't help: fails as long as a file explorer opens it !
               EventQueue.invokeLater(new Runnable() { public void run() {
                 System.out.println("  try2: "+ fi.setLastModified(lm2));
                 System.out.println("  try3: "+ fi.setLastModified(lm2-1000));
                 System.out.println("  try4: "+ fi.setLastModified(lm2+1000));
               }});

            }
         }
      }

      System.out.println("done.");
      if(fail>0) System.out.println(""+fail+" failures.");
   }

   /** only looks ast files directly in the dir (files and dirs)
   */
   public long lastMod_OfLevel1(File dir)
   {
      File[] files = dir.listFiles();
      if(files==null) return -1;

      boolean hasFile = false;

      long lastMod = -1;
      for(File fi : files)
      {
         long lm = fi.lastModified();
         if(lm>lastMod) lastMod=lm;

         if(!hasFile) hasFile = !fi.isDirectory();
      }

      //no! subtle bugs if so...  if(!hasFile) return -1;

      return lastMod;
   }

   public static void main(String[] args) throws Exception {
      //new LastModNormalizer(new File("C:/Java/docs/api/java"));
      new LastModNormalizer(new File("C:/projects"));

      //new File("C:\Java\docs\api\java\text\spi\class-use").setLastModified(System.currentTimeMillis()-1000L*3600*24*365);
   }

}