package snow.files;

import java.io.File;

/** A file stored with some infos. And a relative path.
*   May also be instancied for files no more existing.
*   Used in search / compare functions and browse in the JFilesTableModel
*/
public class JFile
{
   public final /*@org.checkerframework.checker.nullness.qual.Nullable*/ File f;
   public final String relName;
   public final long lastModified;
   public final long length;

   public JFile(File f, String relName)
   {
      this.f = f;
      this.relName = relName;
      lastModified = f.lastModified();
      length = f.length();
   }

   public JFile(String relName)
   {
      this.f = null;
      this.relName = relName;
      this.lastModified = -1;
      this.length = -1;
   }

   // used for removed files
   public JFile(final String relName, final long lastMod, final long length)
   {
      this.f = null;
      this.relName = relName;
      this.lastModified = lastMod;
      this.length = length;
   }

   @Override public final String toString() {
      return relName;
   }


}