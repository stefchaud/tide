package snow.files;

import snow.utils.storage.FileUtils;
import snow.utils.DateUtils;
import snow.sortabletable.*;
import java.util.*;

/** Displays {File, Age, Size, Detailled Date}.
*/
public class JFilesTableModel extends FineGrainTableModel
{
   final List<JFile> hits;
   final int columnsToSee;

   /** @param columnsToSee 4 for all.
   */
   public JFilesTableModel(List<JFile> hits, final int columnsToSee)
   {
      this.hits = hits;
      this.columnsToSee = columnsToSee;
   }

   public JFile getHitAt(int row)
   {
      return hits.get(row);
   }


   /** rel name, date, site
   */
   public Object getValueAt(int row, int col)
   {
      if(col==0) return hits.get(row).relName;
      if(col==1)
      {
        long lm = hits.get(row).lastModified;
        if(lm<=0) return "?";
        return DateUtils.formatDateDifferenceFromNow( lm );
      }
      if(col==2)
      {
        JFile fi =  hits.get(row);
        if(fi.f!=null && fi.f.isDirectory()) return "";  // [jul2011] nicer
        //return FileUtils.formatSize(fi.length);
        return fi.length;   // [jul2013] even nicer
      }
      return new Date(hits.get(row).lastModified);
   }

   public int getRowCount() { return hits.size();     }
   public int getColumnCount() { return columnsToSee; }

   @Override
   public String getColumnName(int c)
   {
      if(c==0) return "File";
      if(c==1) return "Last-mod";
      if(c==2) return "Size";
      return "Date";
   }

   @Override
   public int getPreferredColumnWidth(int column)
   {
      if(column==1) return 4;
      if(column==2) return 4;
      if(column==3) return 7;
      return 21;
   }

   @Override
   public int compareForColumnSort(int pos1, int pos2, int col)
   {
      if(col==0)  // folders and files separately // [june2011]
      {
         if(hits.get(pos1).f !=null && hits.get(pos2).f!=null)
         {
           boolean is1 = hits.get(pos1).f.isDirectory();
           boolean is2 = hits.get(pos2).f.isDirectory();
           int cmp = Boolean.valueOf(is1).compareTo(is2);
           if(cmp!=0) return cmp;

         }

          // else let compare names !

      }

      if(col==1)  // age
      {
         long a1 = hits.get(pos1).lastModified;
         long a2 = hits.get(pos2).lastModified;
         return Long.valueOf(a2).compareTo(a1);
      }

      if(col==2)  // size
      {
         long s1 =  hits.get(pos1).length;
         long s2 =  hits.get(pos2).length;
         return Long.valueOf(s1).compareTo(s2);
      }

      return super.compareForColumnSort(pos1, pos2, col);
   }

}
