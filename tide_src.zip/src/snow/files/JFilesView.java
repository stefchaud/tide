package snow.files;

import java.io.File;
import snow.im.ImageEditor;
import snow.texteditor.SimpleEditor;
import snow.utils.gui.*;
import snow.utils.*;
import java.awt.Desktop;
import java.awt.event.*;
import java.util.*;
import snow.sortabletable.*;
import java.awt.BorderLayout;
import javax.swing.*;

/** Views a JFilesTableModel with search and standard popup.
*/
public final class JFilesView extends JPanel
{
   final JFilesTableModel htm;
   final SortableTableModel stm;
   final JTable table;
   final MultiSearchPanel asp;

   //helper
   public static List<JFile> makeJFiles(List<JRelFile> relFiles)
   {
      List<JFile> ret = new ArrayList<JFile>();
      for(JRelFile rf : relFiles)
      {
         JFile nf = new JFile(rf.getFile_Cache(), rf.getRelName());
         ret.add(nf);
      }
      return ret;
   }


   /** @param columnsToSee controls which columns are visible from  {file, age, size, date}
   */
   public JFilesView( final List<JFile> files, final int columnsToSee, boolean sortPerDate)
   {
        super(new BorderLayout());

        htm = new JFilesTableModel(files, columnsToSee);
        stm = sortPerDate ? new SortableTableModel(htm,1,true) : new SortableTableModel(htm);
        table = new JTable(stm);
        stm.installGUI(table);

        add(GUIUtils.makeSmall(new JScrollPane(table)), BorderLayout.CENTER);
        asp = new MultiSearchPanel(stm);
        add(asp, BorderLayout.NORTH);


        table.addMouseListener(new MouseAdapter(){
          @Override public void mousePressed(MouseEvent me)
          {
             if(me.isPopupTrigger()) showPopup(me);
          }
          @Override public void mouseReleased(MouseEvent me)
          {
             if(me.isPopupTrigger()) showPopup(me);
          }
        });
   }

   public final JTable getTable() { return table; }
   public final MultiSearchPanel getMultiSearchPanel() { return asp; }
   public final SortableTableModel getSortableTableModel() { return stm; }


   public List<JFile> getSelectedFiles()
   {
      final List<JFile> selFiles = new ArrayList<JFile>();
      int[] str = table.getSelectedRows();
      if(str==null || str.length==0) return selFiles;


      for(int si : str)
      {
        int posm = stm.getIndexInUnsortedFromTablePos(si);
        final JFile sh = htm.getHitAt(posm);
        selFiles.add(sh);
      }
      return selFiles;
   }


   private void showPopup(MouseEvent me)
   {
      int[] str = table.getSelectedRows();
      if(str==null || str.length==0) return;

      if(str.length>1)
      {
         // multiselection
         JPopupMenu pop = new JPopupMenu();
         pop.add(str.length+" selected files");

         // delete [sep2011]
         JMenuItem del = new JMenuItem("Delete", Icons.sharedCross);
         pop.add(del);
         del.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
            int rep = JOptionPane.showConfirmDialog(JFilesView.this, "Deleted files will be lost!\n"+"Are you sure ?", "Confirmation", JOptionPane.YES_NO_CANCEL_OPTION);
            if(rep!=JOptionPane.OK_OPTION) { return; }

            List<Integer> sel = stm.getSelectedRows_sortedBasicIndices(table);
            System.out.println("deleting "+sel.size()+" files");

            int errs = 0;
            for(int si : sel)
            {
               JFile fi = htm.getHitAt(si);
               System.out.println("deleting "+fi.f);
               try{
                  if(!fi.f.delete()){
                     System.err.println("Cannot delete");
                     errs++;
                  }
               }
               catch(final Exception e) {
                  System.err.println("Cannot delete");
                  errs++;
               }
            }

            if(errs>0)
            {
               JOptionPane.showMessageDialog(JFilesView.this, "deletion of "+sel.size()+" with "+errs+" errors", "Cannto delete", JOptionPane.WARNING_MESSAGE);
            }

         }});

         pop.show(table, me.getX(), me.getY());

         return;
      }

      int posm = stm.getIndexInUnsortedFromTablePos(str[0]);
      final JFile sh = htm.getHitAt(posm);
      if(sh.f==null) return;

      JPopupMenu pop = new JPopupMenu();
      JMenuItem nameItem = new JMenuItem(sh.relName);
      nameItem.setToolTipText(""+sh.f+" ("+new Date(sh.f.lastModified())+")");  // absolute name
      pop.add(nameItem);

      pop.addSeparator();
      JMenuItem open = new JMenuItem("Open (system exec)", Icons.sharedSmallStart);
      pop.add(open);
      open.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
         try{
            //FAILS: file:/C:/Program%20Files/Common%20Files/Adobe/Web/adobeonlineprefs)
            Desktop.getDesktop().open(sh.f);
         }
         catch(Exception e)
         {
            e.printStackTrace();
            try
            {
               //TODO: also not working
              SysUtils.openDocumentInSystem((""+sh.f).replace(" ", "%20"), false);
            }catch(Exception e2) {e2.printStackTrace();}
         }
      } });

      if(sh.f.isFile())
      {
        final JMenuItem openi = new JMenuItem("Open in internal text editor", Icons.FileIcon.textFile(16));
        pop.add(openi);
        openi.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {

           SimpleEditor sed = new SimpleEditor(GUIUtils.getWindowForComponent( JFilesView.this ), ""+sh.f.getAbsolutePath(), true, false);
           sed.allowDropFilesFromOS();
           try
           {
              sed.setText(sh.f);
           }
           catch(Exception e) {e.printStackTrace(); }
        }});


        JMenuItem openim = new JMenuItem("Open in internal image editor", Icons.sharedEye);
        pop.add(openim);
        openim.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {

           try //todo: pass the parent dialog because of modality
           {
              new ImageEditor(null, sh.f, sh.relName);
           }
           catch(Exception e) {e.printStackTrace(); }
        }});

        final File parentFile = sh.f.getParentFile();
        if(parentFile!=null)
        {
           GUIUtils.addSeparator(pop);

           JMenuItem openp = new JMenuItem("Open parent folder", Icons.sharedSystemFolder);
           pop.add(openp);
           openp.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {

              try{
                 Desktop.getDesktop().open(parentFile);
              }
              catch(Exception e) {
                 e.printStackTrace();
              }
           } });

           JMenuItem opens = new JMenuItem("Open shell", Icons.sharedShellIcon);
           pop.add(opens);
           opens.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {

              try{
                 SysUtils.openShellAt(parentFile);
              }
              catch(Exception e) {
                 e.printStackTrace();
              }
           } });
        }

        GUIUtils.addSeparator(pop);
        JMenuItem del = new JMenuItem("Delete", Icons.sharedCross);
        pop.add(del);
        del.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
           if(!sh.f.delete())
           {
              JOptionPane.showMessageDialog(null, "Can't delete: "+sh.f, "Error", JOptionPane.ERROR_MESSAGE);
              //ask to delete on exit ?
              // ask to wipe (overwrite content sometimes work eevn if file cannot be deleted?)
              //
           }
        }});

      } // is file


      pop.show(table, me.getX(), me.getY());
   }


}