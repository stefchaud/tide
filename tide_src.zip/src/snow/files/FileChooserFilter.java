package snow.files;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Insets;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.beans.*;
import java.io.*;
import java.util.*;
import java.util.prefs.Preferences;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.*;
import snow.HexViewer;
import snow.concurrent.SoftInterruptedException;
import snow.im.ImageEditor;
import snow.lab.DateAndTimeLab;
import snow.sortabletable.*;
import snow.texteditor.SimpleEditor;
import snow.utils.CollectionUtils;
import snow.utils.DateUtils;
import snow.utils.StringUtils;
import snow.utils.SysUtils;
import snow.utils.gui.*;
import snow.utils.jarex.JarExplorer;
import snow.utils.storage.*;
import snow.watchdog.WatchUtils;
import snow.watchdog.WatchedData;
import tide.editor.UIConstants;

/** Can be used in accessory panels of JFileChooser.

    Installs a realtime filefilter, take eventual already installed filefilter in account !

    Options: browse, search and filter files and folders, with statistics.

    TODO: previews as text/images.
    TODO: unify the various popups  ( addPopupItemsFor(File f) )  for example for JarExplorer, ...

    TODO: solve the ugly modality issues here !

*/
public class FileChooserFilter extends JPanel implements PropertyChangeListener
{

  // the three option/utilities buttons
  final JButton searchBt = new JButton(Icons.sharedSearch);
  final JButton selectBt = new JButton(Icons.sharedHighlight);

  final JButton optionsButton = new JButton("OS"); //Icons.sharedSwingSettings); // .drawLine();"Options");
  final JButton favBt = new JButton(Icons.sharedPentagonStar); //new Icons.LetterIcon("*", false, 16, 16, true, Color.blue));
  final JButton colorizeBt = new JButton(Icons.tempScaleIcon16);

  final JTextField searchField = new JTextField(4);
  final AnimatedColorPanel filtPan = new AnimatedColorPanel(new FlowLayout(FlowLayout.LEFT,4,0), 200L);
  final JCheckBox filterFolders = new JCheckBox("Filter Folders", false);
  //final JCheckBox viewNew = new JCheckBox("Only new", false);
  //always show the preview: final JCheckBox preview = new JCheckBox("Preview", false);
  final private JLabel imagePreview = new JLabel();
  // allows for export, edit, copy to clip, ...
  private /*@org.checkerframework.checker.nullness.qual.Nullable*/ File displayedPreviewImage = null;

  static final File storageFile = new File(System.getProperty("user.home"), ".tide_global/files_explorer.vec");

  final JFileChooser fileChooser;

  // may be null
  private javax.swing.filechooser.FileFilter originalFilter;
  private javax.swing.filechooser.FileFilter filteredFilter;


  enum Colorization { None, ReadWrite, Age, Size }
  private Colorization choosedColorization = Colorization.ReadWrite;
  {
       try{
          choosedColorization = Colorization.valueOf(Preferences.userNodeForPackage(FileChooserFilter.class).get("Colorization", "ReadWrite"));
       }
       catch(final Exception e) {
          //e.printStackTrace();
       }
  }


  /** Creates and install as accessory panel
  */
  public static FileChooserFilter create(final JFileChooser fileChooser)
  {
     FileChooserFilter fcf = new FileChooserFilter(fileChooser);
     fileChooser.setAccessory(fcf);
     return fcf;
  }



  private FileChooserFilter(final JFileChooser fileChooser)
  {
    super(new BorderLayout());

    fileChooser.addPropertyChangeListener(JFileChooser.SELECTED_FILE_CHANGED_PROPERTY, this);

//very bad (?) also ugly with other layouts...
//TODO: FIX THIS !!
    this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

    JPanel gp = this; //new JGridPanel(2);
//    add(gp, BorderLayout.CENTER);

    //this.originalFilter = fileChooser.getFileFilter();
    this.fileChooser = fileChooser;


    gp.add( filtPan);
    filtPan.add(new JLabel("Filter: "));
    filtPan.add(searchField);
    searchField.addFocusListener(new FocusAdapter(){
       @Override public final void focusGained( final FocusEvent e ) {
          searchField.selectAll();
       }
    });

    JPanel filtPan2 = new JPanel(new FlowLayout(FlowLayout.LEFT,GUIUtils.isNimbusLF() ? 0 : 4,0));
    gp.add( filtPan2);
    filtPan2.add(filterFolders);
    filterFolders.setToolTipText("If not checked, all folders are always shown");
    if(fileChooser.getFileSelectionMode()==JFileChooser.DIRECTORIES_ONLY)
    {
       filterFolders.setSelected(true);  // clever set, otherwise, no sense !
    }
    /*else
    {
       JPanel filtPan3 = new JPanel(new FlowLayout(FlowLayout.LEFT,4,0));
       add( filtPan3);
       filtPan3.add(preview);
    }*/


//TOOLBAR appearing in the chooser...

    JPanel optsPan = new JPanel(new FlowLayout(FlowLayout.LEFT,3,0));
    gp.add( optsPan);

    optsPan.add(makeSmall(searchBt));
    searchBt.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae1) {
       showSearchToolPopup();
    }});

    optsPan.add(makeSmall(selectBt));
    selectBt.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae1) {
       showSelectToolPopup();
    }});

    optsPan.add(makeSmall(optionsButton));
    optionsButton.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae1) {
       showOptionsPopup();
    } });

    optsPan.add(makeSmall(favBt));
    favBt.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae1) {
       showFavoritesPopup();
    }});

    optsPan.add(makeSmall(colorizeBt));
    colorizeBt.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae1) {
       showColorizationPopup();
    }});

    // direct search:
    KeyAdapter kad = new KeyAdapter()
    {
      @Override public void keyReleased(KeyEvent ee)
      {
        filterAction();
      }
    };


    searchField.addKeyListener( kad );

    filterFolders.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
       filterAction();
    } });

// imges preview

    gp.add(imagePreview);
    imagePreview.setMinimumSize(new Dimension(110, 120));  // stabilize the rest and ensure image is visible...
    imagePreview.setPreferredSize(new Dimension(110, 120));

    imagePreview.addMouseListener(new MouseAdapter(){
      @Override public void mousePressed(MouseEvent me)
      {
         if(displayedPreviewImage!=null)
         {
           //if(me.isPopupTrigger()) pop
           JPopupMenu pop = new JPopupMenu();
           JMenuItem copyClip = new JMenuItem("Copy image to clipboard");
           pop.add(copyClip);
           copyClip.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
              try
              {
                 ImageUtils.copyToClipboard( ImageIO.read(displayedPreviewImage) );
              }catch(Exception e) {
                JOptionPane.showMessageDialog(null, "Can't copy image to clipboard", "Error", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
              }
           }});

           JMenuItem vim = new JMenuItem("View image");
           pop.add(vim);
           vim.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
              try
              {
                 //todo: modality over this => pass component
                 new ImageEditor(ImageIO.read(displayedPreviewImage), displayedPreviewImage, displayedPreviewImage.getName()+" in "+displayedPreviewImage.getParent());

              }catch(Exception e)
              {
                JOptionPane.showMessageDialog(null, "Can't open image ", "Error", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
              }
           }});


           pop.show(imagePreview, me.getX(), me.getY());

         }
      }

      @Override public void mouseReleased(MouseEvent me)
      {
      }
    });

    setColorization();

  } // Constructor


  static JButton makeSmall(JButton bt)
  {
     if(GUIUtils.isNimbusLF())
     {
       bt.setMargin(new Insets(-2,-7,-2,-7));
     }
     else
     {
       bt.setMargin(new Insets(0,2,0,2));
     }
     bt.setFocusPainted(false);
     return bt;
  }


  private void setDisplayedFile(final File favi)
  {
     if(fileChooser==null)
     {
        new Throwable("null chooser").printStackTrace(System.out);
     }

     if(favi==null)
     {
        fileChooser.setCurrentDirectory(null);
        return;
     }

     // subtle and works fine
     if(favi.exists())
     {
        if(favi.isFile())
        {
           try{
              //System.out.println("Setting parent "+favi.getParentFile());
              fileChooser.setSelectedFile(favi);
              fileChooser.setCurrentDirectory(favi.getParentFile());  //NPE ???
              fileChooser.setSelectedFile(favi);
           }
           catch(Exception e) {
              e.printStackTrace();
           }
        }
        else
        {
           fileChooser.setCurrentDirectory(favi);
        }
     }
     else
     {
        // [Mar2010] !
        fileChooser.setSelectedFile(favi);
     }
  }

  /**
   * Implementation of the PropertyChangeListener interface method.
   * Called at each selection change !
   */
  public void propertyChange(PropertyChangeEvent e)
  {
    String prop = e.getPropertyName();
    if (prop.equals(JFileChooser.SELECTED_FILE_CHANGED_PROPERTY))
    {
      File file = (File) e.getNewValue();
      if (isShowing())
      {
        createImagePreview();
      }
    }
  }


  void createImagePreview()
  {
     imagePreview.setText("");
     File f = null;
     try
     {
       f = fileChooser.getSelectedFile();   //TODO: fix. is null for folders !
       //System.out.println("sel: "+f);

       if(displayedPreviewImage!=null && f.equals(displayedPreviewImage)) return;  // ok

       BufferedImage bim = ImageUtils.readSubsampling(new FileInputStream(f), f.getAbsolutePath(), 200);
       imagePreview.setIcon(new ImageIcon(bim));
       displayedPreviewImage = f;
     }
     catch(Exception e) {
       // e.printStackTrace();
       imagePreview.setIcon(null);
       displayedPreviewImage = null;
     }

     if(f!=null)
     {
       //not working !
       imagePreview.setAlignmentX(0f);
       imagePreview.setHorizontalAlignment(SwingConstants.LEFT);
       imagePreview.setVerticalTextPosition(SwingConstants.BOTTOM);

       imagePreview.setText("<html><body>size: "+FileUtils.formatSize(f.length())
       +"<br>last-mod: "+DateUtils.formatDateDifferenceFromNow(f.lastModified()));

     }


  }

  @SuppressWarnings("unchecked")
  static List<File> getFavorites()
  {
     List<File> fav = new ArrayList<File>();
     if(storageFile.exists())
     {
        try
        {
          List<Object> reps = FileUtils.loadVectorFromFile(storageFile);
          List<Object> fis = (List<Object>) reps.get(1);
          for(Object oi : fis)
          {
             File fi = new File(""+oi);
             if(fi.exists())
             {
               fav.add( fi );
             }
          }
        }
        catch(Exception e)
        {
          e.printStackTrace();
        }
     }
     return fav;
  }

  static void saveFavorites(List<File> fav)
  {
     List<Object> rep = new ArrayList<Object>();
     rep.add(1); // version

     List<Object> fis = new ArrayList<Object>();
     rep.add(fis);
     for(File fi: fav)
     {
        fis.add(fi.getAbsolutePath());
     }

     try
     {
       FileUtils.saveVectorToFile(storageFile, rep);
     }catch(Exception e)
     {
       e.printStackTrace();
     }
  }

  /** With options dialog.
  */
  void advancedSearch()
  {
     JDialog d = new JDialog(null, "Advanced search in "+fileChooser.getCurrentDirectory(), Dialog.ModalityType.APPLICATION_MODAL);

     JPanel p = new JPanel();
     p.setBorder(new EmptyBorder(4,4,4,4));
     d.add(p, BorderLayout.CENTER);
     GridLayout3 gl = new GridLayout3(2, p);

     gl.addTitleSeparator("Text to search");
     gl.add("In filenames");
     JTextField filenameFilter =  new JTextField(10);
     gl.add(filenameFilter);

     //gl.add(new JComboBox(new String[]{"In file names only", "In file names with folder", "In file string content"}));

     gl.add("in file content");
     JTextField stf =  new JTextField();
     gl.add(stf, true);

     JCheckBox recurse = new JCheckBox("Recurse search", true);
     gl.add("");
     gl.add(recurse);

     gl.addTitleSeparator("Date and time range");

     // date
     SpinnerDateModel sdm = new SpinnerDateModel(new Date(0), null, null, Calendar.HOUR);
     JSpinner searchFrom = new JSpinner(sdm);
     searchFrom.setEditor(new JSpinner.DateEditor(searchFrom, "dd.MMM.yyyy HH:mm"));
     gl.add("From date");
     gl.add(searchFrom);

     SpinnerDateModel sdm2 = new SpinnerDateModel(new Date(System.currentTimeMillis()+DateUtils.oneDayMs), null, null, Calendar.HOUR);
     JSpinner searchTo = new JSpinner(sdm2);
     searchTo.setEditor(new JSpinner.DateEditor(searchTo, "dd.MMM.yyyy HH:mm"));
     gl.add("To date");
     gl.add(searchTo);

     JTextField dayRange = new JTextField("0-7", 12);
     JTextField hourRange = new JTextField("0-24", 12);

     gl.add("Day of week (0:Sunday)");
     gl.add(dayRange);

     gl.add("Hour in day (e.g. 6-11, 14-18)");
     gl.add(hourRange);

     final JCheckBox ignoreUnzippedFiles = new JCheckBox("Ignore unzipped files (not robust)", false);
     gl.add("");
     gl.add(ignoreUnzippedFiles);

     final JCheckBox see100RecentHitsOnly = new JCheckBox("See max 100 most recent hits", false);
     gl.add("");
     gl.add(see100RecentHitsOnly);

     //idea: include lastmod equals modulo 31289 ! => a way to filter secret lists !!

     //todo: filter sizes !


     final CloseControlPanel ccp = new CloseControlPanel(d, true, true, "Search");
     d.add(ccp, BorderLayout.SOUTH);

     d.pack();
     d.setLocationRelativeTo(null);
     d.setVisible(true);  // modal

     if(ccp.getWasCancelled())
     {
        return;
     }

     IntRanges dayRanges = null;
     IntRanges hourRanges = null;
     try{
        if(dayRange.getText().isEmpty() || dayRange.getText().equals("0-7"))
        {
           dayRanges = null;  // all, (easyer)
        }
        else
        {
           dayRanges = new IntRanges(dayRange.getText());
        }

        if(hourRange.getText().isEmpty() || hourRange.getText().equals("0-24"))
        {
           hourRanges = null;
        }
        else
        {
           hourRanges = new IntRanges(hourRange.getText());
        }
     }
     catch(Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(d, ""+e.getMessage(), "Illegal range", JOptionPane.ERROR_MESSAGE);
        return;
     }



     search(recurse.isSelected(),
         filenameFilter.getText(), stf.getText(),
         sdm.getDate().getTime(), sdm2.getDate().getTime(),
         dayRanges, hourRanges,
         ignoreUnzippedFiles.isSelected(),  // exotic search
         see100RecentHitsOnly.isSelected() ? 100 : -1
     );

  }

  /** Used for example to express  0-12, 13-18, 22
  *   Only applies for positive ranges.
  */
  static final class IntRanges
  {
     // internal representation, able to quickly answers
     // if some x is contained in the range
     List<int[]> ranges = new ArrayList<int[]>();

     private String actualNb = "";
     //boolean rangeFollows = false;
     private int actualRangeStart = -1;  // -1: NO def

     IntRanges(final String txt)
     {
        // parse

        for(int i=0; i<txt.length(); i++)
        {
           char ci = txt.charAt(i);
           if(Character.isDigit(ci))
           {
              actualNb += ci;
           }
           else if(ci=='-')
           {
              // range follows.. store actual
              if(actualNb.isEmpty()) throw new RuntimeException("Illegal range: "+txt+": \"-\" must follow a range start");

              actualRangeStart = Integer.parseInt(actualNb);
              actualNb = "";
           }
           else //if(ci==' ')
           {
              addActual();
           }
        }

        addActual();

        if(actualRangeStart>=0)
        {
           throw new RuntimeException("Illegal range: "+txt+": not ended !");
        }
     }

     /** Only adds if valid
     */
     private void addActual()
     {
        if(actualNb.isEmpty()) return;   // incomplete

        if(actualRangeStart<0)
        {
           // single item

           int actual = Integer.parseInt(actualNb);
           ranges.add(new int[]{actual});

           actualNb = "";
        }
        else
        {
           // range.
           int actual = Integer.parseInt(actualNb);

           if(actualRangeStart== actual) throw new RuntimeException("Illegal range: "+actualRangeStart+"-"+actual);

           ranges.add(new int[]{actualRangeStart, actual});

           actualNb = "";
           actualRangeStart = -1;

        }
     }

     @Override public final String toString() {
        StringBuilder sb = new StringBuilder();
        for(int[] ri : ranges)
        {
           StringUtils.appendToIfSrcNonEmpty(sb, ", ");
           if(ri.length==1) {
             sb.append(""+ri[0]);
           }
           else
           {
              sb.append(""+ri[0]+" - "+ri[1]+"");
           }

        }
        return sb.toString();
     }


     boolean isInRange(double x)
     {
        for(int[] ri : ranges)
        {
           if(ri.length==1)
           {
              if(x>=ri[0] && x<=ri[0]+1) return true;
           }
           else
           {
              if(x>=ri[0] && x<=ri[1]) return true;
           }
        }
        return false;
     }
  }




  void simpleSearchRecurseDialog()
  {
     String toSearch = JOptionPane.showInputDialog(this, "Enter the file name part to search in\n   "+fileChooser.getCurrentDirectory()
         +"\npress enter to see all files.");
     if(toSearch==null) return;
     search(true, toSearch, "");
  }

  /** without time limitation
  */
  void search(boolean recurse, String toSearchInNames, String toSearchInContents)
  {
     search(recurse, toSearchInNames, toSearchInContents, -1, Long.MAX_VALUE, null, null, false, -1);
  }

  /** Uses a modal dialog to display if several...
  */
  void search(boolean recurse, String toSearchInNames, String toSearchInContents,
     long after, long before,
     final /*@org.checkerframework.checker.nullness.qual.Nullable*/ IntRanges dayInWeekFilter, final /*@org.checkerframework.checker.nullness.qual.Nullable*/ IntRanges hourInDayFilter,
     boolean ignoreUnzipped,
     final int onlyNMostRecent)
  {
     toSearchInNames = toSearchInNames.toUpperCase();
     String base = FileUtils.getCanonicalName(fileChooser.getCurrentDirectory());
     int baseLen = base.length();

     final List<JFile> hits = new ArrayList<JFile>();
     final ProgressModalDialog pmd = new ProgressModalDialog(new JFrame(), "Searching files and folders...", true);
     pmd.start();
     boolean cancelled = false;
     try
     {
        File dir = fileChooser.getCurrentDirectory();
        System.out.println("Searching in "+dir);
        searchWithUI(recurse, hits, dir, toSearchInNames, toSearchInContents, baseLen,
           after, before,
           dayInWeekFilter, hourInDayFilter,
           ignoreUnzipped,  onlyNMostRecent,
           pmd);
     }
     catch(SoftInterruptedException sie)
     {
        cancelled = true;
        System.err.println("Search cancelled by user");
     }
     finally
     {
        pmd.closeDialog();
     }

     System.out.println(""+hits.size()+" hits");

     if(hits.isEmpty())
     {
        JOptionPane.showMessageDialog(this, "No file found");
     }
     else if(hits.size()==1)
     {
        fileChooser.setSelectedFile( hits.get(0).f);
     }
     else
     {
        // show them in a sortable table... in a dialog...

        final JFilesTableModel htm = new JFilesTableModel(hits, 4);
        //JFilesView jfw = new JFilesView(hits,3,after>0);
        final SortableTableModel stm = (after>0 || onlyNMostRecent>0) ? new SortableTableModel(htm,1,true) : new SortableTableModel(htm);
        final JTable table = new JTable(stm);

        stm.installGUI(table);
        UniversalTableCellRenderer utr = new UniversalTableCellRenderer(stm, table);

        JDialog d = new JDialog(new JFrame(),
              (cancelled?" [WAS CANCELLED]":"")
          +hits.size()+" files found in "+base
          + (recurse?"":" [NOT recursive]"
          )
          + (onlyNMostRecent>0?"  only "+onlyNMostRecent+" most recent" : ""), true);
        d.add(SortableTableUtils.createTableWithSearchBar(stm,table), BorderLayout.CENTER);
        final CloseControlPanel ccp = new CloseControlPanel(d, true, true, "Select");
        d.add(ccp, BorderLayout.SOUTH);
        d.pack();
        d.setLocationRelativeTo(this);


        table.addMouseListener(new MouseAdapter(){
          @Override public void mousePressed(MouseEvent me)
          {
             if(me.isPopupTrigger()) showPopup(me);
          }
          @Override public void mouseReleased(MouseEvent me)
          {
             if(me.isPopupTrigger()) showPopup(me);
          }

          public void showPopup(MouseEvent me)
          {
             int[] str = table.getSelectedRows();
             if(str==null || str.length==0) return;

             if(str.length!=1) return;   // TODO: offer functions

             int posm = stm.getIndexInUnsortedFromTablePos(str[0]);
             final JFile sh = htm.getHitAt(posm);

             if(sh.f==null) return;

             JPopupMenu pop = new JPopupMenu();
             pop.add(""+sh.relName);
             pop.addSeparator();
             JMenuItem open = new JMenuItem("Open (system)");
             pop.add(open);
             open.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
                try{
                   //FAILS: file:/C:/Program%20Files/Common%20Files/Adobe/Web/adobeonlineprefs)
                   assert sh.f != null;
                   if(sh.f!=null)
                   {
                     Desktop.getDesktop().open(sh.f);
                   }
                }
                catch(Exception e)
                {
                   e.printStackTrace();
                   try
                   {
                      //TODO: also not working
                     SysUtils.openDocumentInSystem((""+sh.f).replace(" ", "%20"), false);
                   }catch(Exception e2) {e2.printStackTrace();}
                }
             } });

             if(sh.f.isFile())
             {
               final JMenuItem openi = new JMenuItem("Open in internal text editor", Icons.FileIcon.textFile(16));
               pop.add(openi);
               openi.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {

                  fileChooser.setVisible(false);
                  SimpleEditor sed = new SimpleEditor(GUIUtils.getWindowForComponent(table), ""+sh.f.getAbsolutePath(), true, false);
                  sed.allowDropFilesFromOS();
                  try
                  {
                     sed.setText(sh.f);
                  }
                  catch(Exception e) {e.printStackTrace(); }
               }});

               JMenuItem openim = new JMenuItem("Open in internal image editor");
               pop.add(openim);
               openim.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
                      try
                      {
                         ImageEditor imed = new ImageEditor(null, sh.f, sh.relName);
                      }
                      catch(Exception e) {e.printStackTrace(); }
               }});

               JMenuItem the = new JMenuItem("Open in tHEX");
               pop.add(the);
               the.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
                      try
                      {
                         new HexViewer(GUIUtils.getWindowForComponent(table)).setFile(sh.f);
                      }
                      catch(Exception e) {e.printStackTrace(); }
               }});

               JMenuItem openp = new JMenuItem("Open parent folder");
               pop.add(openp);
               openp.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {

                  fileChooser.setVisible(false);
                  try{
                     File pf = sh.f.getParentFile();
                     if(pf!=null)
                     {
                       Desktop.getDesktop().open(pf);
                     }
                  }
                  catch(Exception e) {
                     e.printStackTrace();
                  }
               } });

               if(sh.relName.endsWith(".jar") || sh.relName.endsWith(".zip"))
               {
                 JMenuItem je = new JMenuItem("Jar Explorer", Icons.sharedJarFile);
                 pop.add(je);
                 je.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
                     new JarExplorer(sh.f, GUIUtils.getWindowForComponent(table));
                 }});
               }
             }

             pop.show(table, me.getX(), me.getY());
          }
        });


        d.setVisible(true);  // MODAL.

        if(ccp.getWasAccepted() && table.getSelectedRowCount()==1)
        {
           int pos = stm.getIndexInUnsortedFromTablePos(table.getSelectedRow());
           final File sf = hits.get(pos).f;
           assert sf!=null : "nullness";

           System.out.println("Setting selected file from search: "+sf);
           // FAILS Without EDTLATER here !!!!!
           EventQueue.invokeLater(new Runnable() { public void run() {
              setDisplayedFile(sf);
           }});
           //setDisplayedFile(sf);
           //fileChooser.setCurrentDirectory(sf.getParentFile());  // important: otherwise: NPE at first selection (1.6.0_15 bug?) !!!
           //fileChooser.setSelectedFile( sf );
        }
        stm.removeOldListeners();
     }

     hits.clear();
  }

  //todo: ThreadLocalize !!
  private Calendar cal = GregorianCalendar.getInstance();
  private int[] getDayInWeekAndHourInDay(long timeMillis)
  {
     cal.setTimeInMillis(timeMillis);
     return new int[]{cal.get(Calendar.DAY_OF_WEEK), cal.get(Calendar.HOUR_OF_DAY)};
  }

  private void searchWithUI(final boolean recurse, final List<JFile> hits, final File dir,
          final String toSearchUP, final String toSearchInContents, final int baseLength,
          final long after, final long before,
          final /*@org.checkerframework.checker.nullness.qual.Nullable*/ IntRanges dayInWeekFilter,
          final /*@org.checkerframework.checker.nullness.qual.Nullable*/ IntRanges hourInDayFilter,
          final boolean ignoreUnzipped, final int onlyNMostRecent,
          final ProgressModalDialog pmd)
  {

     pmd.setShowPause(true);

     java.io.FileFilter filter = new java.io.FileFilter()
     {
        public final boolean accept( final File f ) {

// low cost checks first !!
           if(f.isDirectory()) return true;  // always pass directories

           if(after>0 && f.lastModified()<after) return false;
           if(f.lastModified() > before) return false;

           String relName = f.getAbsolutePath();
           if(relName.length()<baseLength)
           {
              //warn...
              System.out.println("Cannot relativize name: "+relName);
           }
           else
           {
              relName = relName.substring(baseLength);
           }

           if(toSearchUP.length()>0)
           {
              if(relName.toUpperCase().indexOf(toSearchUP)<0) return false;
           }


           if(ignoreUnzipped)
           {
              long lm = f.lastModified();
              if(lm % 2000 == 0) return false;    // NOT ROBUST !
           }

           if(dayInWeekFilter!=null || hourInDayFilter!=null)
           {
              int[] dh = getDayInWeekAndHourInDay(f.lastModified());
              if(dayInWeekFilter!=null)
              {
                 if(!dayInWeekFilter.isInRange( dh[0] )) return false;
              }
              if(hourInDayFilter!=null)
              {
                 if(!hourInDayFilter.isInRange( dh[1] )) return false;
              }
           }

           // high cost search !
           if(!toSearchInContents.isEmpty())
           {
              String ext = FileUtils.getExtension(relName).toLowerCase();

              //todo: only look in text files ??
              if(ext.equals("mp3") || ext.equals("wav") || ext.equals("zip") || ext.equals("gz") || ext.equals("gzip") || ext.equals("cab")
                 || ext.equals("jpg") || ext.equals("bmp")) return false;


              // only look in "small" files (< 5 mega)
              if(f.length()<5e6)
              {
                pmd.setProgressCommentAndKeepIndeterminate("looking in "+relName);
                if(!containsStringInFile(f, toSearchInContents)) return false;
              }
           }

           return true;
        }
     };

     // only include dir entries if not searching recent.
     //  its just nicer...

     boolean includeDirs = false; //after < 1;
     searchRecurse(filter, recurse, includeDirs, hits, dir, baseLength, onlyNMostRecent, pmd);
  }



  //todo: manage charset ? and case ? and eventually approx match
  private static boolean containsStringInFile(File f, String sUP)
  {
     try{
        String cont = FileUtils.getFileStringContent(f).toUpperCase();
        return cont.contains(sUP.toUpperCase());
     }
     catch(Exception e) {
        System.out.println("Warn: Cant' read content of "+f );
        e.printStackTrace();
     }
     return false;

  }

 @tide.annotations.Recurse
  void searchRecurse(final java.io.FileFilter ff, boolean recurse, boolean includeDirsInHits, final List<JFile> hits, final File dir, int baseLength, final int onlyNMostRecent, final ProgressModalDialog pmd)
  {
     if(pmd.getWasCancelled()) throw new SoftInterruptedException();
     pmd.pauseIfNeeded();

     final File[] childs = ff!=null ? dir.listFiles(ff) : dir.listFiles();

     if(childs==null)
     {
        System.out.println("Null childs for "+dir);
        return;
     }

     for(final File ci : childs)
     {
        String ap = ci.getAbsolutePath();
        final String relName;
        if(ap.length()<baseLength)
        {
           relName = ap;
           System.out.println("Cannot relativize name: "+ap);
        }
        else
        {
           relName = ap.substring(baseLength);
        }

        // add dirs before childs...
        if(includeDirsInHits || !ci.isDirectory())
        {
          hits.add(new JFile(ci, relName));
        }

        if(ci.isDirectory() && recurse)
        {
           searchRecurse(ff, recurse, includeDirsInHits, hits, ci, baseLength, onlyNMostRecent, pmd);
        }
     }

     if(onlyNMostRecent>0 && hits.size()>onlyNMostRecent)
     {
        //sort and keep N
        Collections.sort(hits, lastModifiedComparator);

        // after sort, first is the oldest => keep the last indices

        final List<JFile> lhits = CollectionUtils.takeLast(hits, onlyNMostRecent, true);  // => last will be the most recent showed below
        hits.clear();
        hits.addAll(lhits);

     }

     if(hits.size()>0)
     {
        if(onlyNMostRecent>0)
        {
           //dbg
           //System.out.println("dbg::: "+hits.size()+" files found, last: "+hits.get(0)+"  ["+DateUtils.formatDateDifferenceFromNow(hits.get(0).f.lastModified())+"]");
           pmd.setCommentLabel("last: "+hits.get(0)+"  ["+DateUtils.formatDateDifferenceFromNow(hits.get(0).f.lastModified())+"]");
        }
        else
        {
           pmd.setCommentLabel( ""+hits.size()+" files found, last: "+hits.get(0));
        }
     }
     else
     {
        pmd.setCommentLabel( "no files found, looking in "+dir);
     }

  }

  public final static LastModifiedComparator lastModifiedComparator = new LastModifiedComparator();
  /** After sort, with Collections.sort(list, comp), the first is oldest
  */
  public static final class LastModifiedComparator implements Comparator<JFile>
  {
     public int compare(JFile f1, JFile f2)
     {
        return Long.valueOf(f1.f.lastModified()).compareTo(f2.f.lastModified());
     }
  }


  private void filterAction()
  {
     filtPan.activateAnimation( searchField.getText().trim().length()>0 );

     if(filteredFilter==null)
     {
        if(originalFilter==null)
        {
          originalFilter = fileChooser.getFileFilter();
        }

        filteredFilter = new javax.swing.filechooser.FileFilter()
        {
           public String getDescription()
           {
              if(originalFilter!=null) { return "Filtered "+originalFilter.getDescription(); }
              return "Filtered files";
           }

           public boolean accept(File f)
           {
              return filterAccept(f);
           }
        };

        fileChooser.setFileFilter( filteredFilter );
     }
     fileChooser.rescanCurrentDirectory();
  }

  /** Considering filter(s)
  */
  private boolean filterAccept(File f)
  {
     if(!filterFolders.isSelected() && f.isDirectory()) return true;

     // don't accept files also refused from original
     //  sometime strange...
     //todo: ameliorate: use the selected filter ! (but selected is the filtered) => find out which, if changed.
     // for ex if user select "all files" during filter
     if(originalFilter!=null) { if(!originalFilter.accept(f)) return false; }

     String nameLow = f.getName().toLowerCase();
     String toSearch = searchField.getText().trim().toLowerCase();
     if(toSearch.length()==0) return true;
     if(nameLow.indexOf(toSearch)==-1) return false;
     return true;
  }


  private void showSearchToolPopup()
  {
       JPopupMenu popup = new JPopupMenu();
       JMenuItem searchRec = new JMenuItem("Search file", Icons.sharedSearch);
       popup.add(searchRec);
       searchRec.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
          Thread t = new Thread(){ public void run() {
             simpleSearchRecurseDialog();
          }};
          t.start();
       } });

       JMenuItem asearchRec = new JMenuItem("Advanced Search", Icons.searchIcon(15,15,true,"+"));
       popup.add(asearchRec);
       asearchRec.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
          Thread t = new Thread(){ public void run() {
             advancedSearch();
          }};
          t.start();
       } });

       final JMenuItem openExplorer = new JMenuItem("Explore all files (recurse)");
       popup.addSeparator();
       popup.add(openExplorer);
       openExplorer.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
          Thread t = new Thread(){ public void run() {
             search(true, "", "");
          }};
          t.start();
       } });

       final JMenuItem openExplorer2 = new JMenuItem("Explore recent files (<7 days) (recurse)");
       popup.add(openExplorer2);
       openExplorer2.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
          Thread t = new Thread(){ public void run() {
             search(true, "", "", System.currentTimeMillis()-1000L*3600*24*7, Long.MAX_VALUE, null, null, false, -1);    // 7 days
          }};
          t.start();
       } });


       final JMenuItem snf = new JMenuItem("Explore recent files (<90 days) (recurse)");  // 3 months
       popup.add(snf);
       snf.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
          Thread t = new Thread(){ public void run() {
             search(true, "", "", System.currentTimeMillis()-1000L*3600*24*90, Long.MAX_VALUE, null, null, false, -1);    // 90 days
          }};
          t.start();
       } });



       final JMenuItem snrf = new JMenuItem("Search 10 most recent files (recurse)");
       popup.add(snrf);
       snrf.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
          Thread t = new Thread(){ public void run() {
             search(true, "", "", -1, Long.MAX_VALUE, null, null, false,
               15);
          }};
          t.start();
       } });

       JMenuItem openExplorer3 = new JMenuItem("Explore all files in this folder only");
       popup.addSeparator();
       popup.add(openExplorer3);
       openExplorer3.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
          Thread t = new Thread(){ public void run() {
             search(false, "", "");
          }};
          t.start();
       } });


       JMenuItem openFExplorer = new JMenuItem("Explore all folders");
       popup.addSeparator();
       popup.add(openFExplorer);
       openFExplorer.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
          Thread t = new Thread(){ public void run() {
             new DirectoryStatExplorer( fileChooser.getCurrentDirectory(), fileChooser );
          }};
          t.start();
       } });

       popup.show(searchBt, 0, 15);
  }


  private void showSelectToolPopup()
  {
       JPopupMenu popup = new JPopupMenu();

       JMenuItem sel1 = new JMenuItem("Select most recent file", Icons.sharedTimerGray);
       sel1.setToolTipText("considering the original filter and custom filter");

       popup.add(sel1);
       sel1.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
          //
          File dir = fileChooser.getCurrentDirectory();
          if(dir!=null)
          {
             File last = null;
             File[] fs = dir.listFiles();
             if(fs!=null)
             {
                for(File fi : fs)
                {
                   if(fi.isDirectory()) continue;
                   if(!filterAccept(fi)) continue;

                   if(last==null) last=fi;
                   else
                   {
                     long lm = fi.lastModified();
                     if(lm>last.lastModified()) last=fi;
                   }
                }

                if(last!=null)
                {
                   fileChooser.setSelectedFile(last);
                }
             }
          }
       } });

       popup.show(selectBt, 0, 15);
  }


  private void showColorizationPopup()
  {
       JPopupMenu popup = new JPopupMenu();

       final JCheckBoxMenuItem colNone = new JCheckBoxMenuItem("None", choosedColorization==Colorization.None);
       final JCheckBoxMenuItem colRW   = new JCheckBoxMenuItem("Read Write", choosedColorization==Colorization.ReadWrite);
       final JCheckBoxMenuItem colAge  = new JCheckBoxMenuItem("Age",  choosedColorization==Colorization.Age);
       final JCheckBoxMenuItem colSize = new JCheckBoxMenuItem("Size",  choosedColorization==Colorization.Size);

       popup.add(colNone);
       popup.add(colRW);
       popup.add(colAge);
       popup.add(colSize);

       ActionListener al = new ActionListener() { public void actionPerformed(final ActionEvent ae) {
          if(ae.getSource()==colNone) choosedColorization = Colorization.None;
          else if(ae.getSource()==colRW) choosedColorization = Colorization.ReadWrite;
          else if(ae.getSource()==colAge) choosedColorization = Colorization.Age;
          else if(ae.getSource()==colSize) choosedColorization = Colorization.Size;

          Preferences.userNodeForPackage(FileChooserFilter.class).put("Colorization", ""+choosedColorization);

          setColorization();
       } };

       colNone.addActionListener(al);
       colRW.addActionListener(al);
       colAge.addActionListener(al);
       colSize.addActionListener(al);

       popup.show(colorizeBt, 0, 15);
  }

  void setColorization()
  {
     if(fileChooser==null) return;

     final Icon readOnlyFile = Icons.readOnlyFile(16);
     final Icons.FileIcon colFile = Icons.readOnlyFile(16);

     fileChooser.setFileView(new FileView()
     {

        //don't work.
        @Override public final /*@org.checkerframework.checker.nullness.qual.Nullable*/ String getTypeDescription( final File f ) {
           String ext = FileUtils.getExtension(f.getName());
           if(ext.equals("txt")) return "Text file";
           return null;
        }

        // null => use default UI
        @Override public final /*@org.checkerframework.checker.nullness.qual.Nullable*/ Icon getIcon( final File f ) {
           if(choosedColorization == Colorization.None) return null;
           if(choosedColorization == Colorization.ReadWrite)
           {


              //if(f.isDirectory()) return null;  [dec2011]: see them
              if(!f.canWrite())
              {
                 colFile.directory = f.isDirectory();
                 colFile.color = UIConstants.red;
                 return colFile; //readOnlyFile;
              }
              return null;
           }
           if(choosedColorization == Colorization.Age)
           {
              double ageInDays = (System.currentTimeMillis()-f.lastModified())/(1000*3600*24);
              colFile.directory = f.isDirectory();

              if(ageInDays<7)   // [dec2011]: 3 to 7
              {
                 colFile.color = Color.green;
              }
              else if(ageInDays<50) // dec2011: 40 to 50
              {
                 colFile.color = new Color((float) ageInDays/50, (float)((50-ageInDays)/50), 0f);
              }
              else
              {
                 colFile.color = Color.red;
              }

              return colFile;
           }
           if(choosedColorization == Colorization.Size)
           {
              double sizeMB = f.length()*1e-6;
              colFile.directory = f.isDirectory();

              /*too slow ! => todo: let choose user !
              if( colFile.directory )
              {
                 // [dec2011]: attempt (first level only)
                 File[] flef = f.listFiles();
                 if(flef!=null)
                 {
                   for(File fii : flef)
                   {
                     sizeMB+=fii.length();
                   }
                 }
              }*/

              if(sizeMB<0.1)
              {
                 colFile.color = Color.white;
              }
              else if(sizeMB>5) // dec2011: 10 to 5
              {
                 colFile.color = Color.red;
              }
              else
              {
                 colFile.color = new Color((float) sizeMB/5, (float)((5-sizeMB)/5), 0f);
              }

              return colFile;
           }

           return null;
        }
     });

     fileChooser.repaint();
  }


  private void showOptionsPopup()
  {
       JPopupMenu popup = new JPopupMenu();

       //FileIcon dir = new FileIcon(true, 15);
       //dir.setType(FileIcon.IconColor.System);
       JMenuItem openSysExplorer = new JMenuItem("Open system file explorer", Icons.sharedSystemFolder);
       popup.add(openSysExplorer);
       openSysExplorer.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
          SysUtils.openFileExplorer( fileChooser.getCurrentDirectory() ) ;
       } });

       JMenuItem openInShell = new JMenuItem("Open system shell", Icons.sharedShellIcon);
       popup.add(openInShell);
       openInShell.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
          final File d = fileChooser.getCurrentDirectory();
          try
          {
            SysUtils.openShellAt( d ) ;
          }catch(Exception e) {
            JOptionPane.showMessageDialog(null, "Can't open shell at\n   "+d+"\n\nError: "+e.getMessage(),
               "Error", JOptionPane.ERROR_MESSAGE);
          }
       } });


       final File fss = fileChooser.getSelectedFile();
       if(fss!=null)
       {

         if(fss.isFile())
         {
           final JMenuItem addFav = new JMenuItem("Open in internal text editor", Icons.FileIcon.textFile(16));
           popup.addSeparator();
           popup.add(addFav);
           addFav.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
                SimpleEditor sed = new SimpleEditor(GUIUtils.getWindowForComponent(optionsButton), ""+fss.getAbsolutePath(), true, false, true, true);
                sed.allowDropFilesFromOS();
                try
                {
                   sed.setText(fss);
                }
                catch(Exception e) {e.printStackTrace(); }
                sed.setVisible(true);
           }});

               JMenuItem the = new JMenuItem("Open in tHEX");
               popup.add(the);
               the.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
                      try
                      {
                         new HexViewer(GUIUtils.getWindowForComponent(optionsButton)).setFile(fss);
                      }
                      catch(Exception e) {e.printStackTrace(); }
               }});

           final JMenuItem openim = new JMenuItem("Open in internal image editor");
           popup.add(openim);
           openim.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
                try
                {
                  try
                  {
                     //todo: pass parent component with GUIUtils.getWindowForComponent
                     new ImageEditor(null, fss, fss.getName());
                  }
                  catch(Exception e) {e.printStackTrace(); }
                }
                catch(Exception e) {e.printStackTrace(); }
           }});

           if(fss.getName().endsWith(".jsnap"))
           {
              popup.addSeparator();
              JMenuItem snac = new JMenuItem("Compare with disk", Icons.sharedEye);
              popup.add(snac);
              snac.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
                   fileChooser.cancelSelection();
                   WatchUtils.compareStandaloneSnap(fss);
              }});
           }

           if(fss.getName().toLowerCase().endsWith(".jar"))
           {
              popup.addSeparator();
              JMenuItem snac = new JMenuItem("Explore Jar", Icons.sharedWiz);
              popup.add(snac);
              snac.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
                   //fileChooser.cancelSelection();
                   new JarExplorer(fss, GUIUtils.getWindowForComponent(optionsButton));
              }});
           }

           JMenuItem cd = new JMenuItem("Change date", Icons.sharedTimer);
           popup.addSeparator();
           popup.add(cd);
           cd.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
                Date orig = new Date(fss.lastModified());
                SpinnerDateModel sdm = new SpinnerDateModel(orig, null, null, Calendar.HOUR);

                JSpinner spd = new JSpinner(sdm);
                spd.setEditor(new JSpinner.DateEditor(spd, "dd.MMM.yyyy HH:mm"));

                int rep = JOptionPane.showConfirmDialog(null, spd, "Change date of "+fss,
                   JOptionPane.YES_NO_CANCEL_OPTION,
                   JOptionPane.QUESTION_MESSAGE);
                 // new String[]{"Change", "Don't change", "Cancel"}, "Cancel");
                if(rep!=JOptionPane.OK_OPTION) return;
                System.out.println(""+rep);
                fss.setLastModified(sdm.getDate().getTime());

           }});
         }
         else if(fss.isDirectory())
         {
              popup.addSeparator();
              JMenuItem snac = new JMenuItem("Create snapshot...", Icons.sharedEye);
              popup.add(snac);
              snac.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
                  fileChooser.cancelSelection();

                  JComboBox recursionCB = new JComboBox(WatchedData.recursionDepthTypes);

                  JDialog f = new JDialog(new JFrame("Snap"), "Snapshoot of "+fss, true);
                  File dest = new File(fss.getParentFile(), fss.getName()+".jsnap");

                  f.add(GUIUtils.createReadOnlyDescriptionArea("Create a snapshot of the actual state of"
                   +"\n\n   "+fss+"\n\n(Using file dates and lengths, no hashcode)."),
                     BorderLayout.NORTH);

                  GridLayout3 gl3 = new GridLayout3(2);
                  f.add(gl3.getTargetPanel(), BorderLayout.CENTER);

                  gl3.add("depth");
                  gl3.add(recursionCB);

                  recursionCB.setMaximumRowCount(20);

                  final CloseControlPanel ccp = new CloseControlPanel(f, true, true, "Ok");
                  f.add(ccp, BorderLayout.SOUTH);

                  f.pack();
                  f.setLocationRelativeTo(null);
                  f.setLocation(f.getX(), f.getY()-200);
                  f.setVisible(true); // MODAL

                  if(ccp.getWasCancelled()) return;
                  if(!ccp.getWasAccepted()) return;

                  final File fdest;
                  if(FileUtils.createIfPossible(dest))
                  {
                     fdest = dest;
                  }
                  else
                  {
                     JFileChooser ch = new JFileChooser(fss.getParentFile());
                     ch.setDialogTitle("Choose the folder where to store the snapshot");
                     ch.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                     if(ch.showOpenDialog(null)!=JFileChooser.APPROVE_OPTION) return;

                     fdest = new File(ch.getSelectedFile(), dest.getName());
                  }

                  if(fdest==null) return;


                  final WatchedData wd = new WatchedData();

                  wd.name = fss.getName();
                  wd.objectKind = 0; //file
                  //wd.fileKind = 0;  // files and folders recurse
                  //cd.freq
                  //wd.target = fss;
                  wd.setTarget(""+fss);
                  wd.recursionDepth = recursionCB.getSelectedIndex();

                  final ProgressModalDialog pmd = ProgressModalDialog.createStandaloneProgress("Snapshot creation");
                  Thread t = new Thread()
                  {
                     public void run()
                     {
                        String s = "error";
                        try
                        {
                          s = wd.shouldAlertNow(pmd);
                          StorageVector sv = wd.getRep();
                          //File dest = new File(fss.getParentFile(), fss.getName()+".jsnap");
                          FileUtils.saveZippedVectorToFile(fdest, sv);
                          s+= "\n\nStored in "+fdest;
                        }
                        catch(Exception e)
                        {
                          s = e.getMessage();
                        }
                        finally
                        {
                          pmd.closeDialog();
                        }
                        JOptionPane.showMessageDialog(null, ""+s, "Snapshot", JOptionPane.INFORMATION_MESSAGE);
                     }
                  };
                  t.start();
              }});


              JMenuItem ada = new JMenuItem("Advanced date analysis...", Icons.sharedStat);
              popup.add(ada);
              ada.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
                 File root = fileChooser.getSelectedFile();
                  fileChooser.cancelSelection();

                  List<Long> dates = new ArrayList<Long>();
                  List<File> files = new ArrayList<File>();
                  System.out.println("collecting "+root);
                  FileUtils.getAllFilesRecurse(root, files, false, true);
                  System.out.println("analysing "+files.size()+" files...");
                  for(final File fi : files)
                  {
                     dates.add(fi.lastModified());
                  }

                  DateAndTimeLab.showAdvancedDateAnalysis(dates, ""+root);
              }});
         }
       }

       popup.show(optionsButton, 0, 15);
  }


  private void showFavoritesPopup()
  {
       JPopupMenu popup = new JPopupMenu();

       // favorites
       final List<File> favs = getFavorites();
       //JMenu favMenu = new JMenu("Favorites");
       //popup.add(favMenu);

       final File curD = fileChooser.getCurrentDirectory();
       if(curD!=null && !favs.contains(curD))
       {
         JMenuItem addFav = new JMenuItem("Add to favorites: "+fileChooser.getCurrentDirectory(), Icons.sharedAddToFavorites);
         popup.add(addFav);
         addFav.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
                favs.add( curD );
                saveFavorites(favs);
         }});
       }

       final File fss = fileChooser.getSelectedFile();
       if(fss!=null && !fss.equals(fileChooser.getCurrentDirectory()) && fss.getName().length()>0 && !favs.contains(fss))
       {
         JMenuItem addFav = new JMenuItem("Add to favorites: "+fileChooser.getSelectedFile(), Icons.sharedAddToFavorites);
         popup.add(addFav);
         addFav.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
              favs.add( fss );
              saveFavorites(favs);
         }});
       }


       JMenuItem manFav = new JMenuItem("Manage favorites");
       popup.add(manFav);
       popup.addSeparator();
       manFav.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
          manageFavorites();
       }});

       for(final File favi : favs)
       {
         JMenuItem fmi = new JMenuItem(""+favi.getAbsolutePath());
         popup.add(fmi);
         fmi.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) {
            //System.out.println("Set "+favi);
            setDisplayedFile(favi);

         }});
       }

       popup.show(favBt, 0, 15);
  }

  void manageFavorites()
  {
     final List<File> favs = getFavorites();
     final List<JFile> relFiles = new ArrayList<JFile>();
     for(File fi : favs)
     {
        relFiles.add(new JFile(fi, ""+fi));
     }

     final JFilesView fv = new JFilesView(relFiles, 3, false);
     final JDialog d = new JDialog(GUIUtils.getWindowForComponent(favBt), "Manage Favorites", Dialog.ModalityType.DOCUMENT_MODAL);

     JPanel cp = new JPanel();
     d.add(cp, BorderLayout.SOUTH);
     JButton rem = new JButton("Remove Selected", Icons.sharedCross);
     cp.add(rem);
     rem.addActionListener(new ActionListener() { public void actionPerformed(final ActionEvent ae) {
         List<JFile> sels = fv.getSelectedFiles();
         for(JFile fi : sels)
         {
            if(fi.f!=null)
            {
              favs.remove(fi.f);
            }
         }
         saveFavorites(favs);

         // either update UI or close...
         d.setVisible(false);
         d.dispose();
     } });


     d.add(fv, BorderLayout.CENTER);
     d.pack();
     d.setLocationRelativeTo(null);
     d.setVisible(true);  //MODAL
  }



  /** To be used in the filechooser.
  *  Accepts ALL directories and only files with given extension.
  */
  static javax.swing.filechooser.FileFilter createFilterForTypes(final String description, final String... extensions )
  {
     return new javax.swing.filechooser.FileFilter()
     {
        @Override public boolean accept(File f)
        {
           if(f.isDirectory() ) return true;  // Even if files_only !! because it only limits the end choosed file !
           //if(fileChooserSelectionMode == JFileChooser.DIRECTORIES_ONLY) return false;

           for(String ei : extensions)
           {
             if(f.getName().toLowerCase().endsWith(ei.toLowerCase())) return true;
           }
           return false;
        }

        public String getDescription()
        {
           return description;
        }
     };
  }

   public static void main(String[] args) throws Exception {
      GUIUtils.setNimbusLookAndFeel_IfPossible();

      //simple: new JFileChooser2().chooseToSave();
      EventQueue.invokeLater(new Runnable() { public void run() {
         File sel = new JFileChooser2().title("Choose a file to open").chooseToOpen();
      }});
   }


}