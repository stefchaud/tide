package snow.files;

import snow.utils.gui.GUIUtils;
import java.awt.EventQueue;
import java.util.prefs.Preferences;
import java.awt.Component;
import java.io.*;
import javax.swing.*;

/** Builder to create file choosers to choose file(s).
*
*  Example usage:
*    File sel = new JFileChooser2().title("Choose a file to save to").directoriesOnly().chooseToSave();
*
*  Remarks:
*   1) remember to perform all UI calls in EDT !
*/
public final class JFileChooser2
{

   //Known missing features:
   // remember sorting (how to set it, seems NOT accessible with properties), write custom UI ?

   private final /*@org.checkerframework.checker.nullness.qual.Nullable*/ Component parent;
   // underlying chooser
   private final JFileChooser chooser = new JFileChooser();
   // accessory panel and view goodies. (colour filter)
   private final FileChooserFilter cFilter;
   private  String keyForRememberInPreferences = null;

   public JFileChooser2()
   {
      this(null);
   }

   public JFileChooser2(/*@org.checkerframework.checker.nullness.qual.Nullable*/ Component parent)
   {
      this.parent = parent;
      cFilter = FileChooserFilter.create(chooser);

      // [feb2011]: cool
      chooser.setDragEnabled(true);
   }

   // builder for passing options


   public JFileChooser2 title(String title)
   {
      chooser.setDialogTitle(title);
      return this;
   }


   /** If f is a file, the parent folder is used.
   */
   public JFileChooser2 defaultDir(/*@org.checkerframework.checker.nullness.qual.Nullable*/ File f)
   {
      if(keyForRememberInPreferences!=null)
      {
         System.out.println("Caution: you called defaultDir after remember!");
         new Throwable().printStackTrace(System.out);
      }
      if(f==null) return this;

      if(f.isFile())
      {
         f = f.getParentFile();
      }

      chooser.setCurrentDirectory(f);
      return this;
   }

   /**
   */
   public JFileChooser2 defaultFile(/*@org.checkerframework.checker.nullness.qual.Nullable*/ File f)
   {
      if(keyForRememberInPreferences!=null)
      {
         // Warn misuse
         System.out.println("Caution: you called defaultFile after remember!");
         new Throwable().printStackTrace(System.out);
      }
      if(f==null) return this;

      chooser.setSelectedFile(f);  // also sets parent dir
      return this;
   }


   public JFileChooser2 remember(String key)
   {
      return remember(key, null);
   }


   /** Sets the selected file from preferences using the given key. Use default if provided and not present in the preferences.
   *   The given key is also stored and allow to remember the selected file, later.
   *   Storage place:  preferences.
   *   Note: if def is a folder, sets its parent as current dir.
   */
   public JFileChooser2 remember(String key, /*@org.checkerframework.checker.nullness.qual.Nullable*/ File def)
   {
      keyForRememberInPreferences = key;
      // look if value exists

      File remf = getRememberedFile(key);
      if(remf!=null)
      {
         System.out.println("Remembered "+remf);
         chooser.setSelectedFile(remf);  // dont work if not in EDT
       }
      else if(def!=null)
      {
         System.out.println("using default: "+def);
         chooser.setSelectedFile(def);
      }

      return this;
   }


   /** Choosed previously file or null if none.
   */
   public static /*@org.checkerframework.checker.nullness.qual.Nullable*/ File getRememberedFile( String keyForRememberInPreferences )
   {
     String defs = Preferences.userNodeForPackage(JFileChooser2.class).get(getRobustPrefKey(keyForRememberInPreferences), null);
     if(defs==null)
     {
       return null;
     }

     return new File(defs);
   }

   public static void doRemember(final String key, final File f)
   {
      Preferences.userNodeForPackage(JFileChooser2.class).put(getRobustPrefKey(key), f.getAbsolutePath());
   }

   /** Ensuring that Preferences.MAX_KEY_LENGTH is not reached
   */
   private static String getRobustPrefKey(String keyForRememberInPreferences)
   {
     if(keyForRememberInPreferences.length()>=Preferences.MAX_KEY_LENGTH)
     {
        // to avoid ugly runtime errors
        return "hkey_"+keyForRememberInPreferences.hashCode();
     }
     else
     {
        return keyForRememberInPreferences;
     }
   }

   /** Sets chooser fileSelectionMode to JFileChooser.FILES_ONLY.
   *   this is the default for open and save dialogs.
   *   Folders are seen but can't be choosed.
  */
   public JFileChooser2 filesOnly()
   {
      chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
      return this;
   }

   /** Sets chooser fileSelectionMode to JFileChooser.DIRECTORIES_ONLY.
   *   Only directories are displayed and selectable !
   */
   public JFileChooser2 directoriesOnly()
   {
      chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
      return this;
   }

   /** Sets chooser fileSelectionMode to JFileChooser.FILES_AND_DIRECTORIES.
   *   Either files or directories are displayed and selectable !
   */
   public JFileChooser2 filesAndDirectories()
   {
      chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
      return this;
   }


   public JFileChooser2 addChoosableType(String description, String... extensions)
   {
      //chooser.setAcceptAllFileFilterUsed();

      chooser.addChoosableFileFilter( FileChooserFilter.createFilterForTypes(description, extensions));
      return this;
   }

   public JFileChooser2 setOnlyChoosableType(String description, String... extensions)
   {
      chooser.setAcceptAllFileFilterUsed(false);
      chooser.addChoosableFileFilter( FileChooserFilter.createFilterForTypes(description, extensions));
      return this;
   }


// Open and save dialogs
//

   /** Blocking dialog to choose a file to save to.
   *   null if cancelled.
   *   per default: only files are selectable. no directories.
   */
   public /*@org.checkerframework.checker.nullness.qual.Nullable*/ File chooseToSave()
   {
      int rep = chooser.showSaveDialog(parent); //blocks
      if(rep!=JFileChooser.APPROVE_OPTION) return null;
      return storeInPreferencesIfRequired(chooser.getSelectedFile());
   }

   /** Blocking dialog to choose a file to save to.
   *   null if cancelled.
   */
   public /*@org.checkerframework.checker.nullness.qual.Nullable*/ File chooseToOpen()
   {
      int rep = chooser.showOpenDialog(parent); //blocks
      if(rep!=JFileChooser.APPROVE_OPTION) return null;
      return storeInPreferencesIfRequired(chooser.getSelectedFile());
   }



   // Internals
   //


   private File storeInPreferencesIfRequired(File f)
   {
      if(keyForRememberInPreferences==null) return f;

      // store
      try{
         Preferences.userNodeForPackage(JFileChooser2.class).put(getRobustPrefKey(keyForRememberInPreferences), f.getAbsolutePath());
      }
      catch(final Exception e) {
         e.printStackTrace();
      }

      return f;
   }


//test
   public static void main(String[] args) throws Exception {
      GUIUtils.setNimbusLookAndFeel_IfPossible();
      //simple: new JFileChooser2().chooseToSave();
      EventQueue.invokeLater(new Runnable() { public void run() {
          simpleTest();
      }});
   }

   private static void simpleTest()
   {
      File sel = new JFileChooser2().title("Choose a file to open")
        //.directoriesOnly()
        .addChoosableType("circuit files", ".asc", ".zip")
        .defaultDir(new File("c:/temp/tup/jdk_null.astub"))
        .remember("test", new File("c:/temp/load.asc"))  //.filesAndDirectories()
        .chooseToOpen();

      System.out.println("choosen: "+sel);
   }

}