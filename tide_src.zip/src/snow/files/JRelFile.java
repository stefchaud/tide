package snow.files;

import java.io.File;
import java.util.*;

/** Stored file or folder, using relative path.
*/

public final class JRelFile
{
   //todo: import *usages* from TRestorizer !!

      private String relName;
      private long lastMod;

      //[June2010]
      private long length = -1;

      // transient, not stored
      public boolean visited = false;

      private File f;

      @Override
      public int hashCode() { return relName.hashCode(); }

      public final String getRelName() { return relName; }
      public final long getLastMod() { return lastMod; }
      // only if set
      public final File getFile_Cache() { return f; }

      /** file length in bytes since [June2010].
      *  -1 for old RelFiles, 0 for folders.
      */
      public final long getLength() { return length; }

      /** Compares relative names
      */
      @Override
      public boolean equals(/*@org.checkerframework.checker.nullness.qual.Nullable*/ Object o)   // [Aug2010]: now nullable !!
      {
         if(o==null) return false;  //was missing: discovered by the checker that enforced the above ann !
         JRelFile other = (JRelFile) o;
         return relName.equals(other.relName);
      }

      /** to use for a file */
      public JRelFile(File f, int baseL)
      {
         this.f = f;
         this.relName = f.getAbsolutePath().substring(baseL);
         this.lastMod = f.lastModified();
         if(f.isDirectory())
         {
           this.length = 0;
         }
         else
         {
           this.length = f.length();
         }
      }

      public JRelFile(String name, long lastMod)
      {
         this.relName = name;
         this.lastMod = lastMod;
      }


      // for a stored rep
      public JRelFile(List<Object> rep)
      {
         this.relName = (String) rep.get(1);
         this.lastMod =   (Long) rep.get(2);
         if(rep.size()>3)
         {
            this.length =   (Long) rep.get(3);
         }
      }

      public List<Object> getRep()
      {
         List<Object> rep = new ArrayList<Object>();
         rep.add(2);
         rep.add(relName);
         rep.add(lastMod);
         rep.add(length);

         return rep;
      }

      @Override public final String toString() {
         return relName;
      }
   }