/**
 * javax.annotation: contains the JSR305 as found in findbugs1.3.9rc lib folder.
 *
 * tIDE support:
 *  1) OverridingMethodsMustInvokeSuper
 *
 * Checkers framework
 *  1) Nullable
 *  2) Nonnull
 *
 *
 * No known support
 *
 * TO TEST:
 *
 *  MatchesPattern ??
 */
package javax;
