/** Several utilities
 *
 */
package optionalutils;
