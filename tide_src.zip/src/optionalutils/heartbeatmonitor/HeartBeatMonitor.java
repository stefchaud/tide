package optionalutils.heartbeatmonitor;

/** class HeartBeatMonitor.
*/
public final class HeartBeatMonitor
{
   /** Constructor. */
   public HeartBeatMonitor()
   {
   }

   public static void main(String[] args) throws Exception
   {
      new HeartBeatMonitor();
   }

}