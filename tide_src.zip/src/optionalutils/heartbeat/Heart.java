package optionalutils.heartbeat;

import java.util.TimerTask;
import java.util.Timer;


/** The heart of an application.
*/
public final class Heart
{
   //todo, not perfect... for example if we change the system clock, the timer will "hang" for a while
   final private Timer timer = new Timer(false);  // daemon (do not keep app alive if only survivor)


   /** Creates a heart that beats each periodMillis
   */
   public Heart(long periodMillis)
   {
     timer.schedule(new TimerTask(){
        @Override public final void run(  ) {
           beat();
        }
     }, 0L, periodMillis);
   }


   // called by the timer
   private void beat()
   {
      System.out.println("ding");
   }

   public static void main(String[] args) throws Exception
   {
      new Heart(1000L);



   }

}