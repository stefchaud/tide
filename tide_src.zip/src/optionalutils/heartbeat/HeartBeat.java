package optionalutils.heartbeat;

/** a single heart beat, to be written "recorded" in a heartbeat file
*/
public final class HeartBeat
{
   final long timeMs;
   public HeartBeat(Heart source)
   {
      timeMs = System.currentTimeMillis();
   }


   void writeToFile()
   {

   }



}