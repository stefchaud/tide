/** [may2014] Partial import from commons compress 1.8  (zip and tar tools)
 *
 */
package org.apache.commons;
