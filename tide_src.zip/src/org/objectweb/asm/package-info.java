/**
 *  todo: update when java8 compatible.
 */
package org.objectweb.asm;
