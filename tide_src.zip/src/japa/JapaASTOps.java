package japa;

import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.*;
/** class JapaASTOps.
*/
public final class JapaASTOps
{
   /** Constructor. */
   public JapaASTOps()
   {
   }

   public static boolean containsLine(Node n, int line)
   {
      if(n.getBeginLine()-1>line) return false;
      if(n.getEndLine()-1<line) return false;
      return true;
   }

   public static boolean contains(Node n, int[] lineCol)
   {
      return contains(n, lineCol[0], lineCol[1]);
   }

   public static boolean contains(Node n, int line, int column)
   {
      if(n.getBeginLine()-1>line) return false;
      if(n.getEndLine()-1<line) return false;

      // only check if we are on that line AND there is only one line
      boolean isOnBeginLine = n.getBeginLine()-1 == line;
      boolean isOnEndLine = n.getEndLine()-1 == line;

      if(isOnBeginLine && n.getBeginColumn()-1 > column) return false;
      if(isOnEndLine && n.getEndColumn() < column) return false;  // removed -1 to recognize also when the caret is at the end

      return true;
   }

   /** Field access, type, ...
   *   use getParentNode() to climb the AST up to the parent type !
   */
   public static Node getDeepestNameExprAt(CompilationUnit cu, final int[] lineCol)
   {

      final Node[] deepestNode = new Node[1];

      System.out.println("inspect CU");

      cu.accept(new VoidVisitorAdapter<String>(){

         //Overrides method of VoidVisitorAdapter
         @Override public final void visit( final MethodDeclaration n, final String arg ) {
            if( JapaASTOps.contains(n, lineCol))
            {
               System.out.println("found containing method: "+n.getName());
               deepestNode[0] = n;
            }
            else
            {
               //System.out.println("NOT containing method: "+n.getName());
            }
            super.visit(n, arg);
         }

         @Override public final void visit( final ConstructorDeclaration n, final String arg ) {
            if( JapaASTOps.contains(n, lineCol))
            {
               System.out.println("found containing constructor: "+n.getName());
               deepestNode[0] = n;
            }
            else
            {
               //System.out.println("NOT containing method: "+n.getName());
            }
            super.visit(n, arg);
         }


         @Override public final void visit( final ClassOrInterfaceDeclaration n, final String arg ) {
            if( JapaASTOps.contains(n, lineCol))
            {
               System.out.println("found containing class: "+n.getName());
               deepestNode[0] = n;
            }
            else
            {
               //System.out.println("NOT containing method: "+n.getName());
            }
            super.visit(n, arg);
         }


         /** As "System" in System.out
         */
         @Override public final void visit( final NameExpr n, final String arg ) {
            if( JapaASTOps.contains(n, lineCol))
            {
               System.out.println("NameExpr expr: "+n);
               deepestNode[0] = n;
            }
            else
            {
               //System.out.println("NOT NameExpr expr: "+n);
            }
            super.visit(n, arg);
         }


         /**
         */
         @Override public final void visit( final QualifiedNameExpr n, final String arg ) {
            if( JapaASTOps.contains(n, lineCol))
            {
               System.out.println("QualifiedNameExpr expr: "+n);
               deepestNode[0] = n;
            }
            else
            {
              // System.out.println("NOT QualifiedNameExpr expr: "+n);
            }
            super.visit(n, arg);
         }

         /**
         */
         @Override public final void visit( final MethodCallExpr n, final String arg ) {
            if( JapaASTOps.contains(n, lineCol))
            {
               //System.out.println("MethodCallExpr expr: "+n);
               deepestNode[0] = n;
            }
            else
            {
               //System.out.println("NOT MethodCallExpr expr: "+n);
            }
            super.visit(n, arg);
         }

         /**
         */
         @Override public final void visit( final FieldAccessExpr n, final String arg ) {
            if( JapaASTOps.contains(n, lineCol))
            {
               System.out.println("FieldAccessExpr expr: "+n);
               deepestNode[0] = n;
            }
            else
            {
              // System.out.println("NOT FieldAccessExpr expr: "+n);
            }
            super.visit(n, arg);
         }
      }, "arg");

      return deepestNode[0];
   }

}