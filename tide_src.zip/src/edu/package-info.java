/** These are the annotations defined by findbugs 1.2.1
*  Do not modify the names. They are recognized by findbugs.
*
* [sep2011]: we only use When in our checker OverrideMustInvokeChecker .
*/
package edu;
